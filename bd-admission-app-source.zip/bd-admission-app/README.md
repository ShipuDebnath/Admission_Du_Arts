# বাংলাদেশ বিশ্ববিদ্যালয় ভর্তি প্রস্তুতি — Super App (v3.2.0)

একটিমাত্র স্বয়ংসম্পূর্ণ HTML ফাইলের অফলাইন অ্যাপ — ঢাবি B/D, জাবি B/C/E, রাবি A, চবি B/D, গুচ্ছ B ও শাবিপ্রবি B ইউনিটের প্রস্তুতি।
ব্রাউজারে `file://` থেকে বা WebIntoApp (HTML → APK) দিয়ে Android অ্যাপ হিসেবে চলে; ইন্টারনেট লাগে না।

- ১৩টি বিষয়, ৩৭৬টি পাঠ, ≈৬,০০০ MCQ (প্রতিটি অপশনের ব্যাখ্যাসহ), ≈৪,২০০ Flashcard
- ৫১টি চার্ট ও ডায়াগ্রাম + প্রতিটি অধ্যায়ের স্বয়ংক্রিয় কনসেপ্ট ম্যাপ
- টাইমড টেস্ট, Mega Mock, Subject Final, Quiz, Flashcard (SRS), ভুলের খাতা, PYQ ও সাম্প্রতিক হাব, DU লিখিত ল্যাব
- সাজানো যায় এমন হোম, ৩০ দিনের পড়ার রং-ক্যালেন্ডার, ১০টি থিম, XP-লেভেল-ব্যাজ, ৬টি গেম
- IndexedDB + localStorage সংরক্ষণ, ফাইল ও কোড ব্যাকআপ

## চূড়ান্ত ফাইল

`dist/index.html` — CSS, JS, সব ডেটা ও বাংলা ফন্ট ইনলাইন। সরাসরি খুলুন বা APK কনভার্টারে দিন।
WebIntoApp Free প্ল্যান ২ MB পর্যন্ত ZIP নেয়; এই ফাইলের ZIP ≈ ১.৭২ MB।

## ফোল্ডার

```
src/index.html              শেল (বিল্ড এখান থেকে)
src/css/                    app.css (লেআউট, চার্ট), themes.css (থিম)
src/js/                     storage, data, qbank, lesson, app, progress, fx, themefx, practice,
                            ca, written, ready, mega, gami, about, charts
src/data/toc.json           পাঠ্যসূচি (tools/gen_toc.py থেকে তৈরি)
src/data/exam-config.json   পরীক্ষার কাঠামো — বছর বদলালে শুধু এটি এডিট করুন
src/data/lessons/           পাঠ (বিষয়ভিত্তিক)
src/data/questions/         MCQ
src/data/flashcards/        Flashcard
src/data/charts/            চার্ট ও ডায়াগ্রাম
src/data/ca/, written/      সাম্প্রতিক হাব, DU লিখিত ল্যাব
tools/content/*.py          কনটেন্ট জেনারেটর (চালালে src/data-তে JSON লেখে)
tools/gen_toc.py            পাঠ্যসূচি
tools/build.py              Single-file বিল্ড → dist/index.html (এবং src/data/js/ — ডেভ মোডের জন্য, gitignore-এ)
tools/qc.py                 QC চেকলিস্ট
tools/release.py            QC → বিল্ড → সব ব্রাউজার টেস্ট → ES5 স্ক্যান → রিপোর্ট
tools/smoke_test*.py        Playwright ব্রাউজার টেস্ট
tools/fonts/                বাংলা ফন্ট (SIL OFL 1.1 — লাইসেন্স ফাইল সঙ্গে)
docs/                       মাস্টার প্রম্পট (ভর্তি অ্যাপ v4.0, HSC অ্যাপের ফিচার-প্রম্পট)
```

## কমান্ড

```bash
python3 tools/build.py          # dist/index.html তৈরি
python3 tools/qc.py             # QC
python3 tools/release.py        # পূর্ণ রিলিজ: QC + বিল্ড + সব টেস্ট
python3 tools/content/uni.py    # উদাহরণ: একটি বিষয়ের কনটেন্ট পুনর্জন্ম
```

টেস্টের জন্য Python 3 ও Playwright (Chromium) লাগে; `CHROME` এনভায়রনমেন্ট ভেরিয়েবলে Chromium-এর পথ দেওয়া যায়।
কোড শুধু ES5 — পুরোনো Android WebView-এ চলার জন্য।

## লাইসেন্স ও সূত্র

ফন্ট: SIL Open Font License 1.1 (`tools/fonts/OFL*.txt`)। কনটেন্টের সূত্র প্রতিটি পাঠ ও চার্টের নিচে দেওয়া আছে।
