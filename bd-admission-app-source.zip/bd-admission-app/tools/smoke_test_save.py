#!/usr/bin/env python3
"""smoke_test_save.py — পাঠ/MCQ/Flashcard/লিখিত টপিক সংরক্ষণ ও সংরক্ষিত পাতা"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'src' if 'src' in sys.argv[1:] else 'dist', 'index.html')
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    boot(page, '#/home')
    check('হোমে সংরক্ষিত কার্ড আছে', page.locator('#home-saved').count() == 1)
    # পাঠ
    boot(page, '#/l/bn1-1-1')
    btn = page.locator('main .save-btn[data-save="l|bn1-1-1"]')
    check('পাঠে দৃশ্যমান ☆ সংরক্ষণ বাটন', btn.count() == 1 and btn.is_visible())
    btn.click(); page.wait_for_timeout(150)
    check('চাপলে ★ সংরক্ষিত হয় ও উপরের 🔖-ও মিলে যায', btn.get_attribute('aria-pressed') == 'true' and page.locator('#bmbtn').get_attribute('aria-pressed') == 'true')
    # MCQ
    boot(page, '#/quiz/s/bn2'); page.wait_for_selector('.qcard')
    qb = page.locator('.qcard .save-btn')
    check('MCQ কার্ডে সংরক্ষণ বাটন', qb.count() == 1 and qb.is_visible())
    qid = qb.get_attribute('data-save').split('|', 1)[1]
    qb.click(); page.wait_for_timeout(150)
    check('বাটন চাপলে উত্তর না দিয়েই প্রশ্ন সংরক্ষিত', page.evaluate(f"Core.isSaved('q','{qid}')") and page.locator('.opt.right, .opt.wrong').count() == 0)
    # Flashcard
    boot(page, '#/flash/review?mode=all'); page.wait_for_selector('#card')
    fb = page.locator('.fc-top .save-btn'); fid = fb.get_attribute('data-save').split('|', 1)[1]
    fb.click(); page.wait_for_timeout(150)
    check('Flashcard সংরক্ষিত, কার্ড উল্টায়নি', page.evaluate(f"Core.isSaved('fc','{fid}')") and 'flipped' not in (page.get_attribute('#card', 'class') or ''))
    # লিখিত
    boot(page, '#/written/t/bn-bhab')
    wb = page.locator('main .save-btn'); wb.click(); page.wait_for_timeout(150)
    check('লিখিত টপিক সংরক্ষিত', page.evaluate("Core.isSaved('wt','bn-bhab')"))
    # সংরক্ষিত পাতা
    boot(page, '#/saved/bm')
    t = page.inner_text('main')
    check('সংরক্ষিত পাতায় ৬টি ট্যাব ও সংখ্যা', page.locator('.saved-tabs button').count() == 6 and 'MCQ (১)' in t and 'Flashcard (১)' in t and 'লিখিত (১)' in t and 'পাঠ (১)' in t, t[:200])
    if SHOTS: page.screenshot(path=f'{SHOTS}/save-bm.png', full_page=True)
    boot(page, '#/saved/q')
    check('MCQ ট্যাবে প্রশ্ন ও Quiz বাটন', page.locator('main details').count() == 1 and page.locator('a[href="#/quiz/saved"]').count() == 1)
    page.locator('main details summary').click()
    check('খুললে সঠিক উত্তর ও ব্যাখ্যা দেখায়', 'সঠিক উত্তর' in page.inner_text('main details'))
    if SHOTS: page.screenshot(path=f'{SHOTS}/save-q.png', full_page=True)
    boot(page, '#/quiz/saved'); page.wait_for_selector('.qcard')
    check('সংরক্ষিত MCQ Quiz চলে', page.locator('.qcard .save-btn').get_attribute('aria-pressed') == 'true')
    boot(page, '#/flash/review?saved=1'); page.wait_for_selector('#card')
    check('সংরক্ষিত কার্ড রিভিউ: ১টি কার্ড', page.inner_text('.fc-mast').endswith('/১'), page.inner_text('.fc-mast'))
    boot(page, '#/saved/wt')
    check('লিখিত ট্যাবে টপিকের লিংক', page.locator('a[href="#/written/t/bn-bhab"]').count() == 1)
    boot(page, '#/home')
    check('হোমে সংরক্ষিত সংখ্যা', 'MCQ ১' in page.inner_text('#home-saved'), page.inner_text('#home-saved'))
    # সরানো
    boot(page, '#/saved/fc'); page.locator('main details summary').click(); page.locator('main details .save-btn').click(); page.wait_for_timeout(150)
    check('আবার চাপলে সরে যায়', not page.evaluate(f"Core.isSaved('fc','{fid}')"))
    boot(page, '#/l/bn1-1-1')
    check('রিলোডের পরও পাঠ সংরক্ষিত থাকে', page.locator('main .save-btn').get_attribute('aria-pressed') == 'true')
    check('৩৬০px-এ অনুভূমিক স্ক্রল নেই', page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"))
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close(); br.close()
print(f'\n{sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
