#!/usr/bin/env python3
"""smoke_test_p7.py — Phase 7: ICT পাঠ, ফিগার, কুইজ, ৩২০px"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'src' if 'src' in sys.argv[1:] else 'dist', 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
LIDS = [f'ict-1-{i}' for i in range(1, 7)] + [f'ict-2-{i}' for i in range(1, 9)] + ['ict-3-1', 'ict-3-2']
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, offline=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    boot(page, '#/s/ict')
    check('ICT বিষয়-পাতা: ৭টি অধ্যায় (পাঠ্যবইয়ের ৬টি + অতিরিক্ত), সবগুলোতে পাঠ', page.locator('details.chap').count() == 7 and page.evaluate("Core.SMAP.ict.ch.every(c=>c.l.every(l=>l.has))"))
    wide, empty = [], []
    for lid in LIDS:
        boot(page, '#/l/' + lid)
        if page.locator('#lbody .box, #lbody h3, #lbody table').count() < 2: empty.append(lid)
        w = page.evaluate('document.documentElement.scrollWidth')
        if w > 320: wide.append(f'{lid}={w}')
    check('১৬টি ICT পাঠেই কনটেন্ট', not empty, ', '.join(empty))
    check('৩২০px + অফলাইনে সব ICT পাঠ ফিট করে', not wide, ', '.join(wide))
    boot(page, '#/l/ict-2-6')
    check('ফুল অ্যাডারের সত্যক সারণি (৮ সারি)', page.locator('[data-fig="table"]').nth(1).locator('tbody tr').count() == 8)
    boot(page, '#/l/ict-1-4')
    mf = page.locator('[data-fig="match"]').first
    n = mf.locator('.m-l .m-it').count()
    for j in range(n):
        mf.locator(f'.m-l .m-it[data-j="{j}"]').click(); mf.locator(f'.m-r .m-it[data-j="{j}"]').click()
    check('প্রবর্তক-মিলকরণ ফিগার কাজ করে', n == 6 and mf.locator('.m-l .m-it.ok').count() == n)
    n = page.evaluate("QB.all().filter(q=>q.sub==='ict').length")
    check('ICT MCQ সংখ্যা ≥ ২০০', n >= 200, str(n))
    boot(page, '#/quiz/s/ict'); page.wait_for_selector('.qcard')
    check('ICT বিষয় কুইজ চলে', 'ict' == page.evaluate("QB.all().find(q=>q.q===document.querySelector('.qtext').textContent).sub"))
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
