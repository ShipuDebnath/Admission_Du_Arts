#!/usr/bin/env python3
"""English — Block 1 (A–C): Appropriate Preposition, Idioms & Phrases, Vocabulary, Spelling, Group Verbs
ব্যাখ্যা বাংলায় (পরিভাষা ইংরেজিতে); Idiom/Vocabulary-তে বাংলা + English অর্থ, Synonym/Antonym, উৎস/প্রসঙ্গ।
সূত্র: Oxford / Cambridge learner's dictionary-র প্রচলিত ব্যবহার; Idiom-এর উৎস যেখানে অনিশ্চিত সেখানে তা উল্লেখ করা হয়েছে।
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *

B = Bank('enb1b', 'en', 9102)
Q = B.q
UNIT = ('ঢাবি, গুচ্ছ, জাবি, রাবি ও চবির English অংশে Appropriate Preposition, Idiom, Synonym/Antonym, Spelling ও Group Verb থেকে নিয়মিত প্রশ্ন আসার প্রবণতা আছে — '
        'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না।')
S = ['Oxford / Cambridge learner\'s dictionary-র প্রচলিত ব্যবহার', 'Idiom-এর উৎস: প্রচলিত ব্যাখ্যা; অনিশ্চিত হলে তা লেখা আছে']
L = 'en-1-'

# =====================================================================
# 1.5 Appropriate Preposition (A–C)
# =====================================================================
PREPS = ['of', 'to', 'with', 'at', 'in', 'for', 'on', 'from', 'by', 'into']
# (word, prep, sentence, বাংলা অর্থ, বিকল্প যা-ও কখনো চলে → distractor থেকে বাদ)
PR = [('abide', 'by', 'We must abide ___ the rules.', 'মেনে চলা', ()), ('absent', 'from', 'He was absent ___ class yesterday.', 'অনুপস্থিত', ()),
      ('accede', 'to', 'The manager acceded ___ our request.', 'সম্মত হওয়া', ()), ('accuse', 'of', 'He was accused ___ theft.', 'অভিযুক্ত করা', ()),
      ('accustomed', 'to', 'She is accustomed ___ hard work.', 'অভ্যস্ত', ()), ('addicted', 'to', 'He is addicted ___ smoking.', 'আসক্ত', ()),
      ('afraid', 'of', 'The child is afraid ___ dogs.', 'ভীত', ()), ('aim', 'at', 'He aimed ___ the target.', 'লক্ষ্য করা/তাক করা', ()),
      ('angry (person)', 'with', 'Father was angry ___ me.', '(কারও ওপর) রাগান্বিত', ('at',)), ('anxious (worried)', 'about', 'She is anxious ___ her son\'s health.', 'উদ্বিগ্ন', ('for',)),
      ('apologise (reason)', 'for', 'He apologised ___ his rude behaviour.', '(কোনো কাজের জন্য) ক্ষমা চাওয়া', ()), ('astonished', 'at', 'I was astonished ___ his rudeness.', 'বিস্মিত', ('by',)),
      ('aware', 'of', 'Are you aware ___ the danger?', 'অবগত/সচেতন', ()), ('beware', 'of', 'Beware ___ pickpockets.', 'সাবধান থাকা', ()),
      ('believe', 'in', 'I believe ___ honesty.', '(কোনো কিছুর মূল্যে) আস্থা রাখা', ()), ('belong', 'to', 'This pen belongs ___ me.', '(কারও) হওয়া/অন্তর্ভুক্ত হওয়া', ()),
      ('blind (one eye)', 'in', 'He is blind ___ one eye.', '(এক চোখে) অন্ধ', ()), ('boast', 'of', 'He boasts ___ his wealth.', 'বড়াই করা', ('about',)),
      ('busy', 'with', 'She is busy ___ her studies.', 'ব্যস্ত', ()), ('capable', 'of', 'He is capable ___ doing the job.', 'সক্ষম', ()),
      ('comply', 'with', 'You must comply ___ the order.', 'মান্য করা', ()), ('confide', 'in', 'I confide ___ my sister.', 'বিশ্বাস করে মনের কথা বলা', ()),
      ('congratulate', 'on', 'We congratulated him ___ his success.', 'অভিনন্দন জানানো', ()), ('consist', 'of', 'Water consists ___ hydrogen and oxygen.', 'গঠিত হওয়া', ()),
      ('cope', 'with', 'She could not cope ___ the pressure.', 'সামলানো', ()), ('cure', 'of', 'The doctor cured him ___ fever.', 'আরোগ্য করা', ()),
      ('conscious', 'of', 'He is conscious ___ his duties.', 'সচেতন', ()), ('comment', 'on', 'He refused to comment ___ the issue.', 'মন্তব্য করা', ('about',))]
B.lesson(L + '5', [
    H('Appropriate Preposition কী'),
    P('কিছু **word** (verb, adjective, noun)-এর পরে নির্দিষ্ট একটি **preposition** বসে — এটি নিয়ম দিয়ে নয়, ব্যবহার দিয়ে ঠিক হয়েছে। তাই **word + preposition** একসাথে একটি টুকরো (chunk) হিসেবে মুখস্থ করুন: accuse **of**, comply **with**, congratulate **on**।'),
    TABLE('Word + Preposition (কলাম-লুকাও দিয়ে অনুশীলন)', ['Word', 'বাংলা অর্থ', 'উদাহরণ', 'Preposition'], *[(w, b, s.replace('___', p), p) for w, p, s, b, _ in PR]),
    TABLE('একই word, ভিন্ন preposition → ভিন্ন অর্থ', ['Phrase', 'অর্থ ও উদাহরণ'],
          ('angry with + ব্যক্তি', 'কারও ওপর রাগ: Father is angry with me.'), ('angry at/about + বিষয়', 'কোনো ঘটনায় রাগ: angry at the delay'),
          ('anxious about', 'উদ্বিগ্ন: anxious about the result'), ('anxious for', 'আকুল/আগ্রহী: anxious for success'),
          ('apologise to + ব্যক্তি, for + কারণ', 'He apologised to me for the delay.')),
    MNEM(('"of-দল: accuse, afraid, aware, beware, capable, conscious, consist, cure"', '"of" লাগে এমন শব্দ', 'এক নিঃশ্বাসে ছড়ার মতো পড়ুন।'),
         ('"to-দল: accede, accustomed, addicted, belong" — সবাই কোনো দিকে "যায়"', '"to" লাগে এমন শব্দ', '"to" = দিক/অভিমুখ।'),
         ('"with-দল: busy, comply, cope, angry (person)" — কারও/কিছুর "সাথে" জড়িত', '"with" লাগে এমন শব্দ', '"with" = সঙ্গ।')),
    MISTAKES('"accused **for** theft" ✗ → accused **of** theft।', '"congratulate **for**" ✗ → congratulate **on**।', '"consist **from**" ✗ → consist **of**।', '"comply **to**" ✗ → comply **with**।'),
    SUMMARY('Word + preposition একসাথে মুখস্থ করুন', 'angry with (ব্যক্তি) / at (বিষয়)', 'anxious about (উদ্বেগ) / for (আকুলতা)'),
    UNI(UNIT),
], S)
for i, (w, p, s, b, alt) in enumerate(PR):
    pool = [x for x in PREPS if x != p and x not in alt]
    random.Random(4000 + i).shuffle(pool)
    Q(L + '5', 2, s, p, [(x, f'"{w.split(" (")[0]}"-এর পরে এখানে "{x}" বসে না।') for x in pool[:3]],
      f'{w.split(" (")[0]} + {p} = {b}।', 'Word + preposition একসাথে মনে রাখুন; দলভিত্তিক ছড়া কাজে দেবে।', 'Preposition সারণি দেখুন।',
      trap=p in ('with', 'on') or bool(alt))

# =====================================================================
# 1.6 Idioms & Phrases (A–C)
# =====================================================================
# (idiom, বাংলা অর্থ, English meaning, উৎস/প্রসঙ্গ, উদাহরণ)
ID = [
    ('at a stone\'s throw', 'খুব কাছে', 'very near', 'একটা ঢিল ছুড়লে যত দূর যায় — অর্থাৎ হাতের নাগালে।', 'The school is at a stone\'s throw from my house.'),
    ('at sixes and sevens', 'বিশৃঙ্খল অবস্থায়', 'in confusion or disorder', 'উৎস নিয়ে মতভেদ আছে; প্রচলিত মত — মধ্যযুগের পাশা খেলায় ঝুঁকিপূর্ণ দান থেকে এসেছে। মনে রাখুন: ৬ আর ৭ এলোমেলো ছড়িয়ে আছে।', 'After the party, the room was at sixes and sevens.'),
    ('at daggers drawn', 'চরম শত্রুভাবাপন্ন', 'bitterly hostile', 'দুজনের হাতে খোলা ছোরা — যেকোনো মুহূর্তে লড়াই।', 'The two brothers are at daggers drawn over the land.'),
    ('a bolt from the blue', 'বিনা মেঘে বজ্রপাত; আকস্মিক ঘটনা', 'a sudden, unexpected event', 'পরিষ্কার নীল আকাশ থেকে হঠাৎ বজ্র — বাংলা বাগধারা "বিনা মেঘে বজ্রপাত"-এর সঙ্গে হুবহু মেলে।', 'The news of his death came as a bolt from the blue.'),
    ('above board', 'সৎ ও খোলাখুলি', 'honest and open', 'প্রচলিত ব্যাখ্যা: তাস খেলায় হাত টেবিলের (board) ওপরে রাখলে প্রতারণার সুযোগ থাকে না।', 'The deal was completely above board.'),
    ('all at sea', 'সম্পূর্ণ দিশেহারা', 'completely confused', 'সমুদ্রের মাঝে দিক হারানো জাহাজের ছবি।', 'I was all at sea in the chemistry exam.'),
    ('apple of discord', 'বিবাদের কারণ', 'cause of a quarrel', 'গ্রিক পুরাণ: দেবী Eris "সবচেয়ে সুন্দরীর জন্য" লেখা সোনার আপেল ছুড়ে দেন; তা নিয়ে তিন দেবীর বিবাদ থেকে শেষে Trojan War।', 'The property became the apple of discord between them.'),
    ('apple of one\'s eye', 'নয়নের মণি; অতি প্রিয়জন', 'a very dear person', 'পুরোনো ইংরেজিতে চোখের মণিকে (pupil) "apple" বলা হতো; বাইবেলেও এ প্রয়োগ আছে।', 'The little girl is the apple of her grandfather\'s eye.'),
    ('Achilles\' heel', 'দুর্বল স্থান', 'a weak point', 'গ্রিক পুরাণ: মা Thetis শিশু Achilles-কে গোড়ালি ধরে Styx নদীতে ডুবিয়েছিলেন, তাই গোড়ালিটুকু অরক্ষিত থাকে; সেখানেই তীর লেগে তাঁর মৃত্যু।', 'Spelling is my Achilles\' heel.'),
    ('at one\'s wit\'s end', 'কিংকর্তব্যবিমূঢ়', 'totally puzzled; not knowing what to do', 'wit = বুদ্ধি; বুদ্ধির শেষ সীমায় পৌঁছে যাওয়া।', 'I was at my wit\'s end when I lost my passport.'),
    ('bad blood', 'শত্রুতা, বিদ্বেষ', 'enmity, ill feeling', 'রক্তে বিষ মেশার মতো সম্পর্কে তিক্ততা।', 'There is bad blood between the two families.'),
    ('bear the brunt', 'মূল ধাক্কা সামলানো', 'face the main force of something', 'brunt = আক্রমণের সবচেয়ে জোরালো অংশ।', 'The poor bear the brunt of price hikes.'),
    ('bed of roses', 'সুখের জীবন', 'an easy, comfortable life', 'গোলাপের পাপড়ির বিছানার মতো আরাম; প্রায়ই নেতিবাচক: Life is not a bed of roses.', 'Life is not a bed of roses.'),
    ('beat about the bush', 'আসল কথা এড়িয়ে যাওয়া', 'avoid the main point', 'প্রচলিত ব্যাখ্যা: শিকারে পাখি তাড়াতে ঝোপের চারপাশে পেটানো হতো, সরাসরি ঝোপে নয়।', 'Stop beating about the bush and tell me the truth.'),
    ('black sheep', 'কুলাঙ্গার', 'a disgrace to a family or group', 'প্রচলিত ব্যাখ্যা: কালো ভেড়ার পশম রং করা যেত না বলে কম দামি মনে করা হতো।', 'He is the black sheep of the family.'),
    ('blue blood', 'অভিজাত বংশ', 'aristocratic birth', 'স্প্যানিশ "sangre azul" থেকে: রোদে না-পোড়া অভিজাতদের ফর্সা ত্বকে শিরা নীল দেখাত।', 'She was born of blue blood.'),
    ('by hook or by crook', 'যেকোনো উপায়ে (ন্যায় বা অন্যায়)', 'by any means, fair or foul', 'উৎস অনিশ্চিত; "hook" আর "crook" — দুটোই বাঁকা হাতিয়ার — ছন্দে মনে রাখুন।', 'He wants to win the election by hook or by crook.'),
    ('break the ice', 'জড়তা ভাঙা', 'start a conversation in a shy situation', 'বরফ ভেঙে জাহাজের জন্য পথ খোলার ছবি।', 'He told a joke to break the ice.'),
    ('burn the midnight oil', 'গভীর রাত পর্যন্ত পড়া/কাজ করা', 'work or study late at night', 'বিদ্যুতের আগের যুগে রাতে পড়তে তেলের প্রদীপ জ্বালাতে হতো।', 'She burnt the midnight oil before the exam.'),
    ('call a spade a spade', 'স্পষ্ট কথা বলা', 'speak frankly', 'প্রাচীন গ্রিক একটি উক্তির ইংরেজি অনুবাদ থেকে প্রচলিত — কোদালকে কোদাল বলা।', 'He always calls a spade a spade.'),
    ('cats and dogs', 'মুষলধারে (বৃষ্টি)', 'very heavily (of rain)', 'উৎস অনিশ্চিত; শুধু "rain cats and dogs" কাঠামোতে ব্যবহৃত হয়।', 'It is raining cats and dogs.'),
    ('cock-and-bull story', 'আজগুবি গল্প', 'an absurd, unbelievable story', 'উৎস অনিশ্চিত; মনে রাখুন — মোরগ আর ষাঁড়ের অবিশ্বাস্য গল্প।', 'Nobody believed his cock-and-bull story.'),
    ('crocodile tears', 'মায়াকান্না', 'false sorrow', 'প্রাচীন লোকবিশ্বাস: কুমির শিকার খেতে খেতে চোখের জল ফেলে। বাংলা "মায়াকান্না" — একই ভাব।', 'The thief shed crocodile tears in court.'),
    ('cry for the moon', 'অসম্ভব কিছু চাওয়া', 'want the impossible', 'শিশু আকাশের চাঁদ হাতে চেয়ে কাঁদছে — বাংলা "বামন হয়ে চাঁদে হাত"-এর কাছাকাছি।', 'Wanting to be a millionaire overnight is crying for the moon.'),
    ('castle in the air', 'আকাশকুসুম কল্পনা; দিবাস্বপ্ন', 'an impractical daydream', 'বাতাসে দুর্গ বানানো যায় না — বাংলা "আকাশকুসুম" বাগধারার সমতুল্য।', 'Stop building castles in the air and start working.'),
    ('cut a sorry figure', 'হাস্যকর/দুর্বল চেহারা দেখানো', 'make a poor impression', 'figure = চেহারা/ভাবমূর্তি; sorry = করুণ।', 'He cut a sorry figure at the debate.')]
B.lesson(L + '6', [
    H('Idiom কী'),
    P('**Idiom** হলো এমন শব্দগুচ্ছ যার অর্থ শব্দগুলোর আলাদা অর্থ যোগ করে পাওয়া যায় না। যেমন **a bolt from the blue** — নীল আকাশ থেকে বজ্র নয়, অর্থ "আকস্মিক ঘটনা"। বাংলার **বাগধারা**-র মতোই। পরীক্ষায় সাধারণত idiom দিয়ে তার অর্থ (English বা বাংলা) জানতে চাওয়া হয়।'),
    ENTRIES('Idiom কার্ড (A–C) — ট্যাপ করে উৎস ও উদাহরণ দেখুন', *[{'w': a, 'bn': b, 'en': c, 'ctx': d, 'ex': e} for a, b, c, d, e in ID]),
    TABLE('দ্রুত অনুশীলন (কলাম-লুকাও)', ['Idiom', 'বাংলা অর্থ'], *[(a, b) for a, b, *_ in ID]),
    MNEM(('"পুরাণের দুই আপেল: discord = ঝগড়া, eye = আদর"', 'apple of discord / apple of one\'s eye', 'Eris-এর আপেল থেকে যুদ্ধ; চোখের মণি = প্রিয়।'),
         ('"বাংলা জোড়া খুঁজুন"', 'দ্রুত মনে রাখা', 'bolt from the blue = বিনা মেঘে বজ্রপাত; crocodile tears = মায়াকান্না; castle in the air = আকাশকুসুম।')),
    MISTAKES('**apple of discord** (বিবাদের কারণ) ≠ **apple of one\'s eye** (প্রিয়জন)।', '**at sixes and sevens** = বিশৃঙ্খলা — সংখ্যার সঙ্গে সম্পর্ক নেই।', '**above board** = সৎ; "বোর্ডের ওপরে" নয়।'),
    SUMMARY('Idiom = বিশেষ অর্থবাহী শব্দগুচ্ছ (বাংলা বাগধারার মতো)', 'পুরাণ থেকে: Achilles\' heel, apple of discord', 'বাংলা সমতুল্য খুঁজে মনে রাখুন'),
    UNI(UNIT),
], S)
for i, (a, b, c, d, e) in enumerate(ID):
    pool = [x[2] for j, x in enumerate(ID) if j != i]
    random.Random(4100 + i).shuffle(pool)
    Q(L + '6', 2, f'The idiom "{a}" means —', c, [(x, 'এটি অন্য একটি idiom-এর অর্থ।') for x in pool[:3]],
      f'{a} = {c} ({b})।', 'ছবিটা কল্পনা করুন, তারপর রূপক অর্থ ভাবুন; বাংলা সমতুল্য বাগধারা মেলান।', f'উৎস/প্রসঙ্গ: {d}',
      trap=a in ('apple of discord', 'apple of one\'s eye', 'at sixes and sevens', 'above board'))

# =====================================================================
# 1.7 Vocabulary (A–C)
# =====================================================================
# (word, POS, বাংলা অর্থ, English meaning, synonyms, antonyms, cluster)
VB = [('abandon', 'v', 'পরিত্যাগ করা', 'to leave completely', ['forsake', 'desert', 'give up'], ['keep', 'retain'], 'leave'),
      ('abate', 'v', 'কমে যাওয়া, প্রশমিত হওয়া', 'to become less intense', ['diminish', 'subside', 'lessen'], ['intensify', 'increase'], 'less'),
      ('abhor', 'v', 'ঘৃণা করা', 'to hate deeply', ['detest', 'loathe'], ['adore', 'love'], 'hate'),
      ('abundant', 'adj', 'প্রচুর', 'existing in large quantity', ['plentiful', 'ample', 'copious'], ['scarce', 'meagre'], 'much'),
      ('accomplish', 'v', 'সম্পন্ন করা', 'to complete successfully', ['achieve', 'fulfil'], ['fail'], 'do'),
      ('acumen', 'n', 'বিচক্ষণতা, তীক্ষ্ণ বুদ্ধি', 'ability to judge well and quickly', ['shrewdness', 'insight'], ['dullness'], 'mind'),
      ('adamant', 'adj', 'অনমনীয়, অটল', 'refusing to change one\'s mind', ['unyielding', 'inflexible', 'firm'], ['flexible', 'yielding'], 'firm'),
      ('affluent', 'adj', 'ধনী, সচ্ছল', 'having plenty of money', ['wealthy', 'prosperous', 'rich'], ['poor', 'needy'], 'rich'),
      ('alleviate', 'v', 'লাঘব/উপশম করা', 'to make pain or a problem less severe', ['relieve', 'ease', 'mitigate'], ['aggravate', 'worsen'], 'less'),
      ('amiable', 'adj', 'অমায়িক, বন্ধুসুলভ', 'pleasant and friendly', ['friendly', 'genial', 'affable'], ['hostile', 'unfriendly'], 'kind'),
      ('ample', 'adj', 'যথেষ্ট, প্রচুর', 'enough or more than enough', ['sufficient', 'plentiful'], ['insufficient', 'scanty'], 'much'),
      ('arduous', 'adj', 'কষ্টসাধ্য, শ্রমসাধ্য', 'needing great effort', ['strenuous', 'laborious', 'difficult'], ['easy', 'effortless'], 'hard'),
      ('audacious', 'adj', 'দুঃসাহসী', 'boldly willing to take risks', ['bold', 'daring', 'fearless'], ['timid', 'cautious'], 'bold'),
      ('benevolent', 'adj', 'পরোপকারী, দয়ালু', 'kind and wanting to help others', ['kind', 'charitable', 'generous'], ['malevolent', 'cruel'], 'kind'),
      ('bewilder', 'v', 'হতবুদ্ধি করা', 'to confuse completely', ['confuse', 'puzzle', 'baffle'], ['clarify', 'enlighten'], 'confuse'),
      ('blatant', 'adj', 'নির্লজ্জভাবে প্রকাশ্য', 'done openly and shamelessly', ['flagrant', 'glaring', 'obvious'], ['subtle', 'hidden'], 'open'),
      ('brevity', 'n', 'সংক্ষিপ্ততা', 'shortness; conciseness', ['shortness', 'conciseness'], ['length', 'verbosity'], 'short'),
      ('candid', 'adj', 'অকপট, স্পষ্টবাদী', 'truthful and straightforward', ['frank', 'open', 'outspoken'], ['evasive', 'guarded'], 'open'),
      ('cordial', 'adj', 'আন্তরিক, সৌহার্দ্যপূর্ণ', 'warm and friendly', ['warm', 'hearty', 'friendly'], ['cold', 'hostile'], 'kind'),
      ('curtail', 'v', 'কমানো, ছেঁটে ফেলা', 'to reduce or cut short', ['cut short', 'reduce', 'restrict'], ['extend', 'prolong'], 'less'),
      ('callous', 'adj', 'নির্দয়, অনুভূতিহীন', 'cruelly insensitive to others', ['unfeeling', 'heartless', 'insensitive'], ['compassionate', 'sensitive'], 'cruel'),
      ('cogent', 'adj', 'জোরালো, যুক্তিগ্রাহ্য', 'clear, logical and convincing', ['convincing', 'compelling', 'persuasive'], ['weak', 'unconvincing'], 'believe'),
      ('conceal', 'v', 'গোপন করা, লুকানো', 'to hide', ['hide', 'cover', 'mask'], ['reveal', 'disclose'], 'hide'),
      ('credible', 'adj', 'বিশ্বাসযোগ্য', 'able to be believed', ['believable', 'plausible', 'reliable'], ['incredible', 'implausible'], 'believe'),
      ('cryptic', 'adj', 'রহস্যময়, দুর্বোধ্য', 'having a hidden or unclear meaning', ['mysterious', 'obscure', 'enigmatic'], ['clear', 'plain'], 'hide')]
ROOTS = {'abandon': 'ফরাসি "à bandon" (অন্যের নিয়ন্ত্রণে) থেকে — সব ছেড়ে দেওয়া।', 'benevolent': 'Latin bene (ভালো) + volens (ইচ্ছুক) — "ভালো চায় এমন"। বিপরীতে male (মন্দ) → malevolent।',
         'brevity': 'brief (সংক্ষিপ্ত) থেকে।', 'credible': 'Latin credere (বিশ্বাস করা) — credit, creed, incredible একই পরিবারের।', 'cryptic': 'Greek kryptos (লুকানো) — crypt, cryptography।',
         'curtail': 'curt (সংক্ষিপ্ত) + tail — লেজ ছেঁটে ছোট করার ছবি।', 'abhor': 'Latin ab (দূরে) + horrere (শিউরে ওঠা) — horror একই মূল।',
         'amiable': 'Latin amicus (বন্ধু) — amicable, amity।', 'affluent': 'Latin affluere (প্রবাহিত হওয়া) — টাকা যার দিকে বয়ে আসে।'}
B.lesson(L + '7', [
    H('Vocabulary কীভাবে পড়বেন'),
    P('ভর্তি পরীক্ষায় **Synonym** (সমার্থক) ও **Antonym** (বিপরীত) প্রশ্নই বেশি। প্রতিটি শব্দ শিখুন এভাবে: **বাংলা অর্থ + English meaning + ১টি জোরালো synonym + ১টি antonym**। শব্দমূল (root) জানলে অচেনা শব্দও আন্দাজ করা যায়।'),
    ENTRIES('Vocabulary কার্ড (A–C)', *[{'w': f'{w} ({p})', 'bn': b, 'en': e, 'syn': ', '.join(sy), 'ant': ', '.join(an), 'ctx': ROOTS.get(w)} for w, p, b, e, sy, an, _ in VB]),
    TABLE('দ্রুত অনুশীলন (কলাম-লুকাও)', ['Word', 'Synonym', 'বাংলা অর্থ'], *[(w, sy[0], b) for w, p, b, e, sy, an, _ in VB]),
    MNEM(('"bene = ভালো, male = মন্দ"', 'শব্দমূল', 'benevolent / malevolent, benefit / malefactor।'),
         ('"ab- = দূরে"', 'শব্দমূল', 'abhor (দূরে শিউরে ওঠা), abandon, abstain।'),
         ('"cred = বিশ্বাস"', 'শব্দমূল', 'credible, credit, incredible।')),
    MISTAKES('**abate** = কমা, "বাড়া" নয়।', '**callous** = নির্দয়, "careless" নয়।', '**candid** = অকপট, "candy" (মিষ্টি) নয়।', '**incredible** = অবিশ্বাস্য — credible-এর antonym।'),
    SUMMARY('২৫টি শব্দ (A–C), প্রতিটিতে বাংলা + English অর্থ, synonym, antonym', 'শব্দমূল: bene/male, ab-, cred, crypt'),
    UNI(UNIT),
], S)
def vq(i, w, b, ans, bad_set, kind, seed):
    me = VB[i]
    pool = []
    for j, x in enumerate(VB):
        if j == i or x[6] == me[6]: continue
        cand = (x[4] if kind == 'syn' else x[5])[0]
        if cand not in bad_set and cand not in pool: pool.append(cand)
    random.Random(seed).shuffle(pool)
    return pool[:3]
for i, (w, p, b, e, sy, an, cl) in enumerate(VB):
    wr = vq(i, w, b, sy[0], set(sy) | set(an), 'syn', 4200 + i)
    Q(L + '7', 2, f'Choose the synonym of "{w}".', sy[0], [(x, 'অর্থ মেলে না — এটি অন্য শব্দের synonym।') for x in wr],
      f'{w} = {b} ({e}); synonyms: {", ".join(sy)}।', 'শব্দমূল ও বাক্যে ব্যবহার ভেবে দেখুন।', f'Antonym: {", ".join(an)}।',
      trap=w in ('abate', 'callous', 'blatant', 'cogent', 'curtail'))
for i, (w, p, b, e, sy, an, cl) in enumerate(VB):
    if i % 2: continue
    wr = vq(i, w, b, an[0], set(sy) | set(an), 'ant', 4300 + i)
    Q(L + '7', 2, f'Choose the antonym of "{w}".', an[0], [(x, 'এটি বিপরীতার্থক নয়।') for x in wr],
      f'{w} = {b}; antonym: {", ".join(an)}।', 'Antonym একই part of speech হবে।', f'Synonyms: {", ".join(sy)}।', trap=w in ('candid', 'benevolent', 'credible'))

# =====================================================================
# 1.8 Spelling (A–C)
# =====================================================================
SP = [('accommodate', 'স্থান সংকুলান করা', 'c দুটি, m দুটি', ['accomodate', 'acommodate', 'accommadate']),
      ('achievement', 'অর্জন', 'i আগে, তারপর e (ie)', ['acheivement', 'achievment', 'achievemant']),
      ('acquaintance', 'পরিচয়/পরিচিত ব্যক্তি', 'c-q পাশাপাশি; শেষে -ance', ['aquaintance', 'acquaintence', 'acquintance']),
      ('address', 'ঠিকানা/ভাষণ', 'd দুটি, s দুটি', ['adress', 'addres', 'adresse']),
      ('aggressive', 'আক্রমণাত্মক', 'g দুটি, s দুটি', ['agressive', 'aggresive', 'agresive']),
      ('apparent', 'স্পষ্ট/আপাত', 'p দুটি; শেষে -ent', ['apparant', 'aparent', 'apparrent']),
      ('argument', 'যুক্তি/তর্ক', 'argue-এর e বাদ পড়ে', ['arguement', 'argumant', 'arguemant']),
      ('beginning', 'শুরু', '-ing-এর আগে n দুটি', ['begining', 'beggining', 'beginnig']),
      ('believe', 'বিশ্বাস করা', 'ie (lie মাথায় রাখুন: be-LIE-ve)', ['beleive', 'belive', 'beleave']),
      ('bureaucracy', 'আমলাতন্ত্র', 'bureau (দপ্তর) + cracy', ['beaurocracy', 'bureaucrasy', 'buraucracy']),
      ('business', 'ব্যবসা', 'busy-র y → i: busi-ness', ['buisness', 'busness', 'bussiness']),
      ('calendar', 'পঞ্জিকা', 'শেষে -ar', ['calender', 'calandar', 'callendar']),
      ('category', 'শ্রেণি', 'cat-e-gory', ['catagory', 'categary', 'catergory']),
      ('cemetery', 'কবরস্থান', 'তিনটি স্বরই e', ['cemetary', 'cematery', 'cemetry']),
      ('colleague', 'সহকর্মী', 'col + league', ['collegue', 'colleage', 'coleague']),
      ('commitment', 'অঙ্গীকার', 'm দুটি, কিন্তু -ment-এর আগে t একটি', ['committment', 'comitment', 'commitmant']),
      ('committee', 'কমিটি', 'm দুটি, t দুটি, e দুটি', ['commitee', 'comittee', 'committe']),
      ('conscience', 'বিবেক', 'con + science', ['conscence', 'consience', 'concience']),
      ('conscious', 'সচেতন', 'sc; শেষে -ious', ['concious', 'consious', 'conscous']),
      ('convenience', 'সুবিধা', 'শেষে -ience', ['convenince', 'conveniance', 'convinience'])]
B.lesson(L + '8', [
    H('Spelling-এ ভুল কোথায় হয়'),
    P('বেশির ভাগ ভুল হয় তিন জায়গায়: **double letter** (accommodate), **ie/ei** (believe, achieve), আর **অনুচ্চারিত স্বর** (-ant/-ent, -ar/-er)। প্রতিটি শব্দের "বিপদের জায়গা"টা আলাদা করে মনে রাখুন।'),
    TABLE('সঠিক বানান (কলাম-লুকাও)', ['বাংলা অর্থ', 'বিপদের জায়গা', 'সঠিক বানান'], *[(b, t, w) for w, b, t, _ in SP]),
    MNEM(('"accommodate-এ দুটি c আর দুটি m-এর জায়গা হয়"', 'accommodate', 'দুটোই double।'),
         ('"cemetery-তে তিনটি e — ভয়ে সবাই eee করে"', 'cemetery', 'সব স্বর e।'),
         ('"committee: Many Meetings, Too Tiring, Every Evening"', 'committee', 'mm, tt, ee।'),
         ('"i before e, except after c"', 'ie/ei', 'believe, achieve; কিন্তু receive, ceiling।')),
    MISTAKES('"calender" ✗ → **calendar**।', '"arguement" ✗ → **argument**।', '**commitment**-এ t একটি, কিন্তু **committee**-তে t দুটি।'),
    SUMMARY('Double letter, ie/ei, -ant/-ent, -ar/-er খেয়াল করুন', 'A–C-র ২০টি বহুল-প্রচলিত শব্দ'),
    UNI(UNIT),
], S)
for i, (w, b, t, wr) in enumerate(SP):
    Q(L + '8', 2, f'Which spelling is correct? ({b})', w, [(x, 'বানান ভুল।') for x in wr], f'সঠিক বানান: {w} — {t}।', 'শব্দের "বিপদের জায়গা" দেখুন।', f'অর্থ: {b}।',
      trap=w in ('commitment', 'calendar', 'cemetery', 'argument'))

# =====================================================================
# 1.9 Group Verbs (A–C)
# =====================================================================
GV = [('account for', 'ব্যাখ্যা দেওয়া', 'explain'), ('act upon', '(পরামর্শ) অনুযায়ী কাজ করা', 'follow (advice)'),
      ('allow for', 'বিবেচনায় রাখা', 'take into consideration'), ('back out', 'প্রতিশ্রুতি থেকে সরে আসা', 'withdraw from a promise'),
      ('break down', 'বিকল হওয়া; ভেঙে পড়া', 'stop working'), ('break into', 'জোর করে ঢোকা', 'enter by force'),
      ('break out', 'হঠাৎ শুরু হওয়া (যুদ্ধ, আগুন, রোগ)', 'start suddenly'), ('break off', 'হঠাৎ ছিন্ন করা', 'end suddenly'),
      ('bring about', 'ঘটানো', 'cause to happen'), ('bring up', 'লালনপালন করা', 'raise (a child)'),
      ('blow up', 'বিস্ফোরণে উড়িয়ে দেওয়া', 'explode'), ('call off', 'বাতিল করা', 'cancel'),
      ('call on', '(কারও সঙ্গে) দেখা করতে যাওয়া', 'visit (a person)'), ('call for', 'প্রয়োজন হওয়া', 'require'),
      ('carry on', 'চালিয়ে যাওয়া', 'continue'), ('carry out', 'পালন/বাস্তবায়ন করা', 'execute'),
      ('come across', 'হঠাৎ দেখা পাওয়া', 'meet by chance'), ('come by', 'জোগাড় করা', 'obtain'),
      ('cut down', 'কমানো', 'reduce'), ('catch up with', 'সমান হয়ে যাওয়া/ধরে ফেলা', 'reach the same level as')]
B.lesson(L + '9', [
    H('Group Verb কী'),
    P('**Group verb** (phrasal verb) = **verb + particle** (preposition বা adverb), যা মিলে নতুন অর্থ তৈরি করে। **break out** মানে "বাইরে ভাঙা" নয় — "হঠাৎ শুরু হওয়া"। একটি verb-এর সব group verb একসাথে (পরিবার ধরে) পড়ুন।'),
    TABLE('Group Verb (কলাম-লুকাও)', ['Group verb', 'English meaning', 'বাংলা অর্থ'], *[(a, c, b) for a, b, c in GV]),
    MNEM(('"BREAK পরিবার: down-বিকল, into-ঢোকা, out-শুরু, off-ছিন্ন"', 'break', 'এক verb, চার অর্থ — একসাথে পড়ুন।'),
         ('"CALL পরিবার: off-বাতিল, on-দেখা করা, for-প্রয়োজন"', 'call', 'একসাথে পড়ুন।'),
         ('"CARRY: on = চলতেই থাকো, out = কাজটা বাইরে বের করে শেষ করো"', 'carry', 'continue বনাম execute।')),
    MISTAKES('**call on** = দেখা করা; **call off** = বাতিল।', '**bring up** = লালনপালন; **bring about** = ঘটানো।', '**carry on** = চালিয়ে যাওয়া; **carry out** = বাস্তবায়ন।'),
    SUMMARY('Verb পরিবার ধরে পড়ুন: break, bring, call, carry, come', 'A–C-র ২০টি বহুল-প্রচলিত group verb'),
    UNI(UNIT),
], S)
for i, (a, b, c) in enumerate(GV):
    pool = [x[2] for j, x in enumerate(GV) if j != i]
    random.Random(4400 + i).shuffle(pool)
    Q(L + '9', 2, f'The group verb "{a}" means —', c, [(x, 'এটি অন্য একটি group verb-এর অর্থ।') for x in pool[:3]],
      f'{a} = {c} ({b})।', 'Verb পরিবার ধরে মনে রাখুন।', 'Group verb সারণি।', trap=a in ('call on', 'call off', 'carry out', 'bring about'))
FILL = [('The match was ___ due to rain.', 'called off', ['called on', 'called for', 'carried on'], 'বৃষ্টির কারণে বাতিল'),
        ('A fire ___ in the market last night.', 'broke out', ['broke off', 'broke down', 'broke into'], 'হঠাৎ আগুন লাগা'),
        ('Thieves ___ the shop and stole the cash.', 'broke into', ['broke out', 'broke off', 'brought about'], 'জোর করে ঢোকা'),
        ('She was ___ by her grandmother.', 'brought up', ['brought about', 'broken up', 'called up'], 'লালনপালন'),
        ('I ___ an old friend at the station.', 'came across', ['came by', 'carried on', 'called for'], 'হঠাৎ দেখা'),
        ('The soldiers ___ the order at once.', 'carried out', ['carried on', 'called off', 'came by'], 'আদেশ পালন'),
        ('Can you ___ your absence from class?', 'account for', ['allow for', 'call for', 'act upon'], 'ব্যাখ্যা দেওয়া'),
        ('This situation ___ quick action.', 'calls for', ['calls on', 'calls off', 'carries on'], 'প্রয়োজন হওয়া')]
for s, a, wr, b in FILL:
    Q(L + '9', 2, s, a, [(x, 'অর্থ প্রসঙ্গের সঙ্গে মেলে না।') for x in wr], f'প্রসঙ্গ: {b} → {a}।', 'বাক্যের ভাব বুঝে group verb বাছুন।', 'Group verb সারণি।', trap=True)

# ---- Flashcard: কার্ডে বাংলা + English অর্থ ----
for a, b, c, d, e in ID:
    B.card(L + '6', a, f'{b}\n{c}\n\nউৎস: {d}')
for w, p, b, e, sy, an, _ in VB:
    B.card(L + '7', w, f'{b}\n{e}\n\nSyn: {", ".join(sy)}\nAnt: {", ".join(an)}')
for a, b, c in GV:
    B.card(L + '9', a, f'{b}\n{c}')
B.autofill_cards(12)
B.save('b1b', 'en-b1b')
