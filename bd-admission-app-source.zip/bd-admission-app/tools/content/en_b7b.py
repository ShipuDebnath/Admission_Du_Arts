#!/usr/bin/env python3
"""English — Block 7 (অংশ ২): Reading Comprehension, Cloze Test, Translation, Paragraph Writing, Letter/Application Writing
সব passage এই অ্যাপের জন্য নতুন করে লেখা (কপিরাইটমুক্ত)। ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে।"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb7b', 'en', 9751)
Q = B.q
S = ['এই অ্যাপের জন্য লেখা মৌলিক passage', 'প্রচলিত English grammar ও লেখার রীতি']
L = 'en-7-'
def FQ(lid, tip, fact, rows):
    for s, a, w, r, trap in rows:
        Q(lid, 2, s, a, w, r, tip, fact, trap=trap)

# =====================================================================
# 7.1 Reading Comprehension
# =====================================================================
PA = ('The Sundarbans is the largest mangrove forest in the world. It lies in the delta of the Ganges, the Brahmaputra and the Meghna, '
      'and it is shared by Bangladesh and India. The forest is home to the Royal Bengal Tiger, spotted deer, crocodiles and hundreds of species of birds. '
      'Its thick roots hold the soil together, and the forest acts as a natural shield that weakens cyclones before they reach the villages. '
      'However, rising salinity, illegal felling of trees and climate change are threatening its survival. If we fail to protect it, '
      'we will lose not only a unique ecosystem but also our first line of defence against natural disasters.')
PB = ('Many young people today say they have no time to read books. They spend hours scrolling through social media, yet they claim to be too busy for a novel. '
      'Reading, however, does something that short videos cannot do. It trains the mind to concentrate, it widens our vocabulary, and it lets us live a thousand lives through the eyes of others. '
      'A person who reads regularly learns to think before reacting and to understand people who are different from him. '
      'Building the habit is not difficult: ten pages a day is enough to begin with. What matters is not how fast we read, but that we never stop.')
PC = ('On his way home from school, Rafi found a brown wallet lying near the bus stop. Inside were some money, an identity card and a photograph of a little girl. '
      'Rafi\'s family was poor, and the money could have bought him the cricket bat he had wanted for months. For a moment he hesitated. '
      'Then he looked at the photograph again and walked to the address on the card. An old man opened the door. When he saw the wallet, his eyes filled with tears. '
      '"This was my granddaughter\'s last photo," he whispered. He offered Rafi a reward, but Rafi politely refused. '
      'That evening Rafi had no new bat, yet he felt richer than he had ever felt before.')
B.lesson(L + '1', [
    H('Reading Comprehension: কৌশল'),
    P('Passage পড়ে প্রশ্নের উত্তর দিতে হয়। পরীক্ষায় সাধারণত পাঁচ ধরনের প্রশ্ন: **main idea**, **specific detail**, **vocabulary in context**, **inference** (পরোক্ষ ইঙ্গিত) ও **title/tone**।'),
    TABLE('প্রশ্নের ধরন ও কৌশল', ['ধরন', 'কৌশল'],
          ('Main idea / Title', 'প্রথম ও শেষ বাক্য মিলিয়ে পুরো passage-এর মূল কথা খুঁজুন — একটি অংশের কথা নয়।'),
          ('Specific detail', 'প্রশ্নের মূল শব্দ passage-এ খুঁজে ঠিক সেই বাক্যটি পড়ুন।'),
          ('Vocabulary in context', 'শব্দের আশপাশের বাক্য দেখে অর্থ ঠিক করুন — অভিধানের প্রথম অর্থ নয়।'),
          ('Inference', 'যা সরাসরি লেখা নেই কিন্তু লেখা থেকে নিশ্চিতভাবে বোঝা যায় — অতিরিক্ত অনুমান নয়।'),
          ('Reference (it/they/this)', 'Pronoun-এর ঠিক আগের সম্ভাব্য noun-টি বসিয়ে বাক্য মিলিয়ে দেখুন।')),
    H('Passage A'), P(PA), H('Passage B'), P(PB), H('Passage C'), P(PC),
    MNEM(('"আগে প্রশ্ন, পরে passage"', 'সময় বাঁচানো', 'প্রশ্নগুলো এক নজর দেখে নিলে passage পড়ার সময়ই উত্তর চোখে পড়ে।'),),
    MISTAKES('Passage-এ নেই এমন নিজের জ্ঞান দিয়ে উত্তর দেবেন না।', '"always/never/only" যুক্ত অপশন প্রায়ই অতিরিক্ত দাবি করে — সাবধান।'),
    SUMMARY('পাঁচ ধরনের প্রশ্ন: main idea, detail, vocabulary, inference, title/tone', 'উত্তর passage থেকে, নিজের অনুমান থেকে নয়'),
    UNI(UNIT_EN),
], S)
PTXT = {'Passage A': PA, 'Passage B': PB, 'Passage C': PC}
def PQ(tag, text):
    return f'[{tag}] {PTXT[tag]} — Q: ' + text
FQ(L + '1', 'প্রশ্নের মূল শব্দ passage-এ খুঁজুন; main idea-র জন্য প্রথম ও শেষ বাক্য।', 'Reading Comprehension পাঠের passage A, B, C।', [
    (PQ('Passage A', 'What is the main idea of the passage?'), 'The Sundarbans is valuable and must be protected.', [('Tigers live only in the Sundarbans.', 'Passage-এ "only" বলা হয়নি; এটি একটি detail।'), ('Cyclones are common in Bangladesh.', 'প্রসঙ্গ, মূল কথা নয়।'), ('India owns most of the Sundarbans.', 'Passage-এ এমন কথা নেই।')], 'প্রথম বাক্য (গুরুত্ব) + শেষ বাক্য (রক্ষার আহ্বান)।', True),
    (PQ('Passage A', 'According to the passage, how does the forest protect villages?'), 'It weakens cyclones before they reach the villages.', [('It stops all floods.', 'Passage-এ "all floods" নেই।'), ('It supplies drinking water.', 'উল্লেখ নেই।'), ('It keeps tigers away from people.', 'উল্লেখ নেই।')], 'Detail: "acts as a natural shield that weakens cyclones"।', False),
    (PQ('Passage A', 'The word "shield" in the passage means —'), 'protection', [('weapon', 'এখানে আক্রমণের অর্থ নেই।'), ('decoration', 'অর্থ মেলে না।'), ('boundary', 'কাছাকাছি, তবে প্রসঙ্গে "রক্ষা"।')], 'প্রসঙ্গ: ঝড় দুর্বল করে → রক্ষাকবচ।', True),
    (PQ('Passage A', 'Which is NOT mentioned as a threat to the forest?'), 'tourism', [('rising salinity', 'উল্লেখ আছে।'), ('illegal felling of trees', 'উল্লেখ আছে।'), ('climate change', 'উল্লেখ আছে।')], 'তিনটি হুমকি: salinity, illegal felling, climate change।', True),
    (PQ('Passage A', 'In "its survival", "its" refers to —'), 'the Sundarbans', [('climate change', 'হুমকি, যার টিকে থাকার প্রশ্ন নয়।'), ('the tiger', 'আলোচনার বিষয় পুরো বন।'), ('salinity', 'হুমকি।')], 'যার survival হুমকিতে — বনটি।', False),
    (PQ('Passage A', 'The tone of the last sentence is one of —'), 'warning', [('celebration', 'উল্টো ভাব।'), ('humour', 'মেলে না।'), ('indifference', 'মেলে না।')], '"If we fail… we will lose" — সতর্কবার্তা।', False),
    (PQ('Passage A', 'A suitable title for the passage is —'), 'The Sundarbans: A Shield Under Threat', [('The Life of the Royal Bengal Tiger', 'শুধু একটি অংশ।'), ('Rivers of Bangladesh', 'প্রসঙ্গ মাত্র।'), ('How Cyclones Form', 'Passage-এর বিষয় নয়।')], 'গুরুত্ব + হুমকি — দুটোই শিরোনামে।', True),
    (PQ('Passage A', 'It can be inferred that losing the forest would make coastal villages —'), 'more exposed to cyclones', [('richer', 'অযৌক্তিক অনুমান।'), ('safer from floods', 'উল্টো।'), ('free from salinity', 'উল্লেখ বা যুক্তি নেই।')], 'বন ঝড় দুর্বল করে → বন না থাকলে ঝুঁকি বাড়ে।', True),
    (PQ('Passage B', 'What is the writer\'s main argument?'), 'Reading books offers benefits that short videos cannot.', [('Social media should be banned.', 'লেখক এমন দাবি করেননি।'), ('Young people are lazy.', 'অতিরিক্ত দাবি।'), ('Reading fast is most important.', 'লেখক উল্টো বলেছেন।')], '"Reading, however, does something that short videos cannot do."', True),
    (PQ('Passage B', 'According to the writer, how many pages a day are enough to begin with?'), 'ten', [('twenty', 'উল্লেখ নেই।'), ('a hundred', 'উল্লেখ নেই।'), ('one book', 'উল্লেখ নেই।')], 'Detail: "ten pages a day is enough to begin with"।', False),
    (PQ('Passage B', '"Live a thousand lives through the eyes of others" suggests that reading —'), 'lets us experience other people\'s lives', [('makes us live longer', 'আক্ষরিক অর্থ নয়।'), ('damages our eyesight', 'অর্থ মেলে না।'), ('makes us copy others', 'অর্থ মেলে না।')], 'রূপক: বইয়ের চরিত্রের অভিজ্ঞতা নিজের হয়ে ওঠে।', True),
    (PQ('Passage B', 'The word "concentrate" is closest in meaning to —'), 'focus', [('relax', 'উল্টো।'), ('forget', 'অর্থ মেলে না।'), ('hurry', 'অর্থ মেলে না।')], 'মনোযোগ দেওয়া = focus।', False),
    (PQ('Passage B', 'What, according to the writer, matters most?'), 'never stopping the habit of reading', [('reading very fast', 'লেখক বলেছেন গতি গুরুত্বপূর্ণ নয়।'), ('reading only novels', 'উল্লেখ নেই।'), ('reading at night', 'উল্লেখ নেই।')], 'শেষ বাক্য: "…but that we never stop."', True),
    (PQ('Passage B', 'The tone of the passage is mainly —'), 'persuasive', [('angry', 'সমালোচনা আছে, রাগ নেই।'), ('humorous', 'মেলে না।'), ('sorrowful', 'মেলে না।')], 'পাঠককে পড়ার অভ্যাসে রাজি করানোর চেষ্টা।', False),
    (PQ('Passage B', 'Which statement can be inferred?'), 'Regular reading can make a person more understanding of others.', [('Social media improves concentration.', 'উল্টো ইঙ্গিত।'), ('Only students should read.', 'উল্লেখ নেই।'), ('Novels are harmful.', 'উল্টো।')], '"…understand people who are different from him."', True),
    (PQ('Passage B', 'A suitable title for the passage is —'), 'Why We Must Keep Reading', [('The History of Social Media', 'বিষয় নয়।'), ('How to Make Short Videos', 'বিষয় নয়।'), ('Ten Famous Novels', 'উল্লেখ নেই।')], 'মূল যুক্তি = পড়ার গুরুত্ব।', False),
    (PQ('Passage C', 'Where did Rafi find the wallet?'), 'near the bus stop', [('in his classroom', 'উল্লেখ নেই।'), ('at the old man\'s door', 'সেখানে ফেরত দিয়েছে।'), ('in a shop', 'উল্লেখ নেই।')], 'Detail: প্রথম বাক্য।', False),
    (PQ('Passage C', 'Why did Rafi hesitate for a moment?'), 'The money could buy the bat he wanted.', [('He could not read the address.', 'উল্লেখ নেই।'), ('He was afraid of the old man.', 'উল্লেখ নেই।'), ('The bus was coming.', 'উল্লেখ নেই।')], 'আগের বাক্য: টাকায় তার কাঙ্ক্ষিত ব্যাট কেনা যেত।', True),
    (PQ('Passage C', 'Why did the old man\'s eyes fill with tears?'), 'The wallet held his granddaughter\'s last photo.', [('He was angry with Rafi.', 'উল্টো ভাব।'), ('He had lost his money.', 'টাকা তো ফিরে পেয়েছেন।'), ('He was ill.', 'উল্লেখ নেই।')], '"This was my granddaughter\'s last photo."', True),
    (PQ('Passage C', '"He felt richer than he had ever felt before" means Rafi —'), 'felt proud and happy for doing the right thing', [('got a lot of money', 'পুরস্কার নেননি।'), ('bought a new bat', 'নতুন ব্যাট ছিল না।'), ('became famous', 'উল্লেখ নেই।')], 'রূপক: মনের ঐশ্বর্য।', True),
    (PQ('Passage C', 'The word "refused" means —'), 'declined', [('accepted', 'উল্টো।'), ('demanded', 'অর্থ মেলে না।'), ('counted', 'অর্থ মেলে না।')], 'পুরস্কার নিতে অস্বীকার।', False),
    (PQ('Passage C', 'The moral of the story is —'), 'Honesty brings true satisfaction.', [('Money is everything.', 'উল্টো।'), ('Never talk to strangers.', 'প্রসঙ্গ নয়।'), ('Cricket is a good game.', 'প্রসঙ্গ নয়।')], 'লোভ জয় করে সততা → আনন্দ।', False),
    (PQ('Passage C', 'Which word best describes Rafi?'), 'honest', [('greedy', 'লোভ জয় করেছে।'), ('careless', 'মেলে না।'), ('rude', 'বিনয়ের সঙ্গে প্রত্যাখ্যান করেছে।')], 'কাজ দেখেই চরিত্র।', False),
    (PQ('Passage C', 'A suitable title for the story is —'), 'The Richest Evening', [('The Lost Cricket Bat', 'ব্যাট হারায়নি।'), ('A Bus Journey', 'প্রসঙ্গ মাত্র।'), ('The Angry Old Man', 'বৃদ্ধ রাগেননি।')], 'শেষ বাক্যের ভাব থেকে।', True),
])

# =====================================================================
# 7.2 Cloze Test
# =====================================================================
CA = 'Bangladesh is a land (1) rivers. Most of its people depend (2) agriculture, and rivers make the soil fertile. However, rivers can also (3) great damage. Every year floods wash (4) crops and houses. People living (5) the banks often lose everything. Still, they do not give (6). They rebuild their homes as soon as the water (7). Their courage is worthy (8) praise. If we plan wisely, we (9) turn our rivers into a blessing rather (10) a curse.'
CB = 'Time is the most valuable thing (1) the world. Once lost, it can never (2) regained. A student who wastes time (3) in the end. (4) the other hand, those who use every minute wisely (5) success. We should therefore make a routine and follow it (6). We must not put (7) today\'s work till tomorrow. As the saying goes, "Time and tide wait (8) none." (9) we value time, we will (10) in life.'
B.lesson(L + '2', [
    H('Cloze Test'),
    P('একটি passage-এ কয়েকটি শব্দ বাদ থাকে; প্রসঙ্গ বুঝে সঠিক শব্দ বসাতে হয়। প্রতিটি শূন্যস্থানে দেখুন: **কোন part of speech লাগবে** (preposition, verb, conjunction…), **আগে-পরের শব্দের সঙ্গে জোড়া** (depend **on**, give **up**), আর **পুরো বাক্যের অর্থ**।'),
    TABLE('শূন্যস্থান পূরণের ধাপ', ['ধাপ', 'কী দেখবেন'], ('১', 'পুরো passage একবার পড়ে মূল ভাব বুঝুন'), ('২', 'শূন্যস্থানের আগে-পরে কোন part of speech লাগবে'),
          ('৩', 'Fixed phrase: depend on, give up, on the other hand, rather than'), ('৪', 'Tense ও agreement মিলিয়ে নিন'), ('৫', 'বসিয়ে পুরো বাক্য আবার পড়ুন')),
    H('Cloze A'), P(CA), H('Cloze B'), P(CB),
    MNEM(('"আগে-পরে-অর্থ"', 'তিন চেক', 'আগের শব্দ, পরের শব্দ, তারপর পুরো অর্থ।'),),
    MISTAKES('শুধু আগের শব্দ দেখে preposition বসাবেন না — পুরো phrase মেলান।', '"rather ___" — than ছাড়া কিছু বসে না।'),
    SUMMARY('Part of speech → fixed phrase → tense/agreement → অর্থ', 'Cloze A (নদী) ও Cloze B (সময়) অনুশীলন'),
    UNI(UNIT_EN),
], S)
CLA = [('Bangladesh is a land (1) rivers.', 'of', ['in', 'for', 'with'], 'a land of rivers — নদীর দেশ।'),
       ('Most of its people depend (2) agriculture.', 'on', ['in', 'at', 'with'], 'depend on।'),
       ('However, rivers can also (3) great damage.', 'cause', ['do of', 'make for', 'give up'], 'cause damage — ক্ষতি করা।'),
       ('Every year floods wash (4) crops and houses.', 'away', ['out', 'off', 'up'], 'wash away — ভাসিয়ে নেওয়া।'),
       ('People living (5) the banks often lose everything.', 'on', ['in', 'at', 'into'], 'live on the banks — তীরে বাস। ("along" চলে, তাই অপশনে নেই।)'),
       ('Still, they do not give (6).', 'up', ['in to', 'off', 'away'], 'give up — হাল ছাড়া।'),
       ('They rebuild their homes as soon as the water (7).', 'recedes', ['rises', 'floods', 'grows'], 'পানি নেমে গেলেই — recede।'),
       ('Their courage is worthy (8) praise.', 'of', ['for', 'to', 'with'], 'worthy of।'),
       ('If we plan wisely, we (9) turn our rivers into a blessing.', 'can', ['could have', 'had', 'did'], 'If + present → can/will + V1।'),
       ('…into a blessing rather (10) a curse.', 'than', ['then', 'to', 'from'], 'rather than।')]
CLB = [('Time is the most valuable thing (1) the world.', 'in', ['of', 'at', 'on'], 'superlative + in the world।'),
       ('Once lost, it can never (2) regained.', 'be', ['been', 'being', 'is'], 'can + be + V3 (passive)।'),
       ('A student who wastes time (3) in the end.', 'suffers', ['suffer', 'suffering', 'to suffer'], 'Subject "A student" singular → suffers।'),
       ('(4) the other hand, those who use every minute wisely…', 'On', ['In', 'At', 'By'], 'On the other hand।'),
       ('…those who use every minute wisely (5) success.', 'achieve', ['achieves', 'achieving', 'to achieve'], 'Subject "those" plural → achieve।'),
       ('We should therefore make a routine and follow it (6).', 'strictly', ['strict', 'strictness', 'stricter than'], 'verb follow-কে বিশেষিত করে → adverb।'),
       ('We must not put (7) today\'s work till tomorrow.', 'off', ['out', 'on', 'up with'], 'put off — স্থগিত করা।'),
       ('"Time and tide wait (8) none."', 'for', ['to', 'on', 'with'], 'প্রবাদ: wait for none।'),
       ('(9) we value time, we will prosper.', 'If', ['Unless', 'Though', 'Lest'], 'শর্ত → If।'),
       ('If we value time, we will (10) in life.', 'prosper', ['prosperity', 'prosperous', 'prospering'], 'will + V1।')]
for tag, rows in (('Cloze A', CLA), ('Cloze B', CLB)):
    for s, a, wr, r in rows:
        Q(L + '2', 2, f'[{tag}] {s} — fill in the blank.', a, [(x, 'প্রসঙ্গ/গঠন মেলে না।') for x in wr], r, 'আগে-পরে-অর্থ — তিনটিই মিলিয়ে দেখুন।', f'{tag} passage দেখুন।', trap=a in ('recedes', 'strictly', 'suffers', 'be'))

# =====================================================================
# 7.3 Translation (Bangla ↔ English)
# =====================================================================
B.lesson(L + '3', [
    H('Translation: বাংলা ↔ English'),
    P('অনুবাদে **শব্দ নয়, ভাব** বদলাতে হয়। আগে বাংলা বাক্যের **tense** চিনুন (ক্রিয়ার রূপ থেকে), তারপর English কাঠামো বসান। প্রবাদ-প্রবচনের ক্ষেত্রে আক্ষরিক অনুবাদ নয়, প্রচলিত English প্রবাদ বসান।'),
    TABLE('বাংলা ক্রিয়ার রূপ → Tense', ['বাংলা', 'Tense', 'উদাহরণ'],
          ('করি / করে', 'present indefinite', 'আমি খাই → I eat.'), ('করছি / করছে', 'present continuous', 'সে পড়ছে → He is reading.'),
          ('করেছি / করেছে', 'present perfect', 'আমি খেয়েছি → I have eaten.'), ('ধরে করছি', 'present perfect continuous', 'দুই ঘণ্টা ধরে পড়ছি → I have been reading for two hours.'),
          ('করলাম / করেছিলাম', 'past indefinite / past perfect', 'গতকাল গেলাম → I went yesterday.'), ('করব', 'future indefinite', 'আমি যাব → I shall/will go.')),
    TABLE('বিশেষ কাঠামো', ['বাংলা', 'English'],
          ('তোমার বয়স কত?', 'How old are you?'), ('আমার জ্বর হয়েছে।', 'I have a fever.'), ('সে ইংরেজিতে কাঁচা।', 'He is weak in English.'),
          ('মিথ্যা বলো না।', 'Do not tell a lie.'), ('চলো, খেলতে যাই।', 'Let us go out to play.'), ('আমি যদি পাখি হতাম!', 'If I were a bird!')),
    MNEM(('"ক্রিয়ার শেষাংশ দেখুন: -ছি = continuous, -য়েছি = perfect, ধরে = perfect continuous"', 'Tense চেনা', 'বাংলা ক্রিয়াই tense বলে দেয়।'),),
    MISTAKES('"I am fever" ✗ → I have a fever।', '"Sun rises from the east" ✗ → The sun rises **in** the east।', '"He is weak at English" — পরীক্ষার প্রচলিত উত্তর weak **in**।'),
    SUMMARY('আগে tense, তারপর কাঠামো', 'প্রবাদে প্রচলিত English প্রবাদ', 'আক্ষরিক নয়, ভাবানুবাদ'),
    UNI(UNIT_EN),
], S)
FQ(L + '3', 'বাংলা ক্রিয়ার রূপ থেকে tense ঠিক করুন; প্রবাদে প্রচলিত English প্রবাদ।', 'Translation সারণি।', [
    ('Translate: "আমি প্রতিদিন স্কুলে যাই।"', 'I go to school every day.', [('I am going to school every day.', 'অভ্যাস → present indefinite।'), ('I went to school every day.', 'Tense ভুল।'), ('I have gone to school every day.', 'Tense ভুল।')], 'অভ্যাস → present indefinite।', False),
    ('Translate: "সে এখন পড়ছে।"', 'He is reading now.', [('He reads now.', '"পড়ছে" = continuous।'), ('He has read now.', 'Tense ভুল।'), ('He was reading now.', 'Tense ভুল।')], '-ছে → present continuous।', False),
    ('Translate: "আমি কাজটি শেষ করেছি।"', 'I have finished the work.', [('I finished the work now.', '"করেছি" → present perfect।'), ('I am finishing the work.', 'Tense ভুল।'), ('I had finish the work.', 'অশুদ্ধ।')], '-য়েছি → present perfect।', False),
    ('Translate: "গতকাল বৃষ্টি হয়েছিল।"', 'It rained yesterday.', [('It has rained yesterday.', 'yesterday → past indefinite।'), ('It rains yesterday.', 'Tense ভুল।'), ('Rain was yesterday.', 'অপ্রচলিত গঠন।')], 'yesterday → past indefinite।', True),
    ('Translate: "আমি দুই ঘণ্টা ধরে পড়ছি।"', 'I have been reading for two hours.', [('I am reading for two hours.', '"ধরে" → perfect continuous।'), ('I read for two hours.', 'Tense ভুল।'), ('I have read since two hours.', 'সময়কাল → for।')], 'ধরে → present perfect continuous।', True),
    ('Translate: "ট্রেন ছাড়ার আগেই আমরা স্টেশনে পৌঁছেছিলাম।"', 'We had reached the station before the train left.', [('We reached the station before the train had left.', 'আগের কাজ (পৌঁছানো)-এ past perfect।'), ('We have reached the station before the train left.', 'Tense ভুল।'), ('We reach the station before the train leaves.', 'Tense ভুল।')], 'আগের অতীত → past perfect।', True),
    ('Translate: "যদি তুমি পরিশ্রম করো, তুমি সফল হবে।"', 'If you work hard, you will succeed.', [('If you will work hard, you will succeed.', 'If-clause-এ future নয়।'), ('If you worked hard, you will succeed.', 'Tense মেলে না।'), ('If you work hard, you would succeeded.', 'অশুদ্ধ।')], 'If + present → will + V1।', True),
    ('Translate: "আমি যদি পাখি হতাম!"', 'If I were a bird!', [('If I was a bird!', 'Subjunctive → were।'), ('If I am a bird!', 'অবাস্তব কল্পনা নয়।'), ('If I would be a bird!', 'অশুদ্ধ।')], 'অবাস্তব ইচ্ছা → were।', True),
    ('Translate: "আমার জ্বর হয়েছে।"', 'I have a fever.', [('I am fever.', 'অশুদ্ধ — জ্বর "আছে", আমি জ্বর নই।'), ('My fever has happened.', 'আক্ষরিক অনুবাদ।'), ('I am in fever having.', 'অশুদ্ধ।')], 'অসুখ → have।', True),
    ('Translate: "তোমার বয়স কত?"', 'How old are you?', [('What is your age how much?', 'আক্ষরিক।'), ('How much are you old?', 'অশুদ্ধ।'), ('How many age you have?', 'অশুদ্ধ।')], 'বয়স → How old…?', False),
    ('Translate: "সূর্য পূর্ব দিকে ওঠে।"', 'The sun rises in the east.', [('The sun rises from the east.', 'পরীক্ষার প্রচলিত উত্তর "in the east"।'), ('Sun rises in east.', 'Article বাদ।'), ('The sun is rising in the east.', 'চিরন্তন সত্য → present indefinite।')], 'চিরন্তন সত্য + in the east।', True),
    ('Translate: "সে আমার চেয়ে লম্বা।"', 'He is taller than I.', [('He is more tall than I.', 'tall → taller।'), ('He is tallest than me.', 'than → comparative।'), ('He is taller to me.', 'than লাগবে।')], 'Comparative + than।', False),
    ('Translate: "মিথ্যা বলো না।"', 'Do not tell a lie.', [('Do not say a lie.', 'lie-এর সঙ্গে tell।'), ('Not tell lie.', 'অশুদ্ধ।'), ('Don\'t speak lies to.', 'অশুদ্ধ।')], 'Negative imperative + tell a lie।', True),
    ('Translate: "চলো, আমরা খেলতে যাই।"', 'Let us go out to play.', [('Let we go to play.', 'Let + objective (us)।'), ('Let us going to play.', 'Let + V1।'), ('Lets go to playing.', 'অশুদ্ধ।')], 'Let us + V1।', False),
    ('Translate: "সে ইংরেজিতে কাঁচা।"', 'He is weak in English.', [('He is raw in English.', 'আক্ষরিক অনুবাদ।'), ('He is weak at the English.', 'অশুদ্ধ।'), ('He is unripe in English.', 'আক্ষরিক অনুবাদ।')], 'কাঁচা = weak in।', True),
    ('Translate: "আমি তাকে চিনি।"', 'I know him.', [('I am knowing him.', 'know continuous হয় না।'), ('I know to him.', 'অপ্রয়োজনীয় to।'), ('I knew him now.', 'Tense ভুল।')], 'Stative verb → present indefinite।', False),
    ('Translate: "বইটি টেবিলের ওপর আছে।"', 'The book is on the table.', [('The book is over the table.', 'ছুঁয়ে আছে → on।'), ('The book has on the table.', 'অশুদ্ধ।'), ('The book is upon of the table.', 'অশুদ্ধ।')], 'ছুঁয়ে ওপরে → on।', False),
    ('Translate: "সে গত বছর থেকে অসুস্থ।"', 'He has been ill since last year.', [('He is ill since last year.', 'since + এখনো → present perfect।'), ('He was ill from last year.', 'অশুদ্ধ।'), ('He has been ill for last year.', 'নির্দিষ্ট শুরুর সময় → since।')], 'since + present perfect।', True),
    ('Translate the proverb: "যত গর্জে তত বর্ষে না।"', 'Barking dogs seldom bite.', [('As much it roars, that much it rains not.', 'আক্ষরিক অনুবাদ — প্রবাদ নয়।'), ('All that glitters is not gold.', 'অন্য প্রবাদ।'), ('Haste makes waste.', 'অন্য প্রবাদ।')], 'প্রবাদের প্রচলিত English সমতুল্য।', True),
    ('Translate the proverb: "অতি লোভে তাঁতি নষ্ট।"', 'Grasp all, lose all.', [('Too much greed destroys the weaver.', 'আক্ষরিক।'), ('Barking dogs seldom bite.', 'অন্য প্রবাদ।'), ('Many hands make light work.', 'অন্য প্রবাদ।')], 'প্রবাদ → প্রবাদ।', True),
    ('Translate the proverb: "ঘরপোড়া গরু সিঁদুরে মেঘ দেখলে ডরায়।"', 'A burnt child dreads the fire.', [('A burnt cow fears the red cloud.', 'আক্ষরিক।'), ('Grasp all, lose all.', 'অন্য প্রবাদ।'), ('Time and tide wait for none.', 'অন্য প্রবাদ।')], 'প্রবাদ → প্রবাদ।', True),
    ('Translate the proverb: "দশের লাঠি একের বোঝা।"', 'Many hands make light work.', [('Ten sticks are one burden.', 'আক্ষরিক।'), ('A burnt child dreads the fire.', 'অন্য প্রবাদ।'), ('Union is strength of sticks.', 'অশুদ্ধ।')], 'প্রবাদ → প্রবাদ।', True),
    ('Translate into Bangla: "He has been living here for ten years."', 'সে এখানে দশ বছর ধরে বাস করছে।', [('সে এখানে দশ বছর বাস করেছিল।', 'perfect continuous = "ধরে …ছে"।'), ('সে এখানে দশ বছর বাস করবে।', 'Tense ভুল।'), ('সে দশ বছর আগে এখানে বাস করত।', 'অর্থ বদলেছে।')], 'has been + -ing + for → ধরে করছে।', True),
    ('Translate into Bangla: "No sooner had he come than she left."', 'সে আসামাত্রই মেয়েটি চলে গেল।', [('সে আসার অনেক পরে মেয়েটি গেল।', 'অর্থ উল্টো।'), ('মেয়েটি যাওয়ার পর সে এল।', 'ক্রম উল্টো।'), ('সে এল না, মেয়েটি গেল।', 'অর্থ বদলেছে।')], 'No sooner … than = …মাত্রই।', True),
    ('Translate into Bangla: "Let him go."', 'তাকে যেতে দাও।', [('তাকে যেতে দিয়ো না।', 'Negative নয়।'), ('সে যাক বা না যাক।', 'অর্থ বদলেছে।'), ('সে চলে গেছে।', 'অর্থ বদলেছে।')], 'Let + object + V1 = …তে দাও।', False),
])

# =====================================================================
# 7.8 Paragraph Writing
# =====================================================================
MODEL = ('**A Village Market** — A village market is a lively meeting place for the people of rural Bangladesh. It usually sits beside a river or under a large banyan tree, '
         'and it opens once or twice a week. Farmers bring rice, vegetables, fish and poultry, while small traders sell clothes, spices and household goods. '
         'Buyers bargain loudly, children enjoy sweets, and old friends share news over cups of tea. Besides buying and selling, the market helps villagers learn about prices '
         'and events in nearby areas. Thus, a village market is not only a centre of trade but also a centre of social life.')
B.lesson(L + '8', [
    H('Paragraph Writing'),
    P('**Paragraph** = একটি মাত্র মূল ভাব নিয়ে লেখা কয়েকটি সম্পর্কিত বাক্যের সমষ্টি। গঠন: **Topic sentence** (মূল ভাব) → **Supporting sentences** (ব্যাখ্যা, উদাহরণ, তথ্য) → **Concluding sentence** (সারকথা)।'),
    TABLE('ভালো paragraph-এর তিন গুণ', ['গুণ', 'অর্থ'], ('Unity', 'সব বাক্য একটিই মূল ভাবের সঙ্গে যুক্ত'), ('Coherence', 'বাক্যগুলো যৌক্তিক ক্রমে, linking word দিয়ে জোড়া'), ('Completeness', 'মূল ভাব যথেষ্ট ব্যাখ্যা ও উদাহরণে পূর্ণ')),
    TABLE('Linking words', ['কাজ', 'শব্দ'], ('যোগ', 'moreover, furthermore, besides, in addition'), ('বৈপরীত্য', 'however, but, on the other hand, nevertheless'),
          ('ফল', 'therefore, thus, as a result, consequently'), ('উদাহরণ', 'for example, for instance, such as'), ('ক্রম', 'firstly, then, finally'), ('উপসংহার', 'in conclusion, in short, to sum up')),
    H('মডেল paragraph'), P(MODEL),
    MNEM(('"T-S-C: Topic, Support, Conclude"', 'গঠন', 'বার্গারের মতো: ওপর-নিচে রুটি, মাঝে পুর।'), ('"U-C-C: Unity, Coherence, Completeness"', 'গুণ', 'একটি ভাব, যুক্ত বাক্য, পূর্ণ ব্যাখ্যা।')),
    MISTAKES('একই paragraph-এ দুটি ভিন্ন মূল ভাব আনবেন না।', 'মূল ভাবের সঙ্গে সম্পর্কহীন বাক্য unity নষ্ট করে।'),
    SUMMARY('Topic → Supporting → Concluding', 'Unity, Coherence, Completeness', 'Linking words দিয়ে বাক্য জুড়ুন'),
    UNI(UNIT_EN),
], S)
FQ(L + '8', 'Topic sentence আগে খুঁজুন; প্রতিটি বাক্য সেই ভাবের সঙ্গে মেলে কি না দেখুন।', 'Paragraph Writing সারণি ও মডেল।', [
    ('A paragraph should develop —', 'one central idea', [('several unrelated ideas', 'Unity নষ্ট হয়।'), ('only examples', 'মূল ভাব লাগে।'), ('a list of words', 'মেলে না।')], 'Paragraph = একটি মূল ভাব।', False),
    ('The sentence that states the main idea of a paragraph is the —', 'topic sentence', [('concluding sentence', 'শেষে সারকথা।'), ('supporting sentence', 'ব্যাখ্যা দেয়।'), ('transition', 'জোড়া দেয়।')], 'Topic sentence = মূল ভাব।', False),
    ('The topic sentence is usually placed —', 'at the beginning', [('at the end only', 'সাধারণত শুরুতে।'), ('in the title', 'মেলে না।'), ('nowhere', 'মেলে না।')], 'শুরুতে রাখা সবচেয়ে স্পষ্ট।', False),
    ('"Unity" in a paragraph means —', 'all sentences relate to one main idea', [('all sentences are of equal length', 'মেলে না।'), ('the paragraph has a title', 'মেলে না।'), ('there are many examples', 'Completeness-এর কাছাকাছি।')], 'Unity = একটি ভাবে বাঁধা।', True),
    ('"Coherence" means —', 'sentences follow a logical, connected order', [('the paragraph is very long', 'মেলে না।'), ('only simple words are used', 'মেলে না।'), ('the paragraph rhymes', 'মেলে না।')], 'Coherence = যৌক্তিক সংযোগ।', True),
    ('Which linking word shows contrast?', 'however', [('moreover', 'যোগ।'), ('therefore', 'ফল।'), ('for example', 'উদাহরণ।')], 'however = বৈপরীত্য।', False),
    ('Which linking word shows result?', 'therefore', [('however', 'বৈপরীত্য।'), ('for instance', 'উদাহরণ।'), ('besides', 'যোগ।')], 'therefore = ফল।', False),
    ('Which linking word adds information?', 'furthermore', [('nevertheless', 'বৈপরীত্য।'), ('consequently', 'ফল।'), ('in conclusion', 'উপসংহার।')], 'furthermore = যোগ।', False),
    ('Which phrase introduces an example?', 'for instance', [('on the other hand', 'বৈপরীত্য।'), ('as a result', 'ফল।'), ('to sum up', 'উপসংহার।')], 'for instance = উদাহরণ।', False),
    ('Which phrase best begins a concluding sentence?', 'In short,', [('For example,', 'উদাহরণ।'), ('Firstly,', 'শুরু।'), ('However,', 'বৈপরীত্য।')], 'In short/To sum up = উপসংহার।', False),
    ('In the model paragraph "A Village Market", the topic sentence is —', 'A village market is a lively meeting place for the people of rural Bangladesh.', [('Farmers bring rice, vegetables, fish and poultry.', 'Supporting detail।'), ('Thus, a village market is not only a centre of trade but also a centre of social life.', 'Concluding sentence।'), ('Buyers bargain loudly.', 'Supporting detail।')], 'প্রথম বাক্যেই মূল ভাব।', True),
    ('In the model paragraph, the concluding sentence begins with —', 'Thus', [('Besides', 'Supporting।'), ('Farmers', 'Supporting।'), ('It usually', 'Supporting।')], '"Thus, …" = সারকথা।', False),
    ('Topic: "Benefits of Trees". Which sentence breaks unity?', 'Cricket is the most popular game in Bangladesh.', [('Trees give us oxygen.', 'প্রাসঙ্গিক।'), ('Trees prevent soil erosion.', 'প্রাসঙ্গিক।'), ('Trees provide fruit and shade.', 'প্রাসঙ্গিক।')], 'বিষয়ের বাইরের বাক্য unity ভাঙে।', True),
    ('Topic: "Uses of Mobile Phones". Which sentence is irrelevant?', 'The first railway in the world was built in England.', [('We can talk to people far away.', 'প্রাসঙ্গিক।'), ('Students can find information online.', 'প্রাসঙ্গিক।'), ('Mobile banking makes payment easy.', 'প্রাসঙ্গিক।')], 'মোবাইলের সঙ্গে সম্পর্কহীন।', True),
    ('Topic: "Load-shedding". Which sentence is irrelevant?', 'The Royal Bengal Tiger lives in the Sundarbans.', [('Students cannot study at night.', 'প্রাসঙ্গিক।'), ('Factories lose production.', 'প্রাসঙ্গিক।'), ('Hot weather becomes unbearable without fans.', 'প্রাসঙ্গিক।')], 'বিষয়ের বাইরের বাক্য।', True),
    ('Best topic sentence for a paragraph about why students should exercise:', 'Regular exercise keeps students healthy and alert.', [('Many students like football.', 'খুব সংকীর্ণ।'), ('My school has a big field.', 'ব্যক্তিগত detail।'), ('Exercise was invented long ago.', 'অসত্য/অপ্রাসঙ্গিক।')], 'মূল ভাব স্পষ্ট ও পূর্ণাঙ্গ।', True),
    ('Best topic sentence for a paragraph on the effects of floods:', 'Floods cause serious damage to life and property in Bangladesh.', [('It rained yesterday.', 'নির্দিষ্ট ঘটনা, মূল ভাব নয়।'), ('Rivers are long.', 'অপ্রাসঙ্গিক।'), ('Boats are made of wood.', 'অপ্রাসঙ্গিক।')], 'বিষয়ের মূল ভাব।', True),
    ('Arrange logically: (a) Then add the tea leaves. (b) First, boil some water. (c) Finally, pour the tea into a cup. (d) Let it brew for two minutes.', 'b, a, d, c', [('a, b, c, d', 'First দিয়ে শুরু হবে।'), ('b, d, a, c', 'পাতা দেওয়ার আগে ভেজানো যায় না।'), ('c, b, a, d', 'Finally শেষে।')], 'ক্রমসূচক শব্দ: First → Then → … → Finally।', True),
    ('Arrange logically: (a) As a result, he passed with distinction. (b) Rana was a weak student. (c) He started studying regularly. (d) One day his teacher encouraged him.', 'b, d, c, a', [('a, b, c, d', 'ফল শুরুতে নয়।'), ('b, c, d, a', 'উৎসাহ আগে, পরিবর্তন পরে।'), ('d, b, a, c', 'পরিচয় আগে।')], 'পরিচয় → ঘটনা → পরিবর্তন → ফল।', True),
    ('Which is NOT a quality of a good paragraph?', 'Repetition of the same sentence', [('Unity', 'গুণ।'), ('Coherence', 'গুণ।'), ('Completeness', 'গুণ।')], 'পুনরাবৃত্তি দোষ।', False),
])

# =====================================================================
# 7.9 Letter/Application Writing
# =====================================================================
APP = ('**Application for leave of absence** — 22 October 2026 / The Headmaster, ABC High School, Dhaka. / Subject: Prayer for leave of absence for three days. / Sir, / '
       'With due respect, I beg to state that I am a student of Class X of your school. I could not attend classes from 18 to 20 October owing to a severe fever. '
       'A medical certificate is enclosed. / I, therefore, pray and hope that you would kindly grant me leave for those three days. / Yours obediently, / Rahim Uddin / Class X, Roll 12')
B.lesson(L + '9', [
    H('Letter ও Application Writing'),
    P('**Formal letter/application**-এর নির্দিষ্ট কাঠামো আছে; পরীক্ষায় অংশগুলোর নাম, ক্রম, salutation ও complimentary close নিয়ে প্রশ্ন আসে।'),
    TABLE('Formal letter-এর অংশ (ক্রম অনুযায়ী)', ['অংশ', 'উদাহরণ'], ('Date', '22 October 2026'), ('Receiver\'s address (Inside address)', 'The Headmaster, ABC High School'),
          ('Subject', 'Subject: Prayer for leave of absence'), ('Salutation', 'Sir, / Dear Sir or Madam,'), ('Body', 'মূল বক্তব্য'), ('Complimentary close', 'Yours obediently / faithfully / sincerely'), ('Signature ও নাম', 'Rahim Uddin')),
    TABLE('Salutation ↔ Complimentary close', ['Salutation', 'Close', 'কখন'],
          ('Sir, (প্রধান শিক্ষক/অধ্যক্ষকে আবেদন)', 'Yours obediently', 'বাংলাদেশের পাঠ্যবইয়ে ছাত্রের আবেদনে প্রচলিত রীতি'),
          ('Dear Sir/Madam', 'Yours faithfully', 'প্রাপকের নাম জানা নেই (ব্রিটিশ রীতি)'), ('Dear Mr Rahman', 'Yours sincerely', 'প্রাপকের নাম জানা (ব্রিটিশ রীতি)'),
          ('Dear Rina (বন্ধু)', 'Yours ever / Your loving friend', 'Informal')),
    H('মডেল application'), P(APP),
    TABLE('Email-এর পরিভাষা', ['শব্দ', 'অর্থ'], ('Subject line', 'চিঠির বিষয় এক লাইনে'), ('CC (carbon copy)', 'অন্যদের কপি — সবাই দেখতে পায়'), ('BCC (blind carbon copy)', 'গোপন কপি — অন্য প্রাপকরা দেখে না'), ('Attachment', 'সংযুক্ত ফাইল')),
    MNEM(('"নাম জানা → sincerely; নাম অজানা → faithfully"', 'Close', 'S-S: Sincerely-Surname জানা।'), ('"D-R-S-S-B-C-S"', 'অংশের ক্রম', 'Date, Receiver, Subject, Salutation, Body, Close, Signature।')),
    MISTAKES('"Yours faithfully" ব্যবহার করলে "Dear Mr …" নয় — "Dear Sir/Madam"।', 'Formal চিঠিতে contraction (don\'t, I\'m) এড়িয়ে চলুন।', 'Complimentary close-এ "Yours" বড় হাতের Y, পরের শব্দ ছোট হাতের।'),
    SUMMARY('অংশ: Date → Receiver → Subject → Salutation → Body → Close → Signature', 'faithfully (নাম অজানা), sincerely (নাম জানা), obediently (ছাত্রের আবেদন)', 'CC দৃশ্যমান, BCC গোপন'),
    UNI(UNIT_EN),
], S)
FQ(L + '9', 'অংশের ক্রম ও salutation–close জোড়া মনে রাখুন।', 'Letter/Application সারণি।', [
    ('An application to the Headmaster usually begins with the salutation —', 'Sir,', [('Dear friend,', 'Informal।'), ('Hello Headmaster,', 'অনানুষ্ঠানিক।'), ('My dear,', 'Informal।')], 'আবেদনে "Sir,"।', False),
    ('In a student\'s application (Bangladesh textbook style), the usual complimentary close is —', 'Yours obediently', [('Your loving friend', 'Informal।'), ('Best wishes', 'Informal।'), ('Cheers', 'Informal।')], 'ছাত্রের আবেদনে Yours obediently প্রচলিত।', True),
    ('If a letter begins "Dear Sir or Madam", it should end with —', 'Yours faithfully', [('Yours sincerely', 'নাম জানা হলে।'), ('Yours lovingly', 'Informal।'), ('Your friend', 'Informal।')], 'নাম অজানা → faithfully।', True),
    ('If a letter begins "Dear Mr Karim", it should end with —', 'Yours sincerely', [('Yours faithfully', 'নাম অজানা হলে।'), ('Your obedient', 'অসম্পূর্ণ।'), ('Love', 'Informal।')], 'নাম জানা → sincerely।', True),
    ('The purpose of the "Subject" line is to —', 'state the topic of the letter briefly', [('greet the receiver', 'Salutation-এর কাজ।'), ('end the letter', 'Close-এর কাজ।'), ('give the date', 'Date-এর কাজ।')], 'Subject = বিষয় এক লাইনে।', False),
    ('Which part comes immediately before the body of a formal letter?', 'the salutation', [('the signature', 'শেষে।'), ('the complimentary close', 'Body-র পরে।'), ('the enclosure note', 'শেষে।')], 'Salutation → Body।', False),
    ('Which part comes immediately after the body?', 'the complimentary close', [('the subject', 'আগে।'), ('the date', 'শুরুতে।'), ('the inside address', 'আগে।')], 'Body → Close → Signature।', False),
    ('"With due respect, I beg to state that…" is a typical opening of —', 'a formal application', [('a love letter', 'মেলে না।'), ('a newspaper report', 'মেলে না।'), ('a story', 'মেলে না।')], 'আবেদনপত্রের প্রচলিত সূচনা।', False),
    ('In email, "BCC" means —', 'blind carbon copy', [('basic copy check', 'অশুদ্ধ।'), ('business carbon copy', 'অশুদ্ধ।'), ('back copy confirm', 'অশুদ্ধ।')], 'BCC = গোপন কপি।', False),
    ('Recipients in the BCC field —', 'are hidden from other recipients', [('are shown to everyone', 'CC-তে দেখা যায়।'), ('cannot read the email', 'পড়তে পারে।'), ('must reply first', 'মেলে না।')], 'BCC গোপন।', True),
    ('"CC" in email stands for —', 'carbon copy', [('closed copy', 'অশুদ্ধ।'), ('common contact', 'অশুদ্ধ।'), ('copy check', 'অশুদ্ধ।')], 'CC = carbon copy।', False),
    ('In the model application, why is a medical certificate mentioned?', 'as proof of the illness', [('to request money', 'মেলে না।'), ('to change class', 'মেলে না।'), ('to complain', 'মেলে না।')], 'Enclosed = প্রমাণ সংযুক্ত।', False),
    ('In the model application, what is requested?', 'leave for three days', [('a scholarship', 'মেলে না।'), ('a transfer certificate', 'মেলে না।'), ('a new uniform', 'মেলে না।')], 'Subject: leave of absence for three days।', False),
    ('Which word means "a document sent along with a letter"?', 'enclosure', [('salutation', 'সম্বোধন।'), ('signature', 'স্বাক্ষর।'), ('subject', 'বিষয়।')], 'Enclosure = সংযুক্তি।', False),
    ('A letter to a newspaper editor usually begins with —', 'Sir,', [('Dear friend,', 'Informal।'), ('Hi Editor,', 'অনানুষ্ঠানিক।'), ('My dear Editor,', 'অনানুষ্ঠানিক।')], 'সম্পাদককে চিঠি: "Sir,"।', False),
    ('A letter to the editor normally ends with —', 'Yours faithfully', [('Yours lovingly', 'Informal।'), ('Your dear', 'অশুদ্ধ।'), ('See you', 'Informal।')], 'Formal, নাম অজানা → faithfully।', False),
    ('Which is a suitable close for a letter to a friend?', 'Your loving friend', [('Yours obediently', 'আবেদনে।'), ('Yours faithfully', 'Formal।'), ('Yours respectfully, Sir', 'Formal।')], 'Informal close।', False),
    ('Which should be avoided in a formal letter?', 'contractions like "don\'t" and "I\'m"', [('a subject line', 'রাখা উচিত।'), ('a clear salutation', 'রাখা উচিত।'), ('the date', 'রাখা উচিত।')], 'Formal চিঠিতে পূর্ণরূপ।', True),
    ('Choose the correctly written complimentary close.', 'Yours faithfully,', [('Your\'s faithfully,', 'Yours-এ apostrophe নেই।'), ('Yours Faithfully,', 'দ্বিতীয় শব্দ ছোট হাতের।'), ('yours faithfully,', 'প্রথম অক্ষর বড় হাতের।')], 'Yours (Y বড়) + faithfully (ছোট), শেষে comma।', True),
    ('The correct order of the opening parts of a formal application is —', 'Date → Receiver\'s address → Subject → Salutation', [('Salutation → Date → Subject → Receiver', 'ক্রম ভুল।'), ('Subject → Salutation → Date → Receiver', 'ক্রম ভুল।'), ('Receiver → Salutation → Date → Subject', 'ক্রম ভুল।')], 'D-R-S-S।', True),
])

B.autofill_cards(12)
B.save('b7b', 'en-b7b')
