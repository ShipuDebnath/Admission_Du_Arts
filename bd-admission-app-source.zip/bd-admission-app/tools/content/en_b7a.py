#!/usr/bin/env python3
"""English — Block 7 (অংশ ১): Sentence Correction, Synonyms & Antonyms, One-word Substitution, Analogy
ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে।"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb7a', 'en', 9701)
Q = B.q
S = ['প্রচলিত English grammar ও learner\'s dictionary-র ব্যবহার']
L = 'en-7-'

# =====================================================================
# 7.4 Sentence Correction
# =====================================================================
SC = [('Each', 'Each of the students has a book.', [('Each of the students have a book.', 'Each → singular verb।'), ('Each of the students are having a book.', 'Each singular; have (অধিকার) continuous হয় না।'), ('Each of the student has a book.', 'of-এর পরে plural noun।')]),
      ('One of', 'One of my friends is a doctor.', [('One of my friends are a doctor.', 'Subject "One" → is।'), ('One of my friend is a doctor.', 'of-এর পরে plural।'), ('One of my friends were a doctor.', 'Plural ও tense ভুল।')]),
      ('since', 'I have known him since 2010.', [('I know him since 2010.', 'since + এখনো → present perfect।'), ('I am knowing him since 2010.', 'know continuous হয় না।'), ('I knew him since 2010.', 'since-এর সঙ্গে মূল বাক্যে present perfect।')]),
      ('look forward to', 'I look forward to hearing from you.', [('I look forward to hear from you.', 'to এখানে preposition → V-ing।'), ('I look forward for hearing from you.', 'look forward to।'), ('I look forward to heard from you.', 'অশুদ্ধ রূপ।')]),
      ('adjective order', 'She bought a beautiful red silk dress.', [('She bought a red beautiful silk dress.', 'Opinion আগে, colour পরে।'), ('She bought a silk red beautiful dress.', 'Material শেষে।'), ('She bought a beautiful silk red dress.', 'Colour, material-এর আগে।')]),
      ('article', 'He is an honest man.', [('He is honest man.', 'Countable singular-এর আগে article লাগে।'), ('He is a honest man.', 'h নীরব → an।'), ('He is an honest men.', 'an + singular।')]),
      ('comparison', 'He is better than any other boy in the class.', [('He is better than any boy in the class.', '"other" বাদ।'), ('He is more better than any other boy in the class.', 'Double comparison।'), ('He is best than any other boy in the class.', 'than-এর সঙ্গে comparative।')]),
      ('superior', 'This pen is superior to that one.', [('This pen is superior than that one.', 'superior to।'), ('This pen is more superior to that one.', 'Double comparison।'), ('This pen is superior from that one.', 'superior to।')]),
      ('married', 'She is married to a doctor.', [('She is married with a doctor.', 'married to।'), ('She is married by a doctor.', 'অর্থ বদলে যায়।'), ('She is married at a doctor.', 'অশুদ্ধ।')]),
      ('between you and me', 'Between you and me, he is wrong.', [('Between you and I, he is wrong.', 'preposition-এর পরে objective (me)।'), ('Between you and myself, he is wrong.', 'Reflexive চলে না।'), ('Between yourself and me, he is wrong.', 'Reflexive চলে না।')]),
      ('ago', 'I met him two years ago.', [('I have met him two years ago.', 'ago → past indefinite।'), ('I had met him two years ago.', 'অপ্রয়োজনীয় past perfect।'), ('I am meeting him two years ago.', 'অশুদ্ধ।')]),
      ('lest', 'Walk carefully lest you should fall.', [('Walk carefully lest you should not fall.', 'lest-এর সঙ্গে not নয়।'), ('Walk carefully lest you will fall.', 'lest + should।'), ('Walk carefully lest you fell.', 'lest + should + V1।')]),
      ('hardly … when', 'Hardly had he arrived when it began to rain.', [('Hardly had he arrived than it began to rain.', 'Hardly-র সঙ্গে when।'), ('Hardly he had arrived when it began to rain.', 'Inversion লাগবে: Hardly had he।'), ('Hardly had he arrive when it began to rain.', 'had + V3।')]),
      ('redundancy', 'He returned home early.', [('He returned back home early.', 'return-এর পরে back অপ্রয়োজনীয়।'), ('He return back home early.', 'Tense ও redundancy দুটোই ভুল।'), ('He returned back again home early.', 'অপ্রয়োজনীয় শব্দ।')]),
      ('linking verb', 'The flower smells sweet.', [('The flower smells sweetly.', 'Linking verb + adjective।'), ('The flower smell sweet.', 'Agreement: smells।'), ('The flower smells sweetness.', 'Adjective লাগবে।')]),
      ('causative make', 'He made me laugh.', [('He made me to laugh.', 'make + V1 (to নেই)।'), ('He made me laughing.', 'অশুদ্ধ।'), ('He made me laughed.', 'অশুদ্ধ।')]),
      ('gerund', 'I enjoy swimming in the river.', [('I enjoy to swim in the river.', 'enjoy + V-ing।'), ('I enjoy swim in the river.', 'অশুদ্ধ।'), ('I enjoy for swimming in the river.', 'অপ্রয়োজনীয় for।')]),
      ('uncountable', 'He gave me some useful advice.', [('He gave me some useful advices.', 'advice-এর plural নেই।'), ('He gave me an useful advice.', '"ইউ" ধ্বনি → a; আর advice uncountable।'), ('He gave me a useful advices.', 'দুটি ভুল।')]),
      ('police', 'The police have arrested the thief.', [('The police has arrested the thief.', 'police → plural।'), ('The police is arresting the thief.', 'police → plural।'), ('The police was arrested the thief.', 'অর্থ ও গঠন ভুল।')]),
      ('many a', 'Many a student has failed.', [('Many a student have failed.', 'Many a → singular।'), ('Many a students has failed.', 'Many a + singular noun।'), ('Many a student are failed.', 'অশুদ্ধ।')]),
      ('tag (Let\'s)', 'Let\'s go, shall we?', [('Let\'s go, will you?', 'Let\'s → shall we।'), ('Let\'s go, don\'t we?', 'অশুদ্ধ।'), ('Let\'s go, shall us?', 'Subject pronoun we।')]),
      ('would rather', 'I would rather you went now.', [('I would rather you go now.', 'অন্যজন → past (went)।'), ('I would rather you will go now.', 'অশুদ্ধ।'), ('I would rather you gone now.', 'অশুদ্ধ।')]),
      ('it is time', 'It is time we started.', [('It is time we start.', 'It is time + past।'), ('It is time we starting.', 'অশুদ্ধ।'), ('It is time we have started.', 'অশুদ্ধ।')]),
      ('conditional', 'If I were rich, I would buy a car.', [('If I was rich, I will buy a car.', 'অবাস্তব কল্পনা → were … would।'), ('If I am rich, I would buy a car.', 'Tense মেলে না।'), ('If I were rich, I will buy a car.', 'were-এর সঙ্গে would।')]),
      ('embedded question', 'Can you tell me where the station is?', [('Can you tell me where is the station?', 'Embedded question-এ statement order।'), ('Can you tell me where does the station?', 'অশুদ্ধ।'), ('Can you tell me the station where is?', 'অশুদ্ধ।')]),
      ('double negative', 'I don\'t have any money.', [('I don\'t have no money.', 'দুটি negative একসাথে নয়।'), ('I haven\'t no money.', 'Double negative।'), ('I don\'t have none money.', 'অশুদ্ধ।')])]
B.lesson(L + '4', [
    H('Sentence Correction'),
    P('চারটি বাক্যের মধ্যে শুদ্ধটি বাছাই বা ভুল অংশ খুঁজে বের করা — এখানে আগের সব grammar একসাথে কাজে লাগে। ধাপে ধাপে চেক করুন: **subject-verb agreement → tense → preposition → article → word order → redundancy/double negative**।'),
    TABLE('দ্রুত চেকলিস্ট', ['কী দেখবেন', 'সাধারণ ভুল', 'শুদ্ধ'],
          ('Agreement', 'Each of them have', 'Each of them **has**'), ('Tense সংকেত', 'I have met him yesterday', 'I **met** him yesterday'),
          ('Preposition', 'married with', 'married **to**'), ('Article', 'a honest man', '**an** honest man'), ('Comparison', 'more better / superior than', 'better / superior **to**'),
          ('Verb form', 'made me to laugh; enjoy to swim', 'made me **laugh**; enjoy **swimming**'), ('Pronoun case', 'between you and I', 'between you and **me**'),
          ('Word order', 'tell me where is the station', 'tell me where **the station is**'), ('Redundancy', 'returned back', '**returned**'), ('Double negative', 'don\'t have no', 'don\'t have **any**')),
    MNEM(('"S-T-P-A-W-R" — Subject, Tense, Preposition, Article, Word order, Redundancy', 'চেকের ক্রম', 'প্রতিটি বাক্যে এই ছয়টি দেখে নিন।'),),
    MISTAKES('প্রথম ভুল পেয়েই থামবেন না — সঠিক অপশনে কোনো ভুল থাকে না, বাকি তিনটিতে অন্তত একটি থাকে।'),
    SUMMARY('Agreement, tense, preposition, article, word order, redundancy — ছয় ধাপে চেক', 'আগের পাঠগুলোর নিয়মই এখানে প্রয়োগ'),
    UNI(UNIT_EN),
], S)
for t, a, w in SC:
    Q(L + '4', 2, f'Choose the correct sentence ({t}).', a, w, f'শুদ্ধ: {a}', 'S-T-P-A-W-R চেকলিস্ট ধরে প্রতিটি অপশন যাচাই করুন।', 'দ্রুত চেকলিস্ট সারণি।', trap=True)

# =====================================================================
# 7.5 Synonyms & Antonyms (mixed)
# =====================================================================
vocab_lesson(B, L + '5', 'মিশ্র (বহুল-প্রচলিত)', [
    ('abstain', 'v', 'বিরত থাকা', 'to choose not to do something', ['refrain', 'forbear', 'desist'], ['indulge', 'partake'], 'avoid'),
    ('adversity', 'n', 'দুর্দশা, বিপদ', 'difficult conditions', ['hardship', 'misfortune', 'distress'], ['prosperity', 'fortune'], 'trouble'),
    ('ambiguous', 'adj', 'দ্ব্যর্থক', 'open to more than one meaning', ['equivocal', 'unclear', 'vague'], ['unambiguous', 'clear'], 'unclear'),
    ('amicable', 'adj', 'বন্ধুত্বপূর্ণ', 'friendly and peaceful', ['friendly', 'cordial', 'harmonious'], ['hostile', 'unfriendly'], 'friend'),
    ('arrogant', 'adj', 'উদ্ধত', 'having too high an opinion of oneself', ['haughty', 'conceited', 'proud'], ['humble', 'modest'], 'pride'),
    ('belligerent', 'adj', 'যুদ্ধংদেহী', 'eager to fight', ['aggressive', 'combative', 'hostile'], ['peaceable', 'friendly'], 'fight'),
    ('brittle', 'adj', 'ভঙ্গুর', 'hard but easily broken', ['fragile', 'breakable', 'delicate'], ['flexible', 'tough'], 'weak'),
    ('cease', 'v', 'থামা, বন্ধ হওয়া', 'to come to an end', ['stop', 'halt', 'end'], ['continue', 'begin'], 'stop'),
    ('compassion', 'n', 'সহানুভূতি', 'concern for others\' suffering', ['sympathy', 'pity', 'mercy'], ['cruelty', 'indifference'], 'kind'),
    ('concur', 'v', 'একমত হওয়া', 'to agree', ['agree', 'accord', 'assent'], ['disagree', 'differ'], 'agree'),
    ('conspicuous', 'adj', 'সহজে চোখে পড়ে এমন', 'clearly visible', ['noticeable', 'prominent', 'obvious'], ['inconspicuous', 'hidden'], 'see'),
    ('diminish', 'v', 'কমে যাওয়া', 'to become less', ['decrease', 'lessen', 'dwindle'], ['increase', 'grow'], 'less'),
    ('enhance', 'v', 'বৃদ্ধি/উন্নত করা', 'to improve the quality of', ['improve', 'boost', 'heighten'], ['reduce', 'impair'], 'more'),
    ('exaggerate', 'v', 'অতিরঞ্জিত করা', 'to make seem larger than it is', ['overstate', 'magnify', 'inflate'], ['understate', 'minimise'], 'over'),
    ('feasible', 'adj', 'সম্ভবপর', 'possible to do', ['practicable', 'viable', 'achievable'], ['impossible', 'impractical'], 'possible'),
    ('frail', 'adj', 'দুর্বল, ক্ষীণ', 'weak and delicate', ['weak', 'feeble', 'infirm'], ['strong', 'robust'], 'weak'),
    ('humane', 'adj', 'মানবিক, দয়ালু', 'showing kindness', ['compassionate', 'kind', 'benevolent'], ['inhumane', 'cruel'], 'kind'),
    ('inherent', 'adj', 'সহজাত', 'existing as a natural part', ['innate', 'intrinsic', 'inborn'], ['acquired', 'extrinsic'], 'innate'),
    ('modest', 'adj', 'বিনয়ী', 'not boastful', ['humble', 'unassuming', 'unpretentious'], ['arrogant', 'boastful'], 'pride'),
    ('novel', 'adj', 'অভিনব', 'new and unusual', ['original', 'innovative', 'fresh'], ['conventional', 'old'], 'new'),
    ('prosper', 'v', 'সমৃদ্ধ হওয়া', 'to succeed and flourish', ['flourish', 'thrive', 'boom'], ['fail', 'decline'], 'grow'),
    ('rigid', 'adj', 'অনমনীয়', 'stiff; not able to bend', ['stiff', 'inflexible', 'strict'], ['flexible', 'pliable'], 'stiff'),
    ('scarce', 'adj', 'দুষ্প্রাপ্য', 'not enough; rare', ['rare', 'scanty', 'insufficient'], ['plentiful', 'abundant'], 'rare'),
    ('vivid', 'adj', 'উজ্জ্বল, জীবন্ত', 'very bright; clear and lively', ['bright', 'graphic', 'lively'], ['dull', 'faint'], 'bright')],
    9710,
    roots={'inherent': 'Latin inhaerere (লেগে থাকা) — ভেতরেই লেগে আছে।', 'belligerent': 'Latin bellum (যুদ্ধ) — bellicose একই মূল।', 'concur': 'con (একসাথে) + currere (দৌড়ানো) — একসাথে চলা।',
           'ambiguous': 'Latin ambi (দুই দিকে) — ambivalent একই মূল।', 'compassion': 'com (সঙ্গে) + passio (কষ্ট) — অন্যের কষ্টে শরিক।'},
    traps=('novel', 'humane', 'inherent', 'conspicuous'),
    mnem=(('"humane ≠ human; novel (adj) ≠ novel (উপন্যাস)"', 'একই রকম দেখতে', 'adj হিসেবে novel = অভিনব।'),),
    mistakes=('**humane** (দয়ালু) ≠ **human** (মানুষ)।', '**conspicuous** (চোখে পড়ে) ≠ **inconspicuous**।'))

# =====================================================================
# 7.6 One-word Substitution
# =====================================================================
OW = [('One who believes in God', 'theist', 'theos = ঈশ্বর'), ('One who does not believe in God', 'atheist', 'a = না + theos'),
      ('One who is not sure whether God exists', 'agnostic', 'a = না + gnosis = জ্ঞান'), ('One who hates mankind', 'misanthrope', 'miso = ঘৃণা + anthropos = মানুষ'),
      ('One who loves mankind', 'philanthropist', 'philo = ভালোবাসা + anthropos'), ('One who hates women', 'misogynist', 'miso + gyne = নারী'),
      ('Life story written by oneself', 'autobiography', 'auto = নিজে + bio = জীবন + graph = লেখা'), ('Life story written by another', 'biography', 'bio + graphy'),
      ('Government by the people', 'democracy', 'demos = জনগণ + kratos = শাসন'), ('Government by a few', 'oligarchy', 'oligos = অল্প + arkhein = শাসন'),
      ('Absolute rule by one person', 'autocracy', 'auto = নিজে + kratos'), ('Rule by officials', 'bureaucracy', 'bureau = দপ্তর + kratos'),
      ('One who knows everything', 'omniscient', 'omni = সব + scire = জানা'), ('Present everywhere', 'omnipresent', 'omni + present'),
      ('An animal that eats both plants and flesh', 'omnivorous', 'omni + vorare = খাওয়া'), ('An animal that eats flesh', 'carnivorous', 'carnis = মাংস + vorare'),
      ('An animal that eats plants', 'herbivorous', 'herba = ঘাস + vorare'), ('That which cannot be read', 'illegible', 'il = না + legere = পড়া'),
      ('One who cannot be corrected', 'incorrigible', 'in = না + corrigere = শোধরানো'), ('That which cannot be avoided', 'inevitable', 'in = না + evitare = এড়ানো'),
      ('That which cannot be heard', 'inaudible', 'in = না + audire = শোনা'), ('That which cannot be cured', 'incurable', 'in = না + cure'),
      ('The study of birds', 'ornithology', 'ornis = পাখি + logy = বিদ্যা'), ('The study of insects', 'entomology', 'entomon = পতঙ্গ + logy'),
      ('One who walks in sleep', 'somnambulist', 'somnus = ঘুম + ambulare = হাঁটা'), ('Fear of water', 'hydrophobia', 'hydro = পানি + phobia = ভয়'),
      ('Fear of heights', 'acrophobia', 'acro = উচ্চ + phobia'), ('A person who speaks many languages', 'polyglot', 'poly = বহু + glotta = ভাষা'),
      ('Murder of a king', 'regicide', 'rex/regis = রাজা + cide = হত্যা'), ('Murder of one\'s father', 'patricide', 'pater = পিতা + cide'),
      ('Murder of one\'s mother', 'matricide', 'mater = মাতা + cide'), ('One who lives on others', 'parasite', 'অন্যের ওপর নির্ভর করে বাঁচে'),
      ('A place where birds are kept', 'aviary', 'avis = পাখি'), ('A place where bees are kept', 'apiary', 'apis = মৌমাছি'),
      ('A place where dead bodies are kept', 'mortuary', 'mors/mortis = মৃত্যু'), ('One who collects stamps', 'philatelist', 'philo = ভালোবাসা + ateleia = মাশুল থেকে অব্যাহতি (ডাকটিকিট = আগেই দেওয়া মাশুল)'),
      ('One who collects coins', 'numismatist', 'nomisma = মুদ্রা')]
B.lesson(L + '6', [
    H('One-word Substitution'),
    P('একটি বাক্যাংশের জায়গায় একটি মাত্র শব্দ বসানো। **শব্দমূল** জানলে মনে রাখা সহজ: -cide = হত্যা, -logy = বিদ্যা, -phobia = ভয়, -cracy = শাসন, omni- = সব, in-/il- = না।'),
    TABLE('মূল উপাদান', ['উপাদান', 'অর্থ', 'উদাহরণ'], ('-cide', 'হত্যা', 'regicide, patricide'), ('-logy', 'বিদ্যা', 'ornithology, entomology'), ('-phobia', 'ভয়', 'hydrophobia, acrophobia'),
          ('-cracy / -archy', 'শাসন', 'democracy, oligarchy'), ('-vorous', 'খাদ্যভোজী', 'carnivorous, herbivorous'), ('miso- / philo-', 'ঘৃণা / ভালোবাসা', 'misanthrope / philanthropist'),
          ('omni-', 'সব', 'omniscient, omnipresent'), ('in- / il- / a-', 'না', 'incurable, illegible, atheist')),
    TABLE('One-word তালিকা (কলাম-লুকাও)', ['বাক্যাংশ', 'শব্দমূল', 'One word'], *[(a, r, b) for a, b, r in OW]),
    MNEM(('"miso ঘৃণা করে, philo ভালোবাসে; anthropos মানুষ, gyne নারী"', 'miso/philo', 'misanthrope, philanthropist, misogynist।'), ('"avi-পাখি, api-মৌমাছি, mort-মৃত"', '-ary (স্থান)', 'aviary, apiary, mortuary।')),
    MISTAKES('**agnostic** (নিশ্চিত নয়) ≠ **atheist** (বিশ্বাস করে না)।', '**illegible** (পড়া যায় না) ≠ **ineligible** (অযোগ্য)।', '**apiary** (মৌমাছি) ≠ **aviary** (পাখি)।'),
    SUMMARY('শব্দমূল দিয়ে one-word', f'{len(OW)}টি বহুল-প্রচলিত one-word'),
    UNI(UNIT_EN),
], S)
for i, (a, b, r) in enumerate(OW):
    pool = [x[1] for j, x in enumerate(OW) if j != i]
    random.Random(9720 + i).shuffle(pool)
    Q(L + '6', 2, f'One word for "{a}" —', b, [(x, 'এটি অন্য বাক্যাংশের one-word।') for x in pool[:3]], f'{a} = {b}।', 'শব্দমূল ভেঙে দেখুন।', f'শব্দমূল: {r}',
      trap=b in ('agnostic', 'apiary', 'aviary', 'illegible', 'oligarchy', 'misogynist'))
    B.card(L + '6', a, f'{b}\n\nশব্দমূল: {r}')

# =====================================================================
# 7.7 Analogy
# =====================================================================
AN = [('Doctor : Hospital :: Teacher : ?', 'School', ['Student', 'Book', 'Lesson'], 'কর্মী : কর্মস্থল'),
      ('Cow : Calf :: Dog : ?', 'Puppy', ['Kitten', 'Cub', 'Foal'], 'প্রাণী : শাবক'), ('Bird : Nest :: Bee : ?', 'Hive', ['Den', 'Stable', 'Kennel'], 'প্রাণী : বাসস্থান'),
      ('Pen : Write :: Knife : ?', 'Cut', ['Sharp', 'Kitchen', 'Steel'], 'যন্ত্র : কাজ'), ('Hot : Cold :: Up : ?', 'Down', ['High', 'Top', 'Sky'], 'বিপরীত শব্দ'),
      ('Lion : Roar :: Dog : ?', 'Bark', ['Neigh', 'Bleat', 'Hiss'], 'প্রাণী : ডাক'), ('Author : Book :: Composer : ?', 'Symphony', ['Orchestra', 'Piano', 'Audience'], 'স্রষ্টা : সৃষ্টি'),
      ('Water : Thirst :: Food : ?', 'Hunger', ['Taste', 'Kitchen', 'Plate'], 'যা নিবারণ করে : অভাব'), ('Eye : See :: Ear : ?', 'Hear', ['Sound', 'Music', 'Head'], 'অঙ্গ : কাজ'),
      ('Carpenter : Wood :: Tailor : ?', 'Cloth', ['Needle', 'Shop', 'Shirt'], 'কারিগর : উপাদান'), ('Glove : Hand :: Sock : ?', 'Foot', ['Shoe', 'Leg', 'Toe'], 'পোশাক : অঙ্গ'),
      ('Brave : Coward :: Generous : ?', 'Miser', ['Rich', 'Kind', 'Donor'], 'বিপরীত গুণের মানুষ'), ('Hour : Minute :: Minute : ?', 'Second', ['Day', 'Clock', 'Time'], 'বড় একক : ছোট একক'),
      ('Painter : Brush :: Writer : ?', 'Pen', ['Book', 'Paper', 'Story'], 'কারিগর : যন্ত্র'), ('Horse : Neigh :: Snake : ?', 'Hiss', ['Bark', 'Roar', 'Bray'], 'প্রাণী : ডাক'),
      ('Grape : Raisin :: Plum : ?', 'Prune', ['Jam', 'Juice', 'Seed'], 'তাজা ফল : শুকনো রূপ'), ('Captain : Ship :: Pilot : ?', 'Aeroplane', ['Airport', 'Sky', 'Passenger'], 'চালক : যান'),
      ('Ocean : Water :: Desert : ?', 'Sand', ['Camel', 'Heat', 'Oasis'], 'স্থান : প্রধান উপাদান'), ('Dhaka : Bangladesh :: Tokyo : ?', 'Japan', ['China', 'Korea', 'Asia'], 'রাজধানী : দেশ'),
      ('Book : Library :: Painting : ?', 'Gallery', ['Artist', 'Canvas', 'Frame'], 'বস্তু : সংরক্ষণস্থল')]
B.lesson(L + '7', [
    H('Analogy (সাদৃশ্য)'),
    P('**A : B :: C : ?** — A আর B-র মধ্যে যে সম্পর্ক, C আর উত্তরের মধ্যেও ঠিক সেই সম্পর্ক। কৌশল: প্রথম জোড়ার সম্পর্ককে একটি বাক্যে বলুন ("ডাক্তার কাজ করেন হাসপাতালে"), তারপর C দিয়ে একই বাক্য বানান।'),
    TABLE('সম্পর্কের ধরন', ['ধরন', 'উদাহরণ'], ('কর্মী : কর্মস্থল', 'Doctor : Hospital'), ('প্রাণী : শাবক', 'Cow : Calf'), ('প্রাণী : বাসস্থান', 'Bee : Hive'),
          ('প্রাণী : ডাক', 'Lion : Roar'), ('যন্ত্র : কাজ', 'Knife : Cut'), ('কারিগর : উপাদান / যন্ত্র', 'Carpenter : Wood / Painter : Brush'),
          ('বিপরীত', 'Hot : Cold'), ('অংশ/একক', 'Hour : Minute'), ('রাজধানী : দেশ', 'Dhaka : Bangladesh')),
    MNEM(('"সম্পর্কটা বাক্যে বলুন"', 'Analogy-র কৌশল', '"Pen দিয়ে লেখা হয়" → "Knife দিয়ে কাটা হয়"।'),),
    MISTAKES('যন্ত্র আর উপাদান গুলিয়ে ফেলবেন না: Carpenter : Wood (উপাদান) — তাই Tailor : Cloth, Needle নয়।', 'একই বিষয়ের শব্দ দেখলেই বাছবেন না — সম্পর্ক মেলান।'),
    SUMMARY('A : B :: C : ? — একই সম্পর্ক', 'সম্পর্ক বাক্যে বলুন, তারপর মেলান'),
    UNI(UNIT_EN),
], S)
for s, a, wr, rel in AN:
    Q(L + '7', 2, s, a, [(x, f'সম্পর্ক ({rel}) মেলে না।') for x in wr], f'সম্পর্ক: {rel} → {a}।', 'প্রথম জোড়ার সম্পর্ক বাক্যে বলুন।', 'সম্পর্কের ধরন সারণি।',
      trap=a in ('Cloth', 'Symphony', 'Prune', 'Hunger'))

B.autofill_cards(12)
B.save('b7a', 'en-b7a')
