#!/usr/bin/env python3
"""চার্ট ডেটা লেখার সহায়ক — src/data/charts/<name>.json লেখে ও স্কিমা যাচাই করে।"""
import json, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
TOC = json.load(open(os.path.join(ROOT, 'src', 'data', 'toc.json'), encoding='utf-8'))
LIDS = {l['id'] for s in TOC['subjects'] for c in s['ch'] for l in c['l']}
KINDS = {'grid', 'flow', 'steps', 'ladder', 'pyramid', 'tree', 'cards', 'timeline', 'tense', 'nest', 'relmap', 'zones', 'bars', 'svg', 'note', 'list'}
SVGS = {'placePrep', 'topology', 'fiber', 'gate', 'adder', 'fcSymbols', 'fcExample', 'er', 'cipher', 'venn', 'compass', 'clock', 'supplyDemand', 'ppf',
        'circularFlow', 'rivers', 'convWork', 'series', 'cipherLive'}

def G(cols, *rows, h=None, stack=False, note=None):
    for r in rows: assert len(r) == len(cols), (cols, r)
    d = {'k': 'grid', 'cols': list(cols), 'rows': [list(r) for r in rows]}
    if h: d['h'] = h
    if stack: d['stack'] = 1
    if note: d['note'] = note
    return d
def Qn(q, *branches): return {'q': q, 'b': [{'l': l, 'n': n} for l, n in branches]}
def An(a, ex=None):
    d = {'a': a}
    if ex: d['ex'] = ex
    return d
def FLOW(root, h=None): return dict({'k': 'flow', 'root': root}, **({'h': h} if h else {}))
def STEPS(*x, h=None):
    out = []
    for s in x:
        d = {'t': s[0]}
        if len(s) > 1 and s[1]: d['d'] = s[1]
        if len(s) > 2 and s[2]: d['ex'] = s[2]
        out.append(d)
    return dict({'k': 'steps', 'x': out}, **({'h': h} if h else {}))
def LADDER(*rows, h=None, fl=None, tl=None):
    d = {'k': 'ladder', 'x': [list(r) for r in rows]}
    if h: d['h'] = h
    if fl: d['fl'], d['tl'] = fl, tl
    return d
def PYR(*x, h=None):
    return dict({'k': 'pyramid', 'x': [dict(zip(('t', 'd', 'ex'), l)) for l in x]}, **({'h': h} if h else {}))
def N(t, d=None, *c):
    n = {'t': t}
    if d: n['d'] = d
    if c: n['c'] = list(c)
    return n
def TREE(root, h=None): return dict({'k': 'tree', 'root': root}, **({'h': h} if h else {}))
def NEST(root, h=None): return dict({'k': 'nest', 'root': root}, **({'h': h} if h else {}))
def CARD(h, b=None, ex=None, tag=None, svg=None):
    d = {'h': h}
    if b: d['b'] = b
    if ex: d['ex'] = ex
    if tag: d['tag'] = tag
    if svg: d['svg'] = svg
    return d
def CARDS(*x, h=None, wide=False):
    d = {'k': 'cards', 'x': list(x)}
    if h: d['h'] = h
    if wide: d['wide'] = 1
    return d
def TL(*x, h=None): return dict({'k': 'timeline', 'x': [dict(zip(('y', 't', 'd'), e)) for e in x]}, **({'h': h} if h else {}))
def SVG(name, p=None, h=None, cap=None):
    assert name in SVGS, name
    d = {'k': 'svg', 'name': name}
    if p: d['p'] = p
    if h: d['h'] = h
    if cap: d['cap'] = cap
    return d
def NOTE(x, tone='info'): return {'k': 'note', 'x': x, 'tone': tone}
def LIST(*x, h=None, o=False):
    d = {'k': 'list', 'x': list(x)}
    if h: d['h'] = h
    if o: d['o'] = 1
    return d

def chart(n, id, sub, t, d, lids, intro, parts, keys=(), ex=(), tip=None, src=(), tags=''):
    for l in lids: assert l in LIDS, (id, l)
    for p in parts: assert p['k'] in KINDS, (id, p['k'])
    assert ex, f'{id}: ব্যতিক্রম অংশ ফাঁকা'
    c = {'n': n, 'id': id, 'sub': sub, 't': t, 'd': d, 'lids': list(lids), 'intro': intro, 'parts': list(parts), 'keys': list(keys), 'ex': list(ex)}
    if tip: c['tip'] = tip
    if src: c['src'] = list(src)
    if tags: c['tags'] = tags
    return c

def save(name, charts):
    ns = [c['n'] for c in charts]
    assert len(ns) == len(set(ns)), ns
    p = os.path.join(ROOT, 'src', 'data', 'charts', name + '.json')
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump({'charts': charts}, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'charts/{name}: {len(charts)}টি চার্ট — ' + ', '.join(str(c['n']) for c in charts))

SRC_EN = ['A. J. Thomson & A. V. Martinet — A Practical English Grammar (Oxford University Press)',
          'Raymond Murphy — English Grammar in Use (Cambridge University Press)', 'NCTB — English Grammar and Composition (Classes IX–X)']
SRC_BN = ['NCTB — বাংলা ভাষার ব্যাকরণ ও নির্মিতি (নবম-দশম শ্রেণি)', 'NCTB — বাংলা ২য় পত্র (একাদশ-দ্বাদশ শ্রেণি)', 'বাংলা একাডেমি প্রমিত বাংলা বানানের নিয়ম']
