#!/usr/bin/env python3
"""English — Block 2 (D–F): Pronoun & Antecedent, Voice, Tag Question, Redundancy + D–F Preposition/Idioms/Vocabulary/Spelling/Group Verbs
ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে। সূত্র: প্রচলিত English grammar ও learner's dictionary।"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb2', 'en', 9201)
Q = B.q
def QS(lid, rows):
    for d, q, a, w, r, t, f, trap in rows:
        Q(lid, d, q, a, w, r, t, f, trap=trap)
S = ['প্রচলিত English grammar (Wren & Martin; Cambridge/Oxford learner grammar)']
L = 'en-2-'

# =====================================================================
# 2.1 Pronoun Types & Antecedent
# =====================================================================
B.lesson(L + '1', [
    H('Pronoun ও তার প্রকার'),
    P('Noun-এর পরিবর্তে যে শব্দ বসে তা **pronoun**। Pronoun যে noun-এর বদলে বসেছে, সেই noun-কে বলে **antecedent**: **Rina** lost **her** pen — এখানে "her"-এর antecedent "Rina"। Pronoun তার antecedent-এর সঙ্গে **number, gender ও person**-এ মিলবে।'),
    TABLE('Pronoun-এর প্রকার', ['প্রকার', 'উদাহরণ', 'কাজ'],
          ('Personal', 'I, you, he, she, it, we, they', 'ব্যক্তি/বস্তুর বদলে'), ('Possessive', 'mine, yours, his, hers, ours, theirs', 'মালিকানা (noun ছাড়া বসে)'),
          ('Reflexive', 'myself, himself, themselves', 'কাজ নিজের ওপর ফেরে: He hurt himself.'), ('Emphatic', 'I myself, he himself', 'জোর দেয়: I myself saw it.'),
          ('Demonstrative', 'this, that, these, those', 'নির্দেশ করে (noun ছাড়া বসলে)'), ('Interrogative', 'who, whom, whose, which, what', 'প্রশ্ন করে'),
          ('Relative', 'who, whom, whose, which, that', 'দুটি clause জোড়ে'), ('Indefinite', 'one, someone, anybody, nobody, all', 'অনির্দিষ্ট'),
          ('Distributive', 'each, either, neither', 'একজন একজন করে — singular'), ('Reciprocal', 'each other, one another', 'পারস্পরিক')),
    TABLE('Antecedent ও agreement-এর নিয়ম', ['নিয়ম', 'উদাহরণ'],
          ('each / every / everyone / either / neither → singular pronoun', 'Each of the boys has done his duty.'),
          ('one → one\'s / oneself', 'One must do one\'s duty.'),
          ('Collective noun একক হিসেবে → it/its; সদস্যরা আলাদা → they/their', 'The jury gave its verdict. / The jury were divided in their opinions.'),
          ('Preposition-এর পরে objective case', 'between you and me'),
          ('than/as-এর পরে ক্রিয়া উহ্য থাকলে subjective case', 'He is taller than I (am).'),
          ('superlative / all / only / same-এর পরে relative pronoun "that"', 'This is the best book that I have read.'),
          ('each other (দুজন), one another (দুইয়ের বেশি) — প্রচলিত নিয়ম', 'The two sisters love each other.')),
    MNEM(('"231 ভালো কাজে, 123 দোষ স্বীকারে"', 'Pronoun-এর ক্রম', 'প্রশংসা: You, he and I (2-3-1); দোষ: I, you and he (1-2-3)।'),
         ('"between, with, for, to… — পরে me/him/her/them"', 'Objective case', 'between you and **me**, not I।')),
    MISTAKES('"between you and I" ✗ → between you and **me**।', '"Each of the students have done their…" (পরীক্ষার নিয়মে) ✗ → has done **his/her**।', '"hisself", "theirselves" ✗ → himself, themselves।', '"He is taller than me" — পরীক্ষার প্রচলিত উত্তর "than I"।'),
    SUMMARY('Pronoun ১০ প্রকার; antecedent-এর সঙ্গে number-gender-person মিলবে', 'each/every/either/neither → singular', '231 (প্রশংসা) / 123 (দোষ)', 'preposition-এর পরে me/him/her/them'),
    UNI(UNIT_EN),
], S)
QS(L + '1', [
    (2, 'Each of the boys ___ done his homework.', 'has', [('have', '"Each" singular — has।'), ('are', 'ভুল auxiliary।'), ('were', 'Plural ও ভুল tense।')],
     'Each/every/either/neither + singular verb ও singular pronoun।', 'Distributive = একজন একজন করে।', 'Agreement সারণি।', True),
    (2, 'One should do ___ duty.', 'one\'s', [('his', 'পরীক্ষার প্রচলিত নিয়মে "one"-এর সঙ্গে one\'s।'), ('their', 'Plural।'), ('your', 'Person মেলে না।')],
     'One → one\'s / oneself।', 'antecedent "one" হলে pronoun-ও one।', 'Agreement সারণি।', True),
    (2, 'The jury gave ___ verdict unanimously.', 'its', [('their', 'সর্বসম্মত রায় — জুরি এক একক হিসেবে কাজ করেছে।'), ('his', 'Gender/number মেলে না।'), ('it\'s', '"it is"-এর সংক্ষেপ, possessive নয়।')],
     'Collective noun একক হিসেবে → its।', 'একক = it/its; সদস্যরা আলাদা = they/their।', 'Collective noun।', True),
    (2, 'The jury ___ divided in their opinions.', 'were', [('was', 'সদস্যরা আলাদা মত দিচ্ছেন — plural।'), ('is', 'Singular।'), ('has', 'Singular, verb-ও ভুল।')],
     'মতভেদ = সদস্যরা আলাদা → plural verb ও their।', 'আলাদা সদস্য = plural।', 'Collective noun।', True),
    (2, 'This is a secret between you and ___ .', 'me', [('I', 'Preposition "between"-এর পরে objective case।'), ('myself', 'Reflexive এখানে চলে না।'), ('mine', 'Possessive।')],
     'Preposition-এর পরে me/him/her/us/them।', 'between you and me।', 'Agreement সারণি।', True),
    (2, 'He is taller than ___ .', 'I', [('me', 'পরীক্ষার প্রচলিত নিয়মে "than I (am)"।'), ('myself', 'Reflexive চলে না।'), ('mine', 'Possessive।')],
     'than-এর পরে উহ্য verb: than I am।', 'বাক্য শেষ করে দেখুন: than I am।', 'Agreement সারণি।', True),
    (2, 'Choose the correct order (praise): ___ will be rewarded.', 'You, he and I', [('I, you and he', '১-২-৩ ক্রম দোষ স্বীকারে।'), ('He, I and you', 'ভুল ক্রম।'), ('I, he and you', 'ভুল ক্রম।')],
     'প্রশংসায় 2-3-1: You, he and I।', '231 ভালো কাজে।', 'মনে রাখার কৌশল।', True),
    (2, 'Choose the correct order (confessing a fault): ___ are to blame.', 'I, you and he', [('You, he and I', 'এটি প্রশংসার ক্রম।'), ('He, you and I', 'ভুল ক্রম।'), ('You, I and he', 'ভুল ক্রম।')],
     'দোষ স্বীকারে 1-2-3: I, you and he।', '123 দোষে।', 'মনে রাখার কৌশল।', True),
    (2, 'This is the best film ___ I have ever seen.', 'that', [('which', 'Superlative-এর পরে "that" প্রচলিত।'), ('what', 'Relative নয় এখানে।'), ('who', 'ব্যক্তির জন্য।')],
     'Superlative/all/only/same-এর পরে that।', 'best … that।', 'Agreement সারণি।', True),
    (2, 'The two brothers helped ___ .', 'each other', [('one another', 'প্রচলিত নিয়মে দুইয়ের বেশি হলে।'), ('themself', 'অশুদ্ধ রূপ।'), ('theirselves', 'অশুদ্ধ রূপ।')],
     'দুজন → each other।', 'two → each other; many → one another।', 'Agreement সারণি।', True),
    (2, 'In "He hurt himself", "himself" is a/an —', 'reflexive pronoun', [('emphatic pronoun', 'Emphatic বাদ দিলে বাক্য অসম্পূর্ণ হয় না; এখানে হয়।'), ('possessive pronoun', 'মালিকানা নয়।'), ('relative pronoun', 'Clause জোড়ে না।')],
     'কাজ subject-এর ওপরেই ফিরেছে।', 'বাদ দিলে বাক্য ভাঙে = reflexive; না ভাঙলে = emphatic।', 'প্রকার সারণি।', True),
    (2, 'In "I myself saw the accident", "myself" is —', 'emphatic pronoun', [('reflexive pronoun', 'বাদ দিলেও বাক্য সম্পূর্ণ — তাই emphatic।'), ('personal pronoun', 'মেলে না।'), ('indefinite pronoun', 'মেলে না।')],
     '"I saw the accident" — বাক্য সম্পূর্ণ; myself শুধু জোর দিয়েছে।', 'বাদ দিয়ে পরীক্ষা করুন।', 'প্রকার সারণি।', True),
    (2, 'Neither of the girls has brought ___ book.', 'her', [('their', 'Neither singular।'), ('them', 'Objective, possessive নয়।'), ('hers', 'Noun-এর আগে hers বসে না।')],
     'Neither → singular pronoun।', 'Distributive = singular।', 'Agreement সারণি।', True),
    (1, '"Whose pen is this?" — "whose" is a/an —', 'interrogative pronoun', [('relative pronoun', 'এখানে প্রশ্ন করছে, clause জুড়ছে না।'), ('demonstrative pronoun', 'মেলে না।'), ('reciprocal pronoun', 'মেলে না।')],
     'প্রশ্ন করছে।', 'প্রশ্ন = interrogative; জোড়া = relative।', 'প্রকার সারণি।', False),
    (2, 'The man ___ you met yesterday is my uncle.', 'whom', [('who', 'Met-এর object — objective case whom।'), ('whose', 'মালিকানা নয়।'), ('which', 'ব্যক্তির জন্য নয়।')],
     'you met him → whom।', 'him হলে whom, he হলে who।', 'Relative pronoun।', True),
    (2, 'This is the boy ___ father is a doctor.', 'whose', [('who', 'মালিকানা বোঝাতে whose।'), ('whom', 'Objective।'), ('which', 'বস্তুর জন্য।')],
     'his father → whose father।', 'মালিকানা → whose।', 'Relative pronoun।', False),
    (2, 'In "Rina lost her pen", the antecedent of "her" is —', 'Rina', [('pen', 'Pen-এর বদলে বসেনি।'), ('lost', 'Verb।'), ('her', 'নিজেই pronoun।')],
     '"her" বসেছে Rina-র বদলে।', 'Pronoun কার বদলে বসেছে = antecedent।', 'সংজ্ঞা।', False),
    (2, 'Everyone must bring ___ own lunch. (exam rule)', 'his or her', [('their', 'পরীক্ষার ঐতিহ্যগত নিয়মে everyone singular।'), ('our', 'Person মেলে না।'), ('its', 'মানুষের জন্য নয়।')],
     'Everyone singular → his/her।', 'আধুনিক ইংরেজিতে "their"-ও চলে, তবে MCQ-তে singular-ই নিরাপদ।', 'Agreement সারণি।', True),
    (2, 'The Padma has changed ___ course many times.', 'its', [('her', 'নদীকে নির্জীব বস্তু ধরা হয় (personification ছাড়া)।'), ('their', 'Plural।'), ('it\'s', '"it is"-এর সংক্ষেপ।')],
     'Neuter antecedent → its।', 'its (possessive) ≠ it\'s (it is)।', 'Agreement।', True),
    (2, 'Which is a reciprocal pronoun?', 'one another', [('oneself', 'Reflexive।'), ('anyone', 'Indefinite।'), ('whichever', 'Relative/indefinite।')],
     'পারস্পরিক সম্পর্ক → each other / one another।', 'Reciprocal = পারস্পরিক।', 'প্রকার সারণি।', False),
    (2, 'It was ___ who called you.', 'I', [('me', 'Formal পরীক্ষা-ইংরেজিতে "It was I"।'), ('myself', 'Reflexive চলে না।'), ('mine', 'Possessive।')],
     'Linking verb (be)-এর পরে subjective case: It is I।', 'be-এর পরে subjective (formal)।', 'Agreement।', True),
])

# =====================================================================
# 2.2 Voice
# =====================================================================
B.lesson(L + '2', [
    H('Voice: Active ও Passive'),
    P('বাক্যে **subject** নিজে কাজ করলে **Active voice**; subject-এর ওপর কাজ হলে **Passive voice**। Passive করার মূল সূত্র: **object → subject**, verb → **be + V3 (past participle)**, আগের subject → **by + objective case**। শুধু **transitive verb** (যার object আছে)-এর passive হয়।'),
    TABLE('Tense অনুযায়ী "be"-এর রূপ', ['Tense', 'Active', 'Passive'],
          ('Present indefinite', 'He writes a letter.', 'A letter **is written** by him.'), ('Present continuous', 'They are building a house.', 'A house **is being built** by them.'),
          ('Present perfect', 'She has written a letter.', 'A letter **has been written** by her.'), ('Past indefinite', 'He wrote a letter.', 'A letter **was written** by him.'),
          ('Past continuous', 'He was writing a letter.', 'A letter **was being written** by him.'), ('Past perfect', 'He had written a letter.', 'A letter **had been written** by him.'),
          ('Future indefinite', 'I will do it.', 'It **will be done** by me.'), ('Modal', 'You must do it.', 'It **must be done** by you.')),
    TABLE('বিশেষ ধরনের বাক্য', ['ধরন', 'Active', 'Passive'],
          ('Imperative', 'Open the door.', 'Let the door be opened.'), ('অনুরোধ', 'Please help me.', 'You are requested to help me.'),
          ('Let যুক্ত', 'Let him do it.', 'Let it be done by him.'), ('Who-প্রশ্ন', 'Who did it?', 'By whom was it done?'),
          ('Wh-প্রশ্ন', 'What did you see?', 'What was seen by you?'), ('Yes/No প্রশ্ন', 'Did he write the letter?', 'Was the letter written by him?'),
          ('Double object', 'He gave me a book.', 'I was given a book by him. / A book was given to me by him.'),
          ('People say that…', 'People say that he is honest.', 'It is said that he is honest. / He is said to be honest.')),
    TABLE('"by" ছাড়া অন্য preposition', ['Active', 'Passive'], ('Everybody knows him.', 'He is known **to** everybody.'), ('His conduct pleased me.', 'I was pleased **with** his conduct.'),
          ('The news surprised me.', 'I was surprised **at** the news.'), ('Water filled the jar.', 'The jar was filled **with** water.'), ('Music interests me.', 'I am interested **in** music.')),
    MNEM(('"OBV — Object সামনে, Be + V3, By + agent"', 'মূল সূত্র', 'তিনটি ধাপ পরপর।'), ('"continuous-এ being, perfect-এ been"', 'be-এর রূপ', 'is being built / has been built।')),
    MISTAKES('Intransitive verb-এর passive হয় না: "He sleeps" — passive নেই।', '"by he" ✗ → by **him** (objective case)।', '"known by everybody" ✗ (পরীক্ষার নিয়মে) → known **to** everybody।'),
    SUMMARY('Passive = object সামনে + be + V3 + by + agent', 'continuous → being; perfect → been; modal → modal + be + V3', 'Imperative → Let … be + V3', 'known to, pleased with, surprised at, filled with, interested in'),
    UNI(UNIT_EN),
], S)
QS(L + '2', [
    (2, 'Passive of "They are building a house" —', 'A house is being built by them.', [('A house is built by them.', 'Continuous-এর "being" বাদ পড়েছে।'), ('A house has been built by them.', 'Tense বদলে perfect হয়েছে।'), ('A house was being built by them.', 'Tense বদলে past হয়েছে।')],
     'Present continuous → is/am/are + being + V3।', 'Continuous-এ being।', 'Tense সারণি।', True),
    (2, 'Passive of "She has written a letter" —', 'A letter has been written by her.', [('A letter was written by her.', 'Tense বদলেছে।'), ('A letter has written by her.', '"been" বাদ।'), ('A letter is being written by her.', 'Tense বদলেছে।')],
     'Present perfect → has/have + been + V3।', 'Perfect-এ been।', 'Tense সারণি।', True),
    (2, 'Passive of "I will do it" —', 'It will be done by me.', [('It will done by me.', '"be" বাদ।'), ('It would be done by me.', 'Will → would হয়নি।'), ('It will be done by I.', 'Agent objective case হবে: me।')],
     'Future → will be + V3।', 'Modal + be + V3।', 'Tense সারণি।', False),
    (2, 'Passive of "Open the door." —', 'Let the door be opened.', [('The door is opened.', 'Imperative ভাব হারিয়েছে।'), ('Let the door opened.', '"be" বাদ।'), ('The door be opened.', '"Let" বাদ।')],
     'Imperative → Let + object + be + V3।', 'হুকুমে Let।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Passive of "Please help me." —', 'You are requested to help me.', [('Let me be helped.', 'অনুরোধের ভাব হারিয়েছে।'), ('I am helped by you.', 'অনুরোধ নয়, বিবৃতি।'), ('Please be helped by me.', 'অর্থ পাল্টেছে।')],
     'Please/Kindly → You are requested to…।', 'অনুরোধ = requested।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Passive of "Who did it?" —', 'By whom was it done?', [('Who was it done by him?', 'অশুদ্ধ।'), ('By whom it was done?', 'প্রশ্নের ক্রম নেই।'), ('Whom was it done?', '"By" বাদ।')],
     'Who → By whom + auxiliary + subject + V3?', 'Who-এর passive = By whom।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Passive of "Did he write the letter?" —', 'Was the letter written by him?', [('Is the letter written by him?', 'Tense বদলেছে।'), ('Was the letter wrote by him?', 'V3 লাগবে: written।'), ('Did the letter written by him?', 'Did-এর passive হয় না এভাবে।')],
     'Did → Was/Were + subject + V3?', 'Yes/No প্রশ্নে be দিয়ে শুরু।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Passive of "Everybody knows him." —', 'He is known to everybody.', [('He is known by everybody.', 'পরীক্ষার প্রচলিত নিয়মে "known to"।'), ('He was known to everybody.', 'Tense বদলেছে।'), ('Everybody is known to him.', 'অর্থ উল্টে গেছে।')],
     'know → known to।', 'known to, pleased with, surprised at।', '"by" ছাড়া preposition সারণি।', True),
    (2, 'Passive of "The news surprised me." —', 'I was surprised at the news.', [('I was surprised by the news at.', 'অশুদ্ধ।'), ('The news was surprised by me.', 'অর্থ উল্টে গেছে।'), ('I am surprised at the news.', 'Tense বদলেছে।')],
     'surprise → surprised at।', '"by" ছাড়া preposition।', '"by" ছাড়া preposition সারণি।', True),
    (2, 'Passive of "Let him do it." —', 'Let it be done by him.', [('Let it done by him.', '"be" বাদ।'), ('It is done by him.', 'Let-এর ভাব হারিয়েছে।'), ('Let him be done it.', 'অশুদ্ধ।')],
     'Let + object + be + V3 + by + agent।', 'Let থাকলে Let-ই থাকে।', 'বিশেষ বাক্য সারণি।', False),
    (2, 'Passive of "You must do it." —', 'It must be done by you.', [('It must done by you.', '"be" বাদ।'), ('It must been done by you.', '"been" নয়, "be"।'), ('It must be did by you.', 'V3 লাগবে: done।')],
     'Modal + be + V3।', 'can/must/should + be + V3।', 'Tense সারণি।', False),
    (3, 'Passive of "People say that he is honest." —', 'It is said that he is honest.', [('He says that people are honest.', 'অর্থ পাল্টেছে।'), ('It was said that he is honest.', 'Tense বদলেছে।'), ('People are said that he is honest.', 'অশুদ্ধ।')],
     'People say that… → It is said that… (অথবা He is said to be honest)।', 'Impersonal passive।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Which verb cannot be changed into the passive?', 'sleep', [('write', 'Transitive।'), ('build', 'Transitive।'), ('teach', 'Transitive।')],
     'Intransitive verb-এর object নেই, তাই passive হয় না।', 'Object নেই = passive নেই।', 'মূল নিয়ম।', True),
    (2, 'Passive of "He gave me a book." —', 'I was given a book by him.', [('I was gave a book by him.', 'V3 লাগবে: given।'), ('A book gave me by him.', '"was" বাদ।'), ('I am given a book by him.', 'Tense বদলেছে।')],
     'Double object: ব্যক্তি-object সামনে আনা প্রচলিত।', 'দুটো রূপই চলে: A book was given to me by him।', 'বিশেষ বাক্য সারণি।', True),
    (2, 'Active of "The letter was posted by Rahim." —', 'Rahim posted the letter.', [('Rahim posts the letter.', 'Tense বদলেছে।'), ('Rahim has posted the letter.', 'Tense বদলেছে।'), ('The letter posted Rahim.', 'অর্থ উল্টে গেছে।')],
     'by-এর পরের agent subject হয়, was + V3 → V2।', 'উল্টো দিকেও tense ঠিক রাখুন।', 'Tense সারণি।', False),
    (2, 'Passive of "He was writing a letter." —', 'A letter was being written by him.', [('A letter was written by him.', '"being" বাদ।'), ('A letter is being written by him.', 'Tense বদলেছে।'), ('A letter had been written by him.', 'Tense বদলেছে।')],
     'Past continuous → was/were + being + V3।', 'Continuous-এ being।', 'Tense সারণি।', False),
    (2, 'Passive of "Water filled the jar." —', 'The jar was filled with water.', [('The jar was filled by water.', 'পরীক্ষার নিয়মে "filled with"।'), ('The jar is filled with water.', 'Tense বদলেছে।'), ('Water was filled by the jar.', 'অর্থ উল্টে গেছে।')],
     'fill → filled with।', '"by" ছাড়া preposition।', '"by" ছাড়া preposition সারণি।', True),
    (2, 'Passive of "What did you see?" —', 'What was seen by you?', [('What were you seen?', 'অর্থ পাল্টেছে।'), ('What was saw by you?', 'V3: seen।'), ('By what did you see?', 'অশুদ্ধ।')],
     'Wh-word + was/were + V3 + by + agent?', 'Wh-প্রশ্নে wh-word সামনেই থাকে।', 'বিশেষ বাক্য সারণি।', False),
    (2, 'Passive of "Music interests me." —', 'I am interested in music.', [('I am interested by music.', 'পরীক্ষার নিয়মে "interested in"।'), ('Music is interested in me.', 'অর্থ উল্টে গেছে।'), ('I was interested in music.', 'Tense বদলেছে।')],
     'interest → interested in।', '"by" ছাড়া preposition।', '"by" ছাড়া preposition সারণি।', True),
    (2, 'In passive voice the main verb is always in the —', 'past participle (V3) form', [('base form (V1)', 'be + V3 লাগে।'), ('past form (V2)', 'V2 নয়।'), ('-ing form only', 'Continuous-এও being + V3।')],
     'Passive = be + V3।', 'V3 ছাড়া passive নেই।', 'মূল সূত্র।', False),
])

# =====================================================================
# 2.3 Tag Question
# =====================================================================
B.lesson(L + '3', [
    H('Tag Question'),
    P('বাক্যের শেষে যোগ করা ছোট প্রশ্ন — সম্মতি বা নিশ্চয়তা চাওয়ার জন্য: You are tired, **aren\'t you**? মূল নিয়ম: **positive বাক্য → negative tag**, **negative বাক্য → positive tag**; tag-এ বাক্যের **auxiliary** + subject-এর **pronoun**।'),
    TABLE('মূল নিয়ম', ['বাক্য', 'Tag'], ('He is a doctor.', 'isn\'t he?'), ('She can swim.', 'can\'t she?'), ('They didn\'t come.', 'did they?'),
          ('He writes well. (auxiliary নেই)', 'doesn\'t he? (do/does/did বসে)'), ('You went there.', 'didn\'t you?')),
    TABLE('বিশেষ ক্ষেত্র', ['বাক্য', 'কারণ', 'Tag'],
          ('I am right.', '"amn\'t I" প্রচলিত নয়', 'aren\'t I?'), ('Let\'s go.', 'Let\'s = প্রস্তাব', 'shall we?'), ('Let him go.', 'অনুমতি চাওয়া', 'will you?'),
          ('Open the door.', 'Imperative', 'will you? / won\'t you?'), ('Don\'t make a noise.', 'Negative imperative', 'will you?'),
          ('Nobody came.', 'nobody/nothing negative → positive tag; nobody → they', 'did they?'), ('Everybody is happy.', 'everybody → they', 'aren\'t they?'),
          ('Nothing is impossible.', 'nothing → it', 'is it?'), ('There is a book.', 'there থাকে', 'isn\'t there?'), ('He has a car. (main verb have)', 'অধিকার অর্থে have — do দিয়ে', 'doesn\'t he?'),
          ('He has finished.', 'auxiliary has', 'hasn\'t he?'), ('She seldom comes.', 'seldom/hardly/never/scarcely = negative', 'does she?'),
          ('Few people came.', 'few = negative', 'did they?'), ('A few people came.', 'a few = positive', 'didn\'t they?'), ('You had better go.', 'had better', 'hadn\'t you?'),
          ('He used to smoke.', 'used to', 'didn\'t he?'), ('This is your pen.', 'this/that → it', 'isn\'t it?'), ('These are yours.', 'these/those → they', 'aren\'t they?'),
          ('I think he is right.', 'I think-এর পরের clause অনুযায়ী', 'isn\'t he?')),
    MNEM(('"উল্টো সুর, একই auxiliary, pronoun subject"', 'মূল নিয়ম', 'positive ↔ negative।'), ('"Let\'s → shall we; Let him → will you"', 'Let', 'প্রস্তাব বনাম অনুমতি।'),
         ('"seldom, hardly, never, few, nobody, nothing — চুপচাপ negative"', 'লুকানো negative', 'এদের পরে positive tag।')),
    MISTAKES('"I am late, amn\'t I?" ✗ → aren\'t I?', '"Nobody came, didn\'t they?" ✗ → did they?', '"He has a car, hasn\'t he?" — পরীক্ষায় প্রচলিত উত্তর doesn\'t he? (have = possess)।'),
    SUMMARY('Positive → negative tag; negative → positive tag', 'auxiliary না থাকলে do/does/did', 'I am → aren\'t I; Let\'s → shall we', 'seldom/hardly/never/few/nobody/nothing = negative'),
    UNI(UNIT_EN),
], S)
TAGS = [('He is a doctor, ___ ?', 'isn\'t he', ['is he', 'doesn\'t he', 'wasn\'t he'], 'Positive → negative, auxiliary is।', False),
        ('They didn\'t come, ___ ?', 'did they', ['didn\'t they', 'do they', 'were they'], 'Negative → positive।', False),
        ('He writes well, ___ ?', 'doesn\'t he', ['isn\'t he', 'does he', 'don\'t he'], 'Auxiliary নেই → does।', False),
        ('I am right, ___ ?', 'aren\'t I', ['amn\'t I', 'am not I', 'isn\'t I'], 'I am → aren\'t I।', True),
        ('Let\'s go for a walk, ___ ?', 'shall we', ['will you', 'don\'t we', 'won\'t we'], 'Let\'s → shall we।', True),
        ('Let him go, ___ ?', 'will you', ['shall we', 'won\'t he', 'doesn\'t he'], 'Let him → will you।', True),
        ('Open the window, ___ ?', 'will you', ['don\'t you', 'shall we', 'do you'], 'Imperative → will you।', True),
        ('Nobody came to the party, ___ ?', 'did they', ['didn\'t they', 'did he', 'didn\'t he'], 'Nobody negative ও plural pronoun they।', True),
        ('Everybody is happy, ___ ?', 'aren\'t they', ['isn\'t he', 'isn\'t it', 'are they'], 'Everybody → they; positive → negative।', True),
        ('Nothing is impossible, ___ ?', 'is it', ['isn\'t it', 'is they', 'are they'], 'Nothing negative → positive tag; pronoun it।', True),
        ('There is a book on the table, ___ ?', 'isn\'t there', ['isn\'t it', 'is there', 'doesn\'t it'], 'There থাকলে tag-এও there।', True),
        ('He has a car, ___ ?', 'doesn\'t he', ['hasn\'t he', 'isn\'t he', 'has he'], 'Main verb have (অধিকার) → does (পরীক্ষার প্রচলিত উত্তর)।', True),
        ('He has finished his work, ___ ?', 'hasn\'t he', ['doesn\'t he', 'has he', 'didn\'t he'], 'Auxiliary has → hasn\'t।', True),
        ('She seldom comes here, ___ ?', 'does she', ['doesn\'t she', 'isn\'t she', 'did she'], 'Seldom = negative → positive tag।', True),
        ('Few people attended the meeting, ___ ?', 'did they', ['didn\'t they', 'did it', 'weren\'t they'], 'Few = negative → positive tag।', True),
        ('A few people attended the meeting, ___ ?', 'didn\'t they', ['did they', 'didn\'t it', 'weren\'t they'], 'A few = positive → negative tag।', True),
        ('You had better go now, ___ ?', 'hadn\'t you', ['didn\'t you', 'wouldn\'t you', 'haven\'t you'], 'Had better → hadn\'t।', True),
        ('He used to smoke, ___ ?', 'didn\'t he', ['usedn\'t he', 'wasn\'t he', 'doesn\'t he'], 'Used to → didn\'t (প্রচলিত)।', True),
        ('This is your pen, ___ ?', 'isn\'t it', ['isn\'t this', 'is it', 'aren\'t they'], 'This → it।', False),
        ('Don\'t make a noise, ___ ?', 'will you', ['won\'t you', 'do you', 'shall we'], 'Negative imperative → will you।', True)]
for s, a, wr, r, trap in TAGS:
    Q(L + '3', 2, s, a, [(x, 'নিয়ম মেলে না।') for x in wr], r, 'উল্টো সুর, একই auxiliary, pronoun subject।', 'বিশেষ ক্ষেত্র সারণি।', trap=trap)

# =====================================================================
# 2.4 Redundancy
# =====================================================================
RD = [('He returned back home.', 'back', 'return মানেই ফিরে আসা।'), ('Please repeat the question again.', 'again', 'repeat মানেই আবার বলা।'),
      ('The reason is because he was ill.', 'because', '"The reason is that…" — reason আর because একই কাজ করে।'), ('They gave us a free gift.', 'free', 'gift মানেই বিনামূল্যে।'),
      ('We must cooperate together.', 'together', 'co-operate = একসাথে কাজ করা।'), ('It was an unexpected surprise.', 'unexpected', 'surprise মানেই অপ্রত্যাশিত।'),
      ('These are the true facts.', 'true', 'fact মানেই সত্য।'), ('He descended down the stairs.', 'down', 'descend = নিচে নামা।'),
      ('The end result was good.', 'end', 'result মানেই শেষ ফল।'), ('Let us join together.', 'together', 'join মানেই যুক্ত হওয়া।'),
      ('He wrote his own autobiography.', 'own', 'autobiography = নিজের লেখা নিজের জীবনী।'), ('This is the most unique design.', 'most', 'unique = অদ্বিতীয়; তুলনা চলে না।'),
      ('She is more superior to me.', 'more', 'superior নিজেই তুলনামূলক।'), ('The house is in close proximity to the river.', 'close', 'proximity = নৈকট্য।'),
      ('He reverted back to his old habits.', 'back', 'revert = আগের অবস্থায় ফেরা।'), ('We need advance planning.', 'advance', 'planning সবসময় আগেই হয়।'),
      ('The past history of the country is glorious.', 'past', 'history মানেই অতীত।'), ('Each and every student must attend.', 'and every', 'Each বা every — একটিই যথেষ্ট।'),
      ('He ascended up the hill.', 'up', 'ascend = ওপরে ওঠা।'), ('Both of them are equally alike.', 'equally', 'alike নিজেই সমতা বোঝায়।')]
B.lesson(L + '4', [
    H('Redundancy (অপ্রয়োজনীয় শব্দ)'),
    P('একই অর্থ দুবার প্রকাশ করলে অতিরিক্ত শব্দটি **redundant**। পরীক্ষায় বলা হয় "Identify the redundant/superfluous word" বা Sentence Correction-এ অতিরিক্ত শব্দটি বাদ দিতে হয়। কৌশল: শব্দটির **নিজের অর্থেই** কি পরের শব্দের ভাব আছে?'),
    TABLE('অপ্রয়োজনীয় শব্দ (কলাম-লুকাও)', ['ভুল বাক্য', 'কেন', 'বাদ দিন'], *[(s, r, w) for s, w, r in RD]),
    MNEM(('"re- নিজেই ফেরায়" — return, repeat, revert-এর পরে back/again নয়', 're- শব্দ', 'return back, repeat again, revert back — সব ✗।'),
         ('"তুলনা চলে না: unique, superior, inferior, perfect"', 'Comparison', 'most unique ✗, more superior ✗।')),
    MISTAKES('"superior than" ✗ → superior **to**।', '"The reason is because" ✗ → The reason is **that**।'),
    SUMMARY('একই অর্থ দুবার = redundancy', 're- শব্দের পরে back/again লাগে না', 'unique/superior/perfect-এ more/most বসে না'),
    UNI(UNIT_EN),
], S)
for i, (s, w, r) in enumerate(RD):
    words = [x.strip('.,') for x in s.split()]
    pool = [x for x in words if x.lower() not in w.lower().split() and len(x) > 2 and x.lower() not in ('the', 'and')]
    random.Random(5000 + i).shuffle(pool)
    Q(L + '4', 2, f'Identify the redundant word/phrase: "{s}"', w, [(x, 'বাক্যে প্রয়োজনীয় শব্দ।') for x in pool[:2]] + [('No redundant word', 'একটি শব্দ অপ্রয়োজনীয় আছে।')], f'"{w}" অপ্রয়োজনীয় — {r}', 'শব্দের নিজের অর্থেই কি ভাবটা আছে?', 'Redundancy সারণি।', trap=w in ('because', 'most', 'more', 'equally'))

# =====================================================================
# 2.5 – 2.9 : D–F
# =====================================================================
RNG = 'D–F'
prep_lesson(B, L + '5', RNG, [
    ('deal (trade)', 'in', 'He deals ___ rice.', 'ব্যবসা করা', ()), ('deal (handle)', 'with', 'The book deals ___ grammar.', 'আলোচনা/মোকাবিলা করা', ()),
    ('depend', 'on', 'Success depends ___ hard work.', 'নির্ভর করা', ('upon',)), ('deprive', 'of', 'They were deprived ___ their rights.', 'বঞ্চিত করা', ()),
    ('derive', 'from', 'This word is derived ___ Latin.', 'উদ্ভূত হওয়া', ()), ('desist', 'from', 'Desist ___ such activities.', 'বিরত থাকা', ()),
    ('despair', 'of', 'Do not despair ___ success.', 'হতাশ হওয়া', ()), ('devoid', 'of', 'He is devoid ___ common sense.', 'বর্জিত, শূন্য', ()),
    ('die (disease)', 'of', 'He died ___ cholera.', '(রোগে) মারা যাওয়া', ('from',)), ('differ (thing)', 'from', 'This book differs ___ that one.', 'ভিন্ন হওয়া', ()),
    ('differ (opinion)', 'with', 'I differ ___ you on this point.', '(কারও সঙ্গে) মতভেদ', ('from',)), ('dispose', 'of', 'He disposed ___ his old car.', 'বিদায় করা/বিক্রি করা', ()),
    ('divide', 'into', 'The cake was divided ___ four parts.', 'ভাগ করা', ()), ('eager', 'for', 'He is eager ___ success.', 'আগ্রহী', ()),
    ('engaged (work)', 'in', 'He is engaged ___ research.', 'নিয়োজিত', ()), ('engaged (marriage)', 'to', 'She is engaged ___ a doctor.', 'বাগদত্তা', ()),
    ('entitled', 'to', 'You are entitled ___ a refund.', 'অধিকারী', ()), ('envious', 'of', 'He is envious ___ my success.', 'ঈর্ষান্বিত', ()),
    ('equal', 'to', 'He is equal ___ the task.', 'সমান/যোগ্য', ()), ('exempt', 'from', 'He was exempt ___ tax.', 'অব্যাহতিপ্রাপ্ত', ()),
    ('expert', 'in', 'She is an expert ___ chemistry.', 'দক্ষ', ('at',)), ('faithful', 'to', 'A dog is faithful ___ its master.', 'বিশ্বস্ত', ()),
    ('familiar (person)', 'with', 'I am familiar ___ this place.', 'পরিচিত (ব্যক্তি জানে)', ()), ('familiar (thing)', 'to', 'This place is familiar ___ me.', 'পরিচিত (বস্তু ব্যক্তির কাছে)', ()),
    ('fond', 'of', 'She is fond ___ music.', 'অনুরাগী', ()), ('free (worry)', 'from', 'He is free ___ anxiety.', 'মুক্ত', ('of',)),
    ('full', 'of', 'The jar is full ___ water.', 'পূর্ণ', ()), ('furnish', 'with', 'They furnished the room ___ new chairs.', 'সজ্জিত করা', ())],
    5100,
    contrast=(('deal in', 'ব্যবসা: He deals in jute.'), ('deal with', 'আলোচনা/মোকাবিলা: The book deals with history.'),
              ('differ from + বস্তু', 'This differs from that.'), ('differ with + ব্যক্তি', 'I differ with you.'),
              ('engaged in + কাজ', 'engaged in research'), ('engaged to + ব্যক্তি', 'engaged to a doctor (বাগদান)'),
              ('familiar with', 'ব্যক্তি কিছু জানে: I am familiar with it.'), ('familiar to', 'কিছু ব্যক্তির কাছে পরিচিত: It is familiar to me.')),
    mnem=(('"die OF রোগ, die FROM কারণ (wound, overwork)"', 'die', 'He died of fever / from a wound।'), ('"deal IN পণ্য, deal WITH বিষয়"', 'deal', 'ব্যবসা বনাম আলোচনা।')),
    mistakes=('"deprived from" ✗ → deprived **of**।', '"divided in two parts" — পরীক্ষায় নিরাপদ: divided **into**।', '"fond for" ✗ → fond **of**।'))

idiom_lesson(B, L + '6', RNG, [
    ('dark horse', 'অপ্রত্যাশিত বিজয়ী; অচেনা প্রতিযোগী', 'a little-known competitor who unexpectedly succeeds', 'ঘোড়দৌড় থেকে: যে ঘোড়ার কথা কেউ জানত না, সে-ই জিতে গেল।', 'The new candidate proved a dark horse.'),
    ('dead letter', 'অকার্যকর আইন/নিয়ম', 'a law or rule no longer enforced', 'আইন খাতায় আছে কিন্তু "মৃত" — কেউ মানে না; ঠিকানাহীন চিঠিকেও dead letter বলা হয়।', 'The old law is now a dead letter.'),
    ('Dutch courage', 'মদের জোরে সাহস', 'courage gained from drinking alcohol', 'প্রচলিত ব্যাখ্যা: সপ্তদশ শতকে ইংরেজ-ডাচ সংঘাতের সময় থেকে কথাটি চালু।', 'He drank to get some Dutch courage.'),
    ('dog in the manger', 'নিজে ভোগ করে না, অন্যকেও করতে দেয় না এমন ব্যক্তি', 'one who selfishly keeps from others what he cannot use himself', 'ঈশপের গল্প: কুকুর খড়ের গাদায় শুয়ে থাকে; নিজে খড় খায় না, গরুকেও খেতে দেয় না।', 'Don\'t be a dog in the manger; lend him the book you never read.'),
    ('eat humble pie', 'অপমান স্বীকার করে ক্ষমা চাওয়া', 'to admit a mistake and apologise humbly', 'প্রচলিত ব্যাখ্যা: "umbles" (পশুর নাড়িভুঁড়ি) দিয়ে তৈরি পাই খেত নিচু শ্রেণির মানুষ — umble pie থেকে humble pie।', 'He had to eat humble pie after losing the bet.'),
    ('at the eleventh hour', 'শেষ মুহূর্তে', 'at the last possible moment', 'বাইবেলের দ্রাক্ষাক্ষেত্রের গল্প: দিনের শেষ (১১তম) ঘণ্টায় কাজে আসা শ্রমিকরাও পুরো মজুরি পেয়েছিল।', 'He submitted the form at the eleventh hour.'),
    ('end in smoke', 'ব্যর্থ হওয়া', 'to come to nothing', 'আগুন নিভে শুধু ধোঁয়া থাকে — কিছুই অবশিষ্ট নেই।', 'All his plans ended in smoke.'),
    ('every inch', 'পুরোপুরি', 'completely, in every way', 'Shakespeare-এর King Lear-এ "every inch a king"।', 'He is every inch a gentleman.'),
    ('face the music', 'কৃতকর্মের ফল ভোগ করা', 'to accept the unpleasant consequences of one\'s actions', 'উৎস অনিশ্চিত; মনে রাখুন — মঞ্চে দর্শকের মুখোমুখি হওয়ার ছবি।', 'After cheating, he had to face the music.'),
    ('fair and square', 'সৎভাবে, ন্যায্যভাবে', 'honestly and fairly', 'square = সোজা, সৎ; দুটো শব্দে জোর।', 'He won the match fair and square.'),
    ('a far cry', 'অনেক তফাত', 'very different from', 'দূরের ডাক — এত দূরে যে শোনা যায় না।', 'His new house is a far cry from his old hut.'),
    ('a feather in one\'s cap', 'গৌরবের কাজ/অর্জন', 'an achievement to be proud of', 'প্রচলিত ব্যাখ্যা: বীরত্বের স্বীকৃতিতে টুপিতে পালক গোঁজার প্রথা।', 'Winning the award was a feather in her cap.'),
    ('a fish out of water', 'বেমানান অবস্থায়', 'someone uncomfortable in an unfamiliar situation', 'পানির বাইরে মাছের অস্বস্তি — বাংলায় "ডাঙায় তোলা মাছ"।', 'He felt like a fish out of water at the party.'),
    ('flesh and blood', 'রক্তমাংসের মানুষ; আপনজন', 'human nature; one\'s own family', 'মানুষের শরীর = রক্ত-মাংস; "my own flesh and blood" = আপন আত্মীয়।', 'He is my own flesh and blood.'),
    ('French leave', 'না বলে চলে যাওয়া/ছুটি নেওয়া', 'leaving without permission or notice', 'প্রচলিত ব্যাখ্যা: অষ্টাদশ শতকে অতিথির বিদায় না নিয়ে চলে যাওয়ার রীতিকে ফরাসি রীতি বলা হতো।', 'He took French leave from the office.'),
    ('from hand to mouth', 'দিন আনে দিন খায়', 'with only just enough money to live', 'হাতে যা আসে সঙ্গে সঙ্গে মুখে যায় — সঞ্চয় নেই।', 'The poor family lives from hand to mouth.'),
    ('few and far between', 'বিরল', 'rare, scarce', 'সংখ্যায় কম, দূরে দূরে ছড়ানো।', 'Good teachers are few and far between.'),
    ('a fly in the ointment', 'আনন্দের মধ্যে বাধা', 'a small flaw that spoils something', 'মলমে মাছি পড়লে পুরো মলম নষ্ট — পুরোনো উপমা (বাইবেলের Ecclesiastes-এ এর পূর্বসূত্র আছে)।', 'The rain was the only fly in the ointment.'),
    ('a drop in the ocean', 'সাগরে এক বিন্দু; নগণ্য পরিমাণ', 'a very small amount compared to what is needed', 'বিশাল সমুদ্রে এক ফোঁটা পানি।', 'His donation was a drop in the ocean.'),
    ('double-dealing', 'প্রতারণা, দুমুখো আচরণ', 'deceitful behaviour', 'দুই পক্ষের সঙ্গে দুই রকম লেনদেন।', 'His double-dealing was exposed.'),
    ('the sword of Damocles', 'মাথার ওপর ঝুলন্ত বিপদ', 'an ever-present danger', 'গ্রিক কাহিনি: রাজার আসনে বসা Damocles-এর মাথার ওপর একটি চুলে বাঁধা তলোয়ার ঝোলানো ছিল — ক্ষমতার সঙ্গে সারাক্ষণের বিপদ।', 'The threat of dismissal hung like the sword of Damocles.'),
    ('dead of night', 'গভীর রাত', 'the quietest, darkest part of the night', 'রাত যখন "মৃত"র মতো নিস্তব্ধ।', 'The thief entered at dead of night.')],
    5200, traps=('dark horse', 'dead letter', 'French leave', 'eat humble pie'),
    mnem=(('"পুরাণ-গল্পের idiom: dog in the manger (ঈশপ), sword of Damocles (গ্রিক), eleventh hour (বাইবেল)"', 'উৎস দিয়ে মনে রাখা', 'গল্পটা মনে পড়লেই অর্থ।'),),
    mistakes=('**dark horse** = অপ্রত্যাশিত বিজয়ী — কালো ঘোড়া বা খারাপ লোক নয়।', '**French leave** = অনুমতি ছাড়া চলে যাওয়া — ফ্রান্সে ছুটি নয়।'))

vocab_lesson(B, L + '7', RNG, [
    ('dearth', 'n', 'অভাব, ঘাটতি', 'a scarcity or lack', ['scarcity', 'shortage', 'lack'], ['abundance', 'plenty'], 'lack'),
    ('deceit', 'n', 'প্রতারণা', 'dishonest behaviour', ['deception', 'fraud', 'trickery'], ['honesty', 'sincerity'], 'cheat'),
    ('decipher', 'v', 'পাঠোদ্ধার করা', 'to work out the meaning of', ['decode', 'interpret'], ['encode'], 'solve'),
    ('defer', 'v', 'স্থগিত করা', 'to put off to a later time', ['postpone', 'delay'], ['advance', 'expedite'], 'delay'),
    ('deft', 'adj', 'দক্ষ, নিপুণ', 'quick and skilful', ['skilful', 'adroit', 'nimble'], ['clumsy', 'awkward'], 'skill'),
    ('deplete', 'v', 'নিঃশেষ করা', 'to use up or reduce greatly', ['exhaust', 'drain', 'use up'], ['replenish', 'restore'], 'less'),
    ('deride', 'v', 'উপহাস করা', 'to mock', ['mock', 'ridicule', 'scoff at'], ['praise', 'respect'], 'mock'),
    ('desolate', 'adj', 'জনশূন্য, নির্জন', 'empty and bleak', ['deserted', 'barren', 'forlorn'], ['populous', 'crowded'], 'empty'),
    ('detrimental', 'adj', 'ক্ষতিকর', 'causing harm', ['harmful', 'damaging'], ['beneficial'], 'harm'),
    ('diligent', 'adj', 'পরিশ্রমী, অধ্যবসায়ী', 'hard-working and careful', ['industrious', 'assiduous', 'hard-working'], ['lazy', 'negligent'], 'work'),
    ('discern', 'v', 'উপলব্ধি/পার্থক্য করা', 'to perceive or recognise', ['perceive', 'detect', 'distinguish'], ['overlook', 'miss'], 'see'),
    ('disdain', 'n', 'অবজ্ঞা', 'contempt; scorn', ['contempt', 'scorn'], ['respect', 'admiration'], 'mock'),
    ('divulge', 'v', '(গোপন কথা) প্রকাশ করা', 'to reveal a secret', ['disclose', 'reveal'], ['conceal', 'hide'], 'reveal'),
    ('docile', 'adj', 'বাধ্য, শান্ত', 'ready to obey', ['obedient', 'submissive', 'tame'], ['unruly', 'rebellious'], 'obey'),
    ('dubious', 'adj', 'সন্দেহজনক', 'doubtful', ['doubtful', 'questionable'], ['certain', 'reliable'], 'doubt'),
    ('eccentric', 'adj', 'খামখেয়ালি, অদ্ভুত', 'unconventional; odd', ['odd', 'peculiar', 'quirky'], ['normal', 'conventional'], 'odd'),
    ('eloquent', 'adj', 'বাগ্মী, সুবক্তা', 'fluent and persuasive in speaking', ['articulate', 'expressive', 'fluent'], ['inarticulate'], 'speak'),
    ('elusive', 'adj', 'অধরা', 'hard to find, catch or achieve', ['evasive', 'slippery'], ['attainable', 'accessible'], 'escape'),
    ('eminent', 'adj', 'বিশিষ্ট, খ্যাতিমান', 'famous and respected', ['distinguished', 'renowned', 'prominent'], ['obscure', 'unknown'], 'fame'),
    ('enigma', 'n', 'রহস্য, ধাঁধা', 'a mysterious person or thing', ['mystery', 'puzzle', 'riddle'], ['clarity'], 'mystery'),
    ('ephemeral', 'adj', 'ক্ষণস্থায়ী', 'lasting a very short time', ['transient', 'fleeting', 'short-lived'], ['permanent', 'lasting'], 'brief'),
    ('eradicate', 'v', 'নির্মূল করা', 'to destroy completely', ['eliminate', 'uproot', 'wipe out'], ['establish', 'plant'], 'destroy'),
    ('exemplary', 'adj', 'অনুকরণীয়', 'serving as a good example', ['model', 'ideal', 'admirable'], ['deplorable'], 'good'),
    ('fallacy', 'n', 'ভ্রান্ত ধারণা', 'a mistaken belief', ['misconception', 'error', 'delusion'], ['truth', 'fact'], 'false'),
    ('feeble', 'adj', 'দুর্বল', 'lacking strength', ['weak', 'frail', 'faint'], ['strong', 'robust'], 'weak'),
    ('fervent', 'adj', 'উৎসাহী, আবেগপূর্ণ', 'very passionate', ['ardent', 'passionate', 'zealous'], ['apathetic', 'indifferent'], 'passion'),
    ('fickle', 'adj', 'চঞ্চলমতি, অস্থির', 'changing frequently', ['capricious', 'inconstant', 'changeable'], ['steadfast', 'constant'], 'change'),
    ('frugal', 'adj', 'মিতব্যয়ী', 'economical with money', ['thrifty', 'economical', 'sparing'], ['extravagant', 'wasteful'], 'save'),
    ('futile', 'adj', 'নিষ্ফল, বৃথা', 'pointless; useless', ['useless', 'vain', 'fruitless'], ['fruitful', 'effective'], 'useless')],
    5300,
    roots={'decipher': 'de + cipher (সাংকেতিক লিপি) — সংকেত খুলে ফেলা।', 'eloquent': 'Latin e (বাইরে) + loqui (বলা) — loquacious একই মূল।',
           'eradicate': 'Latin e (বাইরে) + radix (শিকড়) — শিকড়সহ উপড়ে ফেলা।', 'ephemeral': 'Greek ephemeros = "এক দিনের" — যা মাত্র এক দিন টেকে।',
           'docile': 'Latin docere (শেখানো) — যাকে সহজে শেখানো যায়; doctor একই মূল।', 'fervent': 'Latin fervere (ফুটতে থাকা) — fervour।',
           'eccentric': 'Greek ek (বাইরে) + kentron (কেন্দ্র) — কেন্দ্রের বাইরে, অর্থাৎ স্বাভাবিকের বাইরে।', 'futile': 'Latin futilis (যা থেকে সব গড়িয়ে পড়ে যায়) — কিছুই টেকে না।'},
    traps=('dearth', 'deride', 'fickle', 'discern', 'futile'),
    mnem=(('"e/ex = বাইরে"', 'শব্দমূল', 'eradicate (শিকড় বাইরে), eloquent (কথা বাইরে), eccentric (কেন্দ্রের বাইরে)।'),),
    mistakes=('**dearth** = অভাব, "death" নয়।', '**deride** = উপহাস, "ride"-এর সঙ্গে সম্পর্ক নেই।', '**eminent** (বিশিষ্ট) ≠ **imminent** (আসন্ন)।'))

spelling_lesson(B, L + '8', RNG, [
    ('definitely', 'অবশ্যই', 'finite শব্দটা ভেতরে আছে: de-FINITE-ly', ['definately', 'definitly', 'defenitely']),
    ('deceive', 'প্রতারণা করা', 'c-এর পরে ei', ['decieve', 'deceeve', 'desieve']),
    ('desperate', 'মরিয়া', 'des-PER-ate', ['desparate', 'desperete', 'dispirate']),
    ('development', 'উন্নয়ন', 'develop + ment (e নেই)', ['developement', 'devlopment', 'developmant']),
    ('dilemma', 'উভয়সংকট', 'm দুটি; n নেই', ['dilemna', 'dilema', 'dillemma']),
    ('disappear', 'অদৃশ্য হওয়া', 'dis + appear (s একটি, p দুটি)', ['dissapear', 'disapear', 'dissappear']),
    ('disappoint', 'হতাশ করা', 'dis + appoint', ['dissapoint', 'disapoint', 'dissappoint']),
    ('discipline', 'শৃঙ্খলা', 'dis-CIP-line (sc)', ['dicipline', 'disipline', 'discipiline']),
    ('dissatisfied', 'অসন্তুষ্ট', 'dis + satisfied (s দুটি)', ['disatisfied', 'dissatisfyed', 'disattisfied']),
    ('efficient', 'দক্ষ', 'ff; -cient', ['efficeint', 'eficient', 'efficiant']),
    ('eighth', 'অষ্টম', 'eight + h', ['eigth', 'eightth', 'eihgth']),
    ('embarrass', 'বিব্রত করা', 'r দুটি, s দুটি', ['embarass', 'embarras', 'embaress']),
    ('environment', 'পরিবেশ', 'environ + ment (n ভুলবেন না)', ['enviroment', 'envirnment', 'enviornment']),
    ('exaggerate', 'অতিরঞ্জন করা', 'g দুটি', ['exagerate', 'exaggarate', 'exxagerate']),
    ('excellent', 'চমৎকার', 'l দুটি; -ent', ['excelent', 'excellant', 'exellent']),
    ('existence', 'অস্তিত্ব', '-ence', ['existance', 'existense', 'exsistence']),
    ('February', 'ফেব্রুয়ারি', 'Feb-RU-ary — r বাদ দেবেন না', ['Febuary', 'Februery', 'Febrary']),
    ('fluorescent', 'প্রতিপ্রভ', 'flu-OR (fluor), -escent', ['flourescent', 'fluorescant', 'florescent']),
    ('foreign', 'বিদেশি', 'e আগে, i পরে (ব্যতিক্রম)', ['foriegn', 'forein', 'foreighn']),
    ('forty', 'চল্লিশ', 'four থেকে u বাদ', ['fourty', 'fortey', 'fourtie'])],
    traps=('forty', 'development', 'dilemma', 'February'),
    mnem=(('"dis + মূল শব্দ — s কয়টা মূল শব্দ বলবে"', 'dis- উপসর্গ', 'dis+appear = disappear (s এক); dis+satisfied = dissatisfied (s দুই)।'),
          ('"embarrass — Really Red, So Shy"', 'embarrass', 'rr, ss।')),
    mistakes=('"fourty" ✗ → **forty** (four-এর u বাদ)।', '"definately" ✗ → **definitely**।'))

gv_lesson(B, L + '9', RNG, [
    ('do away with', 'বাতিল/বিলুপ্ত করা', 'abolish'), ('do without', '(কিছু) ছাড়াই চলা', 'manage without'),
    ('draw up', 'খসড়া/দলিল তৈরি করা', 'prepare (a document)'), ('drop in', 'হঠাৎ বেড়াতে আসা', 'visit casually'),
    ('drop out', 'ঝরে পড়া (পড়াশোনা ছেড়ে দেওয়া)', 'leave school or a course'), ('die out', 'বিলুপ্ত হওয়া', 'become extinct'),
    ('dwell on', 'কোনো বিষয়ে দীর্ঘক্ষণ ভাবা/বলা', 'think or talk at length about'), ('eke out', 'কষ্টে চালানো', 'make something last by careful use'),
    ('end up', 'শেষে কোনো অবস্থায় পৌঁছানো', 'finally be in a place or situation'), ('fall back on', 'বিপদে ভরসা করা', 'rely on when other things fail'),
    ('fall out', 'ঝগড়া করা', 'quarrel'), ('fall through', 'ভেস্তে যাওয়া', 'fail to happen'),
    ('fall behind', 'পিছিয়ে পড়া', 'fail to keep up'), ('fill in', '(ফরম) পূরণ করা', 'complete (a form)'),
    ('find out', 'খুঁজে বের করা', 'discover'), ('figure out', 'বুঝে ফেলা', 'understand; solve'),
    ('fend off', 'প্রতিহত করা', 'defend oneself against'), ('do up', 'মেরামত/সাজানো', 'repair or decorate')],
    [('The government decided to ___ the old law.', 'do away with', ['do without', 'drop in', 'draw up'], 'আইন বাতিল'),
     ('The deal ___ at the last moment.', 'fell through', ['fell out', 'fell behind', 'fell back on'], 'চুক্তি ভেস্তে যাওয়া'),
     ('The two friends ___ over a small matter.', 'fell out', ['fell through', 'fell behind', 'filled in'], 'ঝগড়া'),
     ('Please ___ this form.', 'fill in', ['find out', 'fend off', 'figure out'], 'ফরম পূরণ'),
     ('Dinosaurs ___ millions of years ago.', 'died out', ['dropped out', 'ended up', 'did up'], 'বিলুপ্ত'),
     ('He ___ of school because of poverty.', 'dropped out', ['dropped in', 'died out', 'drew up'], 'পড়াশোনা ছেড়ে দেওয়া'),
     ('The lawyer ___ the agreement.', 'drew up', ['did up', 'dropped in', 'ended up'], 'দলিল তৈরি'),
     ('If he loses his job, he can ___ his savings.', 'fall back on', ['fall out', 'fall through', 'fend off'], 'বিপদে ভরসা')],
    5400, traps=('fall out', 'fall through', 'drop in', 'drop out'),
    mnem=(('"FALL পরিবার: out-ঝগড়া, through-ভেস্তে যাওয়া, behind-পিছিয়ে, back on-ভরসা"', 'fall', 'একসাথে পড়ুন।'), ('"DROP: in-বেড়াতে আসা, out-ঝরে পড়া"', 'drop', 'ভেতরে আসা বনাম বাইরে যাওয়া।')),
    mistakes=('**fall out** = ঝগড়া; **fall through** = ব্যর্থ হওয়া।', '**drop in** = হঠাৎ দেখা করতে আসা; **drop out** = ছেড়ে দেওয়া।'))

B.autofill_cards(12)
B.save('b2', 'en-b2')
