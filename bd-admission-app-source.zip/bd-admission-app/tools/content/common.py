"""কনটেন্ট লেখার সহায়ক: প্রশ্ন ও Flashcard যাচাইসহ তৈরি।
প্রতিটি MCQ-তে: একটিই সঠিক উত্তর, প্রতিটি ভুল অপশনের কারণ, নিয়ম (r), কৌশল (t), সম্পর্কিত তথ্য (f) বাধ্যতামূলক।"""
import json, os, random

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


class Bank:
    def __init__(self, prefix, sub, seed):
        self.prefix, self.sub = prefix, sub
        self.Q, self.F, self.L = [], [], {}
        self.rnd = random.Random(seed)
        self._seen = set()

    def q(self, lid, d, question, correct, wrongs, r, t, f, trap=False):
        """wrongs: [(অপশন, কেন ভুল), ...] — ঠিক ৩টি"""
        assert len(wrongs) == 3, question
        assert question not in self._seen, question
        self._seen.add(question)
        opts = [correct] + [w[0] for w in wrongs]
        assert len(set(opts)) == 4, (question, opts)
        why = {correct: 'সঠিক উত্তর।'}
        for o, reason in wrongs:
            assert reason.strip(), (question, o)
            why[o] = reason
        assert r and t and f, question
        self.rnd.shuffle(opts)
        item = {'id': f'{self.prefix}-{len(self.Q) + 1:03d}', 'sub': self.sub, 'lid': lid, 'd': d, 'src': 'মৌলিক',
                'q': question, 'o': opts, 'a': opts.index(correct), 'e': {'r': r, 't': t, 'f': f, 'w': [why[o] for o in opts]}}
        if trap:
            item['trap'] = 1
        self.Q.append(item)

    def card(self, lid, front, back):
        self.F.append({'id': f'fc-{self.prefix}-{len(self.F) + 1:03d}', 'sub': self.sub, 'lid': lid, 'f': front, 'b': back})

    def lesson(self, lid, blocks, src, v=None):
        assert lid not in self.L
        self.L[lid] = {'b': blocks, 'src': src}
        if v:
            self.L[lid]['v'] = v

    def autofill_cards(self, minimum=10):
        """প্রতিটি পাঠে কমপক্ষে `minimum`টি Flashcard: ঘাটতি পূরণ হয় ঐ পাঠেরই যাচাইকৃত MCQ থেকে
        (প্রশ্ন → সঠিক উত্তর + মূল নিয়ম)। "নয়/নেই/সঠিক নয়" ধরনের নেতিবাচক প্রশ্ন বাদ।"""
        import re
        neg = re.compile(r'নয়|নেই|ঘটেনি|সত্য নয়|সঠিক নয়|যুক্ত নয়')
        for lid in self.L:
            have = sum(1 for c in self.F if c['lid'] == lid)
            fronts = {c['f'] for c in self.F}
            for q in self.Q:
                if have >= minimum: break
                if q['lid'] != lid or neg.search(q['q']) or q['q'] in fronts: continue
                ans = q['o'][q['a']]
                self.card(lid, q['q'], f"{ans} — {q['e']['r']}")
                have += 1

    def save(self, lesson_file, name):
        def dump(rel, obj):
            p = os.path.join(ROOT, 'src', 'data', rel)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            json.dump(obj, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        dump(f'lessons/{self.sub}/{lesson_file}.json', self.L)
        dump(f'questions/{name}.json', {'meta': {'sub': self.sub, 'note': 'মৌলিক প্রশ্ন — PYQ নয়'}, 'q': self.Q})
        dump(f'flashcards/{name}.json', {'meta': {'sub': self.sub}, 'cards': self.F})
        from collections import Counter
        print(f'{name}: পাঠ {len(self.L)}, প্রশ্ন {len(self.Q)} (ট্রিকি {sum(1 for x in self.Q if x.get("trap"))}), '
              f'Flashcard {len(self.F)}; পাঠভিত্তিক প্রশ্ন {dict(Counter(x["lid"] for x in self.Q))}')


# ব্লক তৈরির ছোট সহায়ক
def H(x): return {'k': 'h', 'x': x}
def P(x): return {'k': 'p', 'x': x}
def UL(*x): return {'k': 'list', 'x': list(x)}
def OL(*x): return {'k': 'list', 'x': list(x), 'o': 1}
def FACTS(*x, h=None):
    b = {'k': 'facts', 'x': list(x)}
    if h: b['h'] = h
    return b
def SUMMARY(*x): return {'k': 'summary', 'x': list(x)}
def MISTAKES(*x): return {'k': 'mistakes', 'x': list(x)}
def TRICKS(*x): return {'k': 'tricks', 'x': list(x)}
def UNI(x): return {'k': 'uni', 'x': x}
def VERIFY(x): return {'k': 'verify', 'x': x}
def MNEM(*x): return {'k': 'mnemonic', 'x': [{'m': a, 'f': b, 'how': c} for a, b, c in x]}
def QUOTE(q, s, ctx, e): return {'k': 'quote', 'q': q, 's': s, 'ctx': ctx, 'e': e}
def WORDS(*x, h=None):
    b = {'k': 'words', 'x': [list(p) for p in x]}
    if h: b['h'] = h
    return b
def ENTRIES(h, *items):
    """শব্দ/Idiom/প্রবাদ কার্ড: প্রতিটি dict — w (শিরোনাম), bn (বাংলা অর্থ), en?, syn?, ant?, ctx? (উৎস/প্রসঙ্গ), ex? (উদাহরণ)"""
    return {'k': 'entries', 'h': h, 'x': [dict((k, v) for k, v in it.items() if v) for it in items]}
def TABLE(h, cols, *rows): return {'k': 'table', 'h': h, 'c': list(cols), 'r': [list(r) for r in rows]}
def TIMELINE(h, *items): return {'k': 'timeline', 'h': h, 'x': [dict(zip(('y', 't', 'd', 'g'), it)) for it in items]}
def MATCH(h, *pairs): return {'k': 'match', 'h': h, 'x': [list(p) for p in pairs]}

UNI_GENERIC = ('ঢাবি (কলা, আইন ও সামাজিক বিজ্ঞান ইউনিট), গুচ্ছ, জাবি, রাবি ও চবির বাংলা অংশে এইচএসসি সাহিত্যপাঠের রচনা থেকে '
               'লেখক-উৎস-প্রকাশকাল, চরিত্র, উদ্ধৃতি ও শব্দার্থধর্মী প্রশ্ন আসার প্রবণতা আছে — তবে কোন বছর কতটি এসেছে, '
               'সে পরিসংখ্যান যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত এখানে দেওয়া হচ্ছে না। নির্দিষ্ট ইউনিটের সিলেবাস সর্বশেষ বিজ্ঞপ্তিতে মিলিয়ে নিন।')
