#!/usr/bin/env python3
"""EFT (NCTB, সংশোধিত ২০২৪-২৫) — Block 2 ও 3-এর লেসন:
U2·L3 Art, U2·L4 Craft, U3·L1 Myths of Bengal, U3·L2 Icarus, U3·L3 The Legend of Gazi,
U3·L4 Khona, U4·L1 Three Speeches, U4·L2 Great Women, U5·L4 Coal Miners, U5·L5 Frederick Douglass
নীতি: পাঠ্যবইয়ের গদ্য হুবহু নয় — বাংলায় সারাংশ ও নিজের ভাষায় প্রশ্ন; কেবল কপিরাইটমুক্ত লেখার দু-এক লাইন উদ্ধৃত।"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('eneft2', 'en', 9921)
Q = B.q
SRC = ['English For Today, Classes XI-XII & Alim (NCTB, সংশোধিত ২০২৪-২৫ সংস্করণ)']
UNIT_EFT = ('ঢাবি B ইউনিটসহ বিভিন্ন ভর্তি পরীক্ষার English অংশে HSC-র English For Today থেকে লেখক, উৎস, চরিত্র, সাল ও শব্দার্থধর্মী প্রশ্ন আসার প্রবণতা আছে — '
            'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না।')
def FQ(lid, tip, fact, rows):
    for s, a, w, r, trap in rows:
        Q(lid, 2, s, a, w, r, tip, fact, trap=trap)
def W(*w): return [(x, 'পাঠের তথ্যের সঙ্গে মেলে না।') for x in w]

# =====================================================================
# U2·L3 Art  (en-2-10)
# =====================================================================
B.lesson('en-2-10', [
    H('Art — এক নজরে'),
    P('শিল্প = মানুষের কল্পনা ও সৃজনশীলতার প্রকাশ — চিত্রকলা, ড্রয়িং, ভাস্কর্য, স্থাপত্য। লক্ষ্য নান্দনিক অনুভূতি জাগানো, আবার সামাজিক মন্তব্যও হতে পারে। Pablo Picasso-র উক্তি পাঠে আছে: শিল্পের উদ্দেশ্য দৈনন্দিন জীবনের ধুলো আত্মা থেকে ধুয়ে দেওয়া।'),
    TABLE('বাংলাদেশের শিল্পধারা', ['ধারা', 'উদাহরণ/তথ্য'],
          ('লোকশিল্প (folk art)', 'মৃৎশিল্প, নকশিকাঁথা, আলপনা, শখের হাঁড়ি'), ('আধুনিক শিল্পের উৎস', 'উনিশ শতকের মাঝামাঝি পশ্চিম ইউরোপের শিল্পবিপ্লব'),
          ('বাংলাদেশে আধুনিক শিল্পের সূচনা', '১৯৪৮ — জয়নুল আবেদিন ঢাকায় আর্ট ইনস্টিটিউট প্রতিষ্ঠা করেন (এখন ঢাবির চারুকলা অনুষদ)'),
          ('জয়নুলের খ্যাতি', '১৯৪৩-এর বাংলার দুর্ভিক্ষ নিয়ে Famine Sketches'), ('১৯৭১-পরবর্তী', 'installation art, graphic art; ঐতিহ্যবাহী রূপের নবায়ন')),
    FACTS('Zainul Abedin: **1914–1976**', 'অন্যান্য শিল্পী (পাঠে): Qamrul Hassan, SM Sultan, Safiuddin Ahmed, Murtaza Baseer, Mohammad Kibria, Novera Ahmed প্রমুখ', h='শিল্পাচার্য'),
    H('S M Sultan'),
    UL('পুরো নাম **Sheikh Mohammed Sultan**; জন্ম **আগস্ট ১৯২৩, যশোর**; bohemian, ভ্রমণপ্রিয় শিল্পী', 'প্রথম প্রদর্শনী ঢাকায় **১৯৭৬**; Goethe Institut, Dhaka-র retrospective **১৯৮৭**',
       'বিশেষ সুপারিশে **Calcutta School of Arts**-এ তিন বছর পড়েন', 'বিষয়: কৃষক, গ্রামীণ নারী, শিশু, প্রাণী — **পেশিবহুল, অতিমানবীয় কৃষক** তাঁর প্রধান বৈশিষ্ট্য',
       'পুরস্কার: একুশে পদক, স্বাধীনতা পদক, বাংলাদেশ চারুশিল্পী সংসদ পদক', 'Tareque Masud-এর প্রামাণ্যচিত্র **Adam Surat** তাঁকে নিয়ে'),
    H('Novera Ahmed'),
    UL('বাংলাদেশের **প্রথম নারী ভাস্কর** ও আধুনিক ভাস্কর্যের পথিকৃৎ; জন্ম চট্টগ্রামে', 'লন্ডন ও ফ্লোরেন্সে শিক্ষা — পাশ্চাত্য ধারণা ও লোকঐতিহ্যের মিশ্রণ; বৌদ্ধ থিম; নারীর অভিজ্ঞতা',
       'আগস্ট **১৯৬০**: কেন্দ্রীয় গণগ্রন্থাগারে (এখন ঢাবি গ্রন্থাগার) প্রথম একক ভাস্কর্য প্রদর্শনী — দেশে প্রথম', 'উপকরণ: সিমেন্ট, কাঠ, প্লাস্টার, পাথর',
       '১৯৬২-তে ভরতনাট্যম শিখতে বোম্বে, পরে প্যারিসে স্থায়ী', '**শহীদ মিনার**-এর মূল নকশাকারদের একজন — Hamidur Rahman-এর সঙ্গে', '১৯৯৭-এ (অনুপস্থিতিতে) একুশে পদক'),
    SUMMARY('Zainul Abedin (1914–1976), Famine Sketches, ১৯৪৮-এ আর্ট ইনস্টিটিউট', 'SM Sultan — জন্ম ১৯২৩, যশোর; পেশিবহুল কৃষক; Adam Surat', 'Novera Ahmed — প্রথম নারী ভাস্কর; ১৯৬০-এর একক প্রদর্শনী; শহীদ মিনার'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-2-10', 'নাম-সাল-ঘটনা জোড়ায় মুখস্থ রাখুন।', 'Art — সারণি।', [
    ('According to the lesson, modern art practices in Bangladesh began in —', '1948', W('1943', '1952', '1971'), '১৯৪৮-এ জয়নুল আবেদিনের আর্ট ইনস্টিটিউট।', True),
    ('The art institute founded by Zainul Abedin is now —', 'the Faculty of Fine Art, University of Dhaka', W('Bangla Academy', 'Shilpakala Academy', 'the National Museum'), 'এখন ঢাবির চারুকলা অনুষদ।', False),
    ('Zainul Abedin earned all-India fame for his —', 'Famine Sketches', W('Sculptures of Buddha', 'Nakshikantha designs', 'Muscular farmers'), '১৯৪৩-এর দুর্ভিক্ষের স্কেচ।', True),
    ('The Famine Sketches were based on the Bengal famine of —', '1943', W('1947', '1974', '1921'), '১৯৪৩।', True),
    ('Zainul Abedin\'s life span as given in EFT is —', '1914–1976', W('1923–1994', '1930–2015', '1899–1976'), '১৯১৪–১৯৭৬।', False),
    ('Which is an example of folk art mentioned in the lesson?', 'alpana', W('installation art', 'abstract expressionism', 'graphic art'), 'আলপনা, নকশিকাঁথা, শখের হাঁড়ি।', False),
    ('According to the lesson, modern art owes its origin to —', 'the industrial revolution in Western Europe', W('the Mughal court', 'the Bengal famine', 'the Liberation War'), 'উনিশ শতকের শিল্পবিপ্লব।', True),
    ('S M Sultan was born in —', 'Jessore', W('Chattogram', 'Mymensingh', 'Kushtia'), 'আগস্ট ১৯২৩, যশোর।', True),
    ('S M Sultan studied for three years at —', 'the Calcutta School of Arts', W('the Sorbonne', 'Dhaka Art Institute', 'Shantiniketan'), 'বিশেষ সুপারিশে কলকাতায়।', False),
    ('The main feature of S M Sultan\'s paintings is —', 'muscular, larger-than-life farmers', W('city skylines', 'abstract shapes only', 'portraits of kings'), 'পেশিবহুল কৃষক।', True),
    ('A major retrospective that solidified Sultan\'s status was organised in 1987 by —', 'the Goethe Institut, Dhaka', W('Bangla Academy', 'the British Council', 'Alliance Française'), 'Goethe Institut।', True),
    ('The documentary on S M Sultan mentioned in the lesson is —', 'Adam Surat by Tareque Masud', W('Matir Moina by Tareque Masud', 'Pather Panchali by Satyajit Ray', 'Muktir Gaan by Tareque Masud'), 'Adam Surat।', True),
    ('Novera Ahmed is described as Bangladesh\'s first —', 'female sculptor', W('female painter', 'female architect', 'female filmmaker'), 'প্রথম নারী ভাস্কর।', True),
    ('Novera Ahmed was born in —', 'Chittagong', W('Dhaka', 'Sylhet', 'Rajshahi'), 'চট্টগ্রাম।', False),
    ('Novera Ahmed\'s first solo exhibition (1960) was held at —', 'the Central Public Library (now Dhaka University Library)', W('Shilpakala Academy', 'the Goethe Institut', 'Alliance Française, Dhaka'), 'দেশের প্রথম একক ভাস্কর্য প্রদর্শনী।', True),
    ('Novera Ahmed collaborated with Hamidur Rahman in designing —', 'the Shaheed Minar', W('the National Memorial', 'the Parliament House', 'Aparajeyo Bangla'), 'শহীদ মিনারের মূল নকশা।', True),
    ('Novera Ahmed received the Ekushey Padak in —', '1997', W('1976', '1960', '2005'), '১৯৯৭ (অনুপস্থিতিতে)।', False),
])

# =====================================================================
# U2·L4 Craft  (en-2-11)
# =====================================================================
B.lesson('en-2-11', [
    H('Craft — এক নজরে'),
    P('Art অন্তর্দৃষ্টিমূলক ও দূরদর্শী; **craft** হলো দৈনন্দিন ব্যবহার্য, প্রায়ই সুন্দর জিনিস তৈরির ব্যবহারিক দক্ষতা — মৃৎপাত্র, ধাতু-কাঠের কাজ, বেত-বাঁশ, গয়না, একতারা-ঢোল-বাঁশি, বস্ত্র। কারিগরেরা (artisans) অভিজ্ঞদের অধীনে কাজ করতে করতে শেখেন, প্রায়ই একই পরিবার থেকে আসেন।'),
    UL('কৃষিনির্ভর গ্রামীণ সমাজে কুলা থেকে মাটির প্রদীপ, হাতপাখা থেকে ধাতব মুদ্রা — সব কারিগরের তৈরি; হাতে তৈরি বলে **handicrafts**',
       'শিল্পকর্মে শিল্পীর স্বাক্ষর ও খ্যাতি মূল্য ঠিক করে; কারুকাজের নির্মাতা **অনামা** থাকেন, তবু ব্যক্তিগত ছোঁয়া থাকে (টেরাকোটা পুতুল, শতরঞ্জি, নকশিকাঁথা)',
       'কারুকাজ **dynamic** — রুচি ও প্রয়োজনের সঙ্গে বদলায়; আবার কিছু মোটিফ দীর্ঘদিন টিকে থেকে সমাজের মূল্যবোধের **stable signifier** হয়',
       'পাঠের লেখচিত্র: বাংলাদেশ থেকে EU-তে হাতে বোনা কার্পেটের রপ্তানি — ২০১৬-১৭-তে তীব্র বৃদ্ধি'),
    H('Sonargaon ও Panam Nagar'),
    TABLE('Sonargaon', ['বিষয়', 'তথ্য (পাঠ অনুযায়ী)'], ('অবস্থান', 'নারায়ণগঞ্জ জেলার উপজেলা; ঢাকা থেকে প্রায় **২৪ কিমি**'),
          ('লোকশিল্প জাদুঘর', 'জয়নুল আবেদিন **১৯৭০**-এ প্রতিষ্ঠা করেন'), ('ইতিহাস', 'চৌদ্দ শতকের শুরুতে স্বাধীন বাংলার সুলতানির রাজধানী; তারও আগে রাজা দনুজ রায়ের অধীনে বঙ্গের রাজধানী'),
          ('বিদেশি পর্যটক', 'গ্রিক ও রোমান লেখকদের উল্লেখ; **Ibn Battuta** ১৩৪৬-এ আসেন'),
          ('Panam Nagar', 'মোগলরা ১৬১১-এ সোনারগাঁ জয়ের পর শাসকদের আবাস; ব্রিটিশ আমলে **মসলিন** বাণিজ্যকেন্দ্র; শীর্ষে প্রায় ১৪০০ তাঁতি পরিবার; ৬০০ মিটার রাস্তার দুপাশে হিন্দু বণিকদের (১৯ শতকের শুরু–২০ শতকের শুরু) ইটের ভবন; এখন heritage site; তিনটি পুরোনো সেতু ও তিনটি খাল')),
    WORDS(('intuitive', 'অন্তর্দৃষ্টিমূলক'), ('visionary', 'দূরদর্শী'), ('signifier', 'নির্দেশক চিহ্ন'), ('antiquity', 'প্রাচীনত্ব'), ('splendid', 'জাঁকালো'), h='শব্দার্থ'),
    SUMMARY('Art = অন্তর্দৃষ্টি; Craft = ব্যবহারিক দক্ষতা, নির্মাতা অনামা', 'Sonargaon: নারায়ণগঞ্জ, ২৪ কিমি, জাদুঘর ১৯৭০, Ibn Battuta ১৩৪৬', 'Panam Nagar: মসলিন, ১৪০০ তাঁতি পরিবার, ৬০০ মি রাস্তা'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-2-11', 'Sonargaon-এর সংখ্যাগুলো (২৪ কিমি, ১৯৭০, ১৩৪৬, ১৬১১, ১৪০০, ৬০০) আলাদা করে মনে রাখুন।', 'Craft — Sonargaon সারণি।', [
    ('According to the lesson, craft is seen as —', 'a practical application of skills to make objects of everyday use', W('purely intuitive and visionary', 'art signed by famous artists', 'only decorative painting'), 'Art intuitive; craft practical।', True),
    ('Artisans usually learn their skills —', 'on the job under older, experienced artisans', W('at universities', 'from books only', 'through online courses'), 'On-the-job training, প্রায়ই পরিবারে।', False),
    ('Unlike an artwork, a craftwork usually —', 'remains anonymous but keeps a personal touch', W('carries the maker\'s signature', 'is valued by the maker\'s fame', 'is never used at home'), 'নির্মাতা অনামা।', True),
    ('A "shatranji" is —', 'a cotton floor mat', W('a clay doll', 'a winnowing basket', 'a metal coin'), 'শতরঞ্জি।', False),
    ('The lesson calls a craftwork "dynamic" because it —', 'keeps changing with tastes and needs', W('never changes', 'is made by machines', 'is always expensive'), 'রুচি ও প্রয়োজনের সঙ্গে বদলায়।', False),
    ('Sonargaon is an Upazila in the district of —', 'Narayanganj', W('Munshiganj', 'Gazipur', 'Narsingdi'), 'নারায়ণগঞ্জ।', True),
    ('Sonargaon is about how far from Dhaka?', '24 kilometres', W('42 kilometres', '14 kilometres', '64 kilometres'), 'প্রায় ২৪ কিমি।', True),
    ('The Folk Arts and Crafts Museum at Sonargaon was set up by Zainul Abedin in —', '1970', W('1948', '1975', '1965'), '১৯৭০।', True),
    ('In the early 14th century, Sonargaon was the capital of —', 'the independent Sultanate of Bengal', W('the Mughal Empire', 'British India', 'the Pala kingdom'), 'স্বাধীন সুলতানি।', True),
    ('Before the Sultanate, Sonargaon was the capital of Vanga under —', 'Raja Danauja Rai', W('Raja Pratapaditya', 'Isa Khan', 'Raja Ganesh'), 'রাজা দনুজ রায়।', True),
    ('Which traveller visited Sonargaon in 1346?', 'Ibn Battuta', W('Marco Polo', 'Hiuen Tsang', 'Fa-Hien'), 'Ibn Battuta, ১৩৪৬।', True),
    ('According to the lesson, the Moghuls conquered Sonargaon in —', '1611', W('1576', '1757', '1608'), '১৬১১।', True),
    ('Under British rule, Panam Nagar became a centre of —', 'muslin trade', W('jute trade', 'tea trade', 'indigo trade'), 'মসলিন।', True),
    ('At the peak of the trade, about how many weaver families lived around Panam Nagar?', '1400', W('400', '14000', '140'), 'প্রায় ১৪০০।', True),
    ('The old buildings of Panam Nagar line a road of about —', '600 metres', W('6 kilometres', '60 metres', '1600 metres'), '৬০০ মিটার।', False),
    ('The brick buildings of Panam Nagar were built by —', 'Hindu traders', W('Mughal governors', 'British officers', 'Portuguese merchants'), 'হিন্দু বণিকেরা।', False),
    ('Why does no one live in the Panam Nagar buildings now?', 'The place is considered a heritage site.', W('The buildings are under water.', 'They are owned by the army.', 'They are too new.'), 'Heritage site।', False),
])

# =====================================================================
# U3·L1 Myths of Bengal  (en-2-12)
# =====================================================================
B.lesson('en-2-12', [
    H('Myths of Bengal — এক নজরে'),
    FACTS('কবিতা: জীবনানন্দ দাশের **"বাংলার মুখ আমি দেখিয়াছি"**', 'ইংরেজি অনুবাদ: **"I Have Seen Bengal\'s Face"** — অনুবাদক **Fakrul Alam**', 'কবি: **Jibanananda Das (1899–1954)**',
          'কবিতাটি ১৪ চরণের, দুই ভাবগত অংশে বিভক্ত — **sonnet** (বাংলায় **সনেট/চতুর্দশপদী**)', h='মূল তথ্য'),
    P('কবি বাংলার রূপ দেখেছেন বলে পৃথিবীর আর কোনো রূপ খুঁজতে চান না। ভোরে ডুমুরগাছের নিচে দোয়েল, জাম-বট-কাঁঠাল-হিজল-অশ্বত্থের পত্রপল্লব, ফণীমনসার ঝোপ — প্রকৃতির নিবিড় চিত্র। দ্বিতীয় অংশে মধ্যযুগীয় কাহিনির চাঁদ সওদাগর ও বেহুলাকে টেনে এনে দেখান, তারাও এই অপরূপ বাংলা দেখেছিল — বেহুলা গাঙুড়ের জলে ভেলায়, আর ইন্দ্রের সভায় (Amara) নাচের সময় বাংলার নদী-মাঠ তার পায়ে ঘুঙুরের মতো কেঁদেছিল।'),
    TABLE('কবিতায় উল্লিখিত গাছ ও পাখি', ['গাছ/উদ্ভিদ', 'পাখি'], ('fig (ডুমুর), Jaam, Kanthal, Bat (বট), Hijol, Aswatha, Tamal, Champa, cactus, zedoary', 'swallow (অনুবাদে; মূলে দোয়েল), thrush (শ্যামা), wagtail (খঞ্জনা)')),
    H('Behula ও Chand Saodagar (Banglapedia থেকে)'),
    UL('বেহুলা মধ্যযুগীয় কাব্য **মনসামঙ্গল**-এর নায়িকা; উজানিনগরের সায়বেনের কন্যা', 'স্বামী **লখিন্দর** — চম্পকনগরের **চাঁদ সওদাগরের** কনিষ্ঠ পুত্র',
       'শিবভক্ত চাঁদ সওদাগর মনসাকে অবজ্ঞা করতেন; লোহার বাসরঘর বানালেও মনসার পাঠানো সাপ চুলের মতো সরু হয়ে ছিদ্র দিয়ে ঢুকে লখিন্দরকে দংশন করে',
       'বেহুলা কলার ভেলায় স্বামীর মৃতদেহ নিয়ে দেবলোকের দিকে যাত্রা করেন; মনসার কাছে প্রতিশ্রুতি দেন চাঁদ সওদাগর তাঁর পূজা করবেন',
       'মনসা লখিন্দর ও তার ভাইদের ফিরিয়ে দেন; চাঁদ সওদাগর শেষে মনসার কাছে নত হন; লখিন্দর-বেহুলা স্বর্গে ফিরে যান **অনিরুদ্ধ ও ঊষা** রূপে'),
    WORDS(('roosting', 'ডালে বসে বিশ্রাম/রাত কাটানো'), ('hush', 'নিস্তব্ধতা'), ('honeycombed', 'মৌচাকের মতো খোপকাটা (নৌকা)'), ('waning', 'ক্ষীয়মাণ (চাঁদ)'), ('desolate', 'নিঃসঙ্গ, বিষণ্ন'), ('wailed', 'বিলাপ করল'), h='শব্দার্থ'),
    SUMMARY('Jibanananda Das (1899–1954); অনুবাদ Fakrul Alam', '১৪ চরণ, দুই অংশ — sonnet', 'মনসামঙ্গল: বেহুলা, লখিন্দর, চাঁদ সওদাগর; অনিরুদ্ধ-ঊষা'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-2-12', 'কবি, অনুবাদক ও মনসামঙ্গলের চরিত্রগুলো জোড়ায় মনে রাখুন।', 'Myths of Bengal।', [
    ('"I Have Seen Bengal\'s Face" is the English translation of a poem by —', 'Jibanananda Das', W('Rabindranath Tagore', 'Kazi Nazrul Islam', 'Jasimuddin'), '"বাংলার মুখ আমি দেখিয়াছি"।', True),
    ('The poem was translated into English by —', 'Fakrul Alam', W('Kaiser Haq', 'Syed Manzoorul Islam', 'Buddhadeva Bose'), 'Fakrul Alam।', True),
    ('Jibanananda Das\'s life span as given in EFT is —', '1899–1954', W('1861–1941', '1899–1976', '1903–1976'), '১৮৯৯–১৯৫৪।', True),
    ('The poem has fourteen lines in two thematic sections. Such a poem is called —', 'a sonnet', W('a ballad', 'an ode', 'an elegy'), 'Sonnet = চতুর্দশপদী।', True),
    ('Behula is the heroine of the medieval epic —', 'Manasamangal', W('Chandimangal', 'Annadamangal', 'Meghnadbadh Kavya'), 'মনসামঙ্গল।', True),
    ('Behula was the daughter of —', 'Sayven of Ujaninagar', W('Chand Saodagar', 'King Dharmaketu', 'Varaha'), 'উজানিনগরের সায়বেন।', False),
    ('Lakhindar was the youngest son of —', 'Chand Saodagar of Champaknagar', W('Sayven of Ujaninagar', 'King Minos', 'Mihir'), 'চম্পকনগরের চাঁদ সওদাগর।', True),
    ('Chand Saodagar was a devotee of —', 'Shiva', W('Manasa', 'Indra', 'Vishnu'), 'শিবভক্ত, মনসাবিরোধী।', True),
    ('Manasa is described as —', 'the snake goddess', W('the river goddess', 'the goddess of wealth', 'the goddess of learning'), 'সর্পদেবী।', False),
    ('To protect Lakhindar, Chand Saodagar built —', 'an iron chamber', W('a golden cage', 'a stone temple', 'a wooden boat'), 'লোহার বাসরঘর।', True),
    ('How did the snake enter the iron chamber?', 'by making itself as fine as a hair and passing through a tiny hole', W('through the open door', 'through the roof', 'it was already inside'), 'চুলের মতো সরু হয়ে।', False),
    ('Behula carried her husband\'s body on —', 'a banana raft', W('a golden chariot', 'an elephant', 'a merchant ship'), 'কলার ভেলা।', True),
    ('Lakhindar and Behula finally returned to heaven as —', 'Aniruddha and Usa', W('Radha and Krishna', 'Shiva and Parvati', 'Rama and Sita'), 'অনিরুদ্ধ ও ঊষা।', True),
    ('In the poem, "Amara" refers to the place —', 'where the gods held court', W('where Behula was born', 'where Chand lived', 'where the snake hid'), 'ইন্দ্রের সভা।', False),
    ('In the poem, Behula danced "like a desolate —"', 'wagtail', W('swallow', 'thrush', 'peacock'), 'ছিন্ন খঞ্জনা।', False),
    ('The central theme of "I Have Seen Bengal\'s Face" is —', 'the incomparable natural beauty of Bengal', W('the horrors of war', 'city life', 'a love story only'), 'বাংলার অপরূপ রূপ।', False),
    ('The word "waning" (as in the waning moon) means —', 'gradually becoming smaller', W('becoming brighter', 'rising', 'disappearing suddenly'), 'ক্ষীয়মাণ।', False),
])

# =====================================================================
# U3·L2 Icarus  (en-2-13)
# =====================================================================
B.lesson('en-2-13', [
    H('Icarus — এক নজরে'),
    P('গ্রিক পুরাণ: **Crete** দ্বীপে অর্ধেক মানুষ-অর্ধেক ষাঁড় **Minotaur** আতঙ্ক ছড়াত। রাজা **Minos** স্থপতি-উদ্ভাবক **Daedalus**-কে দিয়ে জটিল **labyrinth** (গোলকধাঁধা) বানিয়ে তাতে Minotaur-কে আটকালেন। পরে Daedalus ও তাঁর পুত্র **Icarus**-কেও সেখানে বন্দি করেন। নকশা জানা Daedalus ছেলেকে নিয়ে পালান, কিন্তু দ্বীপ থেকে সমুদ্রপথে পালানোর উপায় ছিল না।'),
    OL('পাখি দেখে Daedalus **পালক ও মোম** দিয়ে ডানা বানালেন।', 'সতর্ক করলেন: সমুদ্রের খুব কাছে উড়লে ডানা আর্দ্রতায় ভারী হবে, সূর্যের খুব কাছে উড়লে মোম গলবে — মাঝারি উচ্চতায় ওড়ো।',
       'উড়ানের উত্তেজনায় Icarus উপদেশ ভুলে ওপরে উঠল; সূর্যের তাপে মোম গলে সে সমুদ্রে পড়ে ডুবে মারা গেল।', 'Daedalus একা **Sicily** পৌঁছে শোক করলেন; ছেলের নামে সমুদ্রের নাম দিলেন **Icarian Sea**।'),
    H('চিত্র ও কবিতা'),
    UL('চিত্রকর্ম: **Landscape with the Fall of Icarus** — **Pieter Brueghel (1525–1569)**', 'কবিতা: একই নামে **William Carlos Williams (1883–1963)**; New Jersey-তে জন্ম, চিকিৎসক ও কবি, free verse; The Red Wheelbarrow (Spring and All, 1923), Paterson; মরণোত্তর Pulitzer Prize',
       'কবিতার মূল বক্তব্য: বসন্তে কৃষক মাঠে লাঙল দিচ্ছে, প্রকৃতি নিজের কাজে ব্যস্ত — উপকূলের কাছে Icarus-এর ডুবে যাওয়া "a splash quite unnoticed"; জগতের **উদাসীনতা**', 'Jorge Luis Borges-এর বিখ্যাত সংকলন **Labyrinths**-এর উল্লেখও আছে'),
    WORDS(('labyrinth', 'গোলকধাঁধা (maze)'), ('intricate', 'জটিল, সূক্ষ্ম'), ('gruesome', 'বীভৎস'), ('stranded', 'আটকে পড়া'), ('heed', 'কানে তোলা, মানা'), ('plummet', 'সোজা নিচে পড়া'), ('ascend', 'ওপরে ওঠা'), ('pageantry', 'জাঁকজমক'), h='শব্দার্থ (পাঠের Column A–B)'),
    SUMMARY('Crete, Minos, Minotaur, Daedalus, labyrinth', 'পালক + মোমের ডানা; মাঝামাঝি ওড়ার উপদেশ', 'Icarus সমুদ্রে; Daedalus Sicily-তে; Icarian Sea', 'Brueghel-এর ছবি; W C Williams-এর কবিতা — উদাসীন জগৎ'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-2-13', 'চরিত্র, স্থান ও উপদেশ মনে রাখুন।', 'Icarus।', [
    ('The story of Icarus is set on the island of —', 'Crete', W('Sicily', 'Cyprus', 'Rhodes'), 'Crete।', True),
    ('The Minotaur was a creature that was —', 'half-man and half-bull', W('half-man and half-horse', 'half-bird and half-lion', 'a giant snake'), 'অর্ধেক মানুষ, অর্ধেক ষাঁড়।', False),
    ('Who designed the labyrinth?', 'Daedalus', W('Icarus', 'King Minos', 'Brueghel'), 'স্থপতি-উদ্ভাবক Daedalus।', True),
    ('Who imprisoned Daedalus and Icarus in the labyrinth?', 'King Minos', W('the Minotaur', 'the King of Sicily', 'Zeus'), 'রাজা Minos।', False),
    ('Daedalus made the wings from —', 'feathers and wax', W('wood and cloth', 'paper and glue', 'leaves and string'), 'পালক ও মোম।', True),
    ('Daedalus got the idea of making wings by —', 'watching birds fly', W('reading a book', 'dreaming at night', 'talking to the King'), 'পাখি দেখে।', False),
    ('Why was Icarus warned not to fly too close to the sea?', 'The wings would become heavy with moisture.', W('The wax would melt.', 'Sharks would attack him.', 'He would lose his way.'), 'সমুদ্র → আর্দ্রতা।', True),
    ('Why was Icarus warned not to fly too close to the sun?', 'The wax would melt.', W('The wings would get wet.', 'He would be seen by guards.', 'Birds would attack him.'), 'সূর্য → মোম গলে।', True),
    ('Icarus fell because he —', 'flew too high, forgetting the warning', W('flew too low', 'was attacked by Minos', 'ran out of wax'), 'উত্তেজনায় উপদেশ ভুলে যায়।', False),
    ('Daedalus finally reached —', 'Sicily', W('Athens', 'Crete', 'Egypt'), 'Sicily।', True),
    ('The sea where Icarus fell was named —', 'the Icarian Sea', W('the Aegean Sea', 'the Daedalian Sea', 'the Cretan Sea'), 'Icarian Sea।', True),
    ('"Landscape with the Fall of Icarus" (painting) is by —', 'Pieter Brueghel', W('Pablo Picasso', 'Leonardo da Vinci', 'Vincent van Gogh'), 'Brueghel (1525–1569)।', True),
    ('The poem "Landscape with the Fall of Icarus" in EFT is by —', 'William Carlos Williams', W('W. H. Auden', 'William Wordsworth', 'Robert Frost'), 'W C Williams (1883–1963)।', True),
    ('In Williams\'s poem, Icarus\'s drowning is described as —', 'a splash quite unnoticed', W('a great tragedy watched by all', 'a loud cry heard by the farmer', 'a celebration'), 'জগতের উদাসীনতা।', True),
    ('The poet\'s main focus in Williams\'s poem is —', 'the indifference of the world towards the fall', W('the details of the wings', 'the anger of Daedalus', 'the cruelty of Minos'), 'উদাসীনতা।', False),
    ('The word "labyrinth" means —', 'a maze', W('a palace', 'a prison cell', 'a tower'), 'গোলকধাঁধা।', False),
    ('The word "plummet" means —', 'to fall straight down at high speed', W('to rise up', 'to float', 'to swim'), 'সোজা নিচে পড়া।', False),
    ('The writer whose collection "Labyrinths" is mentioned is —', 'Jorge Luis Borges', W('Gabriel García Márquez', 'Pablo Neruda', 'Octavio Paz'), 'Borges (আর্জেন্টিনা)।', False),
])

# =====================================================================
# U3·L3 The Legend of Gazi  (en-2-14)
# =====================================================================
B.lesson('en-2-14', [
    H('The Legend of Gazi — এক নজরে'),
    UL('কিংবদন্তি অনুযায়ী **গাজী পীর** ছিলেন একজন মুসলিম সাধক, যিনি সুন্দরবন-সংলগ্ন অঞ্চলে ইসলাম প্রচার করেন বলে কথিত', 'অলৌকিক ক্ষমতা: হিংস্র প্রাণীকে শান্ত ও বাধ্য করতে পারতেন',
       '**পট** বা স্ক্রল চিত্রে সাধারণত হাতে সাপ নিয়ে হিংস্র **বাঘের পিঠে** দেখানো হয়', 'খাল-খাঁড়িতে ভরা, বঙ্গোপসাগরের তীরের জলজঙ্গলে কুমিরের সঙ্গে লড়াইয়ের গল্পও আছে',
       'তাঁর সতর্ক উপস্থিতিতে শিকারি প্রাণী সীমার মধ্যে থাকত; গ্রামবাসী বনের কাছে বাস ও চাষ করতে পারত — তাই সুরক্ষার জন্য তাঁর কাছে প্রার্থনা', 'কাহিনি লোকসাহিত্য, শিল্প ও লোকনাট্যে টিকে আছে; কিছু **গাজীর পট British Museum**-এ সংরক্ষিত'),
    P('পাঠে **for example, also, indeed, consequently** — এগুলো **adverb** জাতীয় শব্দ/বাক্যাংশ, জোর দেওয়া বা বাক্যান্তরে সংযোগের (transition) জন্য ব্যবহৃত।'),
    WORDS(('legend', 'কিংবদন্তি'), ('docile', 'বাধ্য, শান্ত'), ('scroll', 'গুটানো পট/পুঁথি'), ('creek', 'খাঁড়ি'), ('vigilant', 'সজাগ'), ('predatory', 'শিকারি'), ('indigenous', 'দেশজ, আদিবাসী'), h='শব্দার্থ'),
    SUMMARY('গাজী পীর — সুন্দরবন অঞ্চলের কিংবদন্তি সাধক', 'বাঘের পিঠে, হাতে সাপ — পটচিত্র', 'গাজীর পট British Museum-এ', 'for example/also/indeed/consequently = transition adverbs'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-2-14', 'গাজী পীরের ক্ষমতা, অঞ্চল ও শিল্পরূপ মনে রাখুন।', 'The Legend of Gazi।', [
    ('According to legend, Gazi Pir is said to have spread Islam in areas close to —', 'the Sundarbans', W('the Chittagong Hill Tracts', 'Sylhet tea gardens', 'the Barind tract'), 'সুন্দরবন-সংলগ্ন।', True),
    ('Gazi Pir was credited with the power to —', 'calm dangerous animals and make them docile', W('turn stones into gold', 'make it rain', 'cure blindness'), 'হিংস্র প্রাণী শান্ত করা।', True),
    ('In paats (scroll paintings), Gazi is usually shown —', 'riding a Bengal tiger with a snake in his hand', W('riding an elephant', 'sitting in a boat', 'fighting a lion'), 'বাঘের পিঠে, হাতে সাপ।', True),
    ('According to some stories, Gazi also fought —', 'crocodiles', W('dragons', 'pirates', 'wolves'), 'কুমির।', False),
    ('The region where Gazi performed miracles is described as —', 'a watery jungle full of canals and creeks near the Bay of Bengal', W('a dry desert', 'a high mountain range', 'a busy city'), 'খাল-খাঁড়ির জলজঙ্গল।', False),
    ('Why did people of the region pray to Gazi?', 'for protection from wild animals', W('for wealth', 'for rain', 'for victory in war'), 'সুরক্ষা।', False),
    ('Some Gazir paat scrolls are preserved in —', 'the British Museum', W('the Louvre', 'the National Museum, Delhi', 'the Metropolitan Museum'), 'British Museum।', True),
    ('A "paat" is a —', 'scroll painting', W('clay pot', 'folk song', 'wooden mask'), 'পট = স্ক্রল চিত্র।', True),
    ('The story of Gazi has been preserved in —', 'folk literature, art and indigenous theatre', W('only in schoolbooks', 'only in newspapers', 'only in films'), 'লোকসাহিত্য, শিল্প, লোকনাট্য।', False),
    ('The word "docile" means —', 'ready to obey; tame', W('fierce', 'clever', 'lazy'), 'docile = বাধ্য।', False),
    ('The word "predatory" means —', 'living by hunting other animals', W('peaceful', 'plant-eating', 'domestic'), 'শিকারি।', False),
    ('The word "vigilant" means —', 'watchful and alert', W('careless', 'sleepy', 'cruel'), 'সজাগ।', False),
    ('"For example", "also", "indeed" and "consequently" in the passage function mainly as —', 'adverbs used for emphasis or transition', W('nouns', 'prepositions', 'interjections'), 'Transition/emphasis adverbs।', True),
    ('Which of these shows a result (consequence)?', 'consequently', W('for example', 'also', 'indeed'), 'consequently = ফলস্বরূপ।', False),
    ('In the rearrangement task, the paragraph should begin with —', 'Gazi Pir was gifted with the power of miracles.', W('In fact, some of these paats are preserved even in the British Museum.', 'For example, he could tame hostile animals and make them obey him.', 'This is how the British museum pays tribute to this legendary Muslim saint and preacher.'), 'Topic sentence আগে।', True),
])

# =====================================================================
# U3·L4 Khona  (en-3-10)
# =====================================================================
B.lesson('en-3-10', [
    H('Khona — এক নজরে'),
    P('বাংলার লোককাহিনির **খনা** (আসল নাম **লীলা**) — আবহাওয়া ও কৃষিকাজের অসাধারণ জ্ঞানের অধিকারী। তাঁর জ্ঞান ছন্দোবদ্ধ, সহজে মনে রাখার মতো ছড়ায় — **"খনার বচন"**। শাসকশ্রেণি তাঁর প্রতিবাদী ভূমিকায় অসন্তুষ্ট হয়ে **জিভ কেটে** দেয় — তাই নাম "খনা" (যে কথা বলতে পারে না)। তবু তাঁর বচন **১৫০০ বছরের বেশি** ধরে মুখে মুখে টিকে আছে।'),
    P('উদাহরণ (পাঠে): *Jodi borshe magher shesh, dhonyi rajar punyi desh* — মাঘের শেষে বৃষ্টি হলে রাজ্য সমৃদ্ধ হয়।'),
    H('একটি প্রচলিত কাহিনি'),
    OL('**দেউলনগর** রাজ্যে রাজা **ধর্মকেতু**-র রাজজ্যোতিষী **বরাহ**; পুত্র **মিহির** জন্মের সময় স্ত্রী মারা যান।', 'বরাহ গণনা করে দেখেন মিহিরের ভাগ্যে দুর্ভোগ ও মৃত্যু — তাই তামার পাত্রে রেখে **বিদ্যাধরী** নদীতে ভাসিয়ে দেন।',
       'শিশুটি **শ্রীলঙ্কা**য় উদ্ধার হয়, রাজার কাছে বড় হয়, রাজকন্যা জ্যোতিষী **লীলা**কে বিয়ে করে।', 'লীলা ও মিহির বরাহকে খুঁজে প্রমাণ করেন তাঁর ভবিষ্যদ্বাণী ভুল ছিল; দুজনেই রাজজ্যোতিষী হন।',
       'লীলা কৃষকদের সঙ্গে যোগাযোগ রাখতেন, তাদের ছড়ার ভঙ্গিতে নিজের জটিল জ্ঞান সহজ করে বলতেন।', 'ঈর্ষান্বিত বরাহ পুত্রকে দিয়ে লীলার জিভ কাটিয়ে দেন — কিন্তু খনার কাহিনি ও জ্ঞান বেঁচে রইল।'),
    TABLE('পাঠের True/False', ['বক্তব্য', 'উত্তর'], ('খনার ভবিষ্যদ্বাণী শুধু রাজসভার কাজে লাগত', 'False — কৃষকদের কাজে'), ('শাসকেরা খনাকে শাস্তি দেয় কারণ তাঁর জ্ঞান কৃষকদের সাহায্য করছিল', 'True'),
          ('খনার জ্ঞান কালের গর্ভে হারিয়ে গেছে', 'False'), ('খনার বচন সহজ কিন্তু ব্যবহারিক জ্ঞানে ভরা', 'True'), ('বরাহ খনার সাফল্যে গর্বিত ছিলেন', 'False — ঈর্ষান্বিত')),
    SUMMARY('খনা = লীলা; খনার বচন — কৃষি ও আবহাওয়া', 'জিভ কেটে দেওয়া → "খনা"; ১৫০০+ বছর টিকে থাকা', 'বরাহ (জ্যোতিষী), মিহির (পুত্র), ধর্মকেতু (রাজা), দেউলনগর, বিদ্যাধরী, শ্রীলঙ্কা'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-3-10', 'কাহিনির নাম-স্থান-সম্পর্কগুলো মিলিয়ে মনে রাখুন।', 'Khona — কাহিনি ও T/F সারণি।', [
    ('Khona\'s original name was —', 'Lila', W('Mihir', 'Behula', 'Usa'), 'আসল নাম লীলা।', True),
    ('Khona\'s rhyming sayings are known as —', 'Khonar Bochon', W('Manasamangal', 'Charyapada', 'Baul songs'), 'খনার বচন।', True),
    ('Khona\'s wisdom was mainly about —', 'weather and farming', W('medicine only', 'war strategy', 'trade'), 'আবহাওয়া ও কৃষি।', False),
    ('The name "Khona" means —', 'someone who cannot speak', W('a wise woman', 'a royal astrologer', 'a farmer\'s daughter'), 'জিভ কাটার পর।', True),
    ('According to the lesson, Khona\'s sayings have been passed down for over —', '1500 years', W('500 years', '150 years', '3000 years'), '১৫০০ বছরের বেশি।', True),
    ('"Jodi borshe magher shesh…" says that if it rains at the end of Magh, —', 'the kingdom will prosper', W('there will be a flood', 'the crops will fail', 'winter will be long'), 'রাজ্য সমৃদ্ধ হবে।', False),
    ('In the retelling, Varaha was the royal astrologer of —', 'King Dharmaketu', W('King Minos', 'Raja Danauja Rai', 'King Vikramaditya'), 'রাজা ধর্মকেতু।', True),
    ('The kingdom in the retelling was —', 'Deyulnagar', W('Champaknagar', 'Ujaninagar', 'Sonargaon'), 'দেউলনগর।', True),
    ('Varaha\'s son was —', 'Mihir', W('Lakhindar', 'Icarus', 'Chand'), 'মিহির।', False),
    ('Varaha set his baby son afloat on the river —', 'Viddyadhory', W('Ganguri', 'Padma', 'Meghna'), 'বিদ্যাধরী নদী।', True),
    ('The baby Mihir was rescued and raised in —', 'Sri Lanka', W('Burma', 'Nepal', 'Bengal'), 'শ্রীলঙ্কা।', True),
    ('Mihir married —', 'Lila, the king\'s daughter and an astrologer', W('a farmer\'s daughter', 'Behula', 'a dancer of Amara'), 'রাজকন্যা লীলা।', False),
    ('Lila and Mihir proved to Varaha that —', 'his prediction about Mihir had been wrong', W('he was a great king', 'the river was dangerous', 'farmers were lazy'), 'ভবিষ্যদ্বাণী ভুল ছিল।', False),
    ('Why did Varaha order Lila\'s tongue to be cut out?', 'He was jealous and angry.', W('She had stolen from him.', 'The king ordered it.', 'She had insulted the farmers.'), 'ঈর্ষা ও ক্রোধ।', True),
    ('True or false: "Khona\'s predictions were only useful for the royal court."', 'False', W('True', 'Not mentioned', 'Partly true'), 'কৃষকদের উপকারে আসত।', True),
    ('True or false: "Varaha was proud of Khona\'s success."', 'False', W('True', 'Not mentioned', 'True only at first'), 'বরাহ ঈর্ষান্বিত ছিলেন।', True),
])

# =====================================================================
# U4·L1 Three Speeches  (en-3-11)
# =====================================================================
B.lesson('en-3-11', [
    H('Three Speeches — এক নজরে'),
    TABLE('তিন ভাষণ', ['বক্তা', 'তারিখ ও স্থান', 'মূল বিষয়'],
          ('**Martin Luther King Jr.** — "I Have a Dream"', '**২৮ আগস্ট ১৯৬৩**, Washington D.C., USA', 'বর্ণবৈষম্যমুক্ত, সমতার আমেরিকার স্বপ্ন'),
          ('**Sheikh Mujibur Rahman**', '**৭ মার্চ ১৯৭১**', 'বাঙালির অধিকার ও মুক্তির সংগ্রাম; UNESCO-র **Memory of the World Register**-এ অন্তর্ভুক্ত'),
          ('**Nelson Mandela** — আদালতে বিবৃতি', '**২০ এপ্রিল ১৯৬৪** (Rivonia trial)', 'বর্ণবাদ (apartheid)-বিরোধী সংগ্রামের যৌক্তিকতা')),
    H('Martin Luther King Jr.'),
    UL('"Negro" জনগোষ্ঠী এখনো বৈষম্যের শিকল আর বিচ্ছিন্নতার হাতকড়ায় বন্দি — সমৃদ্ধির সাগরে দারিদ্র্যের নিঃসঙ্গ দ্বীপ', 'স্বপ্ন: আমেরিকা তার মূলমন্ত্র "all men are created equal" বাস্তবে রূপ দেবে',
       'Georgia-র লাল পাহাড়ে প্রাক্তন দাস ও দাসমালিকদের সন্তানেরা ভ্রাতৃত্বের টেবিলে বসবে; Mississippi হবে স্বাধীনতা-ন্যায়ের মরূদ্যান', 'তাঁর চার সন্তান গায়ের রং নয়, চরিত্র দিয়ে বিচারিত হবে; Alabama-য় কালো-সাদা শিশুরা হাত ধরবে',
       '"Let freedom ring" — New Hampshire, New York, Pennsylvania-র Alleghenies থেকে Mississippi পর্যন্ত', 'শেষ: পুরোনো Negro spiritual — "Free at last!"', 'সবচেয়ে বেশি ব্যবহৃত literary device: **anaphora** (বারবার "I have a dream", "Let freedom ring")'),
    H('৭ মার্চের ভাষণ (পাঠের অংশ অনুযায়ী)'),
    UL('ঢাকা, চট্টগ্রাম, খুলনা, রাজশাহী, রংপুরের রাস্তা ভাইদের রক্তে রঞ্জিত', 'নির্বাচনে মানুষ আওয়ামী লীগকে ভোট দিলেও "তেইশ বছরের" নির্যাতনের ইতিহাস — ১৯৫২, ১৯৫৪, ১৯৫৮ (আইয়ুব খানের সামরিক শাসন), ১৯৬৬ (ছয় দফা, ৭ জুন), ১৯৬৯',
       'দাবি: সামরিক আইন প্রত্যাহার, সেনা ব্যারাকে ফেরত, হত্যার তদন্ত, জনপ্রতিনিধিদের কাছে ক্ষমতা হস্তান্তর', '"প্রতিটি ঘরকে দুর্গে পরিণত করো"; "সাত কোটি মানুষকে দাবিয়ে রাখতে পারবে না"',
       'শেষ: "এবারের সংগ্রাম আমাদের মুক্তির সংগ্রাম, এবারের সংগ্রাম স্বাধীনতার সংগ্রাম" — Joi Bangla', 'কৌশল: "we/us/our" — শ্রোতার সঙ্গে ঐক্যবোধ'),
    H('Nelson Mandela'),
    UL('১৯৬২-তে গ্রেপ্তার; ১৯৬৪-তে sabotage, high treason, সরকার উৎখাতের ষড়যন্ত্রের অভিযোগ; তিনি "First Accused"', 'BA ডিগ্রিধারী; **Oliver Tambo**-র সঙ্গে Johannesburg-এ আইন পেশা',
       'Transkei-তে শৈশবে গোত্রের প্রবীণদের কাছে পূর্বপুরুষের বীরত্বের গল্প শুনে অনুপ্রাণিত', '**ANC** গঠিত **১৯১২**; ১৯৪৯ পর্যন্ত কঠোরভাবে সাংবিধানিক সংগ্রাম; **Defiance Campaign** — ৮,৫০০-র বেশি মানুষ কারাবরণ, কোনো সহিংসতা নেই',
       '১৯৬০-এ **Sharpeville** গুলিবর্ষণ, জরুরি অবস্থা, ANC নিষিদ্ধ → গোপনে কাজ', 'ANC কমিউনিস্ট সংগঠন নয়; মার্ক্সবাদে প্রভাবিত হলেও "আমরা মার্ক্সবাদী নই"; পশ্চিম ও পূর্ব দুদিক থেকে সেরাটা নেওয়া',
       'লড়াই দুই বিষয়ের বিরুদ্ধে: **দারিদ্র্য** ও **মানবিক মর্যাদার অভাব**', 'শেষ: গণতান্ত্রিক, মুক্ত সমাজের আদর্শ — "an ideal for which I am prepared to die"', 'ছবি: ১১ ফেব্রুয়ারি ১৯৯০ Victor Verster কারাগার থেকে মুক্তি — ২৭ বছর বন্দি'),
    SUMMARY('MLK — ২৮ আগস্ট ১৯৬৩, Washington D.C.; anaphora', '৭ মার্চ ১৯৭১ — UNESCO Memory of the World; মুক্তি ও স্বাধীনতার সংগ্রাম', 'Mandela — ২০ এপ্রিল ১৯৬৪; ANC ১৯১২; Sharpeville ১৯৬০; দারিদ্র্য ও মর্যাদাহীনতা'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-3-11', 'বক্তা-তারিখ-স্থান আর প্রতিটি ভাষণের মূল দাবি মনে রাখুন।', 'Three Speeches সারণি।', [
    ('Martin Luther King Jr. delivered his famous speech on —', 'August 28, 1963', W('March 7, 1971', 'April 20, 1964', 'July 4, 1963'), '২৮ আগস্ট ১৯৬৩।', True),
    ('Martin Luther King Jr.\'s speech was delivered in —', 'Washington D.C.', W('New York', 'Atlanta', 'Chicago'), 'Washington D.C.।', True),
    ('In his speech, King quotes the creed that "all men are —"', 'created equal', W('born free', 'brothers', 'children of God'), '"We hold these truths to be self-evident…"।', False),
    ('King dreamed that his four children would be judged by —', 'the content of their character', W('the colour of their skin', 'their wealth', 'their education'), 'চরিত্র দিয়ে বিচার।', True),
    ('The most frequently used literary device in King\'s speech is —', 'repetition (anaphora)', W('irony', 'onomatopoeia', 'understatement'), '"I have a dream", "Let freedom ring"।', True),
    ('The speech ends with the words of an old Negro spiritual: —', '"Free at last!"', W('"We shall overcome!"', '"Long live freedom!"', '"Joi Bangla!"'), '"Free at last! Thank God Almighty…"।', False),
    ('In the vocabulary task, "sweltering" means —', 'unpleasantly hot', W('very cold', 'crowded', 'peaceful'), 'Mississippi "sweltering with the heat of injustice"।', False),
    ('The 7th March speech was delivered in —', '1971', W('1966', '1969', '1952'), '৭ মার্চ ১৯৭১।', True),
    ('The 7th March speech has been included by UNESCO in —', 'the Memory of the World Register', W('the World Heritage List', 'the Intangible Cultural Heritage List', 'the Creative Cities Network'), 'Memory of the World Register।', True),
    ('In the speech, the Six Point Movement is dated to —', '1966', W('1958', '1969', '1954'), 'ছয় দফা ১৯৬৬।', False),
    ('Which demand was made in the 7th March speech before joining the Assembly?', 'withdrawal of Martial Law', W('a new national flag', 'a Round Table Conference', 'the Prime Minister\'s office'), 'সামরিক আইন প্রত্যাহারসহ চার দাবি।', True),
    ('The 7th March speech ends by calling the struggle one for —', 'emancipation and freedom', W('economic aid', 'a new constitution only', 'provincial elections'), 'মুক্তি ও স্বাধীনতার সংগ্রাম।', False),
    ('Nelson Mandela\'s statement in EFT was made at his trial on —', 'April 20, 1964', W('February 11, 1990', 'August 28, 1963', 'June 1961'), '২০ এপ্রিল ১৯৬৪।', True),
    ('Mandela practised as an attorney in Johannesburg in partnership with —', 'Oliver Tambo', W('Walter Sisulu', 'Desmond Tutu', 'Steve Biko'), 'Oliver Tambo।', True),
    ('According to Mandela, the African National Congress was formed in —', '1912', W('1949', '1960', '1923'), 'ANC ১৯১২।', True),
    ('In the Defiance Campaign, more than how many people went to jail?', '8,500', W('850', '85,000', '5,800'), '৮,৫০০-র বেশি।', False),
    ('The shooting that led to the banning of the ANC took place at —', 'Sharpeville in 1960', W('Soweto in 1976', 'Robben Island in 1964', 'Johannesburg in 1912'), 'Sharpeville ১৯৬০।', True),
    ('Mandela said the two hallmarks of African life they fought against were —', 'poverty and lack of human dignity', W('communism and capitalism', 'foreign rule and taxes', 'illiteracy and disease only'), 'দারিদ্র্য ও মানবিক মর্যাদার অভাব।', True),
    ('According to the caption, Mandela walked out of Victor Verster Prison on February 11, 1990, after being imprisoned for —', '27 years', W('17 years', '7 years', '37 years'), '২৭ বছর।', False),
])

# =====================================================================
# U4·L2 Great Women  (en-3-12)
# =====================================================================
B.lesson('en-3-12', [
    H('Great Women — এক নজরে'),
    P('ভূমিকা: Virginia Woolf (১৯২৮) — লিখতে হলে নারীর চাই "money and a room of her own"। বাংলায় নারীশিক্ষায় **রোকেয়া সাখাওয়াত হোসেন**; তাঁর ইংরেজি রচনা **Sultana\'s Dream** — নারীর লেখা প্রথম বিজ্ঞান-কল্পকাহিনি হিসেবে বিবেচিত।'),
    TABLE('ঢাবি ইংরেজি বিভাগের পথিকৃৎ নারীরা', ['নাম', 'মূল তথ্য (পাঠ অনুযায়ী)'],
          ('**Leela Nag** (Leela Roy)', '১৯২১-এ ঢাবির ইংরেজি MA-তে ভর্তি হওয়া প্রথম নারী — VC **Philip Hartog**-এর বিশেষ অনুমতিতে; ১৯২৩-এ প্রথম নারী MA; দীপালি সংঘ (১৯২৩); মেয়েদের প্রথম আত্মরক্ষা প্রতিষ্ঠান (১৯২৭-২৮); ১৯২৯-এর মধ্যে ১২টি অবৈতনিক বালিকা বিদ্যালয়; নোয়াখালী দাঙ্গা (১৯৪৬) ও শরণার্থী শিবির; ১৯৪৬-এ বঙ্গীয় গণপরিষদে নির্বাচিত একমাত্র বাঙালি নারী'),
          ('**Nadera Begum**', 'মার্ক্সবাদী; ১৯৪৯-এ চতুর্থ শ্রেণির কর্মচারীদের অধিকারের লড়াইয়ে ঢাবি থেকে বহিষ্কৃত; ভাষা আন্দোলনের নারীদের একজন'),
          ('**Razia Khan Amin**', '১৯৬২-তে বিভাগে শিক্ষক; বার্মিংহামে MA; কবি, অভিনেত্রী, সাংবাদিক; একুশে পদক (১৯৯৭); কবিতা: Argus Under Anaesthesia, God in the Goblet (১৯৭১-এর শহীদ বুদ্ধিজীবী), The Old Man and the Girl (বাল্যবিবাহের বিরুদ্ধে)')),
    TABLE('বিশ্বের দুই মহীয়সী', ['নাম', 'মূল তথ্য'],
          ('**Wangari Maathai (1940–2011)**', 'প্রথম আফ্রিকান নারী ও প্রথম পরিবেশবাদী হিসেবে **২০০৪**-এ নোবেল শান্তি পুরস্কার; কেনিয়ায় **Green Belt Movement**-এর প্রতিষ্ঠাতা — বৃক্ষরোপণ, পরিবেশ সংরক্ষণ, নারী অধিকার; ১৯৮৬-তে Pan African Green Belt Network; Time-এর ১০০ প্রভাবশালী (২০০৫)'),
          ('**Marie Curie** (Maria Skłodowska)', 'জন্ম **Warsaw, ৭ নভেম্বর ১৮৬৭**; ১৮৯১-এ প্যারিস (Sorbonne); Pierre Curie-কে বিয়ে (১৮৯৫); **polonium** (মাতৃভূমি পোল্যান্ডের নামে) ও **radium** আবিষ্কার (১৮৯৮); **১৯০৩**-এ Becquerel ও Pierre-এর সঙ্গে **পদার্থবিজ্ঞানে** নোবেল (radioactivity); ১৯০৬-এ Sorbonne-এ শিক্ষকতা করা প্রথম নারী; **১৯১১**-এ বিশুদ্ধ radium পৃথকীকরণের জন্য **রসায়নে** নোবেল; ১৯৩৪-এ aplastic anaemia-য় মৃত্যু; ১৯৯৫-এ Panthéon-এ সমাহিত প্রথম নারী (নিজ কৃতিত্বে)')),
    SUMMARY('Leela Nag — ঢাবির প্রথম নারী MA (১৯২৩)', 'Wangari Maathai — Green Belt Movement, নোবেল শান্তি ২০০৪', 'Marie Curie — দুই বিজ্ঞানে দুই নোবেল (১৯০৩ পদার্থ, ১৯১১ রসায়ন)'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-3-12', 'নাম–প্রথম কৃতিত্ব–সাল জোড়ায় মনে রাখুন।', 'Great Women সারণি।', [
    ('Virginia Woolf wrote that a woman must have money and —', 'a room of her own', W('a university degree', 'a husband', 'a job abroad'), 'Woolf, ১৯২৮।', True),
    ('"Sultana\'s Dream", considered the first science fiction by a woman, was written by —', 'Rokeya Sakhawat Hossain', W('Leela Nag', 'Razia Khan Amin', 'Sufia Kamal'), 'রোকেয়া।', True),
    ('Leela Nag was the first woman admitted to the M.A. in English at Dhaka University in —', '1921', W('1923', '1947', '1912'), '১৯২১-এ ভর্তি, ১৯২৩-এ ডিগ্রি।', True),
    ('Leela Nag was admitted with special permission from Vice Chancellor —', 'Philip Hartog', W('Ramesh Chandra Majumdar', 'Satyendra Nath Bose', 'Ahmed Fazlur Rahman'), 'Philip Hartog।', True),
    ('In 1923, Leela Nag founded —', 'Deepali Sangha', W('the Dhaka Women\'s Committee', 'Bangla Academy', 'the Green Belt Movement'), 'দীপালি সংঘ।', False),
    ('By 1929, Leela Nag had founded how many free primary schools for girls?', '12', W('2', '20', '120'), '১২টি।', True),
    ('In 1946, Leela Nag was the only Bengali woman elected to —', 'the Constituent Assembly of Bengal', W('the British Parliament', 'the Dhaka University Senate', 'the UN General Assembly'), 'বঙ্গীয় গণপরিষদ।', False),
    ('Nadera Begum was expelled from Dhaka University in 1949 for —', 'fighting for the rights of fourth-class employees', W('writing a poem', 'missing exams', 'joining the army'), 'কর্মচারীদের অধিকার।', True),
    ('Razia Khan Amin\'s poem against child marriage is —', 'The Old Man and the Girl', W('Argus Under Anaesthesia', 'God in the Goblet', 'Sultana\'s Dream'), 'The Old Man and the Girl।', True),
    ('Wangari Maathai founded —', 'the Green Belt Movement in Kenya', W('the Defiance Campaign', 'the Radium Institute', 'Deepali Sangha'), 'Green Belt Movement।', True),
    ('Wangari Maathai received the Nobel Peace Prize in —', '2004', W('2014', '1994', '2011'), '২০০৪ — প্রথম আফ্রিকান নারী।', True),
    ('The Green Belt Movement mainly worked through —', 'tree planting, conservation and women\'s rights', W('building dams', 'mining', 'space research'), 'বৃক্ষরোপণ ও নারী অধিকার।', False),
    ('Marie Curie was born in —', 'Warsaw', W('Paris', 'Vienna', 'Berlin'), 'Warsaw, ১৮৬৭।', True),
    ('Marie Curie named polonium in honour of —', 'her native land, Poland', W('her husband', 'her teacher', 'the city of Paris'), 'পোল্যান্ড।', True),
    ('Marie Curie\'s first Nobel Prize (1903), shared with Pierre Curie and Becquerel, was in —', 'Physics', W('Chemistry', 'Medicine', 'Peace'), '১৯০৩ পদার্থবিজ্ঞান।', True),
    ('Marie Curie\'s second Nobel Prize (1911) was in Chemistry for —', 'the isolation of pure radium', W('discovering X-rays', 'inventing the radio', 'discovering uranium'), '১৯১১ রসায়ন।', True),
    ('Marie Curie was the first woman to —', 'teach at the Sorbonne', W('found the Nobel Prize', 'become President of France', 'climb Everest'), '১৯০৬-এ Sorbonne-এর প্রথম নারী শিক্ষক।', False),
    ('Marie Curie died in 1934 of —', 'aplastic anaemia caused by radiation', W('tuberculosis', 'a car accident', 'old age only'), 'বিকিরণজনিত aplastic anaemia।', False),
])

# =====================================================================
# U5·L4 Coal Miners  (en-3-13)
# =====================================================================
B.lesson('en-3-13', [
    H('Coal Miners — এক নজরে'),
    UL('উৎস: **Sharing the Earth** (সম্পাদনা Elizabeth Ammons ও Modhumita Roy) — ন্যায়ভিত্তিক পরিবেশ-রচনার সংকলন', 'প্রসঙ্গ: **Lord Ashley**-র ১৮৪২-এর বক্তৃতা; **১৮৩৮**-এ Yorkshire-এর **Huskar Colliery** দুর্ঘটনার তদন্ত কমিশন',
       'কমিশন দেখে শিশুরা খনিতে দিনে **১৮ ঘণ্টা** পর্যন্ত কাজ করছে, কেউ কেউ ভারী গাড়ির সঙ্গে শিকলে বাঁধা'),
    TABLE('তিন শিশুর সাক্ষ্য', ['নাম ও বয়স', 'কাজ ও অবস্থা'],
          ('**Sarah Goodler, ৮**', 'Gawber pit-এ **trapper** — আলোহীন অন্ধকারে বসে বায়ু চলাচলের trap door খোলা-বন্ধ; ভোর ৪টায় (কখনো সাড়ে ৩টায়) নামে, বিকেল সাড়ে ৫টায় ওঠে; অন্ধকারে ভয়ে গান গাইতে পারে না; Sunday school-এ যায়, খনির চেয়ে স্কুলে থাকতে চায়'),
          ('**Isabella Read, ১২**', 'ভাই-বোনের সঙ্গে কাজ; দিনে ২৫–৩০ বার আসা-যাওয়া; দূরত্ব ১০০–২৫০ fathom (১ fathom = ১.৮ মি); পিঠে প্রায় ১ cwt (≈৫০ কেজি) ও এক চতুর্থাংশ কয়লা; হাঁটু-পানির মধ্য দিয়ে ঝুঁকে চলা; গরমে শ্বাসকষ্ট'),
          ('**Mary Barrett, ১৪**', 'পাঁচ বছর ধরে খনিতে; বারো ভাইবোন — একজন ছাড়া কেউ পড়তে পারে না; সকাল ৭টায় নামে; মোজা-জুতা ছাড়া শুধু chemise পরে পুরুষদের সঙ্গে কাজ')),
    P('ব্যাকরণ: সাক্ষ্যগুলো **direct speech**-এ; কাজ হলো **indirect speech**-এ রূপান্তর (যেমন "Sarah Goodler was an eight-year-old child… She was a trapper…")।'),
    SUMMARY('Lord Ashley (১৮৪২); Huskar Colliery, Yorkshire (১৮৩৮)', 'Sarah (৮, trapper), Isabella (১২, কয়লা বহন), Mary (১৪, পাঁচ বছর)', 'শিশুশ্রম, শিক্ষাহীনতা, অমানবিক পরিবেশ'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-3-13', 'তিন শিশুর নাম-বয়স-কাজ সারণি থেকে মিলিয়ে নিন।', 'Coal Miners সারণি।', [
    ('The lesson is based on testimonies collected by the commission of —', 'Lord Ashley', W('Lord Byron', 'Lord Curzon', 'Lord Macaulay'), 'Lord Ashley-র কমিশন।', True),
    ('The accident investigated by the commission took place at —', 'Huskar Colliery, Yorkshire', W('Gawber pit, Wales', 'Barapukuria, Dinajpur', 'Newcastle docks'), 'Huskar Colliery, ১৮৩৮।', True),
    ('The Huskar Colliery accident happened in —', '1838', W('1842', '1848', '1832'), '১৮৩৮; বক্তৃতা ১৮৪২।', True),
    ('According to the lesson, some children worked in mines as long as —', 'eighteen hours a day', W('eight hours a day', 'twelve hours a week', 'four hours a day'), 'দিনে ১৮ ঘণ্টা পর্যন্ত।', True),
    ('The source book "Sharing the Earth" was edited by —', 'Elizabeth Ammons and Modhumita Roy', W('Lord Ashley and Sarah Goodler', 'Charles Dickens', 'Wangari Maathai'), 'Ammons ও Roy।', False),
    ('Sarah Goodler was —', '8 years old', W('12 years old', '14 years old', '10 years old'), 'আট বছর।', True),
    ('Sarah Goodler worked in the pit as a —', 'trapper', W('hurrier', 'coal cutter', 'cook'), 'trapper।', True),
    ('A trapper\'s job was to —', 'open and close trap doors that let fresh air flow', W('cut coal', 'drive the cart', 'light the lamps'), 'বায়ু চলাচলের দরজা।', True),
    ('Why did Sarah not sing in the dark?', 'She was too scared.', W('She was not allowed to.', 'She was too tired.', 'She did not know any songs.'), '"I dare not sing then."', False),
    ('Sarah said she would like to be —', 'at school rather than in the pit', W('a miner like her father', 'a singer', 'a servant'), 'স্কুলে থাকতে চায়।', False),
    ('Isabella Read was —', '12 years old', W('8 years old', '14 years old', '16 years old'), 'বারো বছর।', True),
    ('Isabella carried about one cwt and a quarter of coal on her back. One cwt is about —', '50 kg', W('5 kg', '100 kg', '25 kg'), '১ cwt ≈ ৫০ কেজি।', True),
    ('According to the lesson, 1 fathom equals about —', '1.8 metres', W('18 metres', '0.8 metres', '8 metres'), '১ fathom = ১.৮ মি।', False),
    ('Mary Barrett had worked in the pit for —', 'five years', W('one year', 'ten years', 'two months'), 'পাঁচ বছর।', True),
    ('Mary Barrett had how many brothers and sisters?', '12', W('5', '2', '8'), 'বারো জন।', False),
    ('The testimonies are given in —', 'direct speech', W('indirect speech', 'passive voice only', 'poetry'), 'Direct → indirect রূপান্তর কাজ।', False),
])

# =====================================================================
# U5·L5 Frederick Douglass  (en-3-14)
# =====================================================================
B.lesson('en-3-14', [
    H('Frederick Douglass — এক নজরে'),
    UL('দাসপ্রথাবিরোধী গুরুত্বপূর্ণ নেতা; জন্ম দাস হিসেবে আনুমানিক **১৮১৮**-এ, **Talbot County, Maryland**', 'প্রেসিডেন্টদের পরামর্শ দেন; নারী অধিকার ও আয়ারল্যান্ডের স্বশাসন নিয়ে বক্তৃতা',
       'বিখ্যাত আত্মজীবনী: **Narrative of the Life of Frederick Douglass, an American Slave** — পাঠে Chapter I'),
    H('Chapter I-এর মূল তথ্য'),
    UL('জন্ম **Tuckahoe**, Hillsborough-র কাছে, Easton থেকে প্রায় ১২ মাইল', 'নিজের বয়স জানতেন না — অধিকাংশ দাস ঘোড়ার মতোই বয়স জানত না; মালিকেরা ইচ্ছা করেই অজ্ঞ রাখত',
       'অনুমান: ১৮৩৫-এ প্রায় ১৭ বছর → লেখার সময় ২৭–২৮ বছর', 'মা **Harriet Bailey**; নানা-নানি Isaac ও Betsey Bailey', 'বাবা একজন শ্বেতাঙ্গ — কানাঘুষা ছিল মালিকই বাবা, নিশ্চিত জানার উপায় ছিল না',
       'শিশুকালেই মায়ের কাছ থেকে বিচ্ছিন্ন — শিশুর বারো মাস হওয়ার আগেই মাকে দূরে কাজে পাঠানো হতো, মা-সন্তানের ভালোবাসা ভেঙে দিতে', 'মা ১২ মাইল দূরে Mr. Stewart-এর খামারে কাজ করতেন; রাতে হেঁটে এসে দেখা করতেন; জীবনে চার-পাঁচবারের বেশি দেখা হয়নি',
       'Douglass-এর প্রায় ৭ বছর বয়সে Lee\'s Mill-এর কাছে মায়ের মৃত্যু; মৃত্যুসংবাদে অনুভূতি প্রায় অপরিচিত কারও মৃত্যুর মতো'),
    QUOTE('I have no accurate knowledge of my age, never having seen any authentic record containing it.', 'Frederick Douglass, Narrative (1845)', 'Chapter I-এর শুরুর অংশ (কপিরাইটমুক্ত)।', 'দাসদের পরিচয় ও অধিকার থেকে বঞ্চিত রাখার প্রথম দৃষ্টান্ত।'),
    P('তুলনা: Al Jazeera-র প্রতিবেদন — **শ্রীমঙ্গল** ("বাংলাদেশের চা-রাজধানী")-এর চা-শ্রমিকেরা দৈনিক ১২০ টাকা মজুরিতে ২৪ কেজি পাতা তোলেন; মজুরি দিনে ৩ ডলার করার দাবিতে আন্দোলন।'),
    SUMMARY('Douglass — জন্ম ~১৮১৮, Talbot County, Maryland (Tuckahoe)', 'Narrative of the Life of Frederick Douglass, an American Slave', 'মা Harriet Bailey; বাবা শ্বেতাঙ্গ (সম্ভবত মালিক); মায়ের মৃত্যু ~৭ বছর বয়সে', 'Subject-verb agreement অনুশীলন'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-3-14', 'জন্মস্থান, পরিবার ও আত্মজীবনীর নাম মনে রাখুন।', 'Frederick Douglass।', [
    ('Frederick Douglass was born into slavery around —', '1818', W('1845', '1865', '1776'), 'আনুমানিক ১৮১৮।', True),
    ('Douglass was born in —', 'Talbot County, Maryland', W('Atlanta, Georgia', 'Boston, Massachusetts', 'Richmond, Virginia'), 'Talbot County, Maryland।', True),
    ('Douglass\'s famous autobiography is titled —', 'Narrative of the Life of Frederick Douglass, an American Slave', W('Up from Slavery', 'Uncle Tom\'s Cabin', 'Long Walk to Freedom'), 'Narrative…', True),
    ('More precisely, Douglass says he was born in —', 'Tuckahoe, near Hillsborough', W('Easton', 'Lee\'s Mill', 'Baltimore'), 'Tuckahoe।', True),
    ('Why did Douglass not know his age?', 'He never saw any authentic record of it.', W('He forgot it.', 'His mother hid it.', 'He was too young to count.'), 'রেকর্ড দেখেননি।', False),
    ('According to Douglass, most masters wished to keep their slaves —', 'ignorant of their ages', W('well educated', 'free on Sundays', 'happy and healthy'), 'ইচ্ছাকৃত অজ্ঞতা।', True),
    ('Douglass estimated that in 1835 he was about —', 'seventeen years old', W('seven years old', 'twenty-seven years old', 'twelve years old'), '১৮৩৫-এ ~১৭।', False),
    ('Douglass\'s mother was named —', 'Harriet Bailey', W('Betsey Bailey', 'Harriet Tubman', 'Mary Stewart'), 'Harriet Bailey।', True),
    ('Douglass\'s grandparents were —', 'Isaac and Betsey Bailey', W('Harriet and Isaac Bailey', 'Mr. and Mrs. Stewart', 'Isaac and Mary Barrett'), 'Isaac ও Betsey Bailey।', False),
    ('About his father, Douglass says that he was —', 'a white man, possibly his master', W('a slave on the same farm', 'a free Black farmer', 'a sailor'), 'শ্বেতাঙ্গ; সম্ভবত মালিক।', True),
    ('Why were slave children separated from their mothers so early?', 'to destroy the natural affection between mother and child', W('to send them to school', 'to protect them from disease', 'because mothers asked for it'), 'Douglass-এর অনুমান।', True),
    ('Douglass\'s mother worked for a Mr. Stewart who lived about —', 'twelve miles away', W('two miles away', 'fifty miles away', 'next door'), '১২ মাইল দূরে।', False),
    ('How many times did Douglass see his mother, to know her as such?', 'not more than four or five times', W('every day', 'once a week', 'never'), 'চার-পাঁচবার, তাও রাতে।', True),
    ('Douglass\'s mother died when he was about —', 'seven years old', W('seventeen years old', 'one year old', 'twelve years old'), 'প্রায় ৭ বছর।', True),
    ('Douglass received the news of his mother\'s death with feelings like those at —', 'the death of a stranger', W('a festival', 'his own birthday', 'a victory'), 'ঘনিষ্ঠতা গড়ে ওঠেনি।', False),
    ('In the comparative exercise, Srimongal is called —', 'Bangladesh\'s tea capital', W('the city of rivers', 'the port city', 'the city of mosques'), 'চা-রাজধানী।', False),
    ('Correct the subject-verb agreement: "Douglass have many challenges in his life."', 'Douglass had many challenges in his life.', W('Douglass have had many challenges in his life.', 'Douglass are having many challenges in his life.', 'Douglass were many challenges in his life.'), 'Singular subject → has/had।', True),
])

B.autofill_cards(12)
B.save('eft2', 'en-eft2')
