#!/usr/bin/env python3
"""English অক্ষর-গুচ্ছ পাঠের (Preposition, Idioms, Vocabulary, Spelling, Group Verbs) পুনর্ব্যবহারযোগ্য টেমপ্লেট।
ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে; Idiom/Vocabulary-তে বাংলা + English অর্থ, Synonym/Antonym, উৎস/প্রসঙ্গ।"""
import random
from common import *

UNIT_EN = ('ঢাবি, গুচ্ছ, জাবি, রাবি ও চবির English অংশে Appropriate Preposition, Idiom, Synonym/Antonym, Spelling ও Group Verb থেকে নিয়মিত প্রশ্ন আসার প্রবণতা আছে — '
           'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না।')
SRC_EN = ['Oxford / Cambridge learner\'s dictionary-র প্রচলিত ব্যবহার', 'Idiom-এর উৎস: প্রচলিত ব্যাখ্যা; অনিশ্চিত হলে তা লেখা আছে']
PREPS = ['of', 'to', 'with', 'at', 'in', 'for', 'on', 'from', 'by', 'into', 'about']


def prep_lesson(B, lid, rng, PR, seed, contrast=(), mnem=(), mistakes=()):
    """PR: (word, prep, sentence-with-___, বাংলা অর্থ, বিকল্প-যা-চলে tuple)"""
    blocks = [H(f'Appropriate Preposition — {rng}'),
              P('নির্দিষ্ট **word**-এর পরে নির্দিষ্ট **preposition** বসে — নিয়মে নয়, ব্যবহারে ঠিক হয়েছে। তাই **word + preposition** একসাথে মুখস্থ করুন।'),
              TABLE('Word + Preposition (কলাম-লুকাও দিয়ে অনুশীলন)', ['Word', 'বাংলা অর্থ', 'উদাহরণ', 'Preposition'], *[(w, b, s.replace('___', p), p) for w, p, s, b, _ in PR])]
    if contrast: blocks.append(TABLE('একই word, ভিন্ন preposition → ভিন্ন অর্থ', ['Phrase', 'অর্থ ও উদাহরণ'], *contrast))
    if mnem: blocks.append(MNEM(*mnem))
    if mistakes: blocks.append(MISTAKES(*mistakes))
    blocks += [SUMMARY('Word + preposition একসাথে মুখস্থ করুন', f'{rng}: {len(PR)}টি বহুল-প্রচলিত chunk'), UNI(UNIT_EN)]
    B.lesson(lid, blocks, SRC_EN)
    for i, (w, p, s, b, alt) in enumerate(PR):
        pool = [x for x in PREPS if x != p and x not in alt]
        random.Random(seed + i).shuffle(pool)
        base = w.split(' (')[0]
        B.q(lid, 2, s, p, [(x, f'"{base}"-এর পরে এখানে "{x}" বসে না।') for x in pool[:3]],
            f'{base} + {p} = {b}।', 'Word + preposition একসাথে মনে রাখুন।', 'Preposition সারণি দেখুন।', trap=bool(alt))


def idiom_lesson(B, lid, rng, ID, seed, mnem=(), mistakes=(), traps=()):
    """ID: (idiom, বাংলা অর্থ, English meaning, উৎস/প্রসঙ্গ, উদাহরণ)"""
    blocks = [H(f'Idioms & Phrases — {rng}'),
              P('**Idiom**-এর অর্থ শব্দগুলোর আক্ষরিক অর্থ থেকে আসে না — বাংলার বাগধারার মতো। প্রতিটি কার্ডে বাংলা ও English অর্থ, উৎস/প্রসঙ্গ আর উদাহরণ আছে; উৎস জানলে মনে রাখা সহজ।'),
              ENTRIES(f'Idiom কার্ড ({rng}) — ট্যাপ করে উৎস ও উদাহরণ দেখুন', *[{'w': a, 'bn': b, 'en': c, 'ctx': d, 'ex': e} for a, b, c, d, e in ID]),
              TABLE('দ্রুত অনুশীলন (কলাম-লুকাও)', ['Idiom', 'বাংলা অর্থ'], *[(a, b) for a, b, *_ in ID])]
    if mnem: blocks.append(MNEM(*mnem))
    if mistakes: blocks.append(MISTAKES(*mistakes))
    blocks += [SUMMARY(f'{rng}: {len(ID)}টি idiom', 'উৎসের গল্প + বাংলা সমতুল্য দিয়ে মনে রাখুন'), UNI(UNIT_EN)]
    B.lesson(lid, blocks, SRC_EN)
    for i, (a, b, c, d, e) in enumerate(ID):
        pool = [x[2] for j, x in enumerate(ID) if j != i]
        random.Random(seed + i).shuffle(pool)
        B.q(lid, 2, f'The idiom "{a}" means —', c, [(x, 'এটি অন্য একটি idiom-এর অর্থ।') for x in pool[:3]],
            f'{a} = {c} ({b})।', 'ছবিটা কল্পনা করুন, তারপর রূপক অর্থ ভাবুন।', f'উৎস/প্রসঙ্গ: {d}', trap=a in traps)
        B.card(lid, a, f'{b}\n{c}\n\nউৎস: {d}')


def vocab_lesson(B, lid, rng, VB, seed, roots=None, mnem=(), mistakes=(), traps=()):
    """VB: (word, POS, বাংলা অর্থ, English meaning, [synonyms], [antonyms], cluster)
    cluster: কাছাকাছি অর্থের শব্দ একই cluster-এ — ভুল বিকল্প হিসেবে বাদ পড়ে।"""
    roots = roots or {}
    blocks = [H(f'Vocabulary — {rng}'),
              P('প্রতিটি শব্দ শিখুন: **বাংলা অর্থ + English meaning + synonym + antonym**। শব্দমূল (root) জানলে অচেনা শব্দও আন্দাজ করা যায়।'),
              ENTRIES(f'Vocabulary কার্ড ({rng})', *[{'w': f'{w} ({p})', 'bn': b, 'en': e, 'syn': ', '.join(sy), 'ant': ', '.join(an), 'ctx': roots.get(w)} for w, p, b, e, sy, an, _ in VB]),
              TABLE('দ্রুত অনুশীলন (কলাম-লুকাও)', ['Word', 'Synonym', 'বাংলা অর্থ'], *[(w, sy[0], b) for w, p, b, e, sy, an, _ in VB])]
    if mnem: blocks.append(MNEM(*mnem))
    if mistakes: blocks.append(MISTAKES(*mistakes))
    blocks += [SUMMARY(f'{rng}: {len(VB)}টি শব্দ — বাংলা + English অর্থ, synonym, antonym'), UNI(UNIT_EN)]
    B.lesson(lid, blocks, SRC_EN)

    def pick(i, kind, bad, sd):
        me = VB[i]; pool = []
        for j, x in enumerate(VB):
            if j == i or x[6] == me[6]: continue
            cand = (x[4] if kind == 'syn' else x[5])[0]
            if cand not in bad and cand not in pool: pool.append(cand)
        random.Random(sd).shuffle(pool)
        return pool[:3]
    for i, (w, p, b, e, sy, an, cl) in enumerate(VB):
        B.q(lid, 2, f'Choose the synonym of "{w}".', sy[0], [(x, 'অর্থ মেলে না — এটি অন্য শব্দের synonym।') for x in pick(i, 'syn', set(sy) | set(an), seed + i)],
            f'{w} = {b} ({e}); synonyms: {", ".join(sy)}।', 'শব্দমূল ও বাক্যে ব্যবহার ভেবে দেখুন।', f'Antonym: {", ".join(an)}।', trap=w in traps)
        B.card(lid, w, f'{b}\n{e}\n\nSyn: {", ".join(sy)}\nAnt: {", ".join(an)}')
    for i, (w, p, b, e, sy, an, cl) in enumerate(VB):
        if i % 2: continue
        B.q(lid, 2, f'Choose the antonym of "{w}".', an[0], [(x, 'এটি বিপরীতার্থক নয়।') for x in pick(i, 'ant', set(sy) | set(an), seed + 100 + i)],
            f'{w} = {b}; antonym: {", ".join(an)}।', 'Antonym একই part of speech হবে।', f'Synonyms: {", ".join(sy)}।', trap=w in traps)


def spelling_lesson(B, lid, rng, SP, mnem=(), mistakes=(), traps=()):
    """SP: (correct, বাংলা অর্থ, বিপদের জায়গা, [3 ভুল বানান])"""
    blocks = [H(f'Spelling — {rng}'),
              P('ভুল সাধারণত হয় **double letter**, **ie/ei** আর **অনুচ্চারিত স্বরে** (-ant/-ent, -ence/-ance)। প্রতিটি শব্দের "বিপদের জায়গা"টা মনে রাখুন।'),
              TABLE('সঠিক বানান (কলাম-লুকাও)', ['বাংলা অর্থ', 'বিপদের জায়গা', 'সঠিক বানান'], *[(b, t, w) for w, b, t, _ in SP])]
    if mnem: blocks.append(MNEM(*mnem))
    if mistakes: blocks.append(MISTAKES(*mistakes))
    blocks += [SUMMARY(f'{rng}: {len(SP)}টি বহুল-প্রচলিত শব্দ'), UNI(UNIT_EN)]
    B.lesson(lid, blocks, SRC_EN)
    for w, b, t, wr in SP:
        B.q(lid, 2, f'Which spelling is correct? ({b})', w, [(x, 'বানান ভুল।') for x in wr], f'সঠিক বানান: {w} — {t}।', 'শব্দের "বিপদের জায়গা" দেখুন।', f'অর্থ: {b}।', trap=w in traps)


def gv_lesson(B, lid, rng, GV, FILL, seed, mnem=(), mistakes=(), traps=()):
    """GV: (group verb, বাংলা অর্থ, English meaning); FILL: (sentence, answer, [3 wrong], প্রসঙ্গ)"""
    blocks = [H(f'Group Verbs — {rng}'),
              P('**Group verb** (phrasal verb) = **verb + particle**; মিলে নতুন অর্থ। একই verb-এর সব group verb পরিবার ধরে একসাথে পড়ুন।'),
              TABLE('Group Verb (কলাম-লুকাও)', ['Group verb', 'English meaning', 'বাংলা অর্থ'], *[(a, c, b) for a, b, c in GV])]
    if mnem: blocks.append(MNEM(*mnem))
    if mistakes: blocks.append(MISTAKES(*mistakes))
    blocks += [SUMMARY(f'{rng}: {len(GV)}টি group verb', 'Verb পরিবার ধরে পড়ুন'), UNI(UNIT_EN)]
    B.lesson(lid, blocks, SRC_EN)
    for i, (a, b, c) in enumerate(GV):
        pool = [x[2] for j, x in enumerate(GV) if j != i]
        random.Random(seed + i).shuffle(pool)
        B.q(lid, 2, f'The group verb "{a}" means —', c, [(x, 'এটি অন্য একটি group verb-এর অর্থ।') for x in pool[:3]],
            f'{a} = {c} ({b})।', 'Verb পরিবার ধরে মনে রাখুন।', 'Group verb সারণি।', trap=a in traps)
        B.card(lid, a, f'{b}\n{c}')
    for s, a, wr, b in FILL:
        B.q(lid, 2, s, a, [(x, 'অর্থ প্রসঙ্গের সঙ্গে মেলে না।') for x in wr], f'প্রসঙ্গ: {b} → {a}।', 'বাক্যের ভাব বুঝে group verb বাছুন।', 'Group verb সারণি।', trap=True)
