#!/usr/bin/env python3
"""English — Block 4 (J–L): Verb & its Types, Causative, Linking, Subjunctive, Right Form of Verbs + J–L অংশ
ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে। সূত্র: প্রচলিত English grammar ও learner's dictionary।"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb4', 'en', 9401)
Q = B.q
S = ['প্রচলিত English grammar (Wren & Martin; Cambridge/Oxford learner grammar)']
L = 'en-4-'
def FQ(lid, tip, fact, rows):
    """rows: (stem, answer, [(wrong, কেন ভুল) x3], নিয়ম, trap)"""
    for s, a, w, r, trap in rows:
        Q(lid, 2, s, a, w, r, tip, fact, trap=trap)

# =====================================================================
# 4.1 Verb & its Types
# =====================================================================
B.lesson(L + '1', [
    H('Verb ও তার প্রকার'),
    P('যে শব্দ কাজ করা, হওয়া বা থাকা বোঝায় তা **verb**। পরীক্ষায় সবচেয়ে বেশি আসে: **transitive / intransitive**, **principal / auxiliary**, **finite / non-finite**, এবং কিছু বিশেষ ধরন (factitive, cognate object, irregular verb-এর রূপ)।'),
    TABLE('প্রধান ভাগ', ['ভাগ', 'চেনার উপায়', 'উদাহরণ'],
          ('Transitive', 'object আছে ("কী/কাকে?" প্রশ্নের উত্তর)', 'He **rang** the bell.'), ('Intransitive', 'object নেই', 'The bell **rang**.'),
          ('Principal (main)', 'নিজের অর্থ আছে', 'He **has** a car.'), ('Auxiliary', 'অন্য verb-কে সাহায্য করে (be, have, do, modal)', 'He **has** gone.'),
          ('Finite', 'subject-এর person/number ও tense অনুযায়ী বদলায়', 'He **goes** to school.'), ('Non-finite', 'বদলায় না: infinitive, gerund, participle', 'He wants **to go**.'),
          ('Factitive', 'object-এর পরে complement লাগে', 'They **made** him captain.'), ('Cognate object', 'verb-এর সমগোত্রীয় noun object', 'She **lived** a happy life.')),
    TABLE('বিভ্রান্তিকর irregular verb', ['V1', 'V2', 'V3', 'অর্থ'],
          ('lie', 'lay', 'lain', 'শোয়া'), ('lay', 'laid', 'laid', 'রাখা/ডিম পাড়া'), ('lie', 'lied', 'lied', 'মিথ্যা বলা'),
          ('hang', 'hung', 'hung', 'ঝোলানো'), ('hang', 'hanged', 'hanged', 'ফাঁসি দেওয়া'), ('rise', 'rose', 'risen', 'ওঠা (intransitive)'),
          ('raise', 'raised', 'raised', 'তোলা (transitive)'), ('find', 'found', 'found', 'খুঁজে পাওয়া'), ('found', 'founded', 'founded', 'প্রতিষ্ঠা করা'), ('bear', 'bore', 'born/borne', 'জন্ম দেওয়া/বহন করা')),
    MNEM(('"lie-lay-lain শোয়ায়, lay-laid-laid রাখায়"', 'lie/lay', 'নিজে শোয় = lie; কিছু রাখে = lay।'), ('"মানুষ hanged, ছবি hung"', 'hang', 'ফাঁসি = hanged।'),
         ('"rise নিজে ওঠে, raise কাউকে তোলে"', 'rise/raise', 'The sun rises; raise your hand।')),
    MISTAKES('"He laid on the bed" (শোয়া অর্থে) ✗ → He **lay** on the bed।', '"The murderer was hung" ✗ → **hanged**।', '"Prices have raised" ✗ → have **risen**।'),
    SUMMARY('Transitive = object আছে; intransitive = নেই', 'Auxiliary: be, have, do, modal', 'Non-finite: infinitive, gerund, participle', 'lie/lay, hang/hanged, rise/raise সাবধানে'),
    UNI(UNIT_EN),
], S)
FQ(L + '1', '"কী/কাকে?" জিজ্ঞাসা করে object খুঁজুন; বাক্যে কাজ দেখুন।', 'প্রধান ভাগ সারণি।', [
    ('In "The bell rang", "rang" is —', 'intransitive', [('transitive', 'object নেই।'), ('auxiliary', 'নিজের অর্থ আছে।'), ('non-finite', 'tense অনুযায়ী বদলেছে।')], 'object নেই → intransitive।', True),
    ('In "He rang the bell", "rang" is —', 'transitive', [('intransitive', 'object "the bell" আছে।'), ('linking', 'মেলে না।'), ('auxiliary', 'মেলে না।')], 'object আছে → transitive।', True),
    ('In "He has a car", "has" is a/an —', 'principal verb', [('auxiliary verb', 'অন্য verb নেই; নিজের অর্থ (অধিকার)।'), ('modal verb', 'মেলে না।'), ('non-finite verb', 'মেলে না।')], 'নিজের অর্থ → principal।', True),
    ('In "He has gone home", "has" is a/an —', 'auxiliary verb', [('principal verb', 'gone-কে সাহায্য করছে।'), ('transitive verb', 'মেলে না।'), ('linking verb', 'মেলে না।')], 'অন্য verb-কে সাহায্য → auxiliary।', False),
    ('In "He did his homework", "did" is a/an —', 'principal verb', [('auxiliary verb', 'এখানে "do" নিজেই কাজ (করা)।'), ('modal verb', 'মেলে না।'), ('linking verb', 'মেলে না।')], 'did = করল (main verb)।', True),
    ('In "He wants to go", "to go" is a/an —', 'non-finite verb', [('finite verb', 'subject অনুযায়ী বদলায় না।'), ('auxiliary verb', 'মেলে না।'), ('modal verb', 'মেলে না।')], 'Infinitive = non-finite।', False),
    ('In "They made him captain", "made" is a/an —', 'factitive verb', [('intransitive verb', 'object আছে।'), ('linking verb', 'object আছে।'), ('auxiliary verb', 'মেলে না।')], 'object + complement → factitive।', True),
    ('In "She lived a happy life", "life" is a/an —', 'cognate object', [('indirect object', 'মেলে না।'), ('complement', 'মেলে না।'), ('subject', 'মেলে না।')], 'live-এর সমগোত্রীয় noun life → cognate object।', True),
    ('He ___ on the bed for an hour yesterday.', 'lay', [('laid', 'laid = কিছু রাখা।'), ('lied', 'lied = মিথ্যা বলা।'), ('lain', 'V3, auxiliary ছাড়া বসে না।')], 'lie (শোয়া) → lay (V2)।', True),
    ('She ___ the book on the table.', 'laid', [('lay', 'এটি lie-এর V2 (শোয়া)।'), ('lied', 'মিথ্যা বলা।'), ('lain', 'V3।')], 'lay (রাখা) → laid।', True),
    ('The murderer was ___ .', 'hanged', [('hung', 'বস্তু ঝোলানো অর্থে।'), ('hang', 'V1।'), ('hunged', 'অশুদ্ধ।')], 'ফাঁসি = hanged।', True),
    ('The picture was ___ on the wall.', 'hung', [('hanged', 'মানুষের ফাঁসি অর্থে।'), ('hang', 'V1।'), ('hunged', 'অশুদ্ধ।')], 'ঝোলানো = hung।', True),
    ('Prices have ___ sharply.', 'risen', [('raised', 'raise transitive — object লাগে।'), ('rose', 'V2; have-এর পরে V3।'), ('arisen', 'ভিন্ন অর্থ (উদ্ভূত হওয়া)।')], 'rise-rose-risen (intransitive)।', True),
    ('Please ___ your hand if you know the answer.', 'raise', [('rise', 'object "your hand" আছে — transitive লাগবে।'), ('arise', 'মেলে না।'), ('rose', 'V2।')], 'raise + object।', True),
    ('The university was ___ in 1921.', 'founded', [('found', 'find-এর V2/V3; প্রতিষ্ঠা নয়।'), ('find', 'V1।'), ('funded', 'অর্থায়ন — ভিন্ন শব্দ।')], 'found (প্রতিষ্ঠা করা) → founded।', True),
    ('He ___ a lie to his teacher.', 'told', [('lied', '"lied a lie" হয় না; tell a lie।'), ('lay', 'শোয়া।'), ('laid', 'রাখা।')], 'tell a lie → told a lie।', True),
    ('Which of these is an auxiliary (modal) verb?', 'must', [('run', 'Main verb।'), ('seem', 'Linking verb।'), ('make', 'Main verb।')], 'Modal: can, could, may, might, must, shall, should, will, would…', False),
    ('In "The baby sleeps", "sleeps" is —', 'intransitive', [('transitive', 'object নেই।'), ('factitive', 'complement নেই।'), ('non-finite', '-s যোগ হয়েছে — finite।')], 'sleep সাধারণত intransitive।', False),
    ('A finite verb changes according to —', 'the subject and tense', [('nothing', 'বদলায়।'), ('only the object', 'object-এর ওপর নয়।'), ('the article', 'মেলে না।')], 'He goes / They go; went।', False),
    ('The V3 (past participle) of "bear" (জন্ম অর্থে, passive) is —', 'born', [('bore', 'V2।'), ('beared', 'অশুদ্ধ।'), ('bear', 'V1।')], 'He was born in 1990।', False),
])

# =====================================================================
# 4.2 Causative Verb
# =====================================================================
B.lesson(L + '2', [
    H('Causative Verb'),
    P('নিজে না করে **অন্যকে দিয়ে কাজ করানো** বোঝাতে **have, get, make, let, help** ব্যবহৃত হয়। প্রতিটির পরে verb-এর রূপ আলাদা — এটাই পরীক্ষার প্রশ্ন।'),
    TABLE('কাঠামো', ['Causative', 'কাঠামো', 'উদাহরণ'],
          ('have (active)', 'have + ব্যক্তি + V1', 'I had him **repair** my car.'), ('have (passive)', 'have + বস্তু + V3', 'I had my car **repaired**.'),
          ('get (active)', 'get + ব্যক্তি + **to** V1', 'I got him **to repair** my car.'), ('get (passive)', 'get + বস্তু + V3', 'I got my car **repaired**.'),
          ('make', 'make + ব্যক্তি + V1 (to নেই)', 'He made me **laugh**.'), ('make (passive)', 'be made + **to** V1', 'I was made **to laugh**.'),
          ('let', 'let + ব্যক্তি + V1', 'Let him **go**.'), ('help', 'help + ব্যক্তি + (to) V1', 'She helped me (to) **carry** the bag.')),
    MNEM(('"get-এর সাথে to যায়; have, make, let-এর সাথে যায় না"', 'to-এর নিয়ম', 'got him to do; had/made/let him do।'),
         ('"ব্যক্তি করে → V1; বস্তুর ওপর হয় → V3"', 'active/passive', 'had him repair / had the car repaired।'),
         ('"make-এর passive-এ to ফিরে আসে"', 'make passive', 'He was made to work।')),
    MISTAKES('"He made me to laugh" ✗ → made me **laugh**।', '"I got him repair" ✗ → got him **to repair**।', '"I had my hair cut" ✓ — cut-এর V3-ও cut।'),
    SUMMARY('have/make/let + ব্যক্তি + V1', 'get + ব্যক্তি + to V1', 'have/get + বস্তু + V3', 'be made + to V1'),
    UNI(UNIT_EN),
], S)
FQ(L + '2', 'ব্যক্তি নিজে করবে → V1 (get হলে to V1); বস্তুর ওপর কাজ → V3।', 'Causative কাঠামো সারণি।', [
    ('I had him ___ my car.', 'repair', [('to repair', 'have-এর পরে to বসে না।'), ('repaired', 'ব্যক্তি নিজে করছে — V1।'), ('repairing', 'প্রচলিত কাঠামো নয়।')], 'have + ব্যক্তি + V1।', True),
    ('I had my car ___ .', 'repaired', [('repair', 'গাড়ি নিজে মেরামত করে না — V3।'), ('to repair', 'অশুদ্ধ।'), ('repairing', 'অশুদ্ধ।')], 'have + বস্তু + V3।', True),
    ('I got him ___ my car.', 'to repair', [('repair', 'get + ব্যক্তি + to V1।'), ('repaired', 'ব্যক্তি নিজে করছে।'), ('repairs', 'অশুদ্ধ।')], 'get + ব্যক্তি + to V1।', True),
    ('She got her watch ___ .', 'mended', [('mend', 'বস্তু → V3।'), ('to mend', 'বস্তু নিজে মেরামত করে না।'), ('mending', 'অশুদ্ধ।')], 'get + বস্তু + V3।', False),
    ('The joke made me ___ .', 'laugh', [('to laugh', 'make (active)-এর পরে to নেই।'), ('laughed', 'অশুদ্ধ।'), ('laughing', 'অশুদ্ধ।')], 'make + ব্যক্তি + V1।', True),
    ('I was made ___ for two hours.', 'to wait', [('wait', 'Passive-এ to ফিরে আসে।'), ('waited', 'অশুদ্ধ।'), ('waiting', 'অশুদ্ধ।')], 'be made + to V1।', True),
    ('Let him ___ home.', 'go', [('to go', 'let-এর পরে to নেই।'), ('goes', 'অশুদ্ধ।'), ('going', 'অশুদ্ধ।')], 'let + ব্যক্তি + V1।', False),
    ('My father let me ___ the car.', 'drive', [('to drive', 'let-এর পরে to নেই।'), ('driven', 'অশুদ্ধ।'), ('driving', 'অশুদ্ধ।')], 'let + ব্যক্তি + V1।', False),
    ('She helped me ___ the bag.', 'carry', [('carried', 'অশুদ্ধ।'), ('carrying', 'অশুদ্ধ।'), ('carries', 'অশুদ্ধ।')], 'help + ব্যক্তি + (to) V1 — "to carry"-ও শুদ্ধ, তাই অপশনে রাখা হয়নি।', False),
    ('I will have the letter ___ by tomorrow.', 'typed', [('type', 'চিঠি নিজে টাইপ করে না।'), ('to type', 'অশুদ্ধ।'), ('typing', 'অশুদ্ধ।')], 'have + বস্তু + V3।', False),
    ('The teacher made the students ___ the poem.', 'recite', [('to recite', 'make-এর পরে to নেই।'), ('recited', 'অশুদ্ধ।'), ('reciting', 'অশুদ্ধ।')], 'make + ব্যক্তি + V1।', True),
    ('The students were made ___ the poem.', 'to recite', [('recite', 'Passive-এ to লাগে।'), ('recited', 'অশুদ্ধ।'), ('reciting', 'অশুদ্ধ।')], 'be made + to V1।', True),
    ('I got my hair ___ yesterday.', 'cut', [('to cut', 'চুল নিজে কাটে না।'), ('cutting', 'অশুদ্ধ।'), ('cuts', 'অশুদ্ধ।')], 'cut-এর V3 = cut।', True),
    ('Which sentence is correct? (causative)', 'He got the mechanic to check the engine.', [('He got the mechanic check the engine.', 'get-এর পরে to লাগবে।'), ('He had the mechanic to check the engine.', 'have-এর পরে to নেই।'), ('He made the mechanic to check the engine.', 'make-এর পরে to নেই।')], 'get + ব্যক্তি + to V1।', True),
    ('"I had the room cleaned" means —', 'someone else cleaned the room for me', [('I cleaned the room myself', 'Causative = অন্যকে দিয়ে।'), ('The room cleaned itself', 'অর্থহীন।'), ('I did not want the room cleaned', 'উল্টো অর্থ।')], 'Causative have = অন্যকে দিয়ে করানো।', False),
    ('Don\'t let the children ___ in the rain.', 'play', [('to play', 'let-এর পরে to নেই।'), ('played', 'অশুদ্ধ।'), ('plays', 'অশুদ্ধ।')], 'let + V1।', False),
    ('Which verb is NOT normally followed by "to" before the next verb (active)?', 'make', [('get', 'get + ব্যক্তি + to V1।'), ('want', 'want + to V1।'), ('ask', 'ask + ব্যক্তি + to V1।')], 'make/let/have + V1।', True),
    ('They had their house ___ last year.', 'painted', [('paint', 'বাড়ি নিজে রং করে না।'), ('painting', 'অশুদ্ধ।'), ('to paint', 'অশুদ্ধ।')], 'have + বস্তু + V3।', False),
    ('He made his son ___ hard.', 'study', [('to study', 'make-এর পরে to নেই।'), ('studied', 'অশুদ্ধ।'), ('studying', 'অশুদ্ধ।')], 'make + ব্যক্তি + V1।', False),
    ('Causative verbs show that the subject —', 'causes someone else to do the action', [('does the action alone', 'মেলে না।'), ('receives no action', 'মেলে না।'), ('only describes a state', 'Linking verb-এর কাজ।')], 'Causative = করানো।', False),
])

# =====================================================================
# 4.3 Linking Verb
# =====================================================================
B.lesson(L + '3', [
    H('Linking Verb'),
    P('**Linking verb** কোনো কাজ বোঝায় না; subject-কে তার পরের **complement** (adjective বা noun)-এর সঙ্গে যুক্ত করে। তাই এদের পরে **adjective** বসে, **adverb নয়**: The rose smells **sweet** (sweetly ✗)।'),
    TABLE('প্রধান linking verb', ['দল', 'Verb', 'উদাহরণ'],
          ('be', 'am, is, are, was, were', 'She is **happy**.'), ('হয়ে ওঠা', 'become, grow, turn, get, fall', 'He became **famous**. The milk turned **sour**. He fell **ill**.'),
          ('মনে হওয়া', 'seem, appear, look', 'She looks **tired**.'), ('ইন্দ্রিয়', 'feel, smell, taste, sound', 'The food tastes **good**.'), ('থাকা', 'remain, stay, keep', 'He remained **silent**.')),
    TABLE('একই verb, দুই ভূমিকা', ['Linking (→ adjective)', 'Action (→ adverb)'],
          ('She looked **angry**. (দেখাচ্ছিল)', 'She looked **angrily** at me. (তাকাল)'), ('The soup tastes **delicious**.', 'He tasted the soup **carefully**.'),
          ('I feel **bad** about it.', 'He felt the cloth **gently**.'), ('The plan sounds **good**.', '—')),
    MNEM(('"is দিয়ে বদলে দেখুন: অর্থ ঠিক থাকলে linking"', 'Linking পরীক্ষা', 'She looks happy → She is happy ✓ → linking → adjective।'),),
    MISTAKES('"The flower smells sweetly" ✗ → smells **sweet**।', '"I feel badly" ✗ (অনুভূতি অর্থে) → feel **bad**।', '"He fell illness" ✗ → fell **ill**।'),
    SUMMARY('Linking verb + adjective (adverb নয়)', 'be, become, seem, appear, look, feel, smell, taste, sound, grow, turn, remain, get', 'is দিয়ে বদলে পরীক্ষা করুন'),
    UNI(UNIT_EN),
], S)
FQ(L + '3', 'Verb-টা কাজ করছে, নাকি শুধু অবস্থা জুড়ছে? is বসিয়ে দেখুন।', 'Linking verb সারণি।', [
    ('The rose smells ___ .', 'sweet', [('sweetly', 'Linking verb-এর পরে adjective।'), ('sweetness', 'Noun — "smells sweetness" অশুদ্ধ।'), ('sweeten', 'Verb।')], 'smell (linking) + adjective।', True),
    ('She looks ___ today.', 'happy', [('happily', 'look = দেখানো (linking) → adjective।'), ('happiness', 'Noun।'), ('happier than', 'অসম্পূর্ণ তুলনা।')], 'look (দেখানো) + adjective।', True),
    ('She looked ___ at the stranger.', 'angrily', [('angry', 'look at = তাকানো (action) → adverb।'), ('anger', 'Noun।'), ('angered', 'অর্থ মেলে না।')], 'look at = action verb → adverb।', True),
    ('The milk has turned ___ .', 'sour', [('sourly', 'turn (হয়ে যাওয়া) linking।'), ('sourness', 'Noun।'), ('to sour', 'অশুদ্ধ।')], 'turn + adjective।', True),
    ('He fell ___ last week.', 'ill', [('illness', 'Noun — fall ill প্রচলিত।'), ('badly', 'অর্থ মেলে না।'), ('sickly', 'অশুদ্ধ প্রয়োগ।')], 'fall ill = অসুস্থ হওয়া।', True),
    ('The food tastes ___ .', 'delicious', [('deliciously', 'taste (স্বাদ লাগা) linking।'), ('deliciousness', 'Noun।'), ('delicacy', 'অর্থ বদলে যায়।')], 'taste + adjective।', True),
    ('I feel ___ about my mistake.', 'bad', [('badly', 'অনুভূতি অর্থে feel linking → adjective।'), ('worse than', 'অসম্পূর্ণ।'), ('badness', 'Noun।')], 'feel + adjective।', True),
    ('He remained ___ throughout the meeting.', 'silent', [('silently', 'remain linking।'), ('silence', 'Noun।'), ('silenced', 'অর্থ বদলে যায়।')], 'remain + adjective।', False),
    ('Your plan sounds ___ .', 'good', [('well', 'sound linking → adjective।'), ('goodly', 'অশুদ্ধ।'), ('goodness', 'Noun।')], 'sound + adjective।', True),
    ('Which of these is NOT usually a linking verb?', 'run', [('seem', 'Linking।'), ('become', 'Linking।'), ('appear', 'Linking।')], 'run = action verb।', False),
    ('She became ___ after the film.', 'famous', [('famously', 'become linking।'), ('fame', 'Noun — become fame অশুদ্ধ।'), ('famed by', 'অসম্পূর্ণ।')], 'become + adjective।', False),
    ('The weather is growing ___ .', 'cold', [('coldly', 'grow (হয়ে ওঠা) linking।'), ('coldness', 'Noun।'), ('colder than', 'অসম্পূর্ণ তুলনা।')], 'grow + adjective।', False),
    ('He seems ___ today.', 'tired', [('tiredly', 'seem linking।'), ('tiring', 'অর্থ বদলে যায় (ক্লান্তিকর)।'), ('tiredness', 'Noun।')], 'seem + adjective।', True),
    ('He tasted the curry ___ .', 'carefully', [('careful', 'এখানে taste = চেখে দেখা (action) → adverb।'), ('care', 'Noun।'), ('cared', 'অশুদ্ধ।')], 'taste + object = action verb → adverb।', True),
    ('A linking verb is followed by a —', 'complement (adjective or noun)', [('direct object', 'Linking verb object নেয় না।'), ('adverb of manner', 'Action verb-এর পরে।'), ('preposition only', 'মেলে না।')], 'Linking verb + complement।', False),
    ('The story proved ___ .', 'false', [('falsely', 'prove (প্রমাণিত হওয়া) linking।'), ('falsehood', 'অর্থ বদলে যায়।'), ('falsify', 'Verb।')], 'prove + adjective।', False),
    ('The child appears ___ .', 'healthy', [('healthily', 'appear (মনে হওয়া) linking।'), ('health', 'Noun।'), ('healthful', 'ভিন্ন অর্থ (স্বাস্থ্যকর)।')], 'appear + adjective।', False),
    ('She kept ___ during the exam.', 'calm', [('calmly', 'keep (থাকা) linking।'), ('calmness', 'Noun।'), ('calmed', 'অর্থ বদলে যায়।')], 'keep + adjective।', False),
    ('Choose the correct sentence (linking).', 'The music sounds beautiful.', [('The music sounds beautifully.', 'Linking verb-এর পরে adverb নয়।'), ('The music sound beautiful.', 'Agreement ভুল।'), ('The music sounds beauty.', 'Noun বসে না এখানে।')], 'sound + adjective।', True),
    ('He grew ___ with age.', 'wise', [('wisely', 'grow (হয়ে ওঠা) linking।'), ('wisdom', 'Noun।'), ('wiser than', 'অসম্পূর্ণ।')], 'grow + adjective।', False),
])

# =====================================================================
# 4.4 Subjunctive
# =====================================================================
B.lesson(L + '4', [
    H('Subjunctive (কল্পনা, ইচ্ছা, প্রস্তাব)'),
    P('বাস্তব নয় এমন **ইচ্ছা, কল্পনা, প্রার্থনা বা প্রস্তাব** বোঝাতে verb-এর বিশেষ রূপকে **subjunctive** বলে। মূল সূত্র: অবাস্তব কল্পনায় **were** (সব subject-এর সঙ্গে) ও **past form**; প্রস্তাব/দাবিতে **base form (V1)**।'),
    TABLE('কাঠামো', ['ধরন', 'কাঠামো', 'উদাহরণ'],
          ('wish (বর্তমান)', 'wish + past / were', 'I wish I **were** a bird.'), ('wish (অতীত)', 'wish + had + V3', 'I wish I **had studied** harder.'),
          ('If (অবাস্তব)', 'If + were', 'If I **were** you, I would go.'), ('as if / as though', '+ past / were', 'He talks as if he **were** a king.'),
          ('It is (high) time', '+ past', 'It is time we **started**.'), ('would rather', '+ ব্যক্তি + past', 'I\'d rather you **went** now.'),
          ('suggest/insist/demand/recommend that', '+ subject + V1', 'He suggested that she **go**.'), ('প্রার্থনা/আশীর্বাদ', 'V1', 'Long **live** Bangladesh! God **bless** you.'),
          ('lest', '+ should + V1', 'Walk carefully lest you **should** fall.')),
    MNEM(('"অবাস্তব = এক ধাপ পেছনে (present → past, past → past perfect)"', 'wish / as if / if', 'I wish I knew; I wish I had known।'),
         ('"সবাই were — I, he, she সবাই"', 'Subjunctive were', 'If he were rich…'), ('"lest-এর সঙ্গী should, আর not বসে না"', 'lest', 'lest you should fall (lest you should not ✗)।')),
    MISTAKES('"I wish I was a bird" — পরীক্ষার প্রচলিত উত্তর **were**।', '"It is time we start" ✗ → we **started**।', '"lest he should not fail" ✗ → lest he **should** fail (lest নিজেই নেতিবাচক)।', '"He suggested that she goes" (পরীক্ষায়) ✗ → she **go**।'),
    SUMMARY('wish / as if / if (অবাস্তব) → were / past', 'It is time / would rather → past', 'suggest/insist/demand that → V1', 'lest → should + V1'),
    UNI(UNIT_EN),
], S)
FQ(L + '4', 'বাস্তব না কল্পনা? কল্পনা হলে এক ধাপ পেছনের tense; প্রস্তাব হলে V1।', 'Subjunctive সারণি।', [
    ('I wish I ___ a bird.', 'were', [('was', 'পরীক্ষার প্রচলিত subjunctive রূপ were।'), ('am', 'বাস্তব অবস্থা নয়।'), ('will be', 'wish-এর পরে future নয়।')], 'wish + were।', True),
    ('If I ___ you, I would accept the offer.', 'were', [('was', 'অবাস্তব শর্তে were।'), ('am', 'আমি তুমি নই — অবাস্তব।'), ('had been', 'অতীত কল্পনা নয়।')], 'If I were you।', True),
    ('He talks as if he ___ the owner.', 'were', [('is', 'আসলে মালিক নয় — অবাস্তব।'), ('will be', 'মেলে না।'), ('be', 'অশুদ্ধ।')], 'as if + were।', True),
    ('It is high time we ___ for the station.', 'started', [('start', 'It is time + past।'), ('will start', 'মেলে না।'), ('have started', 'মেলে না।')], 'It is (high) time + past।', True),
    ('I would rather you ___ home now.', 'went', [('go', 'would rather + ব্যক্তি + past।'), ('will go', 'মেলে না।'), ('gone', 'অশুদ্ধ।')], 'would rather + past।', True),
    ('The doctor suggested that he ___ smoking.', 'stop', [('stops', 'Subjunctive-এ -s নেই।'), ('stopped', 'Past নয়।'), ('will stop', 'মেলে না।')], 'suggest that + V1।', True),
    ('Walk carefully lest you ___ fall.', 'should', [('will', 'lest-এর সঙ্গে should।'), ('would', 'প্রচলিত নয়।'), ('should not', 'lest নিজেই "না হয় যেন" — not বসে না।')], 'lest + should + V1।', True),
    ('I wish I ___ harder last year.', 'had studied', [('studied', 'অতীতের অপূর্ণ ইচ্ছায় had + V3।'), ('have studied', 'মেলে না।'), ('study', 'মেলে না।')], 'wish (অতীত) + had + V3।', True),
    ('Long ___ our motherland!', 'live', [('lives', 'প্রার্থনায় V1।'), ('lived', 'মেলে না।'), ('living', 'মেলে না।')], 'প্রার্থনা → V1।', False),
    ('God ___ you!', 'bless', [('blesses', 'আশীর্বাদে V1।'), ('blessed', 'মেলে না।'), ('blessing', 'মেলে না।')], 'আশীর্বাদ → V1।', False),
    ('They insisted that the meeting ___ postponed.', 'be', [('is', 'insist that + V1 (be)।'), ('was', 'মেলে না।'), ('being', 'মেলে না।')], 'insist that + V1।', True),
    ('If he ___ rich, he would help the poor.', 'were', [('is', 'অবাস্তব কল্পনা।'), ('was being', 'অশুদ্ধ।'), ('be', 'অশুদ্ধ।')], 'If + were।', False),
    ('She looked as though she ___ a ghost.', 'had seen', [('saw', 'দেখার আগের ঘটনা — past perfect।'), ('has seen', 'মেলে না।'), ('sees', 'মেলে না।')], 'as though + had + V3 (আগের কল্পিত ঘটনা)।', True),
    ('It is time the children ___ to bed.', 'went', [('go', 'It is time + past।'), ('goes', 'মেলে না।'), ('will go', 'মেলে না।')], 'It is time + past।', False),
    ('I demand that he ___ present tomorrow.', 'be', [('is', 'demand that + V1।'), ('will be', 'মেলে না।'), ('was', 'মেলে না।')], 'demand that + V1।', True),
    ('I wish I ___ how to swim.', 'knew', [('know', 'বর্তমানের অপূর্ণ ইচ্ছা → past।'), ('had known', 'অতীতের ইচ্ছা নয়।'), ('will know', 'মেলে না।')], 'wish + past।', True),
    ('Which sentence is correct? (subjunctive)', 'Work hard lest you should fail.', [('Work hard lest you should not fail.', 'lest-এর সঙ্গে not নয়।'), ('Work hard lest you will fail.', 'should লাগবে।'), ('Work hard lest you failed.', 'should + V1 লাগবে।')], 'lest + should + V1।', True),
    ('We recommended that she ___ a doctor.', 'see', [('sees', 'recommend that + V1।'), ('saw', 'মেলে না।'), ('seeing', 'মেলে না।')], 'recommend that + V1।', False),
    ('I would rather ___ at home than go out.', 'stay', [('stayed', 'নিজের ক্ষেত্রে would rather + V1।'), ('to stay', 'to বসে না।'), ('staying', 'মেলে না।')], 'নিজে: would rather + V1; অন্যজন: + past।', True),
    ('Subjunctive "were" is used with —', 'all subjects (I, he, she, they…)', [('only "they"', 'সবার সঙ্গে।'), ('only plural subjects', 'সবার সঙ্গে।'), ('only "you"', 'সবার সঙ্গে।')], 'If I/he/she were…', False),
])

# =====================================================================
# 4.5 Right Form of Verbs
# =====================================================================
B.lesson(L + '5', [
    H('Right Form of Verbs'),
    P('বাক্যের **সংকেত শব্দ** (since, for, no sooner, would you mind, used to…) দেখে verb-এর সঠিক রূপ বসাতে হয়। নিচের নিয়মগুলোই পরীক্ষায় ঘুরেফিরে আসে।'),
    TABLE('সংকেত শব্দ → verb-এর রূপ', ['সংকেত', 'রূপ', 'উদাহরণ'],
          ('চিরন্তন সত্য / অভ্যাস', 'present indefinite', 'The sun **rises** in the east.'),
          ('since/for + সময় (এখনো চলছে)', 'present perfect (continuous)', 'I **have lived** here since 2015.'),
          ('It is/has been … since', 'since-এর পরে past indefinite', 'It is two years since he **died**.'),
          ('No sooner had … than / Hardly had … when', 'past perfect + past', 'No sooner **had** he **come** than it rained.'),
          ('After + past perfect; before-এর আগের অংশে past perfect', '', 'After he **had left**, I came. / The train **had left** before I reached.'),
          ('would you mind / cannot help / look forward to / be used to / avoid', '+ V-ing', 'Would you mind **opening** the door?'),
          ('used to (অতীত অভ্যাস) / had better / would rather', '+ V1', 'He used to **smoke**. You had better **go**.'),
          ('If + present → will; If + past → would + V1; If + had V3 → would have V3', 'Conditional', 'If he had come, I **would have helped**.'),
          ('each/every/one of/the number of', 'singular verb', 'One of the boys **is** absent.'), ('a number of', 'plural verb', 'A number of students **are** absent.'),
          ('neither…nor / either…or', 'কাছের subject অনুযায়ী', 'Neither he nor I **am** guilty.'), ('as soon as / when (অতীত ঘটনা)', 'past + past', 'As soon as he **came**, we left.')),
    MNEM(('"since-এর পরে মৃত অতীত, আগে জীবিত বর্তমান"', 'since', 'It is two years since he died; I have known him since 2010।'),
         ('"mind, help, forward, used to (be), avoid — সবাই -ing খায়"', '+ V-ing', 'look forward to meeting (to meet ✗)।'),
         ('"No sooner-এর সঙ্গী than, Hardly-র সঙ্গী when"', 'জোড়া', 'No sooner … than; Hardly/Scarcely … when।')),
    MISTAKES('"I look forward to meet you" ✗ → to **meeting**।', '"One of the boys are" ✗ → **is**।', '"No sooner had he come when" ✗ → **than**।', '"I am used to get up early" ✗ → used to **getting** up।'),
    SUMMARY('চিরন্তন সত্য → present indefinite', 'since/for (চলমান) → present perfect', 'No sooner had … than; Hardly had … when', 'mind/help/look forward to/be used to/avoid + -ing', 'One of / each / the number of → singular; a number of → plural'),
    UNI(UNIT_EN),
], S)
FQ(L + '5', 'আগে সংকেত শব্দ খুঁজুন (since, no sooner, would you mind…), তারপর নিয়ম বসান।', 'সংকেত শব্দ সারণি।', [
    ('The earth ___ round the sun. (move)', 'moves', [('moved', 'চিরন্তন সত্য — present indefinite।'), ('is moving', 'চিরন্তন সত্যে present indefinite।'), ('has moved', 'মেলে না।')], 'চিরন্তন সত্য → present indefinite।', False),
    ('I ___ here since 2015. (live)', 'have lived', [('lived', 'এখনো চলছে — present perfect।'), ('live', 'since-এর সঙ্গে present indefinite নয়।'), ('had lived', 'মেলে না।')], 'since + সময় (এখনো) → present perfect।', True),
    ('It is five years since he ___ . (die)', 'died', [('has died', 'since-এর পরে past indefinite।'), ('dies', 'মেলে না।'), ('had died', 'মেলে না।')], 'It is … since + past indefinite।', True),
    ('No sooner had he arrived ___ it started raining.', 'than', [('when', 'Hardly/Scarcely-এর সঙ্গে when।'), ('then', 'অশুদ্ধ।'), ('that', 'অশুদ্ধ।')], 'No sooner … than।', True),
    ('Hardly had I reached the station ___ the train left.', 'when', [('than', 'No sooner-এর সঙ্গে than।'), ('then', 'অশুদ্ধ।'), ('that', 'অশুদ্ধ।')], 'Hardly … when।', True),
    ('No sooner ___ the bell rung than the students left.', 'had', [('has', 'অতীত ঘটনা — had (past perfect inversion)।'), ('did', '"did"-এর পরে V1 (ring) লাগত, rung নয়।'), ('was', 'অশুদ্ধ।')], 'No sooner had + subject + V3।', True),
    ('Would you mind ___ the window? (open)', 'opening', [('to open', 'mind + V-ing।'), ('open', 'mind + V-ing।'), ('opened', 'অশুদ্ধ।')], 'would you mind + V-ing।', True),
    ('I am looking forward to ___ you. (meet)', 'meeting', [('meet', 'এখানে "to" preposition — পরে V-ing।'), ('met', 'অশুদ্ধ।'), ('be meeting', 'অশুদ্ধ।')], 'look forward to + V-ing।', True),
    ('He used to ___ early. (get up)', 'get up', [('getting up', 'used to (অতীত অভ্যাস) + V1।'), ('got up', 'অশুদ্ধ।'), ('gets up', 'অশুদ্ধ।')], 'used to + V1।', True),
    ('He is used to ___ early. (get up)', 'getting up', [('get up', 'be used to (অভ্যস্ত) + V-ing।'), ('got up', 'অশুদ্ধ।'), ('gets up', 'অশুদ্ধ।')], 'be used to + V-ing।', True),
    ('You had better ___ a doctor. (see)', 'see', [('to see', 'had better + V1।'), ('seeing', 'মেলে না।'), ('saw', 'মেলে না।')], 'had better + V1।', True),
    ('I cannot help ___ at his joke. (laugh)', 'laughing', [('laugh', 'cannot help + V-ing।'), ('to laugh', 'প্রচলিত নয়।'), ('laughed', 'অশুদ্ধ।')], 'cannot help + V-ing।', True),
    ('If he comes, I ___ him. (tell)', 'will tell', [('would tell', 'If + present → will।'), ('told', 'মেলে না।'), ('would have told', 'মেলে না।')], 'If + present → will + V1।', False),
    ('If I had money, I ___ a car. (buy)', 'would buy', [('will buy', 'If + past → would + V1।'), ('would have bought', 'If + had V3 হলে।'), ('bought', 'মেলে না।')], 'If + past → would + V1।', True),
    ('If he had worked hard, he ___ . (succeed)', 'would have succeeded', [('would succeed', 'If + had V3 → would have V3।'), ('will succeed', 'মেলে না।'), ('succeeded', 'মেলে না।')], 'If + had V3 → would have + V3।', True),
    ('One of the boys ___ absent today. (be)', 'is', [('are', 'Subject "One" — singular।'), ('were', 'মেলে না।'), ('have been', 'মেলে না।')], 'One of + plural noun + singular verb।', True),
    ('A number of students ___ absent. (be)', 'are', [('is', 'a number of = অনেক — plural।'), ('was', 'মেলে না।'), ('has been', 'মেলে না।')], 'a number of + plural verb।', True),
    ('The number of students ___ increasing. (be)', 'is', [('are', 'the number = সংখ্যাটি — singular।'), ('were', 'মেলে না।'), ('have been', 'মেলে না।')], 'the number of + singular verb।', True),
    ('Neither he nor I ___ guilty. (be)', 'am', [('is', 'কাছের subject "I"।'), ('are', 'কাছের subject অনুযায়ী।'), ('be', 'অশুদ্ধ।')], 'neither … nor → কাছের subject।', True),
    ('After he ___ his work, he went out. (finish)', 'had finished', [('finished', 'আগের কাজ — past perfect (পরীক্ষার প্রচলিত উত্তর)।'), ('has finished', 'মেলে না।'), ('finishes', 'মেলে না।')], 'After + past perfect, past indefinite।', True),
    ('The patient ___ before the doctor came. (die)', 'had died', [('died', 'before-এর আগের ঘটনা past perfect।'), ('has died', 'মেলে না।'), ('dies', 'মেলে না।')], 'আগের অতীত → past perfect।', True),
    ('Each of the girls ___ a prize. (get)', 'gets', [('get', 'Each singular।'), ('are getting', 'মেলে না।'), ('have got', 'Plural।')], 'each + singular verb।', False),
    ('He avoided ___ me. (meet)', 'meeting', [('to meet', 'avoid + V-ing।'), ('meet', 'মেলে না।'), ('met', 'মেলে না।')], 'avoid + V-ing।', True),
    ('As soon as the teacher ___, the students stood up. (enter)', 'entered', [('had entered', 'as soon as-এ সাধারণত দুই অংশেই past indefinite।'), ('enters', 'মেলে না।'), ('has entered', 'মেলে না।')], 'as soon as + past, past।', True),
    ('I have been waiting for you ___ two hours.', 'for', [('since', 'সময়ের পরিমাণ (দুই ঘণ্টা) → for।'), ('from', 'প্রচলিত নয়।'), ('during', 'মেলে না।')], 'for + সময়ের পরিমাণ; since + শুরুর সময়।', True),
    ('Mathematics ___ my favourite subject. (be)', 'is', [('are', '-ics বিষয় singular।'), ('were', 'মেলে না।'), ('have been', 'মেলে না।')], 'Mathematics = singular।', False),
    ('He made me ___ the work. (do)', 'do', [('to do', 'make + V1।'), ('doing', 'মেলে না।'), ('done', 'মেলে না।')], 'make + ব্যক্তি + V1।', False),
    ('It is time we ___ the shop. (close)', 'closed', [('close', 'It is time + past।'), ('closing', 'মেলে না।'), ('will close', 'মেলে না।')], 'It is time + past।', False),
    ('I saw him ___ the road. (cross)', 'cross', [('to cross', 'see/hear/watch + object + V1 (বা V-ing)।'), ('crossed', 'মেলে না।'), ('crosses', 'মেলে না।')], 'Perception verb + object + V1/V-ing — "crossing"-ও শুদ্ধ, তাই অপশনে রাখা হয়নি।', True),
    ('He is senior ___ me in service.', 'to', [('than', 'Latin comparative-এর পরে to।'), ('from', 'অশুদ্ধ।'), ('over', 'অশুদ্ধ।')], 'senior to।', False),
])

# =====================================================================
# 4.6 – 4.10 : J–L
# =====================================================================
RNG = 'J–L'
prep_lesson(B, L + '6', RNG, [
    ('jealous', 'of', 'He is jealous ___ his brother\'s success.', 'ঈর্ষান্বিত', ()), ('junior', 'to', 'She is junior ___ me in office.', 'কনিষ্ঠ', ()),
    ('justified', 'in', 'You were justified ___ refusing.', 'যুক্তিসংগত', ()), ('keen', 'on', 'He is keen ___ football.', 'আগ্রহী', ()),
    ('kind', 'to', 'Be kind ___ animals.', 'দয়ালু', ()), ('knock', 'at', 'Someone is knocking ___ the door.', 'কড়া নাড়া', ('on',)),
    ('known', 'to', 'He is known ___ everyone.', 'পরিচিত', ()), ('lacking', 'in', 'He is lacking ___ confidence.', 'ঘাটতি আছে', ()),
    ('laugh', 'at', 'Don\'t laugh ___ the poor.', 'উপহাস করা', ()), ('lean', 'against', 'He leaned ___ the wall.', 'হেলান দেওয়া', ('on',)),
    ('liable (responsible)', 'for', 'You are liable ___ the damage.', 'দায়ী', ()), ('liable (subject to)', 'to', 'Prices are liable ___ change.', 'বদলাতে পারে এমন', ()),
    ('listen', 'to', 'Listen ___ your teacher.', 'শোনা', ()), ('live', 'on', 'Cows live ___ grass.', '(খাদ্য) খেয়ে বাঁচা', ()),
    ('long', 'for', 'He longs ___ home.', 'আকুল হওয়া', ()), ('loyal', 'to', 'He is loyal ___ his country.', 'অনুগত', ()),
    ('lame', 'in', 'He is lame ___ one leg.', 'খোঁড়া', ()), ('labour', 'under', 'He is labouring ___ a misunderstanding.', 'ভুল ধারণায় ভোগা', ()),
    ('lag', 'behind', 'Don\'t lag ___ others.', 'পিছিয়ে পড়া', ()), ('lament', 'over', 'He lamented ___ his loss.', 'বিলাপ করা', ('for',))],
    7100,
    contrast=(('liable for', 'দায়ী: liable for the loss'), ('liable to', 'সম্ভাব্য/অধীন: liable to change'), ('lean against', 'কিছুতে ঠেস দিয়ে: lean against the wall'), ('lean on', 'নির্ভর করা: lean on friends')),
    mnem=(('"to-দল: junior, kind, known, listen, loyal, liable(সম্ভাব্য)"', '"to" লাগে', 'কারও দিকে।'),),
    mistakes=('"listen me" ✗ → listen **to** me।', '"jealous on" ✗ → jealous **of**।', '"live by rice" ✗ (খাদ্য অর্থে) → live **on** rice।'))

idiom_lesson(B, L + '7', RNG, [
    ('jack of all trades', 'সব কাজের কাজি (কোনোটায় পারদর্শী নয়)', 'a person who can do many things', 'পরে যোগ হয়েছে "master of none" — অনেক কাজ জানে, কোনোটায় দক্ষ নয়।', 'He is a jack of all trades.'),
    ('Job\'s comforter', 'যে সান্ত্বনা দিতে গিয়ে কষ্ট বাড়ায়', 'one who worsens distress while trying to comfort', 'বাইবেলের Job-এর বন্ধুরা সান্ত্বনার বদলে তাকেই দোষ দিয়েছিল।', 'His words made him a Job\'s comforter.'),
    ('Judas kiss', 'বিশ্বাসঘাতকতা', 'an act of betrayal disguised as friendship', 'বাইবেল: Judas চুম্বনের মাধ্যমে Jesus-কে শত্রুদের হাতে ধরিয়ে দেয়।', 'His praise was a Judas kiss.'),
    ('keep one\'s fingers crossed', 'সাফল্যের আশায় থাকা', 'to hope for good luck', 'আঙুল ক্রস করা — সৌভাগ্য কামনার প্রচলিত ভঙ্গি।', 'Keep your fingers crossed for my result.'),
    ('keep the wolf from the door', 'অনাহার ঠেকানো', 'to earn just enough to avoid hunger', 'দরজায় ক্ষুধার্ত নেকড়ে = অভাব।', 'He works two jobs to keep the wolf from the door.'),
    ('kick the bucket', 'মারা যাওয়া (অনানুষ্ঠানিক)', 'to die (informal)', 'উৎস অনিশ্চিত; কথ্য ও হালকা ভঙ্গির প্রয়োগ।', 'The old man kicked the bucket last night.'),
    ('kill two birds with one stone', 'এক ঢিলে দুই পাখি মারা', 'to achieve two aims with one action', 'বাংলাতেও হুবহু একই বাগধারা।', 'By cycling to work, I kill two birds with one stone.'),
    ('kith and kin', 'আত্মীয়স্বজন', 'friends and relatives', 'kith (পুরোনো ইংরেজি: পরিচিতজন) + kin (আত্মীয়)।', 'He invited all his kith and kin.'),
    ('a lame excuse', 'খোঁড়া অজুহাত', 'a weak, unconvincing excuse', 'খোঁড়া পা যেমন ভর সয় না।', 'Being late because of rain is a lame excuse.'),
    ('the last straw', 'ধৈর্যের শেষ সীমা', 'the final problem that makes a situation unbearable', '"the straw that broke the camel\'s back" — উটের পিঠে শেষ খড়টাই ভার অসহ করে তোলে।', 'His rudeness was the last straw.'),
    ('laugh in one\'s sleeve', 'মনে মনে হাসা', 'to laugh secretly', 'জামার হাতায় মুখ লুকিয়ে হাসা।', 'He laughed in his sleeve at my mistake.'),
    ('lead a dog\'s life', 'দুঃখকষ্টের জীবন কাটানো', 'to live a miserable life', 'অবহেলিত কুকুরের জীবনের ছবি।', 'The poor labourer leads a dog\'s life.'),
    ('leave no stone unturned', 'চেষ্টার কোনো ত্রুটি না রাখা', 'to try every possible way', 'প্রাচীন গ্রিক একটি গল্পের সঙ্গে যুক্ত বলে প্রচলিত — লুকানো ধন খুঁজতে প্রতিটি পাথর উল্টে দেখার পরামর্শ।', 'The police left no stone unturned.'),
    ('let the cat out of the bag', 'গোপন কথা ফাঁস করা', 'to reveal a secret', 'প্রচলিত ব্যাখ্যা: হাটে শূকরছানার নামে থলেতে বিড়াল বিক্রির প্রতারণা — থলে খুললে ফাঁস।', 'She let the cat out of the bag about the party.'),
    ('the lion\'s share', 'সিংহভাগ', 'the largest part', 'ঈশপের গল্প: শিকারে সবাই মিলে খাটলেও সিংহ পুরোটাই নিয়ে নেয় — বাংলা "সিংহভাগ"।', 'He took the lion\'s share of the profit.'),
    ('lip service', 'মৌখিক সমর্থন (কাজে নয়)', 'support in words but not in action', 'শুধু ঠোঁটের সেবা — কাজে নয়।', 'They only pay lip service to equality.'),
    ('lock, stock and barrel', 'সম্পূর্ণভাবে', 'completely', 'বন্দুকের তিনটি অংশ (lock, stock, barrel) মিলে পুরো বন্দুক।', 'He sold his business lock, stock and barrel.'),
    ('a labour of love', 'ভালোবাসার শ্রম (পারিশ্রমিক ছাড়া)', 'work done for pleasure, not money', 'টাকার জন্য নয়, ভালোবাসায় করা কাজ।', 'Editing the magazine was a labour of love.'),
    ('a left-handed compliment', 'দ্ব্যর্থক প্রশংসা (আসলে অপমান)', 'a compliment that is really an insult', 'বাম হাত দিয়ে দেওয়া — আন্তরিক নয়।', '"You look good for your age" is a left-handed compliment.'),
    ('let sleeping dogs lie', 'পুরোনো ঝামেলা না জাগানো', 'to avoid stirring up old trouble', 'ঘুমন্ত কুকুরকে জাগালে কামড়াতে পারে।', 'Don\'t mention the old quarrel; let sleeping dogs lie.'),
    ('loaves and fishes', 'পার্থিব লাভ', 'material benefits', 'বাইবেলে রুটি ও মাছের অলৌকিক ঘটনার পর অনেকে শুধু খাবারের লোভে অনুসরণ করেছিল — সেখান থেকে।', 'Many politicians care only for loaves and fishes.'),
    ('look before you leap', 'ভেবেচিন্তে কাজ করা', 'think before acting', 'লাফ দেওয়ার আগে দেখে নাও — প্রবাদ হিসেবেও প্রচলিত।', 'Look before you leap into business.')],
    7200, traps=('Job\'s comforter', 'lip service', 'left-handed compliment', 'kick the bucket'),
    mnem=(('"বাইবেলের তিন: Job\'s comforter, Judas kiss, loaves and fishes"', 'উৎস দিয়ে মনে রাখা', 'চরিত্রের কাজ = idiom-এর অর্থ।'), ('"বাংলা জোড়া: lion\'s share = সিংহভাগ; kill two birds = এক ঢিলে দুই পাখি"', 'সমতুল্য', 'হুবহু মিলে যায়।')),
    mistakes=('**Job\'s comforter** = যে কষ্ট বাড়ায় — "চাকরিদাতা" নয়।', '**left-handed compliment** = আসলে অপমান।'))

vocab_lesson(B, L + '8', RNG, [
    ('jeopardy', 'n', 'বিপদ, ঝুঁকি', 'danger of loss or harm', ['danger', 'peril', 'risk'], ['safety', 'security'], 'danger'),
    ('jovial', 'adj', 'হাসিখুশি, প্রফুল্ল', 'cheerful and friendly', ['cheerful', 'jolly', 'genial'], ['morose', 'gloomy'], 'happy'),
    ('jubilant', 'adj', 'উল্লসিত', 'feeling great happiness and triumph', ['joyful', 'triumphant', 'elated'], ['dejected', 'despondent'], 'happy'),
    ('judicious', 'adj', 'বিবেচক, বিচক্ষণ', 'having good judgement', ['wise', 'prudent', 'sensible'], ['foolish', 'rash'], 'wise'),
    ('juvenile', 'adj', 'কিশোর; অপরিণত', 'young; childish', ['youthful', 'immature', 'adolescent'], ['adult', 'mature'], 'young'),
    ('juxtapose', 'v', 'পাশাপাশি রাখা', 'to place side by side', ['place side by side', 'compare'], ['separate'], 'place'),
    ('keen', 'adj', 'আগ্রহী; তীক্ষ্ণ', 'eager; sharp', ['eager', 'enthusiastic', 'sharp'], ['reluctant', 'dull'], 'eager'),
    ('kindle', 'v', 'প্রজ্বালিত করা; জাগিয়ে তোলা', 'to set fire to; to arouse', ['ignite', 'arouse', 'inflame'], ['extinguish', 'quench'], 'fire'),
    ('knack', 'n', 'দক্ষতা, কৌশল', 'a special skill', ['skill', 'talent', 'flair'], ['inability', 'incompetence'], 'skill'),
    ('laconic', 'adj', 'স্বল্পভাষী, সংক্ষিপ্ত', 'using very few words', ['terse', 'brief', 'concise'], ['verbose', 'wordy'], 'brief'),
    ('lament', 'v', 'বিলাপ করা', 'to express grief', ['mourn', 'grieve', 'bewail'], ['rejoice', 'celebrate'], 'sad'),
    ('languid', 'adj', 'নিস্তেজ, অবসন্ন', 'weak and lacking energy', ['listless', 'sluggish', 'lethargic'], ['energetic', 'lively'], 'slow'),
    ('lavish', 'adj', 'অমিতব্যয়ী; প্রচুর', 'very generous or extravagant', ['extravagant', 'sumptuous', 'profuse'], ['frugal', 'meagre'], 'much'),
    ('lenient', 'adj', 'সহনশীল, কোমল', 'not strict in punishing', ['tolerant', 'merciful', 'forgiving'], ['strict', 'harsh'], 'soft'),
    ('lethal', 'adj', 'প্রাণঘাতী', 'able to cause death', ['deadly', 'fatal', 'mortal'], ['harmless', 'safe'], 'death'),
    ('liberal', 'adj', 'উদার', 'open to new ideas; generous', ['broad-minded', 'tolerant', 'generous'], ['narrow-minded', 'conservative'], 'soft'),
    ('lofty', 'adj', 'উঁচু; মহৎ', 'very tall; noble', ['towering', 'high', 'noble'], ['low', 'base'], 'high'),
    ('loquacious', 'adj', 'বাচাল', 'talking a great deal', ['talkative', 'garrulous', 'chatty'], ['taciturn', 'reticent'], 'talk'),
    ('lucid', 'adj', 'স্পষ্ট, প্রাঞ্জল', 'clearly expressed', ['clear', 'intelligible', 'plain'], ['obscure', 'confusing'], 'clear'),
    ('lucrative', 'adj', 'লাভজনক', 'producing much profit', ['profitable', 'rewarding', 'gainful'], ['unprofitable', 'loss-making'], 'profit'),
    ('ludicrous', 'adj', 'হাস্যকর', 'so foolish as to be amusing', ['absurd', 'ridiculous', 'preposterous'], ['sensible', 'reasonable'], 'silly'),
    ('lure', 'v', 'প্রলুব্ধ করা', 'to tempt', ['tempt', 'entice', 'attract'], ['repel', 'deter'], 'tempt'),
    ('lustre', 'n', 'দীপ্তি, ঔজ্জ্বল্য', 'a gentle shine', ['shine', 'gloss', 'radiance'], ['dullness'], 'shine'),
    ('luxuriant', 'adj', 'প্রচুর ও ঘন (গাছপালা)', 'growing thickly and richly', ['lush', 'dense', 'abundant'], ['sparse', 'barren'], 'much')],
    7300,
    roots={'laconic': 'গ্রিসের Laconia (স্পার্টা) অঞ্চলের মানুষ খুব কম কথা বলার জন্য বিখ্যাত ছিল।', 'loquacious': 'Latin loqui (বলা) — eloquent একই মূল।',
           'lucid': 'Latin lux/lucidus (আলো) — আলোর মতো পরিষ্কার।', 'lethal': 'Latin letum (মৃত্যু)।', 'juxtapose': 'Latin juxta (পাশে) + pose (রাখা)।',
           'luxuriant': 'সাবধান: luxuriant (ঘন, প্রচুর) ≠ luxurious (বিলাসবহুল)।', 'judicious': 'judge/judicial-এর একই পরিবার — বিচারবুদ্ধিসম্পন্ন।'},
    traps=('luxuriant', 'laconic', 'lenient', 'lucid', 'juvenile'),
    mnem=(('"lux/luc = আলো"', 'শব্দমূল', 'lucid (স্পষ্ট), lustre (দীপ্তি)।'), ('"loqu = বলা"', 'শব্দমূল', 'loquacious, eloquent, soliloquy।')),
    mistakes=('**luxuriant** ≠ **luxurious**।', '**laconic** = স্বল্পভাষী — "lazy" নয়।', '**lenient** = নরম, "lean" (রোগা) নয়।'))

spelling_lesson(B, L + '9', RNG, [
    ('jealous', 'ঈর্ষান্বিত', 'jea-lous (ea)', ['jelous', 'jealus', 'jellous']),
    ('jeopardy', 'বিপদ', 'jeo-pardy (eo)', ['jepordy', 'jeapardy', 'jeoperdy']),
    ('journey', 'ভ্রমণ', 'jour-ney (ou, ey)', ['journy', 'jurney', 'journee']),
    ('jubilee', 'জয়ন্তী', 'ju-bi-lee', ['jubilie', 'jubillee', 'jubele']),
    ('kindergarten', 'শিশু বিদ্যালয়', 'garten (জার্মান), garden নয়', ['kindergarden', 'kindergarton', 'kindegarten']),
    ('knowledge', 'জ্ঞান', 'know + ledge (d ভুলবেন না)', ['knowlege', 'knowladge', 'knowledg']),
    ('knowledgeable', 'জ্ঞানী', 'knowledge-এর e থাকে + able', ['knowledgable', 'knowlegeable', 'knowledgible']),
    ('label', 'লেবেল', 'শেষে -el', ['lable', 'labell', 'lebel']),
    ('laboratory', 'পরীক্ষাগার', 'labor-a-tory', ['labratory', 'laboratary', 'labortory']),
    ('language', 'ভাষা', 'lang-u-age', ['langauge', 'languege', 'langage']),
    ('legitimate', 'বৈধ', 'le-git-i-mate', ['legitamate', 'legitimite', 'legimate']),
    ('leisure', 'অবসর', 'ei (ব্যতিক্রম)', ['liesure', 'leasure', 'leisur']),
    ('liaison', 'যোগাযোগ', 'i-a-i: li-ai-son', ['liason', 'liaision', 'laison']),
    ('library', 'গ্রন্থাগার', 'lib-ra-ry (r দুটি)', ['libary', 'librery', 'liberary']),
    ('lieutenant', 'লেফটেন্যান্ট', 'lieu-tenant', ['leiutenant', 'lieutenent', 'leutenant']),
    ('likelihood', 'সম্ভাবনা', 'likely-র y → i', ['likelyhood', 'likelihod', 'likleihood']),
    ('literature', 'সাহিত্য', 'lit-er-a-ture', ['literture', 'litrature', 'literatue']),
    ('loneliness', 'নিঃসঙ্গতা', 'lone + li + ness', ['lonliness', 'lonelyness', 'loneliess']),
    ('luxury', 'বিলাস', 'lux-u-ry', ['luxary', 'luxery', 'luxuri']),
    ('lying', 'মিথ্যা বলা/শুয়ে থাকা', 'lie → ie বদলে y + ing', ['lieing', 'lyeing', 'liing'])],
    traps=('kindergarten', 'knowledgeable', 'leisure', 'liaison', 'lying'),
    mnem=(('"liaison — দুই i মাঝখানে a-কে জড়িয়ে রাখে"', 'liaison', 'li-a-i-son।'), ('"lie → lying, die → dying, tie → tying"', '-ie + ing', 'ie বদলে y।')),
    mistakes=('"kindergarden" ✗ → **kindergarten**।', '"knowledgable" ✗ → **knowledgeable**।', '"libary" ✗ → **library**।'))

gv_lesson(B, L + '10', RNG, [
    ('jot down', 'টুকে রাখা', 'write down quickly'), ('keep up', 'বজায় রাখা', 'maintain'), ('keep up with', 'তাল মেলানো', 'stay level with'),
    ('keep off', 'দূরে থাকা', 'stay away from'), ('keep on', 'চালিয়ে যাওয়া', 'continue'), ('knock down', 'ধাক্কা দিয়ে ফেলা; ভেঙে ফেলা', 'hit and make fall; demolish'),
    ('knock out', 'হারিয়ে দেওয়া; অজ্ঞান করা', 'eliminate; make unconscious'), ('lay off', 'ছাঁটাই করা', 'dismiss (workers)'), ('lay out', 'নকশা/সাজানো', 'arrange; plan'),
    ('lay down', 'নির্ধারণ করা; ত্যাগ করা', 'establish (a rule); give up'), ('let down', 'হতাশ করা', 'disappoint'), ('let off', 'শাস্তি না দিয়ে ছেড়ে দেওয়া', 'excuse from punishment'),
    ('look after', 'দেখাশোনা করা', 'take care of'), ('look for', 'খোঁজা', 'search for'), ('look into', 'তদন্ত করা', 'investigate'),
    ('look up', '(অভিধানে) খোঁজা', 'search in a reference book'), ('look down upon', 'হেয় করা', 'despise'), ('look up to', 'শ্রদ্ধা করা', 'respect'),
    ('look forward to', 'আগ্রহভরে অপেক্ষা করা', 'wait eagerly for'), ('look out', 'সাবধান হওয়া', 'be careful')],
    [('Please ___ my little brother while I am out.', 'look after', ['look for', 'look into', 'look up'], 'দেখাশোনা'),
     ('The police are ___ the matter.', 'looking into', ['looking after', 'looking for', 'looking up to'], 'তদন্ত'),
     ('___ the word in a dictionary.', 'Look up', ['Look after', 'Look into', 'Look out'], 'অভিধানে খোঁজা'),
     ('We should not ___ the poor.', 'look down upon', ['look up to', 'look after', 'look forward to'], 'হেয় করা'),
     ('Students ___ their teachers.', 'look up to', ['look down upon', 'look into', 'look out'], 'শ্রদ্ধা'),
     ('The factory ___ 200 workers.', 'laid off', ['laid out', 'let down', 'let off'], 'ছাঁটাই'),
     ('I trusted him, but he ___ me ___.', 'let, down', ['let, off', 'laid, off', 'kept, on'], 'হতাশ করা'),
     ('He ran fast to ___ the others.', 'keep up with', ['keep off', 'keep on', 'knock out'], 'তাল মেলানো')],
    7400, traps=('look after', 'look into', 'look up to', 'look down upon', 'lay off', 'let off'),
    mnem=(('"LOOK পরিবার: after-যত্ন, for-খোঁজা, into-তদন্ত, up-অভিধান, up to-শ্রদ্ধা, down upon-হেয়"', 'look', 'একসাথে পড়ুন — পরীক্ষার সবচেয়ে প্রিয় পরিবার।'),
          ('"LET: down-হতাশ, off-ছাড়"; "LAY: off-ছাঁটাই, out-নকশা, down-নিয়ম"', 'let/lay', 'জোড়ায় জোড়ায়।')),
    mistakes=('**look up to** (শ্রদ্ধা) ≠ **look down upon** (হেয়)।', '**let off** = ছেড়ে দেওয়া; **lay off** = ছাঁটাই।'))

B.autofill_cards(12)
B.save('b4', 'en-b4')
