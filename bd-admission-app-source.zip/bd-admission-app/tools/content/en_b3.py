#!/usr/bin/env python3
"""English — Block 3 (G–I): Adjective Types, Degree of Comparison, Article, Same Word Different Parts of Speech + G–I অংশ
ব্যাখ্যা বাংলায়, পরিভাষা ইংরেজিতে। সূত্র: প্রচলিত English grammar ও learner's dictionary।"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb3', 'en', 9301)
Q = B.q
def QS(lid, rows):
    for d, q, a, w, r, t, f, trap in rows:
        Q(lid, d, q, a, w, r, t, f, trap=trap)
S = ['প্রচলিত English grammar (Wren & Martin; Cambridge/Oxford learner grammar)']
L = 'en-3-'

# =====================================================================
# 3.1 Adjective Types
# =====================================================================
AT = [('a brave soldier', 'brave', 'Adjective of quality'), ('some milk', 'some', 'Adjective of quantity'), ('five books', 'five', 'Adjective of number'),
      ('this pen', 'this', 'Demonstrative adjective'), ('Which book do you want?', 'Which', 'Interrogative adjective'), ('my house', 'my', 'Possessive adjective'),
      ('Bangladeshi people', 'Bangladeshi', 'Proper adjective'), ('every student', 'every', 'Distributive adjective'), ('with my own eyes', 'own', 'Emphasizing adjective'),
      ('What a beautiful day!', 'What', 'Exclamatory adjective')]
B.lesson(L + '1', [
    H('Adjective ও তার প্রকার'),
    P('যে শব্দ **noun বা pronoun**-এর দোষ, গুণ, সংখ্যা, পরিমাণ বা অবস্থা বোঝায় তা **adjective**। চেনার প্রশ্ন: **কেমন? কত? কতগুলো? কোনটি? কার?**'),
    TABLE('Adjective-এর প্রকার (কলাম-লুকাও)', ['উদাহরণ', 'Adjective', 'প্রকার'], *AT),
    TABLE('বিভ্রান্তিকর জোড়া', ['শব্দ', 'Adjective হিসেবে', 'অন্য ভূমিকায়'],
          ('this', 'this pen (noun-এর আগে)', 'This is mine. (একা বসলে pronoun)'), ('my / mine', 'my book (adjective)', 'The book is mine. (pronoun)'),
          ('some', 'some milk = quantity', 'some boys = number (গোনা যায়)'), ('which', 'Which book? (noun-এর আগে)', 'Which is yours? (pronoun)')),
    TABLE('Adjective-এর ক্রম (একাধিক adjective বসলে) — OSASCOMP', ['ক্রম', 'ধরন', 'উদাহরণ'],
          ('O', 'Opinion (মত)', 'beautiful'), ('S', 'Size (আকার)', 'big'), ('A', 'Age (বয়স)', 'old'), ('S', 'Shape (আকৃতি)', 'round'),
          ('C', 'Colour (রং)', 'red'), ('O', 'Origin (উৎস)', 'Chinese'), ('M', 'Material (উপাদান)', 'wooden'), ('P', 'Purpose (উদ্দেশ্য)', 'dining')),
    P('**অবস্থান:** বেশির ভাগ adjective noun-এর আগে বসে (attributive)। কিছু শুধু verb-এর পরে বসে (predicative): **afraid, alive, asleep, alone, awake** — "an asleep child" ✗, "The child is asleep" ✓। কিছু ক্ষেত্রে noun-এর পরে: something **new**, the President **elect**।'),
    MNEM(('"OSASCOMP" — Opinion Size Age Shape Colour Origin Material Purpose', 'Adjective-এর ক্রম', 'a beautiful big old round red Chinese wooden dining table।'),
         ('"a- দিয়ে শুরু adjective নামের আগে বসে না"', 'Predicative-only', 'afraid, alive, asleep, alone, awake।')),
    MISTAKES('"an asleep baby" ✗ → a sleeping baby / The baby is asleep।', '"a red big ball" ✗ → a big red ball (size আগে, colour পরে)।', '"This is my." ✗ → This is mine।'),
    SUMMARY('Adjective = noun/pronoun-কে বিশেষিত করে', 'প্রকার: quality, quantity, number, demonstrative, interrogative, possessive, proper, distributive, emphasizing, exclamatory', 'ক্রম: OSASCOMP', 'afraid/alive/asleep/alone/awake → শুধু verb-এর পরে'),
    UNI(UNIT_EN),
], S)
KINDS_A = sorted(set(x[2] for x in AT))
for i, (ex, w, k) in enumerate(AT):
    pool = [x for x in KINDS_A if x != k]; random.Random(6000 + i).shuffle(pool)
    Q(L + '1', 2, f'In "{ex}", "{w}" is a/an —', k, [(x, 'এখানে শব্দটির কাজ মেলে না।') for x in pool[:3]], f'"{w}" → {k}।', 'জিজ্ঞাসা করুন: কেমন? কত? কতগুলো? কোনটি? কার?', 'প্রকার সারণি।',
      trap=w in ('own', 'What', 'every', 'some'))
QS(L + '1', [
    (2, 'In "This is my pen", "This" is a/an —', 'pronoun', [('demonstrative adjective', 'noun-এর আগে বসেনি — একা বসেছে।'), ('adverb', 'মেলে না।'), ('article', 'মেলে না।')],
     'This একা বসে noun-এর কাজ করছে → pronoun।', 'noun-এর আগে = adjective; একা = pronoun।', 'বিভ্রান্তিকর জোড়া।', True),
    (2, 'In "I want some water", "some" is an adjective of —', 'quantity', [('number', 'water গোনা যায় না।'), ('quality', 'গুণ নয়।'), ('distribution', 'মেলে না।')],
     'Uncountable-এর আগে → quantity।', 'some water = quantity; some boys = number।', 'বিভ্রান্তিকর জোড়া।', True),
    (2, 'In "Some boys are absent", "some" is an adjective of —', 'number', [('quantity', 'boys গোনা যায় — number।'), ('quality', 'গুণ নয়।'), ('demonstration', 'মেলে না।')],
     'Countable plural-এর আগে → number।', 'গোনা যায় = number।', 'বিভ্রান্তিকর জোড়া।', True),
    (2, 'Choose the correct order.', 'a big old red bus', [('a red big old bus', 'Colour আগে বসেছে।'), ('an old red big bus', 'Size পরে বসেছে।'), ('a big red old bus', 'Age, colour-এর আগে বসবে।')],
     'Size → Age → Colour।', 'OSASCOMP।', 'ক্রম সারণি।', True),
    (2, 'Choose the correct order (opinion first).', 'a lovely small wooden box', [('a small lovely wooden box', 'Opinion আগে।'), ('a wooden lovely small box', 'Material শেষে।'), ('a lovely wooden small box', 'Size, material-এর আগে।')],
     'Opinion → Size → Material।', 'OSASCOMP।', 'ক্রম সারণি।', True),
    (2, 'Which adjective is used only after a verb (predicatively)?', 'asleep', [('sleepy', 'noun-এর আগেও বসে: a sleepy child।'), ('sleeping', 'a sleeping baby চলে।'), ('tired', 'a tired man চলে।')],
     'a- দিয়ে শুরু কিছু adjective শুধু verb-এর পরে বসে।', 'afraid, alive, asleep, alone, awake।', 'অবস্থান অনুচ্ছেদ।', True),
    (2, 'Choose the correct sentence.', 'I saw something strange.', [('I saw strange something.', 'something/anything-এর পরে adjective বসে।'), ('I saw a strange something.', 'অশুদ্ধ।'), ('I saw something of strange.', 'অশুদ্ধ।')],
     'something/anything/nothing + adjective।', 'postpositive adjective।', 'অবস্থান অনুচ্ছেদ।', True),
    (1, 'An adjective qualifies a —', 'noun or pronoun', [('verb', 'Adverb-এর কাজ।'), ('preposition', 'মেলে না।'), ('conjunction', 'মেলে না।')],
     'Adjective = noun/pronoun-এর বিশেষণ।', 'Verb-কে বিশেষিত করে adverb।', 'সংজ্ঞা।', False),
    (2, '"The boy is afraid of dogs." — "afraid" is used —', 'predicatively', [('attributively', 'noun-এর আগে বসেনি।'), ('as an adverb', 'is-এর পরে subject-এর অবস্থা বোঝাচ্ছে।'), ('as a noun', 'মেলে না।')],
     'Verb-এর পরে বসে subject-কে বর্ণনা = predicative।', 'আগে = attributive, পরে = predicative।', 'অবস্থান অনুচ্ছেদ।', True),
    (2, 'In "Whose book is this?", "Whose" is a/an —', 'interrogative adjective', [('possessive pronoun', 'noun (book)-এর আগে বসে প্রশ্ন করছে।'), ('relative pronoun', 'Clause জুড়ছে না।'), ('demonstrative adjective', 'মেলে না।')],
     'প্রশ্নবাচক শব্দ + noun = interrogative adjective।', 'Whose/Which/What + noun।', 'প্রকার সারণি।', True),
])

# =====================================================================
# 3.2 Degree of Comparison
# =====================================================================
B.lesson(L + '2', [
    H('Degree of Comparison'),
    P('Adjective/adverb-এর তিনটি **degree**: **Positive** (তুলনা নেই: tall), **Comparative** (দুইয়ের তুলনা: taller than), **Superlative** (দুইয়ের বেশির মধ্যে সর্বোচ্চ: the tallest)। ছোট শব্দে -er/-est, বড় শব্দে more/most।'),
    TABLE('অনিয়মিত (Irregular) রূপ', ['Positive', 'Comparative', 'Superlative'],
          ('good / well', 'better', 'best'), ('bad / ill', 'worse', 'worst'), ('little', 'less', 'least'), ('many / much', 'more', 'most'),
          ('far (দূরত্ব)', 'farther', 'farthest'), ('far (বাড়তি)', 'further', 'furthest'), ('late (সময়)', 'later', 'latest'), ('late (ক্রম)', 'latter', 'last'),
          ('old (বয়স)', 'older', 'oldest'), ('old (পরিবারে)', 'elder', 'eldest')),
    TABLE('Latin comparative — "than" নয়, "to"', ['শব্দ', 'উদাহরণ'], ('superior', 'He is superior **to** me.'), ('inferior', 'This cloth is inferior **to** that.'),
          ('senior / junior', 'She is senior **to** me.'), ('prior', 'prior **to** the meeting'), ('prefer', 'I prefer tea **to** coffee.')),
    TABLE('Degree পরিবর্তন (Transformation)', ['Degree', 'বাক্য'],
          ('Superlative', 'Rahim is the best boy in the class.'), ('Comparative', 'Rahim is better than any other boy in the class.'),
          ('Positive', 'No other boy in the class is as good as Rahim.'),
          ('Superlative (one of)', 'Dhaka is one of the biggest cities in Asia.'), ('Comparative', 'Dhaka is bigger than most other cities in Asia.'),
          ('Positive', 'Very few cities in Asia are as big as Dhaka.')),
    MNEM(('"Superlative → than any other + singular; Positive → No other … as … as"', 'Degree পরিবর্তন', 'any other-এর পরে singular noun; one of the-এর পরে plural।'),
         ('"farther = দূরত্ব (far-away), further = আরও (more)"', 'farther/further', 'further information, farther village।'),
         ('"elder শুধু পরিবারে, আর than বসে না"', 'elder/older', 'my elder brother; older than me।')),
    MISTAKES('"more better", "most best" ✗ — double comparison।', '"superior than" ✗ → superior **to**।', '"one of the best student" ✗ → one of the best **students**।', '"elder than" ✗ → **older** than।', '"than any boy" ✗ (নিজেকে ধরে ফেলে) → than any **other** boy।'),
    SUMMARY('Positive / Comparative / Superlative', 'Irregular: good-better-best, bad-worse-worst, little-less-least', 'superior/inferior/senior/junior/prior/prefer → to', 'Transformation: the best ↔ better than any other ↔ No other … as good as'),
    UNI(UNIT_EN),
], S)
QS(L + '2', [
    (2, 'He is ___ than his brother.', 'more intelligent', [('intelligenter', 'বড় শব্দে more।'), ('most intelligent', 'Superlative।'), ('more intelligenter', 'Double comparison।')],
     'তিন বা বেশি syllable → more/most।', 'বড় শব্দ = more।', 'সংজ্ঞা।', False),
    (2, 'This is the ___ book I have ever read.', 'best', [('better', 'Comparative।'), ('most best', 'Double superlative।'), ('goodest', 'অনিয়মিত রূপ: good-better-best।')],
     'good → better → best।', 'Irregular রূপ মুখস্থ।', 'Irregular সারণি।', False),
    (2, 'She is superior ___ me in mathematics.', 'to', [('than', 'Latin comparative-এর পরে "to"।'), ('from', 'ভুল।'), ('over', 'এখানে প্রচলিত নয়।')],
     'superior/inferior/senior/junior + to।', 'Latin comparative = to।', 'Latin সারণি।', True),
    (2, 'I prefer tea ___ coffee.', 'to', [('than', 'prefer-এর পরে "to"।'), ('over', 'কথ্যে চলে, তবে পরীক্ষার প্রচলিত উত্তর to।'), ('from', 'ভুল।')],
     'prefer A to B।', 'prefer … to।', 'Latin সারণি।', True),
    (2, 'My ___ brother lives in Chattogram.', 'elder', [('older', 'পরিবারের সদস্যের আগে elder প্রচলিত।'), ('eldest than', 'অশুদ্ধ।'), ('more old', 'অশুদ্ধ।')],
     'পরিবারে elder/eldest।', 'elder = পরিবারে; older = সাধারণ বয়স।', 'Irregular সারণি।', True),
    (2, 'He is ___ than me.', 'older', [('elder', '"elder" এর পরে than বসে না।'), ('more old', 'অশুদ্ধ।'), ('eldest', 'Superlative।')],
     'older than ✓; elder than ✗।', 'than থাকলে older।', 'Irregular সারণি।', True),
    (2, 'Do you need ___ information?', 'further', [('farther', 'farther শুধু দূরত্ব।'), ('farthest', 'Superlative দূরত্ব।'), ('more further', 'Double comparison।')],
     'further = আরও/অতিরিক্ত।', 'farther = দূরত্ব; further = আরও।', 'Irregular সারণি।', True),
    (2, 'Of the two plans, the ___ is better.', 'latter', [('later', 'later = সময়ে পরে।'), ('last', 'দুইয়ের বেশিতে।'), ('latest', 'সবচেয়ে নতুন।')],
     'দুটির মধ্যে দ্বিতীয়টি = the latter।', 'latter = ক্রমে; later = সময়ে।', 'Irregular সারণি।', True),
    (3, 'Comparative of "Rahim is the best boy in the class." —', 'Rahim is better than any other boy in the class.', [('Rahim is better than any boy in the class.', '"other" বাদ পড়লে Rahim নিজের চেয়েও ভালো হয়ে যায়।'), ('Rahim is better than all other boys in the class.', 'পরীক্ষার প্রচলিত রূপ "any other + singular"।'), ('No other boy is better than Rahim.', 'এটি positive-এর কাছাকাছি, আর "in the class" বাদ পড়েছে।')],
     'Superlative → than any other + singular noun।', 'any other ভুলবেন না।', 'Transformation সারণি।', True),
    (3, 'Positive of "Rahim is the best boy in the class." —', 'No other boy in the class is as good as Rahim.', [('No other boy in the class is as better as Rahim.', 'Positive-এ positive রূপ: good।'), ('Rahim is as good as any boy.', 'অর্থ বদলেছে।'), ('No other boys in the class is as good as Rahim.', 'No other + singular।')],
     'No other + singular + as + positive + as।', 'Positive = as … as।', 'Transformation সারণি।', True),
    (3, 'Positive of "Dhaka is one of the biggest cities in Asia." —', 'Very few cities in Asia are as big as Dhaka.', [('No other city in Asia is as big as Dhaka.', '"one of" মানে সবচেয়ে বড় নয় — very few লাগবে।'), ('Very few city in Asia is as big as Dhaka.', 'few-এর পরে plural।'), ('Dhaka is as big as very few cities.', 'অর্থ উল্টে গেছে।')],
     'one of the + superlative → Very few … as … as।', 'one of → very few।', 'Transformation সারণি।', True),
    (2, 'He is one of the ___ in the class.', 'best students', [('best student', 'one of the-এর পরে plural।'), ('better students', 'Superlative লাগবে।'), ('good students', 'Superlative লাগবে।')],
     'one of the + superlative + plural noun।', 'one of = অনেকের একজন → plural।', 'Common mistakes।', True),
    (2, 'The ___ you work, the more you earn.', 'harder', [('hard', 'the + comparative, the + comparative।'), ('hardest', 'Superlative নয়।'), ('more hard', 'hard-এর comparative harder।')],
     'The more … the more — দুই দিকেই comparative।', 'the + comparative … the + comparative।', 'বিশেষ কাঠামো।', True),
    (2, 'Which is a double comparison error?', 'more better', [('much better', 'much comparative-কে জোর দেয় — শুদ্ধ।'), ('far better', 'শুদ্ধ।'), ('even better', 'শুদ্ধ।')],
     'better নিজেই comparative — more লাগে না।', 'much/far/even comparative-কে জোর দেয়।', 'Common mistakes।', True),
    (2, 'This cloth is inferior ___ that.', 'to', [('than', 'Latin comparative-এর পরে to।'), ('from', 'ভুল।'), ('of', 'ভুল।')],
     'inferior to।', 'Latin comparative = to।', 'Latin সারণি।', False),
    (2, 'The superlative of "little" is —', 'least', [('littlest', 'পরিমাণ অর্থে প্রচলিত নয়।'), ('less', 'Comparative।'), ('lesser', 'ভিন্ন ব্যবহার।')],
     'little → less → least।', 'Irregular।', 'Irregular সারণি।', False),
    (2, 'The comparative of "bad" is —', 'worse', [('badder', 'অশুদ্ধ।'), ('worst', 'Superlative।'), ('more bad', 'অশুদ্ধ।')],
     'bad → worse → worst।', 'Irregular।', 'Irregular সারণি।', False),
    (2, 'Of the two sisters, Rina is the ___ .', 'taller', [('tallest', 'দুজনের মধ্যে তুলনায় comparative (the + comparative + of the two)।'), ('more tall', 'অশুদ্ধ।'), ('most tall', 'অশুদ্ধ।')],
     'of the two → the + comparative।', 'দুজন = comparative।', 'বিশেষ কাঠামো।', True),
    (2, 'Iron is ___ than any other metal.', 'more useful', [('most useful', 'than থাকলে comparative।'), ('usefuller', 'অশুদ্ধ।'), ('useful', 'Positive।')],
     'than → comparative।', 'বড় শব্দ = more।', 'সংজ্ঞা।', False),
    (2, 'Comparative of "No other river in Bangladesh is as long as the Padma." —', 'The Padma is longer than any other river in Bangladesh.', [('The Padma is the longest river.', 'এটি superlative।'), ('The Padma is longer than any river in Bangladesh.', '"other" বাদ।'), ('The Padma is as long as other rivers.', 'অর্থ বদলেছে।')],
     'Positive → Comparative: than any other।', 'উল্টো দিকেও একই সূত্র।', 'Transformation সারণি।', True),
])

# =====================================================================
# 3.3 Article
# =====================================================================
B.lesson(L + '3', [
    H('Article: a, an, the'),
    P('**a/an** = indefinite article (যেকোনো একটি); **the** = definite article (নির্দিষ্ট)। a নাকি an — নির্ভর করে পরের শব্দের **উচ্চারণের** (sound) ওপর, বানানের ওপর নয়।'),
    TABLE('a নাকি an', ['শব্দ', 'Article', 'কারণ'],
          ('hour, honest, heir', 'an', 'h উচ্চারিত হয় না → স্বরধ্বনি'), ('university, European, one-taka note', 'a', 'শুরু "ইউ/ওয়া" ধ্বনিতে (consonant sound)'),
          ('MA, MP, X-ray, SSC', 'an', 'এম, এক্স, এস — স্বরধ্বনি দিয়ে উচ্চারণ শুরু'), ('useful, unique, uniform', 'a', '"ইউ" ধ্বনি'), ('umbrella, uncle', 'an', '"আ" ধ্বনি')),
    TABLE('"the" বসে', ['ক্ষেত্র', 'উদাহরণ'],
          ('অদ্বিতীয় বস্তু', 'the sun, the moon, the sky'), ('Superlative ও ordinal', 'the best, the first'), ('নদী, সাগর, মহাসাগর, পর্বতমালা, দ্বীপপুঞ্জ', 'the Padma, the Bay of Bengal, the Himalayas'),
          ('ধর্মগ্রন্থ, সংবাদপত্র', 'the Quran, the Daily Star'), ('the + adjective = শ্রেণি', 'the rich, the poor'), ('বাদ্যযন্ত্র', 'play the guitar'),
          ('আগে উল্লেখিত noun', 'I saw a dog. The dog was black.'), ('the + comparative … the + comparative', 'The more, the merrier.')),
    TABLE('Article বসে না', ['ক্ষেত্র', 'উদাহরণ'],
          ('খাবারের বেলা (meal)', 'have breakfast/lunch'), ('খেলা', 'play football'), ('ভাষা', 'speak English'), ('সাধারণ অর্থে abstract noun', 'Honesty is the best policy.'),
          ('একক পর্বতশৃঙ্গ, দেশ (সাধারণত), শহর', 'Mount Everest, Bangladesh, Dhaka'), ('উদ্দেশ্য অর্থে school/hospital/bed', 'go to school (পড়তে) — the school (ভবনে)')),
    MNEM(('"কানে শুনুন, চোখে নয়"', 'a/an', 'an hour (আওয়ার), a university (ইউনিভার্সিটি)।'),
         ('"পানি বয় বা ছড়িয়ে থাকে → the" (নদী, সাগর, পর্বতমালা)', 'the + ভৌগোলিক নাম', 'একা পাহাড় (Everest) ও শহরে নয়।')),
    MISTAKES('"a honest man" ✗ → an honest man।', '"an university" ✗ → a university।', '"play the football" ✗ → play football।', '"the Mount Everest" ✗ → Mount Everest।'),
    SUMMARY('a/an: উচ্চারণ দেখে', 'the: অদ্বিতীয়, superlative, নদী-সাগর-পর্বতমালা, ধর্মগ্রন্থ, বাদ্যযন্ত্র, the + adjective', 'না: meal, game, language, সাধারণ abstract noun'),
    UNI(UNIT_EN),
], S)
AR = [('He is ___ honest man.', 'an', ['a', 'the', 'no article'], 'h নীরব → স্বরধ্বনি → an।', True),
      ('She studies at ___ university.', 'a', ['an', 'the', 'no article'], '"ইউ" ধ্বনি consonant → a।', True),
      ('I waited for ___ hour.', 'an', ['a', 'the', 'no article'], 'hour-এর h নীরব।', True),
      ('He is ___ MA in English.', 'an', ['a', 'the', 'no article'], '"এম" স্বরধ্বনি দিয়ে শুরু।', True),
      ('Give me ___ one-taka coin.', 'a', ['an', 'the', 'no article'], '"ওয়ান" — "w" ধ্বনি।', True),
      ('___ sun rises in the east.', 'The', ['A', 'An', 'No article'], 'অদ্বিতীয় বস্তু।', False),
      ('___ Padma is a big river.', 'The', ['A', 'An', 'No article'], 'নদীর নামের আগে the।', False),
      ('___ Mount Everest is the highest peak.', 'No article', ['The', 'A', 'An'], 'একক পর্বতশৃঙ্গের আগে the বসে না।', True),
      ('We should help ___ poor.', 'the', ['a', 'an', 'no article'], 'the + adjective = শ্রেণি।', False),
      ('He plays ___ guitar well.', 'the', ['a', 'an', 'no article'], 'বাদ্যযন্ত্রের আগে the।', True),
      ('They play ___ football every day.', 'no article', ['the', 'a', 'an'], 'খেলার আগে article নেই।', True),
      ('We have ___ breakfast at 8.', 'no article', ['the', 'a', 'an'], 'Meal-এর আগে সাধারণত article নেই।', True),
      ('___ honesty is the best policy.', 'No article', ['The', 'An', 'A'], 'সাধারণ অর্থে abstract noun।', True),
      ('This is ___ best book in the library.', 'the', ['a', 'an', 'no article'], 'Superlative-এর আগে the।', False),
      ('He went to ___ school to meet the headmaster.', 'the', ['a', 'an', 'no article'], 'পড়তে নয়, ভবনে গেছে → the school।', True),
      ('He goes to ___ school every day (as a student).', 'no article', ['the', 'a', 'an'], 'উদ্দেশ্য (পড়া) → article নেই।', True),
      ('___ Himalayas are in Asia.', 'The', ['A', 'An', 'No article'], 'পর্বতমালার আগে the।', False),
      ('It was ___ unique experience.', 'a', ['an', 'the', 'no article'], '"ইউনিক" — "ইউ" ধ্বনি।', True),
      ('She speaks ___ English fluently.', 'no article', ['the', 'an', 'a'], 'ভাষার নামের আগে article নেই।', False),
      ('I read ___ Daily Star every morning.', 'the', ['a', 'an', 'no article'], 'সংবাদপত্রের নামের আগে the।', False),
      ('He took ___ X-ray of my hand.', 'an', ['a', 'the', 'no article'], '"এক্স" স্বরধ্বনি।', True)]
for s, a, wr, r, trap in AR:
    Q(L + '3', 2, s, a, [(x, 'নিয়ম মেলে না।') for x in wr], r, 'a/an: উচ্চারণ দেখুন; the: নির্দিষ্ট/অদ্বিতীয়/ভৌগোলিক নাম।', 'Article সারণি।', trap=trap)

# =====================================================================
# 3.4 Same Word Different Parts of Speech
# =====================================================================
SW = [('He runs fast.', 'fast', 'Adverb'), ('He has a fast car.', 'fast', 'Adjective'), ('Muslims fast in Ramadan.', 'fast', 'Verb'), ('He broke his fast at sunset.', 'fast', 'Noun'),
      ('He came after me.', 'after', 'Preposition'), ('He came after I had left.', 'after', 'Conjunction'), ('He came soon after.', 'after', 'Adverb'),
      ('The light is on.', 'light', 'Noun'), ('This bag is light.', 'light', 'Adjective'), ('Light the lamp.', 'light', 'Verb'),
      ('She sings well.', 'well', 'Adverb'), ('I am not well today.', 'well', 'Adjective'), ('They dug a well.', 'well', 'Noun'),
      ('I have not seen him since Monday.', 'since', 'Preposition'), ('Since you are ill, rest.', 'since', 'Conjunction'),
      ('All but him came.', 'but', 'Preposition'), ('He is poor but honest.', 'but', 'Conjunction'),
      ('He is still waiting.', 'still', 'Adverb'), ('Keep still.', 'still', 'Adjective'), ('He walked round the field.', 'round', 'Preposition'), ('They sat at a round table.', 'round', 'Adjective')]
POS = ['Noun', 'Verb', 'Adjective', 'Adverb', 'Preposition', 'Conjunction']
B.lesson(L + '4', [
    H('একই শব্দ, ভিন্ন Parts of Speech'),
    P('শব্দের **parts of speech** ঠিক হয় বাক্যে তার **কাজ** দেখে, শব্দ দেখে নয়। জিজ্ঞাসা করুন: নাম বোঝাচ্ছে (noun)? কাজ (verb)? noun-কে বিশেষিত করছে (adjective)? verb-কে (adverb)? noun/pronoun-এর আগে বসে সম্পর্ক দেখাচ্ছে (preposition)? দুটি clause জুড়ছে (conjunction)?'),
    TABLE('উদাহরণ (কলাম-লুকাও)', ['বাক্য', 'শব্দ', 'Parts of speech'], *SW),
    TABLE('দ্রুত চেনার সূত্র', ['কাজ', 'Parts of speech'], ('a/an/the বা adjective-এর পরে বসে', 'Noun'), ('subject-এর পরে কাজ বোঝায়', 'Verb'),
          ('noun-এর আগে বা be-এর পরে গুণ বোঝায়', 'Adjective'), ('কাজ কীভাবে/কখন/কোথায়', 'Adverb'), ('পরে noun/pronoun (object) থাকে', 'Preposition'), ('পরে পুরো clause (subject + verb) থাকে', 'Conjunction')),
    MNEM(('"পরে কী আছে দেখুন: noun → preposition, clause → conjunction, কিছুই না → adverb"', 'after/before/since', 'after me / after I left / soon after।'),),
    MISTAKES('"He runs fast" — fast এখানে adverb (fastly বলে শব্দ নেই)।', '"I am well" — well এখানে adjective (সুস্থ)।'),
    SUMMARY('Parts of speech ঠিক হয় বাক্যে কাজ দেখে', 'after/before/since: পরে noun → preposition; clause → conjunction; কিছু না → adverb'),
    UNI(UNIT_EN),
], S)
for i, (s, w, k) in enumerate(SW):
    pool = [x for x in POS if x != k]; random.Random(6100 + i).shuffle(pool)
    Q(L + '4', 2, f'In "{s}", "{w}" is a/an —', k, [(x, 'বাক্যে শব্দটির কাজ মেলে না।') for x in pool[:3]], f'"{w}" এখানে {k}।', 'বাক্যে শব্দটির কাজ দেখুন, পরে কী আছে দেখুন।', 'দ্রুত চেনার সূত্র।',
      trap=k in ('Adjective', 'Preposition') and w in ('well', 'but', 'still', 'fast'))

# =====================================================================
# 3.5 – 3.9 : G–I
# =====================================================================
RNG = 'G–I'
prep_lesson(B, L + '5', RNG, [
    ('good (skill)', 'at', 'She is good ___ mathematics.', 'দক্ষ', ()), ('grateful (person)', 'to', 'I am grateful ___ you for your help.', '(কারও প্রতি) কৃতজ্ঞ', ()),
    ('grateful (thing)', 'for', 'I am grateful to you ___ your help.', '(কোনো কিছুর জন্য) কৃতজ্ঞ', ()), ('guilty', 'of', 'He was found guilty ___ murder.', 'দোষী', ()),
    ('hanker', 'after', 'Don\'t hanker ___ wealth.', 'লালায়িত হওয়া', ()), ('habituated', 'to', 'He is habituated ___ smoking.', 'অভ্যস্ত', ()),
    ('harmful', 'to', 'Smoking is harmful ___ health.', 'ক্ষতিকর', ()), ('heir', 'to', 'He is the heir ___ the throne.', 'উত্তরাধিকারী', ()),
    ('hint', 'at', 'He hinted ___ my mistake.', 'ইঙ্গিত করা', ()), ('hope', 'for', 'We hope ___ the best.', 'আশা করা', ()),
    ('hostile', 'to', 'They were hostile ___ the plan.', 'বিরূপ', ()), ('ignorant', 'of', 'He is ignorant ___ the rules.', 'অজ্ঞ', ()),
    ('ill', 'with', 'She is ill ___ fever.', '(রোগে) অসুস্থ', ()), ('impose', 'on', 'Don\'t impose your views ___ others.', 'চাপিয়ে দেওয়া', ('upon',)),
    ('independent', 'of', 'He is independent ___ his parents.', 'স্বাধীন, অনির্ভর', ()), ('indifferent', 'to', 'He is indifferent ___ his studies.', 'উদাসীন', ()),
    ('indulge', 'in', 'Don\'t indulge ___ bad habits.', 'প্রশ্রয় দেওয়া/মেতে থাকা', ()), ('infected', 'with', 'He is infected ___ the virus.', 'সংক্রমিত', ()),
    ('inferior', 'to', 'This pen is inferior ___ that one.', 'নিকৃষ্ট', ()), ('insist', 'on', 'He insisted ___ going.', 'জোর দেওয়া', ('upon',)),
    ('interested', 'in', 'She is interested ___ music.', 'আগ্রহী', ()), ('interfere (affairs)', 'in', 'Don\'t interfere ___ my affairs.', '(কারও ব্যাপারে) নাক গলানো', ()),
    ('interfere (thing)', 'with', 'Noise interferes ___ my work.', '(কোনো কাজে) ব্যাঘাত ঘটানো', ()), ('invest', 'in', 'He invested ___ shares.', 'বিনিয়োগ করা', ()),
    ('involved', 'in', 'He was involved ___ the crime.', 'জড়িত', ()), ('hide', 'from', 'He hid the truth ___ me.', 'লুকানো', ())],
    6200,
    contrast=(('grateful to + ব্যক্তি, for + বিষয়', 'I am grateful to you for your help.'), ('good at', 'দক্ষ: good at English'), ('good for', 'উপকারী: Milk is good for health.'),
              ('interfere in + বিষয়/কারও ব্যাপার', 'Don\'t interfere in my affairs.'), ('interfere with + কাজ/বস্তু', 'Noise interferes with my sleep.')),
    mnem=(('"to-দল: grateful(ব্যক্তি), habituated, harmful, heir, hostile, indifferent, inferior"', '"to" লাগে', 'সবাই কারও/কিছুর "দিকে" নির্দেশ করে।'),),
    mistakes=('"guilty for" ✗ → guilty **of**।', '"ill from fever" ✗ → ill **with** fever।', '"interested about" ✗ → interested **in**।'))

idiom_lesson(B, L + '6', RNG, [
    ('give the devil his due', 'শত্রুরও প্রাপ্য স্বীকৃতি দেওয়া', 'to be fair even to a disliked person', 'অপছন্দের মানুষের ভালো দিকটাও স্বীকার করা — ন্যায়বিচারের কথা।', 'He is rude, but give the devil his due — he works hard.'),
    ('go to the dogs', 'অধঃপাতে যাওয়া', 'to deteriorate; be ruined', 'পুরোনো ধারণা: যা কোনো কাজে লাগে না তা কুকুরকে ফেলে দেওয়া হয়।', 'Without care, the business went to the dogs.'),
    ('Greek to me', 'সম্পূর্ণ দুর্বোধ্য', 'completely incomprehensible', 'Shakespeare-এর Julius Caesar-এ Casca বলে: "it was Greek to me"।', 'The lecture on quantum physics was Greek to me.'),
    ('the gift of the gab', 'বাকপটুতা', 'the ability to speak easily and persuasively', 'gab = গল্প/কথা বলা; কথার "উপহার" পাওয়া।', 'A salesman needs the gift of the gab.'),
    ('the golden mean', 'মধ্যপন্থা', 'the middle way between extremes', 'দুই চরমের মাঝামাঝি পথ — গ্রিক দার্শনিক Aristotle-এর মধ্যপন্থার ধারণার সঙ্গে যুক্ত।', 'Follow the golden mean in eating.'),
    ('hand in glove', 'অত্যন্ত ঘনিষ্ঠ (প্রায়ই অসৎ কাজে)', 'in close cooperation, often secretly', 'হাত আর দস্তানা যেমন একেবারে লেগে থাকে।', 'The officer was hand in glove with the smugglers.'),
    ('a hard nut to crack', 'কঠিন সমস্যা/মানুষ', 'a difficult problem or person', 'শক্ত খোসার বাদাম ভাঙা কঠিন।', 'The new manager is a hard nut to crack.'),
    ('hold water', 'যুক্তিগ্রাহ্য হওয়া', 'to be logical or valid', 'ছিদ্রহীন পাত্রই পানি ধরে রাখে — যুক্তিতে ফাঁক নেই।', 'His argument does not hold water.'),
    ('hush money', 'মুখ বন্ধ রাখার ঘুষ', 'a bribe paid to keep something secret', 'hush = চুপ করানো।', 'He was paid hush money.'),
    ('a herculean task', 'দুঃসাধ্য কাজ', 'a task needing enormous effort', 'গ্রিক পুরাণের বীর Hercules-এর বারোটি দুঃসাধ্য কাজ থেকে।', 'Cleaning the river is a herculean task.'),
    ('hue and cry', 'হইচই, প্রতিবাদের শোরগোল', 'a loud public outcry', 'পুরোনো ইংরেজ আইনে অপরাধী ধরতে চিৎকার করে তাড়া করার রীতি থেকে।', 'There was a hue and cry over the price hike.'),
    ('in a nutshell', 'সংক্ষেপে', 'in very few words', 'এত ছোট যে বাদামের খোসায় ধরে যায়।', 'In a nutshell, we lost the match.'),
    ('in black and white', 'লিখিতভাবে', 'in writing', 'সাদা কাগজে কালো কালি।', 'Please give me the promise in black and white.'),
    ('in cold blood', 'ঠান্ডা মাথায় (নিষ্ঠুরভাবে)', 'deliberately and without emotion', 'রাগে "রক্ত গরম" নয়, ঠান্ডা মাথায় পরিকল্পিত।', 'He was killed in cold blood.'),
    ('ins and outs', 'খুঁটিনাটি', 'all the details', 'ভেতর-বাইরের সবকিছু।', 'He knows the ins and outs of the business.'),
    ('in the long run', 'শেষ পর্যন্ত, দীর্ঘমেয়াদে', 'eventually; over a long period', 'দীর্ঘ দৌড়ের শেষে ফল।', 'Honesty pays in the long run.'),
    ('in vain', 'বৃথা', 'without success', 'vain = শূন্য, নিষ্ফল।', 'All our efforts were in vain.'),
    ('ill-gotten gains', 'অসৎ উপায়ে অর্জিত সম্পদ', 'money obtained dishonestly', 'ill = মন্দভাবে; gotten = পাওয়া।', 'Ill-gotten gains never prosper.'),
    ('hit the nail on the head', 'ঠিক কথাটি বলা', 'to say exactly the right thing', 'পেরেকের মাথায় ঠিকঠাক আঘাত।', 'You hit the nail on the head.'),
    ('high and dry', 'অসহায় অবস্থায় ফেলে যাওয়া', 'stranded without help', 'ভাটায় জাহাজ ডাঙায় আটকে পড়ার ছবি।', 'His partners left him high and dry.'),
    ('have an axe to grind', 'স্বার্থসিদ্ধির মতলব থাকা', 'to have a selfish motive', 'প্রচলিত গল্প: কেউ মিষ্টি কথায় ভুলিয়ে নিজের কুড়াল শান দিয়ে নেয়।', 'He praises the boss because he has an axe to grind.'),
    ('get into hot water', 'বিপদে পড়া', 'to get into trouble', 'গরম পানিতে পড়ার অস্বস্তি।', 'He got into hot water for lying.'),
    ('heart and soul', 'মনপ্রাণ দিয়ে', 'with complete dedication', 'হৃদয় ও আত্মা — সম্পূর্ণ সত্তা।', 'She worked heart and soul for the project.')],
    6300, traps=('give the devil his due', 'hold water', 'hand in glove', 'in cold blood'),
    mnem=(('"Greek (Shakespeare), herculean (Hercules), golden mean (Aristotle)"', 'উৎস দিয়ে মনে রাখা', 'গল্প মনে পড়লে অর্থও মনে পড়বে।'),),
    mistakes=('**hold water** = যুক্তিগ্রাহ্য — পানি ধরার আক্ষরিক অর্থ নয়।', '**in cold blood** = ঠান্ডা মাথায় নিষ্ঠুরতা — শীতকাল নয়।'))

vocab_lesson(B, L + '7', RNG, [
    ('garrulous', 'adj', 'বাচাল', 'excessively talkative', ['talkative', 'loquacious', 'chatty'], ['taciturn', 'reticent'], 'talk'),
    ('genuine', 'adj', 'খাঁটি, আসল', 'truly what it is said to be', ['authentic', 'real', 'bona fide'], ['fake', 'counterfeit'], 'real'),
    ('gloomy', 'adj', 'বিষণ্ন, অন্ধকারাচ্ছন্ন', 'dark or sad', ['dismal', 'melancholy', 'sombre'], ['cheerful', 'bright'], 'sad'),
    ('gratify', 'v', 'সন্তুষ্ট করা', 'to give pleasure or satisfaction', ['please', 'satisfy'], ['displease', 'disappoint'], 'please'),
    ('gregarious', 'adj', 'মিশুক', 'fond of company', ['sociable', 'outgoing'], ['unsociable', 'introverted'], 'social'),
    ('gullible', 'adj', 'সহজে প্রতারিত হয় এমন', 'easily deceived', ['credulous', 'naive'], ['sceptical', 'suspicious'], 'trust'),
    ('hamper', 'v', 'বাধা দেওয়া', 'to hinder progress', ['hinder', 'impede', 'obstruct'], ['facilitate', 'help'], 'hinder'),
    ('haughty', 'adj', 'উদ্ধত, অহংকারী', 'arrogantly superior', ['arrogant', 'proud', 'conceited'], ['humble', 'modest'], 'pride'),
    ('hazardous', 'adj', 'বিপজ্জনক', 'risky; dangerous', ['dangerous', 'risky', 'perilous'], ['safe', 'secure'], 'danger'),
    ('heinous', 'adj', 'জঘন্য', 'utterly wicked', ['atrocious', 'monstrous', 'abominable'], ['admirable', 'praiseworthy'], 'evil'),
    ('hostile', 'adj', 'শত্রুভাবাপন্ন', 'unfriendly; antagonistic', ['unfriendly', 'antagonistic', 'aggressive'], ['friendly', 'amicable'], 'enemy'),
    ('hypocrisy', 'n', 'ভণ্ডামি', 'pretending to have virtues one lacks', ['pretence', 'insincerity', 'duplicity'], ['sincerity', 'honesty'], 'fake'),
    ('idle', 'adj', 'অলস; কর্মহীন', 'avoiding work; inactive', ['lazy', 'inactive', 'indolent'], ['busy', 'industrious'], 'lazy'),
    ('illicit', 'adj', 'অবৈধ', 'forbidden by law', ['illegal', 'unlawful', 'illegitimate'], ['legal', 'lawful'], 'law'),
    ('immense', 'adj', 'বিশাল', 'extremely large', ['vast', 'huge', 'enormous'], ['tiny', 'minute'], 'big'),
    ('imminent', 'adj', 'আসন্ন', 'about to happen', ['impending', 'approaching', 'forthcoming'], ['distant', 'remote'], 'soon'),
    ('impartial', 'adj', 'নিরপেক্ষ', 'treating all equally', ['unbiased', 'neutral', 'fair'], ['biased', 'partial'], 'fair'),
    ('impetuous', 'adj', 'হঠকারী', 'acting quickly without thought', ['rash', 'impulsive', 'hasty'], ['cautious', 'careful'], 'rash'),
    ('incessant', 'adj', 'অবিরাম', 'continuing without pause', ['ceaseless', 'continuous', 'constant'], ['intermittent', 'occasional'], 'always'),
    ('indigenous', 'adj', 'দেশজ, আদিবাসী', 'originating in a particular place', ['native', 'aboriginal', 'local'], ['foreign', 'alien'], 'native'),
    ('infamous', 'adj', 'কুখ্যাত', 'well known for something bad', ['notorious', 'disreputable'], ['reputable', 'honourable'], 'fame'),
    ('inevitable', 'adj', 'অনিবার্য', 'certain to happen', ['unavoidable', 'certain', 'inescapable'], ['avoidable', 'uncertain'], 'sure'),
    ('insipid', 'adj', 'স্বাদহীন; নীরস', 'lacking flavour or interest', ['tasteless', 'bland', 'dull'], ['tasty', 'interesting'], 'dull'),
    ('integrity', 'n', 'সততা', 'the quality of being honest and moral', ['honesty', 'uprightness', 'probity'], ['dishonesty', 'corruption'], 'honest'),
    ('intrepid', 'adj', 'নির্ভীক', 'fearless; adventurous', ['fearless', 'dauntless', 'valiant'], ['timid', 'cowardly'], 'brave')],
    6400,
    roots={'gregarious': 'Latin grex (পাল/দল) — দলে থাকতে ভালোবাসে; congregate একই মূল।', 'garrulous': 'Latin garrire (বকবক করা)।',
           'impartial': 'im (না) + partial (পক্ষপাতদুষ্ট) — পক্ষপাত নেই।', 'incessant': 'in (না) + cessare (থামা) — cease একই মূল।',
           'intrepid': 'in (না) + trepidus (ভীত) — trepidation একই মূল।', 'inevitable': 'in (না) + evitare (এড়ানো) — এড়ানো যায় না।',
           'infamous': 'সাবধান: in + famous = "বিখ্যাত নয়" নয় — খারাপ কারণে বিখ্যাত (কুখ্যাত)।', 'hypocrisy': 'Greek hypokrisis (অভিনয়) — মুখোশ পরে থাকা।',
           'indigenous': 'Latin indigena (স্থানীয়, দেশজ)।'},
    traps=('infamous', 'imminent', 'impartial', 'gullible', 'insipid'),
    mnem=(('"in/im = না" (impartial, incessant, inevitable, intrepid) — কিন্তু infamous ব্যতিক্রম!', 'উপসর্গ', 'infamous = কুখ্যাত, "অখ্যাত" নয়।'),),
    mistakes=('**infamous** ≠ "not famous" — অর্থ কুখ্যাত।', '**imminent** (আসন্ন) ≠ **eminent** (বিশিষ্ট)।', '**gullible** = সহজে বোকা বনে — gull (গাংচিল) নয়।'))

spelling_lesson(B, L + '8', RNG, [
    ('government', 'সরকার', 'govern + ment (n ভুলবেন না)', ['goverment', 'govenment', 'governmant']),
    ('grammar', 'ব্যাকরণ', 'শেষে -ar, m দুটি', ['grammer', 'gramar', 'grammor']),
    ('guarantee', 'নিশ্চয়তা', 'gu-a; শেষে ee', ['gaurantee', 'guarentee', 'garantee']),
    ('guard', 'পাহারাদার', 'gu-a-rd', ['gaurd', 'gard', 'guarde']),
    ('guidance', 'নির্দেশনা', 'guide → guid + ance', ['guidence', 'gaidance', 'guidanse']),
    ('harass', 'হয়রানি করা', 'r একটি, s দুটি', ['harrass', 'harras', 'harrasse']),
    ('height', 'উচ্চতা', 'ei; শেষে -ght (h শেষে নয়)', ['hieght', 'heighth', 'hight']),
    ('hierarchy', 'স্তরবিন্যাস', 'hi-er-archy', ['heirarchy', 'hierarcy', 'hirearchy']),
    ('humorous', 'রসাত্মক', 'humour-এর u বাদ পড়ে: humorous', ['humourous', 'humerous', 'humorus']),
    ('hygiene', 'স্বাস্থ্যবিধি', 'hy-gi-ene (ie)', ['hygeine', 'hygene', 'higiene']),
    ('hypocrisy', 'ভণ্ডামি', 'hypo-crisy (s)', ['hypocricy', 'hipocrisy', 'hypocrasy']),
    ('ignorance', 'অজ্ঞতা', '-ance', ['ignorence', 'ignorants', 'ignorrance']),
    ('immediately', 'অবিলম্বে', 'mm; immediate + ly', ['immediatly', 'imediately', 'immediatley']),
    ('independent', 'স্বাধীন', '-ent (দুবার e)', ['independant', 'indipendent', 'independint']),
    ('indispensable', 'অপরিহার্য', '-able', ['indispensible', 'indespensable', 'indispensabel']),
    ('inoculate', 'টিকা দেওয়া', 'n একটি, c একটি', ['innoculate', 'inocculate', 'innocculate']),
    ('intelligence', 'বুদ্ধিমত্তা', 'll; -ence', ['inteligence', 'intelligance', 'intellegence']),
    ('interrupt', 'বাধা দেওয়া', 'rr', ['interupt', 'interrrupt', 'intterupt']),
    ('irrelevant', 'অপ্রাসঙ্গিক', 'rr; -ant', ['irrelevent', 'irelevant', 'irrelavant']),
    ('irresistible', 'অপ্রতিরোধ্য', 'rr; -ible', ['irresistable', 'iresistible', 'irrisistible'])],
    traps=('humorous', 'height', 'harass', 'indispensable', 'inoculate'),
    mnem=(('"harass — একজন Rider, দুইজন Soldier" (r এক, s দুই)', 'harass', 'embarrass-এর উল্টো: সেখানে rr, ss।'),
          ('"humour → humorous: ফরাসি u-টি বাদ"', 'humorous', 'British humour, কিন্তু humorous সবার জন্য।')),
    mistakes=('"heighth" ✗ → **height**।', '"independant" ✗ → **independent**।', '"irresistable" ✗ → **irresistible**।'))

gv_lesson(B, L + '9', RNG, [
    ('get along (with)', 'মিলেমিশে চলা', 'have a good relationship'), ('get over', 'কাটিয়ে ওঠা/সেরে ওঠা', 'recover from'),
    ('get rid of', 'মুক্তি পাওয়া', 'free oneself from'), ('get through', 'পাস করা; শেষ করা', 'pass (an exam); finish'),
    ('give in', 'হার মানা', 'surrender; yield'), ('give up', 'ত্যাগ করা', 'stop doing; abandon'),
    ('give away', 'বিলিয়ে দেওয়া; ফাঁস করা', 'give free; reveal'), ('give off', 'নির্গত করা (গন্ধ, ধোঁয়া)', 'emit'),
    ('go on', 'চালিয়ে যাওয়া', 'continue'), ('go off', 'বিস্ফোরিত হওয়া; বেজে ওঠা', 'explode; ring (alarm)'),
    ('go through', 'খুঁটিয়ে দেখা; ভোগ করা', 'examine; experience'), ('go over', 'পর্যালোচনা করা', 'review'),
    ('hand over', 'হস্তান্তর করা', 'transfer'), ('hand in', 'জমা দেওয়া', 'submit'),
    ('hold on', 'অপেক্ষা করা', 'wait'), ('hold up', 'বিলম্ব ঘটানো; ডাকাতি করা', 'delay; rob'),
    ('hit upon', 'হঠাৎ মাথায় আসা', 'discover by chance'), ('hold back', 'সংযত রাখা; আটকে রাখা', 'restrain')],
    [('He finally ___ smoking.', 'gave up', ['gave in', 'gave off', 'gave away'], 'ধূমপান ছেড়ে দেওয়া'),
     ('The enemy refused to ___.', 'give in', ['give off', 'give away', 'go over'], 'হার মানা'),
     ('Rotten eggs ___ a bad smell.', 'give off', ['give in', 'give up', 'go over'], 'গন্ধ নির্গত'),
     ('A bomb ___ near the station.', 'went off', ['went on', 'went over', 'went through'], 'বিস্ফোরণ'),
     ('Please ___ your assignments by Friday.', 'hand in', ['hand over', 'hold on', 'hold up'], 'জমা দেওয়া'),
     ('It took him weeks to ___ the shock.', 'get over', ['get along', 'get rid of', 'get through'], 'কাটিয়ে ওঠা'),
     ('Traffic ___ us for an hour.', 'held up', ['held on', 'held back', 'handed in'], 'বিলম্ব'),
     ('She ___ a brilliant idea.', 'hit upon', ['held on', 'got over', 'gave off'], 'হঠাৎ মাথায় আসা')],
    6500, traps=('give in', 'give up', 'go off', 'hand in', 'hand over'),
    mnem=(('"GIVE পরিবার: up-ছাড়া, in-হার মানা, off-নির্গত, away-বিলানো/ফাঁস"', 'give', 'একসাথে পড়ুন।'), ('"HAND: in-জমা (শিক্ষককে), over-হস্তান্তর (দায়িত্ব)"', 'hand', 'ছোট জিনিস জমা বনাম ক্ষমতা হস্তান্তর।')),
    mistakes=('**give in** = হার মানা; **give up** = ছেড়ে দেওয়া।', '**go off** = বিস্ফোরিত/বেজে ওঠা; **go on** = চালিয়ে যাওয়া।'))

B.autofill_cards(12)
B.save('b3', 'en-b3')
