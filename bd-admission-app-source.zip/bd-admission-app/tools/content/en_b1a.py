#!/usr/bin/env python3
"""English — Block 1 (grammar): Noun & Determiner, Number, Gender, Embedded Question
ব্যাখ্যা বাংলায়, পরিভাষা (noun, verb, subject…) ইংরেজিতে। সূত্র: প্রচলিত English grammar (Wren & Martin; Cambridge/Oxford learner grammar)।
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from common import *

B = Bank('enb1a', 'en', 9101)
Q = B.q
def QS(lid, rows):
    for d, q, a, w, r, t, f, trap in rows:
        Q(lid, d, q, a, w, r, t, f, trap=trap)
def rand_q(lid, pairs, stem_fmt, tip, fact, seed, trap_keys=(), why='এটি অন্য একটির উত্তর।'):
    for i, (k, v) in enumerate(pairs):
        pool = list(dict.fromkeys(x[1] for j, x in enumerate(pairs) if j != i and x[1] != v))
        random.Random(seed + i).shuffle(pool)
        Q(lid, 2, stem_fmt.format(k), v, [(w, why) for w in pool[:3]], f'{k} → {v}।', tip, fact, trap=k in trap_keys)
UNIT = ('ঢাবি, গুচ্ছ, জাবি, রাবি ও চবির English অংশে Noun/Number/Gender ও Embedded Question থেকে সরাসরি বা Sentence Correction আকারে প্রশ্ন আসার প্রবণতা আছে — '
        'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না।')
S = ['প্রচলিত English grammar (Wren & Martin; Cambridge/Oxford learner grammar)']
L = 'en-1-'

# =====================================================================
# 1.1 Noun & Determiner
# =====================================================================
NT = [('Honesty', 'Abstract noun'), ('Gold', 'Material noun'), ('Team', 'Collective noun'), ('Dhaka', 'Proper noun'), ('River', 'Common noun'),
      ('Childhood', 'Abstract noun'), ('Cotton', 'Material noun'), ('Jury', 'Collective noun'), ('Padma', 'Proper noun'), ('Teacher', 'Common noun')]
COLL = [('cattle', 'herd'), ('bees', 'swarm'), ('wolves', 'pack'), ('ships', 'fleet'), ('fish', 'shoal'), ('flowers', 'bouquet'), ('grapes', 'bunch'), ('soldiers', 'army'), ('sheep', 'flock')]
ABS = [('brave', 'bravery'), ('wise', 'wisdom'), ('child', 'childhood'), ('young', 'youth'), ('free', 'freedom'), ('high', 'height'), ('deep', 'depth'), ('long', 'length'), ('true', 'truth')]
B.lesson(L + '1', [
    H('Noun ও তার প্রকারভেদ'),
    P('যে শব্দ দিয়ে কোনো ব্যক্তি, স্থান, বস্তু, গুণ বা ধারণার নাম বোঝায় তাকে **noun** বলে। প্রচলিত পাঁচ প্রকার: **Proper** (নির্দিষ্ট নাম), **Common** (একই জাতের যেকোনো সদস্য), **Collective** (একদল জিনিসকে এক একক হিসেবে), **Material** (উপাদান/পদার্থ), **Abstract** (গুণ, অবস্থা, কাজ বা ধারণা — যা ছোঁয়া যায় না)।'),
    TABLE('Noun-এর প্রকার (কলাম-লুকাও দিয়ে অনুশীলন)', ['Word', 'Kind'], *NT),
    TABLE('Countable বনাম Uncountable', ['Countable (a/an বসে, plural হয়)', 'Uncountable (a/an বসে না, plural হয় না)'],
          ('a chair, two chairs', 'furniture'), ('a suggestion', 'advice'), ('a bag, bags', 'luggage / baggage'), ('a fact', 'information'), ('a job', 'work'), ('a poem', 'poetry')),
    P('Uncountable noun গুনতে হলে **a piece of / an item of / some** ব্যবহার করুন: a piece of advice, an item of news, some information।'),
    H('Determiner'),
    P('**Determiner** noun-এর আগে বসে noun-কে নির্দিষ্ট বা সীমিত করে: article (a, an, the), demonstrative (this, that, these, those), possessive (my, your, his…), quantifier (some, any, much, many, few, little, each, every, either, neither, several, all) এবং সংখ্যা।'),
    TABLE('Quantifier-এর নিয়ম', ['Determiner', 'কার সাথে বসে', 'উদাহরণ'],
          ('much / little / a little', 'uncountable noun', 'much water, a little milk'), ('many / few / a few / several', 'plural countable noun', 'many books, a few friends'),
          ('each / every', 'singular countable noun', 'every student, each boy'), ('either / neither', 'দুটির মধ্যে একটি (singular)', 'either road, neither answer'),
          ('few বনাম a few', 'few = প্রায় নেই (নেতিবাচক); a few = কয়েকটি আছে (ইতিবাচক)', 'Few came. / A few came.'),
          ('little বনাম a little', 'uncountable-এ একই যুক্তি', 'Little hope. / A little hope.')),
    TABLE('Collective noun', ['যাদের দল', 'Collective noun'], *COLL),
    MNEM(('"a থাকলে আশা আছে" — a few / a little = ইতিবাচক; few / little = প্রায় নেই', 'few / a few, little / a little', 'article "a" অর্থে ইতিবাচকতা যোগ করে।'),
         ('"I-A-L-F-N" — Information, Advice, Luggage, Furniture, News', 'বহুল-প্রচলিত uncountable', 'এদের কারও আগে a/an বা শেষে -s বসে না।')),
    MISTAKES('"advices, informations, furnitures, luggages" — সবসময় ভুল।', '"Every students" ✗ → "every student"।', '"The poor is" ✗ → "The poor are" (the + adjective = একটি শ্রেণির মানুষ, plural)।'),
    SUMMARY('Noun ৫ প্রকার: proper, common, collective, material, abstract', 'Uncountable noun: a/an নেই, plural নেই', 'much/little + uncountable; many/few + plural countable; each/every + singular'),
    UNI(UNIT),
], S)
rand_q(L + '1', NT, '"{}" is a/an —', 'প্রশ্ন করুন: নির্দিষ্ট নাম? দল? পদার্থ? গুণ/ধারণা?', 'Noun-এর প্রকার সারণি।', 3000,
       trap_keys=('Childhood', 'Jury', 'Cotton'), why='শব্দটির প্রকৃতির সঙ্গে মেলে না।')
rand_q(L + '1', COLL, 'Choose the right collective noun: a ___ of {}.', 'বহুল-প্রচলিত collective noun মুখস্থ রাখুন।', 'Collective noun সারণি।', 3100, trap_keys=('fish', 'flowers'), why='এটি অন্য দলের collective noun।')
rand_q(L + '1', ABS, 'The abstract noun of "{}" is —', 'Adjective/Noun → abstract noun: -ty/-ry, -dom, -hood, -th suffix।', 'Abstract noun গঠন।', 3200, trap_keys=('high', 'young'), why='অন্য শব্দের abstract noun।')
QS(L + '1', [
    (2, 'He gave me ___ .', 'a piece of advice', [('an advice', '"advice" uncountable — "an" বসে না।'), ('many advices', '"advices" বলে কোনো plural নেই।'), ('a few advice', '"a few" লাগে plural countable noun-এর সাথে।')],
     'Advice uncountable; "a piece of / some advice" বলতে হয়।', 'Uncountable: advice, information, furniture, luggage, news।', 'Countable বনাম uncountable সারণি।', True),
    (2, 'There is ___ water in the glass, so you can drink it.', 'a little', [('few', '"few" countable plural-এর জন্য।'), ('little', '"little" = প্রায় নেই (নেতিবাচক) — "so you can drink it"-এর সঙ্গে বিরোধ।'), ('many', 'Countable plural-এর জন্য।')],
     'Uncountable-এ "a little" = কিছু আছে (ইতিবাচক)।', 'a little = ইতিবাচক; little = নেতিবাচক।', 'Quantifier সারণি।', True),
    (2, '___ students came, so the hall was almost empty.', 'Few', [('A few', 'ইতিবাচক অর্থ — "almost empty"-এর সঙ্গে বিরোধ।'), ('Much', 'শুধু uncountable-এ।'), ('A little', 'শুধু uncountable-এ।')],
     '"Few" = প্রায় কেউ নয়।', 'few = নেতিবাচক, a few = ইতিবাচক।', 'Quantifier সারণি।', True),
    (2, '___ of the two roads leads to the station; take any.', 'Either', [('Every', '"of the two"-এর সঙ্গে বসে না।'), ('All', 'Plural verb নেয়; দুটির জন্য নয়।'), ('Any', '"Any" দুইয়ের বেশির ক্ষেত্রে।')],
     '"Either" = দুটির যেকোনো একটি।', 'দুটি → either/neither; বেশি → any/none।', 'Quantifier সারণি।', True),
    (1, '"Every" is followed by —', 'a singular countable noun', [('a plural noun', '"every students" ✗।'), ('an uncountable noun', '"every water" ✗।'), ('an adjective only', 'Noun লাগবেই।')],
     'every student, every day।', 'each/every + singular।', 'Quantifier সারণি।', False),
    (2, 'The furniture in this room ___ new.', 'is', [('are', '"furniture" uncountable — singular verb নেয়।'), ('were', 'Plural।'), ('have been', 'Plural।')],
     'Uncountable noun singular verb নেয়।', 'furniture/information/news + is।', 'Countable বনাম uncountable।', True),
    (2, 'The rich ___ not always happy.', 'are', [('is', '"the + adjective" একটি শ্রেণির মানুষ বোঝায় — plural।'), ('was', 'Singular।'), ('has', 'Singular, verb-ও ভুল।')],
     'the rich / the poor / the young = plural।', 'the + adjective = plural শ্রেণি।', 'সাধারণ ভুল।', True),
    (2, 'In "These books are mine", the determiner is —', 'These', [('books', 'এটি noun।'), ('are', 'এটি verb।'), ('mine', 'Possessive pronoun, determiner নয় (noun-এর আগে বসেনি)।')],
     '"These" noun-এর আগে বসে তাকে নির্দিষ্ট করেছে।', 'Determiner noun-এর আগে বসে।', 'Determiner।', True),
    (2, 'Which of these is uncountable?', 'information', [('chair', 'Countable।'), ('idea', 'Countable — an idea, ideas।'), ('suggestion', 'Countable।')],
     'Information-এর আগে "a" বসে না, plural-ও হয় না।', 'I-A-L-F-N মনে রাখুন।', 'Countable বনাম uncountable।', False),
])

# =====================================================================
# 1.2 Number
# =====================================================================
PL = [('ox', 'oxen', ['oxes', 'oxs', 'oxies'], 'পুরোনো -en plural।'), ('child', 'children', ['childs', 'childes', 'childrens'], 'পুরোনো -ren plural।'),
      ('mouse', 'mice', ['mouses', 'mices', 'meese'], 'ভেতরের স্বর বদলায়।'), ('phenomenon', 'phenomena', ['phenomenons', 'phenomenas', 'phenomeni'], 'Greek -on → -a।'),
      ('criterion', 'criteria', ['criterions', 'criterias', 'criteri'], 'Greek -on → -a।'), ('crisis', 'crises', ['crisises', 'crisis', 'crisii'], 'Greek -is → -es।'),
      ('analysis', 'analyses', ['analysises', 'analysis', 'analysi'], '-is → -es।'), ('radius', 'radii', ['radiuses', 'radia', 'radiae'], 'Latin -us → -i।'),
      ('alumnus', 'alumni', ['alumnuses', 'alumna', 'alumnae'], 'Latin -us → -i (alumna/alumnae হলো স্ত্রীলিঙ্গ রূপ)।'),
      ('bacterium', 'bacteria', ['bacteriums', 'bacterias', 'bacterii'], 'Latin -um → -a।'), ('son-in-law', 'sons-in-law', ['son-in-laws', 'sons-in-laws', 'son-ins-law'], 'মূল শব্দটি plural হয়।'),
      ('passer-by', 'passers-by', ['passer-bys', 'passers-bys', 'passer-by'], 'মূল শব্দটি plural হয়।'), ('man-servant', 'men-servants', ['man-servants', 'men-servant', 'mans-servants'], 'দুটি অংশই বদলায়।'),
      ('oasis', 'oases', ['oasises', 'oasis', 'oasi'], '-is → -es।'), ('axis', 'axes', ['axises', 'axis', 'axii'], '-is → -es।'), ('die (for games)', 'dice', ['dies', 'dices', 'die'], 'die → dice।')]
B.lesson(L + '2', [
    H('Number: singular ও plural'),
    P('বেশির ভাগ noun-এ **-s/-es** যোগ করে **plural** হয়। পরীক্ষায় প্রশ্ন আসে **irregular** (অনিয়মিত), **foreign** (Latin/Greek), **compound** (যৌগিক) ও **অপরিবর্তিত** plural থেকে — আর এমন noun থেকে যাদের number বুঝতে ভুল হলে verb-ও ভুল হয়।'),
    TABLE('Irregular ও foreign plural (কলাম-লুকাও)', ['Singular', 'নিয়ম', 'Plural'], *[(a, n, b) for a, b, _, n in PL]),
    TABLE('Singular ও plural একই রূপ', ['Word', 'উদাহরণ'], ('deer', 'one deer, ten deer'), ('sheep', 'a sheep, many sheep'), ('aircraft', 'two aircraft'), ('swine', 'a herd of swine'), ('series', 'a series, two series')),
    TABLE('বিভ্রান্তিকর number', ['ধরন', 'শব্দ', 'Verb'],
          ('দেখতে plural, অর্থে singular', 'news, mathematics, physics, economics (বিষয় হিসেবে)', 'singular: The news is good.'),
          ('সবসময় plural (জোড়া জিনিস)', 'scissors, trousers, spectacles, tongs', 'plural; কিন্তু "a pair of trousers is"'),
          ('-s ছাড়াই plural', 'cattle, people, police, poultry', 'plural: The police are coming.'),
          ('সংখ্যার পরে বসলে', 'two dozen eggs, five hundred taka, a ten-mile walk', 'adjective হিসেবে dozen/hundred/mile-এ -s বসে না')),
    MNEM(('"-us → -i, -um → -a, -is → -es, -on → -a"', 'Latin/Greek plural', 'radius-radii, datum-data, crisis-crises, criterion-criteria।'),
         ('"শ্বশুরবাড়ির ছেলেরা: sons-in-law" — যে মানুষ, সে-ই plural', 'compound plural', 'passer-by-তে মানুষ passer → passers-by।')),
    MISTAKES('"The news are" ✗ → "is"।', '"two dozens eggs" ✗ → "two dozen eggs"।', '"son-in-laws" ✗ → "sons-in-law"।', '"The cattle is" ✗ → "are"।'),
    SUMMARY('Irregular: ox-oxen, child-children, mouse-mice', 'Foreign: -us→-i, -um→-a, -is→-es, -on→-a', 'Compound: মূল শব্দ plural', 'news/mathematics singular; cattle/police plural'),
    UNI(UNIT),
], S)
for k, a, wr, note in PL:
    Q(L + '2', 2, f'The plural of "{k}" is —', a, [(w, 'ভুল রূপ।') for w in wr], f'{k} → {a}। {note}', 'Latin/Greek ending ও compound শব্দে খেয়াল রাখুন।', 'Plural সারণি।',
      trap=k in ('alumnus', 'passer-by', 'man-servant', 'criterion'))
QS(L + '2', [
    (2, 'The news ___ very encouraging.', 'is', [('are', '"news" অর্থে singular।'), ('were', 'Plural।'), ('have been', 'Plural।')],
     'News uncountable ও singular।', 'দেখতে plural, কাজে singular।', 'বিভ্রান্তিকর number।', True),
    (2, 'Mathematics ___ my favourite subject.', 'is', [('are', '-ics দিয়ে শেষ হওয়া বিষয়ের নাম singular।'), ('were', 'Plural।'), ('have', 'Plural, verb-ও ভুল।')],
     'Mathematics/physics/economics বিষয় হিসেবে singular।', '-ics বিষয় = singular।', 'বিভ্রান্তিকর number।', True),
    (2, 'The cattle ___ grazing in the field.', 'are', [('is', '"cattle" সবসময় plural।'), ('was', 'Singular।'), ('has been', 'Singular।')],
     'Cattle-এর singular রূপ নেই; plural verb নেয়।', 'cattle, people, police = plural।', 'বিভ্রান্তিকর number।', True),
    (2, 'He bought two ___ eggs.', 'dozen', [('dozens', 'সংখ্যার পরে "dozen" singular থাকে।'), ('dozens of', 'নির্দিষ্ট সংখ্যা না থাকলে: "dozens of eggs"।'), ('dozen of', 'ভুল কাঠামো।')],
     'two dozen eggs, five hundred people।', 'সংখ্যা + dozen/hundred/thousand: -s নেই।', 'বিভ্রান্তিকর number।', True),
    (2, 'We went for a ___ walk.', 'ten-mile', [('ten-miles', 'Hyphen দেওয়া সংখ্যাবাচক adjective-এ -s বসে না।'), ('ten miles', 'Adjective হিসেবে hyphen ও singular লাগে।'), ('tens-mile', 'ভুল।')],
     'সংখ্যাযুক্ত compound adjective singular থাকে।', 'a five-year plan, a ten-taka note।', 'বিভ্রান্তিকর number।', True),
    (2, 'A pair of trousers ___ on the chair.', 'is', [('are', 'Subject হলো "a pair" (singular)।'), ('were', 'Plural।'), ('have been', 'Plural।')],
     '"a pair of" থাকলে singular।', 'trousers are; a pair of trousers is।', 'বিভ্রান্তিকর number।', True),
    (1, 'Which noun has the same form in singular and plural?', 'deer', [('ox', 'oxen।'), ('mouse', 'mice।'), ('goose', 'geese।')],
     'one deer, many deer।', 'deer, sheep, aircraft, series, swine।', 'একই রূপ সারণি।', False),
    (2, 'The plural of "datum" is —', 'data', [('datums', 'সাধারণ অর্থে datum-এর plural হিসেবে এটি প্রচলিত নয়।'), ('datas', 'দ্বিগুণ plural।'), ('datae', 'ভুল ending।')],
     'Latin -um → -a।', '-um → -a।', 'Foreign plural।', False),
])

# =====================================================================
# 1.3 Gender
# =====================================================================
GN = [('bachelor', 'spinster'), ('drake', 'duck'), ('gander', 'goose'), ('stag', 'hind'), ('fox', 'vixen'), ('colt', 'filly'), ('monk', 'nun'), ('wizard', 'witch'),
      ('nephew', 'niece'), ('lad', 'lass'), ('horse', 'mare'), ('ram', 'ewe'), ('peacock', 'peahen'), ('emperor', 'empress'), ('testator', 'testatrix'), ('sultan', 'sultana'), ('hero', 'heroine'), ('bull', 'cow')]
B.lesson(L + '3', [
    H('Gender'),
    P('English-এ **gender** চার প্রকার: **Masculine** (পুরুষ), **Feminine** (স্ত্রী), **Common** (দুটোই হতে পারে: parent, child, friend, teacher, student, cousin), **Neuter** (কোনোটাই নয় — প্রাণহীন: book, table, tree)।'),
    TABLE('Masculine → Feminine (কলাম-লুকাও)', ['Masculine', 'Feminine'], *GN),
    TABLE('Feminine গঠনের তিন উপায়', ['উপায়', 'উদাহরণ'], ('সম্পূর্ণ ভিন্ন শব্দ', 'bachelor-spinster, drake-duck, stag-hind, colt-filly'),
          ('Suffix যোগ (-ess, -ine, -trix, -a)', 'lion-lioness, hero-heroine, testator-testatrix, sultan-sultana'), ('Compound-এর একটি অংশ বদল', 'peacock-peahen, landlord-landlady, he-goat → she-goat')),
    TABLE('Personification (সাহিত্যে বস্তুকে লিঙ্গ দেওয়া)', ['Masculine', 'Feminine'], ('Sun, Death, Time, Winter, Summer', 'Moon, Earth, Nature, Ship, Spring, Liberty, Mercy')),
    MNEM(('"শক্তিশালী, ভয়ংকর → he; কোমল, সুন্দর, লালনকারী → she"', 'Personification', 'Sun, Death = he; Moon, Nature, Ship = she।'),
         ('"হাঁসের রাজা drake, রাজহাঁসের রাজা gander"', 'বিভ্রান্তিকর পাখি', 'duck ও goose আসলে feminine।')),
    MISTAKES('"duck" হলো feminine; পুরুষ হাঁস "drake"।', '"goose" feminine; পুরুষ রাজহাঁস "gander"।', '"teacher", "friend", "parent" common gender — masculine নয়।'),
    SUMMARY('Gender ৪: masculine, feminine, common, neuter', 'Feminine: নতুন শব্দ / suffix / compound বদল', 'Sun = he; Moon, Nature, Ship = she'),
    UNI(UNIT),
], S)
rand_q(L + '3', GN, 'The feminine of "{}" is —', 'অনেক প্রাণীর জোড়ায় সম্পূর্ণ ভিন্ন শব্দ থাকে।', 'Gender সারণি।', 3300,
       trap_keys=('drake', 'gander', 'stag', 'colt', 'testator'), why='অন্য শব্দের feminine।')
QS(L + '3', [
    (1, '"Parent" is an example of —', 'Common gender', [('Masculine gender', 'বাবা-মা যে-কেউ হতে পারে।'), ('Feminine gender', 'যে-কেউ হতে পারে।'), ('Neuter gender', 'জীবিত মানুষ।')],
     'Common gender = পুরুষ বা স্ত্রী দুটোই।', 'parent, child, friend, teacher।', 'চার gender।', False),
    (1, '"Table" is of — gender.', 'Neuter', [('Common', 'Common = জীবিত প্রাণী, যেকোনো লিঙ্গ।'), ('Masculine', 'প্রাণহীন।'), ('Feminine', 'প্রাণহীন।')],
     'প্রাণহীন বস্তু neuter।', 'Neuter = কোনোটাই নয়।', 'চার gender।', True),
    (2, 'In personification, "the Moon" is usually treated as —', 'feminine', [('masculine', 'Sun হলো masculine।'), ('neuter', 'Personification-এ নয়।'), ('common', 'ব্যবহৃত হয় না।')],
     'চাঁদ কোমল ও স্নিগ্ধ → she।', 'Sun he, Moon she।', 'Personification সারণি।', True),
    (2, 'In personification, "Death" is usually —', 'masculine', [('feminine', 'Nature, Mercy feminine।'), ('neuter', 'Personify করা হলে নয়।'), ('common', 'ব্যবহৃত হয় না।')],
     'শক্তিশালী, ভয়ংকর ধারণা → he।', 'শক্তিশালী → he।', 'Personification সারণি।', True),
    (2, 'The masculine of "duck" is —', 'drake', [('gander', 'পুরুষ রাজহাঁস।'), ('cock', 'মোরগ।'), ('stag', 'পুরুষ হরিণ।')],
     'drake-duck।', 'উল্টো দিক থেকেও প্রশ্ন আসে।', 'Gender সারণি।', True),
])

# =====================================================================
# 1.4 Embedded Question
# =====================================================================
B.lesson(L + '4', [
    H('Embedded question কী'),
    P('একটি প্রশ্ন যখন অন্য একটি বাক্যের ভেতরে ঢুকে যায়, তাকে **embedded question** বলে: Do you know **where the station is**? ভেতরের অংশে **statement word order** (আগে subject, পরে verb) হয়, আর **do/does/did** বাদ পড়ে।'),
    TABLE('Direct → Embedded', ['Direct question', 'Embedded'],
          ('Where is the station?', 'Can you tell me where the station is?'), ('What time does the bus leave?', 'Do you know what time the bus leaves?'),
          ('Why was he late?', 'I don\'t know why he was late.'), ('Has she finished?', 'I wonder whether / if she has finished.'),
          ('Who broke the window?', 'Do you know who broke the window? (wh-word নিজেই subject — ক্রম বদলায় না)')),
    TABLE('নিয়ম', ['নিয়ম', 'উদাহরণ'], ('Subject আগে, verb পরে', 'where he lives ("where does he live" নয়)'), ('do/does/did বাদ; tense চলে যায় মূল verb-এ', 'what she wanted'),
          ('Yes/No প্রশ্ন হলে if / whether', 'I asked whether he was ready.'), ('বাক্যের শেষ চিহ্ন ঠিক করে main clause', 'I wonder where he is. / Do you know where he is?')),
    MNEM(('"প্রশ্নের ভেতরের প্রশ্ন শান্ত — উল্টায় না"', 'Word order', 'wh-word-এর পরে subject + verb।'),
         ('"do/does/did-কে বিদায়, tense যায় verb-এ"', 'Auxiliary বাদ', 'What does she want? → what she wants।')),
    MISTAKES('"Can you tell me where is the post office?" ✗', '"I don\'t know what does he want." ✗ → "what he wants"।', '"I wonder where he has gone?" ✗ → শেষে full stop।'),
    SUMMARY('Embedded = বাক্যের ভেতরে প্রশ্ন', 'Statement order, do/does/did নেই', 'Yes/No → if/whether', 'শেষ চিহ্ন main clause অনুযায়ী'),
    UNI(UNIT),
], S)
QS(L + '4', [
    (2, 'Do you know where ___ ?', 'she lives', [('does she live', 'Embedded question-এ প্রশ্নের ক্রম চলে না।'), ('lives she', 'উল্টো ক্রম।'), ('she does live', 'জোর দেওয়ার "does" এখানে অপ্রয়োজনীয়।')],
     'Statement order: she lives।', 'Subject + verb।', 'নিয়ম সারণি।', True),
    (2, 'Can you tell me where ___ ?', 'the station is', [('is the station', 'Inversion এখানে ভুল।'), ('does the station', 'ভুল auxiliary।'), ('the station does be', 'অশুদ্ধ।')],
     'where the station is।', 'Subject + verb।', 'Direct → embedded সারণি।', True),
    (2, 'I wonder ___ he will come.', 'whether', [('what', 'কোনো অনুপস্থিত বস্তু নেই — এটি হ্যাঁ/না প্রশ্ন।'), ('which', 'বাছাইয়ের noun লাগে।'), ('that', '"that" প্রশ্ন বোঝায় না।')],
     'হ্যাঁ/না প্রশ্ন → whether / if।', 'Embedded yes/no-তে if = whether।', 'নিয়ম সারণি।', True),
    (2, 'Please tell me what time ___ .', 'it is', [('is it', 'উল্টো ক্রম।'), ('does it', 'do/does বসে না।'), ('it does', 'ভুল verb।')],
     'what time it is।', 'Statement order।', 'নিয়ম সারণি।', False),
    (2, 'Could you tell me how much ___ ?', 'this costs', [('does this cost', 'do/does বসে না।'), ('costs this', 'উল্টো ক্রম।'), ('this does cost', 'অপ্রয়োজনীয় জোরের do।')],
     '"does" বাদ দিয়ে verb-এ -s যোগ।', 'Tense মূল verb-এ চলে যায়।', 'নিয়ম সারণি।', True),
    (2, 'I don\'t know why ___ late yesterday.', 'he was', [('was he', 'উল্টো ক্রম।'), ('did he be', 'অশুদ্ধ।'), ('he is', '"yesterday"-এর সঙ্গে tense মেলে না।')],
     'why he was late।', 'Tense ঠিক রাখুন, statement order।', 'Direct → embedded সারণি।', True),
    (2, 'She asked me ___ I had finished my homework.', 'whether', [('that', 'প্রশ্নের জন্য নয়।'), ('what', 'কোনো object অনুপস্থিত নয়।'), ('which', 'বাছাই নেই।')],
     'Reported হ্যাঁ/না প্রশ্ন → whether / if।', 'Yes/No → whether।', 'নিয়ম সারণি।', False),
    (3, 'Do you know who ___ the window?', 'broke', [('did break', '"who" নিজেই subject হলে auxiliary লাগে না।'), ('did he break', 'অতিরিক্ত ভুল subject।'), ('has broken it', 'Object দুবার এসেছে।')],
     '"who" subject — ক্রম একই থাকে: who broke the window।', 'Subject wh-question: বদল নেই।', 'Direct → embedded সারণি।', True),
    (2, 'I\'d like to know when ___ .', 'the train leaves', [('does the train leave', 'do/does বসে না।'), ('leaves the train', 'উল্টো ক্রম।'), ('the train does leaves', 'দুবার চিহ্ন।')],
     'when the train leaves।', 'do বাদ।', 'নিয়ম সারণি।', False),
    (2, 'Do you remember where ___ the keys?', 'you put', [('did you put', 'did বসে না।'), ('put you', 'উল্টো ক্রম।'), ('you did put', 'অপ্রয়োজনীয় জোরের did।')],
     'where you put the keys।', 'Statement order।', 'নিয়ম সারণি।', False),
    (2, 'Which sentence is correct? (wonder)', 'I wonder where he has gone.', [('I wonder where has he gone?', 'Inversion + ভুল শেষ চিহ্ন।'), ('I wonder where he has gone?', 'Main clause statement — শেষে full stop।'), ('I wonder where did he go.', '"did" বসে না।')],
     'Main clause statement → full stop।', 'শেষ চিহ্ন main clause অনুযায়ী।', 'নিয়ম সারণি।', True),
    (2, 'Which sentence is correct? (tell me)', 'Can you tell me what she wants?', [('Can you tell me what does she want?', 'does বসে না।'), ('Can you tell me what she want?', 'Agreement: she wants।'), ('Can you tell me what wants she?', 'উল্টো ক্রম।')],
     'what she wants।', 'Statement order + agreement।', 'নিয়ম সারণি।', True),
    (2, 'Direct: "Is the shop open?" Embedded: "Do you know ___ ?"', 'if the shop is open', [('is the shop open', 'উল্টো ক্রম।'), ('that the shop is open', '"that" বসালে এটি প্রশ্ন না হয়ে statement হয়ে যায়।'), ('the shop is open if', 'ভুল অবস্থান।')],
     'হ্যাঁ/না → if/whether + statement order।', 'if = whether।', 'Direct → embedded সারণি।', True),
    (2, 'Direct: "What did he say?" Embedded: "Tell me ___ ."', 'what he said', [('what did he say', 'did বসে না।'), ('what he did say', 'অপ্রয়োজনীয় জোরের did।'), ('what said he', 'উল্টো ক্রম।')],
     '"did" বাদ, verb past-এ: said।', 'Tense verb-এ চলে যায়।', 'Direct → embedded সারণি।', True),
    (2, 'I have no idea how old ___ .', 'she is', [('is she', 'উল্টো ক্রম।'), ('does she', 'ভুল auxiliary।'), ('she has', 'বয়স বোঝাতে ভুল verb।')],
     'how old she is।', 'Statement order।', 'নিয়ম সারণি।', False),
    (2, 'Nobody knows ___ the money came from.', 'where', [('whether', 'এখানে স্থান অনুপস্থিত, হ্যাঁ/না নয়।'), ('that', 'প্রশ্নবাচক শব্দ নয়।'), ('what', '"from what" হলে ভিন্ন কাঠামো লাগত।')],
     'where the money came from।', 'অনুপস্থিত স্থান → where।', 'নিয়ম সারণি।', False),
    (2, 'Choose the correct sentence (reported).', 'He asked me how I was.', [('He asked me how was I.', 'উল্টো ক্রম।'), ('He asked me how am I.', 'উল্টো ক্রম ও ভুল tense।'), ('He asked me how was I?', 'উল্টো ক্রম + ভুল শেষ চিহ্ন।')],
     'Reported/embedded প্রশ্ন: statement order, statement-এর চিহ্ন।', 'Main clause statement → full stop।', 'নিয়ম সারণি।', True),
    (2, 'Could you tell me which bus ___ to Mirpur?', 'goes', [('does go', '"which bus" নিজেই subject — auxiliary লাগে না।'), ('does it go', 'অতিরিক্ত ভুল subject।'), ('go', 'Agreement: bus goes।')],
     '"which bus" subject → which bus goes।', 'Subject wh-phrase: বদল নেই।', 'Direct → embedded সারণি।', True),
    (1, 'In an embedded question we use —', 'statement word order', [('question word order', 'অন্য বাক্যের ভেতরে নয়।'), ('only "do/does"', 'এগুলো বাদ পড়ে।'), ('the imperative', 'সম্পর্কহীন।')],
     'Subject + verb।', 'মূল নিয়ম।', 'নিয়ম সারণি।', False),
    (2, 'Do you know whether ___ coming tonight?', 'they are', [('are they', 'উল্টো ক্রম।'), ('do they', 'ভুল auxiliary।'), ('they is', 'Agreement ভুল।')],
     'whether they are coming।', 'Statement order।', 'নিয়ম সারণি।', False),
])

B.autofill_cards(12)
B.save('b1a', 'en-b1a')
