"""অর্থনীতি — শেয়ার করা সহায়ক (Q: হাতে লেখা, C: কোডে গণনা)।"""
from common import *

BND = str.maketrans('0123456789', '০১২৩৪৫৬৭৮৯')
def bn(x):
    if isinstance(x, float):
        x = ('%.2f' % x).rstrip('0').rstrip('.')
    return str(x).translate(BND)
def lakh(n):
    s = str(abs(int(n)))
    if len(s) <= 3: return s
    head, tail = s[:-3], s[-3:]
    parts = []
    while len(head) > 2: parts.insert(0, head[-2:]); head = head[:-2]
    if head: parts.insert(0, head)
    return ','.join(parts) + ',' + tail
def tk(x): return ('−' if x < 0 else '') + bn(lakh(x)) + ' টাকা'

SRC_ECO = ['অর্থনীতি ১ম ও ২য় পত্র (NCTB, একাদশ-দ্বাদশ শ্রেণি)', 'বাংলাদেশ পরিসংখ্যান ব্যুরো (BBS) — সাম্প্রতিক সংখ্যা যেখানে উল্লেখ আছে']
UNI_ECO = ('চবি D ইউনিটে ২০ নম্বরের ঐচ্ছিক অংশে গণিত/অর্থনীতি/সাধারণ জ্ঞানের যেকোনো একটি (২০২৫-২৬, ব্লগ সূত্রে)। অন্য ইউনিটে সাধারণ জ্ঞানের অর্থনীতি-অংশের প্রস্তুতিতেও কাজে লাগে।')


def mk(B):
    def Q(lid, tip, fact, rows, d=2):
        for s, a, w, r, trap in rows:
            B.q(lid, d, s, a, [tuple(x.split('|', 1)) for x in w], r, tip, fact, trap=trap)
    def C(lid, stem, ans, wrongs, r, t, f, d=2, trap=False, fmt=tk):
        a = fmt(ans); seen = {a}; ws = []
        for v, why in wrongs:
            x = fmt(v)
            if x in seen: continue
            seen.add(x); ws.append((x, why))
            if len(ws) == 3: break
        assert len(ws) == 3, (stem, a, ws)
        B.q(lid, d, stem, a, ws, r, t, f, trap=trap)
    return Q, C
