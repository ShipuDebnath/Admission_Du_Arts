#!/usr/bin/env python3
"""EFT (NCTB, সংশোধিত ২০২৪-২৫) — Block 4 ও 5-এর লেসন:
U6·L1 What is a Dream?, U6·L2 Dreams in Literature, U7·L1 Brojen Das, U7·L2 Scaling a Mountain Peak,
U7·L3 The Unbeaten Girls, U8·L1 Family Relationship, U8·L2 Warmth in Relationships,
U8·L3 A Mother in Mannville, U8·L4 Love, U9·L1 Storms and Stresses of Adolescence,
U9·L2 Adolescence and Some (Related) Problems in Bangladesh
নীতি: পাঠ্যবইয়ের গদ্য হুবহু নয় — বাংলায় সারাংশ ও নিজের ভাষায় প্রশ্ন; কেবল কপিরাইটমুক্ত লেখার (১৯২৯-এর আগে প্রকাশিত) দু-এক লাইন উদ্ধৃত।"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('eneft3', 'en', 9941)
Q = B.q
SRC = ['English For Today, Classes XI-XII & Alim (NCTB, সংশোধিত ২০২৪-২৫ সংস্করণ)']
UNIT_EFT = ('ঢাবি B ইউনিটসহ বিভিন্ন ভর্তি পরীক্ষার English অংশে HSC-র English For Today থেকে লেখক, উৎস, চরিত্র, সাল ও শব্দার্থধর্মী প্রশ্ন আসার প্রবণতা আছে — '
            'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না।')
def FQ(lid, tip, fact, rows):
    for s, a, w, r, trap in rows:
        Q(lid, 2, s, a, w, r, tip, fact, trap=trap)
def W(*w): return [(x, 'পাঠের তথ্যের সঙ্গে মেলে না।') for x in w]

# =====================================================================
# U6·L1 What is a Dream?  (en-4-11)
# =====================================================================
B.lesson('en-4-11', [
    H('What is a Dream? — এক নজরে'),
    P('হাজার বছর ধরে দার্শনিকেরা স্বপ্ন নিয়ে ভেবেছেন, কিন্তু **empirical research** ও বৈজ্ঞানিক গবেষণা শুরু হয়েছে সাম্প্রতিক কালে। পাঠের সংজ্ঞা: ঘুমের মধ্যে যে ছবি, চিন্তা ও আবেগের অভিজ্ঞতা হয় — সেটাই স্বপ্ন। স্বপ্ন খুব **vivid** হতে পারে, আবার খুব **vague**; আনন্দের হতে পারে, ভয়েরও।'),
    UL('স্বপ্ন কেন দেখি — এ নিয়ে বহু তত্ত্ব আছে, কিন্তু **কোনো consensus নেই**', 'বিজ্ঞান এখনো ঘুমেরই সঠিক উদ্দেশ্য ও কাজ পুরোপুরি বের করতে পারেনি',
       'কারও মতে স্বপ্নের কোনো আসল উদ্দেশ্য নেই; কারও মতে মানসিক, আবেগিক ও শারীরিক সুস্থতার জন্য স্বপ্ন অপরিহার্য'),
    H('Freud ও অন্যান্য তত্ত্ব'),
    TABLE('স্বপ্নের তত্ত্ব (পাঠ অনুযায়ী)', ['তত্ত্ব', 'মূল কথা'],
          ('Sigmund Freud — **psychoanalytic**', 'স্বপ্ন = অবচেতন (subconscious) ইচ্ছা, চিন্তা ও প্রেরণার প্রকাশ; চেতনা থেকে চাপা দেওয়া (repressed) aggressive ও sexual instinct স্বপ্নে ফিরে আসে'),
          ('বই', '**The Interpretation of Dreams (1899)** — স্বপ্ন হলো চাপা দেওয়া ইচ্ছার "ছদ্মবেশী পূরণ" (disguised fulfillments of repressed wishes)'),
          ('সংকেত-ব্যাখ্যা তত্ত্ব', 'ঘুমের সময় মস্তিষ্কের তৈরি সংকেতের ব্যক্তিগত ব্যাখ্যা; স্বপ্ন অর্থহীন নয় — cognitive উপাদান নতুন ধারণা তৈরি করে'),
          ('বাহ্যিক উদ্দীপনা তত্ত্ব', 'ঘুমের মধ্যে বাইরের **stimuli** ব্যাখ্যার চেষ্টা — যেমন রেডিওর শব্দ স্বপ্নে ঢুকে পড়ে'),
          ('computer metaphor', 'কম্পিউটারের clean-up-এর মতো মনের **clutter** পরিষ্কার করে পরের দিনের জন্য প্রস্তুত করে'),
          ('psychotherapy মডেল', 'নিরাপদ পরিবেশে বিভিন্ন চিন্তা ও আবেগের মধ্যে সংযোগ ঘটায়')),
    WORDS(('nightmare', 'দুঃস্বপ্ন'), ('day-dream', 'দিবাস্বপ্ন (জেগে থাকা অবস্থায় সুখকল্পনা)'), ('reverie', 'ভাবনায় বিভোর অবস্থা'), ('hallucination', 'অলীক দর্শন/বিভ্রম'),
          ('empirical', 'পর্যবেক্ষণ/পরীক্ষানির্ভর'), ('vivid', 'স্পষ্ট, উজ্জ্বল'), ('vague', 'অস্পষ্ট'), ('baffling', 'হতবুদ্ধিকর'), ('unravel', 'জট খোলা, রহস্যভেদ করা'),
          ('repressed', 'দমিত, চাপা দেওয়া'), ('cognitive', 'জ্ঞানীয়/বোধসংক্রান্ত'), ('stimuli', 'উদ্দীপনা (stimulus-এর plural)'), ('clutter', 'এলোমেলো জঞ্জাল'), h='শব্দার্থ'),
    P('পাঠের শেষে ভারতের সাবেক রাষ্ট্রপতি ও বিজ্ঞানী **APJ Abdul Kalam**-এর উক্তি: স্বপ্ন সেটা নয় যা ঘুমিয়ে দেখো; স্বপ্ন সেটা যা তোমাকে ঘুমাতে দেয় না।'),
    SUMMARY('স্বপ্ন = ঘুমের মধ্যে ছবি-চিন্তা-আবেগ; উদ্দেশ্য নিয়ে consensus নেই', 'Freud: psychoanalytic; The Interpretation of Dreams (1899); disguised fulfillments of repressed wishes',
            'অন্য তত্ত্ব: brain signals, external stimuli (radio), computer clean-up, psychotherapy', 'stimuli ← stimulus (plural)'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-4-11', 'Freud = psychoanalytic = 1899 — তিনটি একসঙ্গে মনে রাখুন।', 'What is a Dream? — তত্ত্বের সারণি।', [
    ('According to the lesson, dreams have been subjected to empirical research —', 'only recently', W('for thousands of years', 'since the time of Aristotle', 'never at all'), 'দার্শনিকেরা হাজার বছর ভেবেছেন; গবেষণা সাম্প্রতিক।', True),
    ('In the lesson, a dream is defined as —', 'the images, thoughts and emotions experienced during sleep', W('a plan for the future', 'a memory of the past only', 'a disease of the mind'), 'পাঠের সংজ্ঞা।', False),
    ('On the purpose of dreams, researchers have reached —', 'no consensus', W('complete agreement', 'a single proven theory', 'the conclusion that dreams are harmful'), 'বহু তত্ত্ব, ঐকমত্য নেই।', True),
    ('Sigmund Freud\'s theory of dreams follows the — perspective.', 'psychoanalytic', W('behaviourist', 'computer-based', 'cognitive-signal'), 'Psychoanalytic।', True),
    ('Freud\'s famous book on dreams is —', 'The Interpretation of Dreams', W('The Meaning of Sleep', 'Dreams and Reality', 'The Origin of Species'), 'The Interpretation of Dreams।', True),
    ('The Interpretation of Dreams was published in —', '1899', W('1859', '1923', '1905'), '১৮৯৯।', True),
    ('According to Freud, dreams are disguised fulfillments of —', 'repressed wishes', W('daily duties', 'conscious plans', 'external sounds'), 'চাপা দেওয়া ইচ্ছা।', True),
    ('The theory that the sound of a radio may enter a dream treats dreams as —', 'interpretations of external stimuli', W('repressed wishes', 'pure memories', 'a form of exercise'), 'বাহ্যিক উদ্দীপনা।', False),
    ('The computer-metaphor theory says that dreams —', 'clean up clutter from the mind', W('store new files permanently', 'slow down the brain', 'cause nightmares'), 'Clean-up operation।', True),
    ('Another model suggests that dreams work as a form of —', 'psychotherapy', W('surgery', 'punishment', 'entertainment only'), 'Psychotherapy।', False),
    ('"Dream is not what you see in sleep, dream is something that does not let you sleep." — this is quoted in EFT from —', 'APJ Abdul Kalam', W('Sigmund Freud', 'William Wordsworth', 'Langston Hughes'), 'APJ Abdul Kalam।', True),
    ('A very bad, frightening dream is called a —', 'nightmare', [('reverie', 'Reverie = সুখকর ভাবনায় বিভোর থাকা।'), ('day-dream', 'Day-dream = জেগে থাকা অবস্থায় সুখকল্পনা।'), ('vision', 'Vision = দৃষ্টি/দূরদৃষ্টি — ভয়ের অর্থ নেই।')], 'Nightmare = দুঃস্বপ্ন।', False),
    ('A happy dream about one\'s future that one has while awake is called a —', 'day-dream', [('nightmare', 'Nightmare ঘুমের মধ্যে ভয়ের স্বপ্ন।'), ('hallucination', 'Hallucination = অলীক দর্শন, সুখকল্পনা নয়।'), ('fragment', 'Fragment = খণ্ডাংশ।')], 'Day-dream = দিবাস্বপ্ন।', False),
    ('The word "vague" (dreams can be vivid or vague) means —', 'unclear', [('bright', 'Bright ≈ vivid — বিপরীত।'), ('frightening', 'Frightening = ভীতিকর, অস্পষ্টতা নয়।'), ('joyful', 'Joyful = আনন্দময়।')], 'Vague = অস্পষ্ট; antonym vivid।', False),
    ('The word "baffling" is closest in meaning to —', 'puzzling', [('pleasing', 'Pleasing = আনন্দদায়ক।'), ('boring', 'Boring = একঘেয়ে।'), ('frightening', 'Frightening = ভীতিকর।')], 'Baffling = হতবুদ্ধিকর।', False),
    ('"Science is still unraveling the purpose of sleep." Here "unraveling" means —', 'solving or explaining', [('confusing', 'উল্টো অর্থ — জট পাকানো নয়, খোলা।'), ('ignoring', 'Ignoring = উপেক্ষা।'), ('weaving', 'Weaving = বোনা — unravel তার উল্টো।')], 'Unravel = জট খোলা, রহস্য উদঘাটন।', False),
    ('The singular form of "stimuli" is —', 'stimulus', [('stimula', 'অস্তিত্বহীন রূপ।'), ('stimulis', 'ভুল বানান।'), ('stimuluses', 'Latin plural -i; -es যোগ হয় না।')], 'Latin -us → -i: stimulus → stimuli, cactus → cacti।', True),
    ('"Empirical" research is research based on —', 'observation and experiment', [('imagination only', 'কল্পনা empirical-এর বিপরীত।'), ('religious belief', 'বিশ্বাস পর্যবেক্ষণ নয়।'), ('dreams', 'বিষয় নয়, পদ্ধতির কথা।')], 'Empirical = অভিজ্ঞতা/পর্যবেক্ষণনির্ভর।', False),
])

# =====================================================================
# U6·L2 Dreams in Literature  (en-4-12)
# =====================================================================
B.lesson('en-4-12', [
    H('Dreams in Literature — এক নজরে'),
    P('Romantic কবি **William Wordsworth (1770–1850)** কবিদের স্বপ্নদ্রষ্টা মনে করতেন, কারণ তাঁরা "আমাদের ইচ্ছা, শক্তি, ভাবনা"-কে "কাজে" রূপ দিতে পারেন। এই লেসনে আটলান্টিকের দুই পারের দুই কবির দুটি কবিতা, আর মিশরীয় নোবেলজয়ী Naguib Mahfouz-এর একটি স্বপ্ন-গল্প।'),
    TABLE('দুই কবি', ['কবি', 'পরিচয় (পাঠ অনুযায়ী)', 'কবিতার মূল ভাব'],
          ('**D. H. Lawrence (1885–1930)**', 'ইংরেজ ঔপন্যাসিক, কবি ও প্রাবন্ধিক; ঔপন্যাসিক হিসেবেই বেশি খ্যাত',
           'সবাই স্বপ্ন দেখে, কিন্তু সমানভাবে নয়। রাতের স্বপ্নদ্রষ্টারা সকালে দেখে সব অসার (vanity); দিনের স্বপ্নদ্রষ্টারা "বিপজ্জনক" — খোলা চোখে স্বপ্ন দেখে তা সত্যি করে ফেলে'),
          ('**Langston Hughes (1902–1967)**', 'আমেরিকান কবি, ঔপন্যাসিক ও নাট্যকার; ১৯২০-এর দশকে কৃষ্ণাঙ্গদের জীবনে পরিবর্তন আনার আন্দোলন **Harlem Renaissance**-এর নেতা',
           'স্বপ্ন আঁকড়ে ধরো; স্বপ্ন মরলে জীবন ভাঙা-ডানার পাখি, স্বপ্ন চলে গেলে জীবন তুষারে জমে যাওয়া বন্ধ্যা মাঠ')),
    QUOTE('Hold fast to dreams / For if dreams die / Life is a broken-winged bird / That cannot fly.', 'Langston Hughes, "Dreams" (1923)', '১৯২৩-এ প্রকাশিত — কপিরাইটমুক্ত।',
          'দুটি metaphor: broken-winged bird (উড়তে না পারা = লক্ষ্যহীন জীবন) ও barren field frozen with snow (ফলহীন, প্রাণহীন জীবন)।'),
    MATCH('Lawrence-এর কবিতার লাইন ↔ অর্থ (পাঠের Activity E অবলম্বনে)',
          ('All people dream, but not equally', 'সবাই স্বপ্ন দেখি, তবে স্বপ্ন ভিন্ন ভিন্ন'), ('Those who dream by night…', 'আমাদের মতো যারা রাতে ঘুমিয়ে স্বপ্ন দেখে'),
          ('Wake in the morning to find that it was vanity', 'সকালে জেগে দেখে স্বপ্ন অবাস্তব, নিছক কল্পনা'), ('But the dreamers of the day are dangerous people', 'দিবাস্বপ্নদ্রষ্টাদের বিশ্বাস করা যায় না'),
          ('For they dream their dreams with open eyes', 'তারা জেনে-বুঝে স্বপ্ন দেখে, যা বাস্তবায়ন করতে চায়'), ('And make them come true', 'তারা স্বপ্নকে বাস্তবে রূপ দেয়')),
    H('Naguib Mahfouz — Dream #6'),
    UL('**The Dreams** — মিশরীয় নোবেলজয়ী Naguib Mahfouz-এর **১০৪টি স্বপ্নের** সংকলন, প্রথম প্রকাশ **২০০০–২০০৩**; ইংরেজি অনুবাদক **Raymond Stock**',
       'ফোনে কণ্ঠ: "শায়খ মুহাররম, তোমার শিক্ষক" — অথচ কথক প্রায় **ষাট বছর আগে** তাঁর জানাজায় হেঁটেছিলেন (এটাই স্বপ্নের সূত্র)',
       'শিক্ষক ছিলেন সুদর্শন, পরিপাটি পোশাকের, কিন্তু ছাত্রদের প্রতি অত্যন্ত কঠোর; আসেন jubba, caftan ও প্যাঁচানো পাগড়ি পরে',
       'বলেন, "ওপারে" প্রাচীন কাব্য-আবৃত্তিকার ও ধর্মবিশারদদের সঙ্গে কথা বলে বুঝেছেন, তাঁর কিছু পাঠ সংশোধন দরকার — সংশোধনী লেখা একটি **folder** টেবিলে রেখে চলে যান'),
    FACTS('পাঠে উল্লেখ: স্বপ্নের ব্যাখ্যার বইকে আমাদের সংস্কৃতিতে বলা হয় **"খোয়াবনামা"**', 'একই নামের বিখ্যাত উপন্যাস **খোয়াবনামা (১৯৯৬)** — লেখক **আখতারুজ্জামান ইলিয়াস**',
          'D. H. Lawrence-এর পাঁচটি উপন্যাস: The White Peacock, Sons and Lovers, The Rainbow, Women in Love, Lady Chatterley\'s Lover', h='বাড়তি তথ্য (পাঠের Activity অনুযায়ী)'),
    WORDS(('recesses of the mind', 'মনের গভীর গোপন কোণ'), ('dusty', 'ধুলোমাখা — এখানে অবহেলিত, অস্পষ্ট'), ('vanity', 'অসারতা, নিষ্ফলতা'), ('barren', 'বন্ধ্যা, ফসলহীন'),
          ('hold fast', 'শক্ত করে আঁকড়ে ধরা (fast = adverb)'), ('reverent', 'শ্রদ্ধাপূর্ণ'), ('indelible', 'অমোচনীয়'), ('without prologue', 'ভূমিকা ছাড়াই'), h='শব্দার্থ'),
    VERIFY('"All people dream, but not equally…" লাইনগুলো EFT-তে D. H. Lawrence-এর নামে ছাপা; সাহিত্য-গবেষকেরা সাধারণত এগুলোকে T. E. Lawrence-এর Seven Pillars of Wisdom-এর ভূমিকার অংশ হিসেবে চেনেন। ভর্তি পরীক্ষায় পাঠ্যবইয়ের উত্তর (D. H. Lawrence) লিখুন, তবে প্রশ্নে T. E. Lawrence বিকল্প থাকলে প্রশ্নের প্রসঙ্গ খেয়াল করুন।'),
    SUMMARY('Wordsworth (1770–1850): কবি = স্বপ্নদ্রষ্টা', 'Lawrence (1885–1930): দিনের স্বপ্নদ্রষ্টারা "dangerous" — খোলা চোখে স্বপ্ন, বাস্তবায়ন', 'Hughes (1902–1967), Harlem Renaissance: broken-winged bird, barren field',
            'Mahfouz: The Dreams, ১০৪টি স্বপ্ন, ২০০০–২০০৩, অনুবাদ Raymond Stock; Shaykh Muharram', 'খোয়াবনামা — আখতারুজ্জামান ইলিয়াস'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-4-12', 'কবি-সাল-দেশ-metaphor ছক করে মনে রাখুন।', 'Dreams in Literature।', [
    ('According to EFT, William Wordsworth considered poets —', 'dreamers', W('scientists', 'politicians', 'idlers'), 'ইচ্ছা-শক্তি-ভাবনাকে কাজে রূপ দেন।', False),
    ('Wordsworth\'s life span as given in EFT is —', '1770–1850', W('1795–1821', '1885–1930', '1812–1870'), '১৭৭০–১৮৫০।', True),
    ('D. H. Lawrence was more famous as a —', 'novelist', W('playwright', 'painter', 'journalist'), 'ঔপন্যাসিক হিসেবেই খ্যাত।', True),
    ('Which of the following is a novel by D. H. Lawrence?', 'Sons and Lovers', [('Pride and Prejudice', 'Jane Austen-এর উপন্যাস।'), ('Great Expectations', 'Charles Dickens-এর উপন্যাস।'), ('Tess of the d\'Urbervilles', 'Thomas Hardy-র উপন্যাস।')], 'Lawrence: Sons and Lovers, The Rainbow, Women in Love…', True),
    ('Langston Hughes was a leader of —', 'the Harlem Renaissance', W('the Romantic Movement', 'the Bengal Renaissance', 'the Pre-Raphaelite Movement'), '১৯২০-এর দশক, কৃষ্ণাঙ্গদের জীবনে পরিবর্তন।', True),
    ('Langston Hughes\'s life span as given in EFT is —', '1902–1967', W('1885–1930', '1913–1980', '1899–1954'), '১৯০২–১৯৬৭।', True),
    ('In Lawrence\'s poem, those who dream by night wake in the morning to find that it was —', 'vanity', W('reality', 'a prophecy', 'a memory'), 'অসার।', True),
    ('Lawrence calls the dreamers of the day "dangerous" because they —', 'dream with open eyes and make their dreams come true', W('never sleep', 'hurt other people', 'forget their dreams'), 'স্বপ্ন বাস্তবায়ন করে।', True),
    ('In Hughes\'s "Dreams", if dreams die, life becomes —', 'a broken-winged bird that cannot fly', W('a sleeping child', 'a river without water', 'a tree without roots'), 'Metaphor।', True),
    ('In Hughes\'s poem, when dreams go, life is —', 'a barren field frozen with snow', W('a garden in spring', 'a stormy sea', 'a dark night'), 'Barren field।', True),
    ('In "Hold fast to dreams", the word "fast" is used as —', 'an adverb', [('an adjective', 'এখানে hold ক্রিয়াকে বিশেষায়িত করছে।'), ('a verb', 'রোজা রাখা অর্থে নয়।'), ('a noun', 'বিশেষ্য হিসেবে ব্যবহৃত নয়।')], 'Hold fast = শক্ত করে ধরো — fast verb-কে modify করছে = adverb।', True),
    ('In the phrase "broken-winged bird", "winged" is —', 'an adjective', [('a verb', 'বাক্যে ক্রিয়ার কাজ করছে না।'), ('an adverb', 'bird-কে বর্ণনা করছে, ক্রিয়াকে নয়।'), ('a noun', 'Wing noun, কিন্তু winged বিশেষণ।')], 'Noun + -ed → adjective (winged, talented)।', False),
    ('Naguib Mahfouz, whose "Dream #6" is in EFT, was from —', 'Egypt', W('Turkey', 'Iran', 'Lebanon'), 'মিশরীয় নোবেলজয়ী।', True),
    ('According to EFT, "The Dreams" by Naguib Mahfouz is a collection of —', '104 dreams', W('100 dreams', '1001 nights', '64 dreams'), '১০৪টি স্বপ্ন।', True),
    ('"Dream #6" in EFT was translated by —', 'Raymond Stock', W('Fakrul Alam', 'Shouhua Qi', 'Kaiser Haq'), 'Raymond Stock।', True),
    ('In "Dream #6", the caller on the telephone was —', 'Shaykh Muharram, the narrator\'s teacher', W('the narrator\'s father', 'a religious scholar he never met', 'his old classmate'), 'শায়খ মুহাররম।', True),
    ('Which clue shows that the story in "Dream #6" is a dream?', 'The narrator had walked in the teacher\'s funeral procession about sixty years before.', W('The telephone rang loudly.', 'The teacher wore a turban.', 'The narrator answered politely.'), 'মৃত শিক্ষকের আগমন।', False),
    ('In "Dream #6", what did the teacher leave on the table?', 'a folder of corrections to his old lessons', W('a book of poems', 'a letter of apology', 'a gift for the narrator'), 'সংশোধনীর ফোল্ডার।', False),
    ('The famous Bangla novel "Khwabnama" was written by —', 'Akhtaruzzaman Elias', [('Humayun Ahmed', 'তাঁর বিখ্যাত উপন্যাস নন্দিত নরকে, জোছনা ও জননীর গল্প ইত্যাদি।'), ('Syed Waliullah', 'তাঁর উপন্যাস লালসালু, চাঁদের অমাবস্যা।'), ('Shahidullah Kaiser', 'তাঁর উপন্যাস সংশপ্তক, সারেং বৌ।')], 'খোয়াবনামা (১৯৯৬) — আখতারুজ্জামান ইলিয়াস; তাঁর আরেকটি উপন্যাস চিলেকোঠার সেপাই।', True),
])

# =====================================================================
# U7·L1 Brojen Das  (en-4-13)
# =====================================================================
B.lesson('en-4-13', [
    H('Brojen Das — এক নজরে'),
    TABLE('জীবনতথ্য (পাঠ অনুযায়ী)', ['বিষয়', 'তথ্য'],
          ('জন্ম', '**৯ ডিসেম্বর ১৯২৭, মুন্সিগঞ্জ**'), ('কৃতিত্ব', '**এশিয়ার প্রথম** ব্যক্তি হিসেবে **১৯৫৮**-এ ইংলিশ চ্যানেল সাঁতরে পার'),
          ('মোট', 'চ্যানেল পার করেন **ছয়বার**; **১৯৬১**-তে বিশ্বরেকর্ড'), ('বাংলাদেশ সরকারের সম্মাননা', 'জাতীয় ক্রীড়া পুরস্কার **১৯৭৬**; **স্বাধীনতা পদক ১৯৯৯ (মরণোত্তর)**'),
          ('অন্যান্য', '**Pride of Performance ১৯৫৯** (পাকিস্তান সরকার); যুক্তরাজ্য থেকে **King of Channel** ট্রফি'), ('মৃত্যু', '**১ জুন ১৯৯৮**')),
    H('স্মৃতিকথা: "I had not failed my country"'),
    UL('তারিখ **২২ সেপ্টেম্বর ১৯৬১**, ভোর প্রায় ৪টা; ক্লান্ত, তীব্র স্রোতের বাধা; সঙ্গের মোটরবোটে ম্যানেজার **Quazi Mohammad Ali**, skipper **Len Hutchinson**, official observer **J. U. Wood** — সবাই **Kent** তীরের দিকে দেখাচ্ছিলেন',
       'শেষ শক্তিটুকু দিলে **France to England** সাঁতারে নতুন বিশ্বরেকর্ড — চার বছরের লক্ষ্য হাতের কাছে',
       'আবহাওয়ার বিশ্বাসঘাতকতা: ঠান্ডা পানি, বাতাস, ঢেউ, জোয়ার; আবহাওয়া ও দুর্ভাগ্য তাঁকে **পাঁচবার** হারিয়েছে',
       '**৯ সেপ্টেম্বর ১৯৬১** সাঁতার শেষে (**১১ ঘণ্টা ৪৮ মিনিট**) BBC-TV বিছানায় তাঁকে ফিল্ম করে; দেশকে আবার ব্যর্থ করেছেন ভেবে ঘুম আসেনি; ২০ সেপ্টেম্বর ফেরিতে **Calais** যান',
       '**Sea-sickness**: ১৯৬০ ও ৮/৯ সেপ্টেম্বরের ব্যর্থতার মূল কারণ; **Cap Gris Nez** হোটেলে রাতের বিশ্রাম; ২১ সেপ্টেম্বর আবহাওয়া প্রায় নিখুঁত; পঞ্চম সাঁতারের **১২ দিনের মধ্যে** ষষ্ঠবার নামা — সেটাই এক রেকর্ড',
       'সাঁতারের **দ্বিতীয়ার্ধ সবসময় বেশি কঠিন**; তাই গতি স্থির রাখেন; পানিতে নামলে সময়, দূরত্ব, দিক — সবকিছুর হিসাব হারিয়ে যায়',
       'ক্ষুধার্ত হয়ে খাবার চান; ১০ মিনিট নষ্ট না করতে বলা হলেও তিনি খেয়ে নেন — পরে আফসোস: না থামলে ১০ ঘণ্টা ১৫ মিনিটের কমে শেষ করতে পারতেন',
       'শেষে পাথুরে তীর — সময় **ভোর ৪.৩৫ (GMT)**; বিশ্বরেকর্ড **১৫ মিনিট** কমিয়ে ভাঙেন; প্রকাশ: Morning News, ২৭ অক্টোবর ১৯৬১'),
    ENTRIES('পাঠের idiom/phrase',
            {'w': 'last drop of energy', 'bn': 'শেষ বিন্দু শক্তি', 'en': 'all the strength that is left', 'ex': 'He squeezed his body for the last drop of energy.'},
            {'w': 'get one\'s teeth into', 'bn': 'পুরো মনোযোগে কাজে লেগে পড়া', 'en': 'to start doing something with energy and determination', 'ex': 'After the feed he really got his teeth into the strokes.'},
            {'w': 'with all one\'s might', 'bn': 'সর্বশক্তি দিয়ে', 'en': 'using all one\'s strength', 'syn': 'with might and main'},
            {'w': 'on top of the world', 'bn': 'আনন্দে আত্মহারা, দারুণ চনমনে', 'en': 'extremely happy and confident', 'ctx': 'Cap Gris Nez-এ রাতের বিশ্রামের পর লেখকের অনুভূতি।'},
            {'w': 'crowned with success', 'bn': 'সাফল্যমণ্ডিত', 'en': 'to end in success', 'ctx': 'রাজমুকুট পরানোর রূপক — চূড়ান্ত পুরস্কার।'},
            {'w': 'proverbial carrot', 'bn': 'চোখের সামনে ঝুলিয়ে রাখা লোভনীয় পুরস্কার', 'en': 'a reward that keeps one going', 'ctx': 'গাধার নাকের সামনে লাঠিতে গাজর ঝুলিয়ে তাকে চালানোর প্রচলিত গল্প থেকে।'}),
    SUMMARY('জন্ম ৯ ডিসেম্বর ১৯২৭ মুন্সিগঞ্জ; মৃত্যু ১ জুন ১৯৯৮', 'এশিয়ার প্রথম চ্যানেল-জয়ী ১৯৫৮; ছয়বার; রেকর্ড ১৯৬১', 'পুরস্কার: Pride of Performance ১৯৫৯, জাতীয় ক্রীড়া ১৯৭৬, স্বাধীনতা পদক ১৯৯৯ (মরণোত্তর), King of Channel',
            'রেকর্ড: ২২ সেপ্টেম্বর ১৯৬১, ভোর ৪.৩৫ GMT, ১৫ মিনিট কম; France → England'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-4-13', 'সাল-তারিখগুলো আলাদা কার্ডে লিখে মিলিয়ে নিন: ১৯২৭, ১৯৫৮, ১৯৫৯, ১৯৬১, ১৯৭৬, ১৯৯৮, ১৯৯৯।', 'Brojen Das — জীবনতথ্য সারণি।', [
    ('Brojen Das was born in —', 'Munshiganj', W('Narayanganj', 'Faridpur', 'Barishal'), '৯ ডিসেম্বর ১৯২৭, মুন্সিগঞ্জ।', True),
    ('Brojen Das became the first person from Asia to swim across the English Channel in —', '1958', W('1961', '1952', '1965'), '১৯৫৮।', True),
    ('How many times did Brojen Das cross the English Channel?', 'six times', W('five times', 'four times', 'eight times'), 'ছয়বার।', True),
    ('Brojen Das set a world record in Channel swimming in —', '1961', W('1958', '1959', '1976'), '১৯৬১।', True),
    ('Brojen Das received the Swadhinata Padak —', 'posthumously in 1999', W('in 1976', 'in 1959', 'in 1971'), 'মরণোত্তর ১৯৯৯।', True),
    ('The Pride of Performance award (1959) was given to Brojen Das by —', 'the Pakistan government', W('the Bangladesh government', 'the UK government', 'the Indian government'), 'পাকিস্তান সরকার।', True),
    ('The "King of Channel" trophy was given to Brojen Das from —', 'the UK', W('France', 'Pakistan', 'Bangladesh'), 'যুক্তরাজ্য।', False),
    ('Brojen Das died on —', '1 June 1998', W('9 December 1998', '22 September 1961', '1 June 1999'), '১ জুন ১৯৯৮।', True),
    ('Brojen Das\'s record-breaking swim was from —', 'France to England', W('England to France', 'England to Ireland', 'Calais to Dover and back'), 'France → England, Kent তীর।', True),
    ('On the record swim, the official observer in the motorboat was —', 'Mr. J. U. Wood', W('Len Hutchinson', 'Quazi Mohammad Ali', 'a BBC cameraman'), 'Hutchinson ছিলেন skipper, Quazi Mohammad Ali ম্যানেজার।', True),
    ('According to Brojen Das, the main cause of his earlier failures was —', 'sea-sickness', W('hunger', 'cold water', 'lack of practice'), 'Sea-sickness।', True),
    ('On 21 September 1961, Brojen Das jumped into the water —', 'within 12 days of his 5th swim', W('within a week of his 5th swim', 'immediately after his 5th swim', 'a month after his 5th swim'), '১২ দিনের মধ্যে — নিজেই এক রেকর্ড।', True),
    ('According to Brojen Das, the second half of a Channel swim is —', 'always more difficult than the first half', W('easier than the first half', 'as easy as the first half', 'the shortest part'), 'দ্বিতীয়ার্ধ বেশি কঠিন।', False),
    ('Brojen Das broke the world record by —', '15 minutes', W('10 minutes', '48 minutes', '1 hour'), '১৫ মিনিট।', True),
    ('The memoir says Brojen Das reached the shore at —', '4.35 a.m. GMT', W('4.00 a.m. GMT', '11.48 a.m. GMT', '10.15 p.m. GMT'), 'ভোর ৪.৩৫।', False),
    ('Before his last attempt, Brojen Das stayed at a hotel in —', 'Cap Gris Nez', W('Dover', 'Calais', 'London'), 'Cap Gris Nez।', False),
    ('"After the feed I really got my teeth into the strokes." Here "got my teeth into" means —', 'started doing something with full energy', [('started eating', 'আক্ষরিক অর্থ নয়, idiom।'), ('felt toothache', 'অপ্রাসঙ্গিক আক্ষরিক পাঠ।'), ('gave up', 'উল্টো অর্থ।')], 'Get one\'s teeth into = পূর্ণোদ্যমে লেগে পড়া।', False),
    ('"I felt on top of the world." This means he felt —', 'extremely happy and confident', [('very tired', 'উল্টো অবস্থা।'), ('high above the sea', 'আক্ষরিক অর্থ নয়।'), ('afraid', 'অপ্রাসঙ্গিক।')], 'On top of the world = আনন্দে আত্মহারা।', False),
])

# =====================================================================
# U7·L2 Scaling a Mountain Peak  (en-4-14)
# =====================================================================
B.lesson('en-4-14', [
    H('Nishat Mazumder — এক নজরে'),
    TABLE('জীবনতথ্য (পাঠ অনুযায়ী)', ['বিষয়', 'তথ্য'],
          ('জন্ম', '**৫ জানুয়ারি ১৯৮১**, **তেওরি** গ্রাম, **রামগঞ্জ** উপজেলা, **লক্ষ্মীপুর**'), ('পরিবার', 'চার ভাইবোনের মধ্যে **দ্বিতীয়**; বাবা ব্যবসায়ী ও **১৯৭১-এর মুক্তিযোদ্ধা**; মা **আশুরা মজুমদার** গৃহিণী — নিশাতের **role model**'),
          ('শিক্ষা', 'বটমলি হোম গার্লস হাই স্কুল (১৯৯৭); শহীদ আনোয়ার গার্লস কলেজ থেকে HSC (১৯৯৯); ঢাকা সিটি কলেজ থেকে হিসাববিজ্ঞানে স্নাতক ও স্নাতকোত্তর; ঢাবিতে Japan Studies-এ MA-তে ভর্তি'),
          ('পেশা', '**ঢাকা ওয়াসা**-র হিসাবরক্ষক'), ('কৃতিত্ব', '**২০১২** সালে **প্রথম বাংলাদেশি নারী** হিসেবে এভারেস্ট জয়')),
    UL('Superman-অভিনেতা **Christopher Reeve** ১৯৯৬-এর Democratic National Convention-এ বলেন: অনেক স্বপ্ন প্রথমে অসম্ভব, তারপর অসম্ভাব্য, আর ইচ্ছাশক্তি জাগালে অবশ্যম্ভাবী মনে হয় — নিশাতের জীবনেও তা ঘটেছে',
       '**২০০৩**-এ প্রথম পাহাড়: **৯৬৭ ফুট** উঁচু **কেওক্রাডং** — আয়োজন **২৯ মে ২০০৩**, Edmund Hillary ও Tenzing Norgay-র এভারেস্ট জয়ের **৫০তম বার্ষিকী** উপলক্ষে; প্রস্তুতিতে তিন দিন **১৫ কেজি** ব্যাকপ্যাক নিয়ে ঢাকার রাস্তায় হাঁটা',
       '**২০০৬**-এ **Bangladesh Mountaineering and Trekking Club (BMTC)**-এ যোগ; **২০০৭**-এ দার্জিলিংয়ের **Himalayan Mountaineering Institute**-এ basic course',
       '**Nepal-Bangladesh Friendship Peak** — দুই দেশের পর্বতারোহীরা প্রথম একসঙ্গে জয় করেন বলে এই নাম; দলনেতা **M. A. Mohit**',
       'এভারেস্ট অভিযানে Plan International বাংলাদেশের **"Because I am a Girl"** ক্যাম্পেইনের অ্যাম্বাসেডর; বার্তা: ছেলেরা যা পারে, মেয়েরাও পারে',
       'বিডিনিউজ২৪-এ Afsan Chowdhury (২৬ মে ২০১২): নিশাত নেপালের দিক থেকে **৮,৮৫০ মিটার (২৯,০৩৫ ফুট)** চূড়ায়; সঙ্গী M A Mohit — এভারেস্টজয়ী **দ্বিতীয় বাংলাদেশি**'),
    FACTS('**Wasfia Nazreen** — **প্রথম বাংলাদেশি নারী ও প্রথম বাঙালি** হিসেবে **Seven Summits** জয়', 'এভারেস্টে পৌঁছান **২৬ মে ২০১২**; Seven Summits campaign ছিল বাংলাদেশের **স্বাধীনতার ৪০ বছর** উদযাপনে',
          'এভারেস্টের আগে সাত শৃঙ্গের দুটি জয় করেছিলেন; তৃতীয় লক্ষ্য ছিল এভারেস্ট', h='Wasfia Nazreen (Activity F)'),
    WORDS(('icon', 'প্রতীক/আদর্শ ব্যক্তিত্ব'), ('trekking', 'দীর্ঘ পায়ে হাঁটা অভিযান'), ('perseverance', 'অধ্যবসায়'), ('campaign', 'প্রচারাভিযান'), ('calamitous', 'বিপর্যয়কর'), ('inevitable', 'অবশ্যম্ভাবী'), h='শব্দার্থ'),
    VERIFY('পাঠে এভারেস্টের উচ্চতা ৮,৮৫০ মিটার (২৯,০৩৫ ফুট) — ২০১২-র সংবাদ অনুযায়ী। নেপাল-চীন ২০২০ সালে যৌথভাবে নতুন উচ্চতা ঘোষণা করে ৮,৮৪৮.৮৬ মিটার। EFT-ভিত্তিক প্রশ্নে ৮,৮৫০; সাধারণ জ্ঞানের প্রশ্নে ৮,৮৪৮.৮৬ মিটার।'),
    SUMMARY('নিশাত: ৫ জানুয়ারি ১৯৮১, তেওরি, রামগঞ্জ, লক্ষ্মীপুর; ২০১২-তে প্রথম বাংলাদেশি নারী এভারেস্টজয়ী', 'কেওক্রাডং ৯৬৭ ফুট, ২৯ মে ২০০৩; BMTC ২০০৬; HMI দার্জিলিং ২০০৭',
            'M A Mohit — দলনেতা, দ্বিতীয় বাংলাদেশি এভারেস্টজয়ী', 'Wasfia Nazreen — Seven Summits, এভারেস্ট ২৬ মে ২০১২'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-4-14', 'নিশাত = লক্ষ্মীপুর; ওয়াসফিয়া = Seven Summits — গুলিয়ে ফেলবেন না।', 'Scaling a Mountain Peak।', [
    ('Nishat Mazumder was born in a village in the district of —', 'Lakshmipur', W('Noakhali', 'Feni', 'Chandpur'), 'তেওরি, রামগঞ্জ, লক্ষ্মীপুর।', True),
    ('Nishat Mazumder\'s date of birth as given in EFT is —', '5 January 1981', W('5 January 1980', '19 May 1981', '15 January 1981'), '৫ জানুয়ারি ১৯৮১।', True),
    ('Nishat Mazumder is the — of four siblings.', 'second', W('eldest', 'third', 'youngest'), 'দ্বিতীয়।', False),
    ('Nishat Mazumder works as an accountant at —', 'Dhaka WASA', W('Bangladesh Bank', 'BRAC', 'Dhaka City Corporation'), 'ঢাকা ওয়াসা।', True),
    ('Nishat earned her bachelor\'s and master\'s degrees in Accounting from —', 'Dhaka City College', W('University of Dhaka', 'Eden Mohila College', 'Shahid Anwar Girls\' College'), 'ঢাকা সিটি কলেজ।', False),
    ('According to the lesson, Nishat\'s role model was —', 'her mother', W('her father', 'M. A. Mohit', 'Wasfia Nazreen'), 'মা আশুরা মজুমদার।', True),
    ('"So many of our dreams at first seem impossible…" — EFT quotes this from —', 'Christopher Reeve', W('APJ Abdul Kalam', 'Edmund Hillary', 'Martin Luther King Jr.'), 'Christopher Reeve, ১৯৯৬।', True),
    ('Nishat\'s first climb in 2003 was —', 'Keokradong', W('Tajingdong', 'Everest', 'Nepal-Bangladesh Friendship Peak'), 'কেওক্রাডং।', True),
    ('According to EFT, Keokradong is — high.', '967 feet', W('967 metres', '3,172 metres', '1,052 feet'), '৯৬৭ ফুট (পাঠ অনুযায়ী)।', True),
    ('The Keokradong climb of 29 May 2003 celebrated the 50th anniversary of —', 'Hillary and Tenzing\'s conquest of Everest', W('the independence of Bangladesh', 'the founding of BMTC', 'Nishat\'s birth'), '১৯৫৩-র এভারেস্ট জয়ের ৫০ বছর।', True),
    ('Nishat joined Bangladesh Mountaineering and Trekking Club in —', '2006', W('2003', '2007', '2012'), 'BMTC ২০০৬।', True),
    ('Nishat completed a basic training course at the Himalayan Mountaineering Institute in —', 'Darjeeling', W('Kathmandu', 'Shimla', 'Thimphu'), 'দার্জিলিং, ২০০৭।', True),
    ('Nishat was an ambassador of the "Because I am a Girl" campaign of —', 'Plan International', W('UNICEF', 'BRAC', 'Save the Children'), 'Plan International-এর বাংলাদেশ চ্যাপ্টার।', True),
    ('M. A. Mohit is described in EFT as —', 'the second Bangladeshi to have conquered Everest', W('the first Bangladeshi to climb Everest', 'Nishat\'s brother', 'the founder of Plan International'), 'দ্বিতীয় বাংলাদেশি এভারেস্টজয়ী।', True),
    ('The first Bangladeshi woman and first Bengali to climb the Seven Summits is —', 'Wasfia Nazreen', W('Nishat Mazumder', 'Sabina Akhter', 'Ashura Mazumder'), 'Wasfia Nazreen।', True),
    ('According to EFT, Wasfia Nazreen reached Everest on —', 'May 26, 2012', W('May 29, 2003', 'May 19, 2012', 'May 26, 2010'), '২৬ মে ২০১২।', True),
    ('Wasfia\'s Seven Summits campaign celebrated —', '40 years of the independence of Bangladesh', W('50 years of Everest conquest', 'the birth of Nishat', 'International Women\'s Day'), 'স্বাধীনতার ৪০ বছর।', False),
    ('"Perseverance" means —', 'continued effort despite difficulty', [('quick success', 'সাফল্য নয়, চেষ্টার ধারাবাহিকতা।'), ('laziness', 'উল্টো অর্থ।'), ('good luck', 'ভাগ্যের ব্যাপার নয়।')], 'Perseverance = অধ্যবসায়।', False),
])

# =====================================================================
# U7·L3 The Unbeaten Girls  (en-4-15)
# =====================================================================
B.lesson('en-4-15', [
    H('The Unbeaten Girls — এক নজরে'),
    P('প্রচলিত সমাজে ছেলেদের হাতে গাড়ি-বল, মেয়েদের হাতে পুতুল — এই ধারণা যে মেয়েরা কম সক্ষম, তা ভুল প্রমাণ করেছে **ময়মনসিংহ জেলার ধোবাউড়া উপজেলার কলসিন্দুর** গ্রামের মেয়েরা। কিছুদিন আগেও গ্রামে বিদ্যুৎ ছিল না; মেয়েদের সাফল্যের স্বীকৃতিতে সরকার গ্রামে বিদ্যুৎ দেয় — গ্রামটি এখন "footballer factory" ও নারীশক্তির প্রতীক।'),
    TABLE('খেলোয়াড় (পাঠে উল্লিখিত পরিচয়)', ['নাম', 'তথ্য'],
          ('Sanjida Akhter', '২০১৪-তে এশিয়ার অনূর্ধ্ব-১৬ সম্ভাবনাময় নারী খেলোয়াড়দের মধ্যে সপ্তম'), ('Mariya Manda', 'অনূর্ধ্ব-১৫ নারী দলের অধিনায়ক (২০১৭)'),
          ('Shamsunnahar (senior)', 'SAFF অনূর্ধ্ব-১৫ নারী চ্যাম্পিয়নশিপ ২০১৭-তে ভারতের বিপক্ষে একমাত্র গোল'), ('Shamsunnahar (junior)', 'অনূর্ধ্ব-১৫ জাতীয় দলের অধিনায়ক (২০১৯)'),
          ('Tahura Khatun', '২০২১ পর্যন্ত আন্তর্জাতিক ম্যাচে ৪০ গোল'), ('অন্যান্য', 'Sabina Akhter, Shiuli Azim, Marzia, Mahmuda, Nazma, Sajeda, Rozina, Taniya, Rupa, Kalpana, Purnima Vaskar')),
    TIMELINE('সাফল্যের ধারা',
             ('2013–15', 'বঙ্গমাতা গোল্ড কাপ হ্যাটট্রিক', 'কলসিন্দুর সরকারি প্রাথমিক বিদ্যালয় — ২০১৩, ২০১৪, ২০১৫'),
             ('2014–19', 'জাতীয় গ্রীষ্মকালীন ক্রীড়া — চারবার চ্যাম্পিয়ন', 'কলসিন্দুর মাধ্যমিক বিদ্যালয় — ২০১৪, ২০১৫, ২০১৭, ২০১৯'),
             ('2015', 'AFC অনূর্ধ্ব-১৪ আঞ্চলিক চ্যাম্পিয়ন', 'নেপালে; দলে কলসিন্দুরের আধিপত্য'),
             ('2016', 'AFC অনূর্ধ্ব-১৪ আঞ্চলিক, তাজিকিস্তান', 'বিজয়ী দলে অধিনায়ক ও সর্বোচ্চ গোলদাতাসহ কলসিন্দুরের ৮ জন'),
             ('2018', '১ম SAFF অনূর্ধ্ব-১৮ নারী চ্যাম্পিয়নশিপ, ভুটান', 'অপরাজিত চ্যাম্পিয়ন; এরপর স্কুল জাতীয়করণ'),
             ('2019', 'লাওসের সঙ্গে যৌথ চ্যাম্পিয়ন', 'জাতীয় নারী দল — নেতৃত্বে কলসিন্দুরের মেয়েরা'), ('2019–20', 'আন্তঃকলেজ (UMA) গেমসে মেয়েদের ফুটবল চ্যাম্পিয়ন', 'কলসিন্দুরের মেয়েরা'),
             ('2021', 'আরও ৬৫ জন মেয়েকে প্রস্তুত করা হচ্ছে', 'Mala Rani Sarkar-এর ভাষ্য')),
    TABLE('পেছনের মানুষ', ['নাম', 'ভূমিকা'],
          ('Minati Rani Sheel', 'কলসিন্দুর সরকারি প্রাথমিক বিদ্যালয়ের প্রধান শিক্ষক'), ('Mohammad Mafiz Uddin', 'একই বিদ্যালয়ের সহকারী শিক্ষক; অভিভাবকদের রাজি করান'),
          ('Mala Rani Sarkar', 'ইতিহাসের সহকারী অধ্যাপক; পরে কলসিন্দুর নারী দলের Team Manager'), ('Juel Mia', 'Mala Rani-র সহকর্মী, কোচিংয়ে সহায়তা'),
          ('Jalaluddin', 'তৎকালীন মাধ্যমিক বিদ্যালয়ের প্রধান শিক্ষক'), ('Golam Robbani Choton', 'বাংলাদেশ জাতীয় নারী ফুটবল দলের কোচ')),
    P('শুরুতে বুট-জার্সি ছিল না — সালোয়ার-কামিজ পরে খেলত, অপুষ্টিতেও ভুগত। এখন অটোরিকশাচালকেরাও তাদের কাছ থেকে ভাড়া নেন না — গ্রামের গর্ব বলে।'),
    WORDS(('counterpart', 'সমকক্ষ (peer)'), ('illuminate', 'আলোকিত করা'), ('emerge', 'আবির্ভূত হওয়া'), ('mentor', 'পরামর্শদাতা/অভিভাবকসম গুরু'), ('clinch', 'নিশ্চিত করা/জিতে নেওয়া'),
          ('epic', 'মহাকাব্য — দীর্ঘ আখ্যান'), ('adversity', 'প্রতিকূলতা'), ('inhibition', 'সংকোচ'), ('groom', 'প্রস্তুত/তৈরি করা'), ('intrinsic', 'অন্তর্নিহিত'), h='শব্দার্থ (Activity C–D)'),
    SUMMARY('কলসিন্দুর — ধোবাউড়া, ময়মনসিংহ; সাফল্যে বিদ্যুৎ ও স্কুল জাতীয়করণ', 'বঙ্গমাতা কাপ ২০১৩-১৫ হ্যাটট্রিক; AFC U-14 ২০১৫ নেপাল; SAFF U-18 ২০১৮ ভুটান (অপরাজিত)',
            'মিনতি রানী শীল ও মফিজ উদ্দিন → মালা রানী সরকার → গোলাম রব্বানী ছোটন'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-4-15', 'কলসিন্দুর = ধোবাউড়া = ময়মনসিংহ; টুর্নামেন্ট-সাল জোড়ায় মুখস্থ।', 'The Unbeaten Girls।', [
    ('Kalsindur is a village in —', 'Dhobaura upazila, Mymensingh', W('Haluaghat upazila, Mymensingh', 'Ramganj upazila, Lakshmipur', 'Kalmakanda upazila, Netrokona'), 'ধোবাউড়া, ময়মনসিংহ।', True),
    ('In recognition of the girls\' success, the government provided Kalsindur with —', 'electricity', W('a stadium', 'a railway station', 'a hospital'), 'বিদ্যুৎ।', True),
    ('The lesson calls Kalsindur a "footballer factory" and a symbol of —', 'girl power', W('industrial growth', 'tourism', 'political power'), 'নারীশক্তি।', False),
    ('Which Kalsindur player was 7th among the under-16 promising female players of Asia in 2014?', 'Sanjida Akhter', W('Mariya Manda', 'Tahura Khatun', 'Sabina Akhter'), 'Sanjida Akhter।', True),
    ('Mariya Manda was captain of the Under-15 Female Football Team in —', '2017', W('2014', '2019', '2021'), '২০১৭।', True),
    ('Who scored the solitary goal against India to ensure the SAFF Under-15 Women Championship in 2017?', 'Shamsunnahar (senior)', W('Shamsunnahar (junior)', 'Tahura Khatun', 'Kalpana Akhter'), 'Shamsunnahar senior।', True),
    ('According to the lesson, Tahura Khatun scored — goals in international matches till 2021.', '40', W('14', '65', '24'), '৪০ গোল।', True),
    ('Kalsindur Government Primary School had a hat-trick of championships in the Bangamata Gold Cup in —', '2013, 2014 and 2015', W('2014, 2015 and 2017', '2015, 2016 and 2018', '2012, 2013 and 2014'), '২০১৩-১৫।', True),
    ('Kalsindur Secondary School became champions in the National Summer Sports Competition —', 'four times', W('three times', 'twice', 'five times'), '২০১৪, ২০১৫, ২০১৭, ২০১৯।', True),
    ('Bangladesh girls won the AFC Under-14 Regional Football Championship 2015 in —', 'Nepal', W('Tajikistan', 'Bhutan', 'Hong Kong'), 'নেপাল।', True),
    ('The 1st SAFF Under-18 Women Championship (2018), won unbeaten by Bangladesh, was held in —', 'Bhutan', W('Nepal', 'India', 'Sri Lanka'), 'ভুটান।', True),
    ('The head teacher of Kalsindur Government Primary School was —', 'Minati Rani Sheel', W('Mala Rani Sarkar', 'Mohammad Mafiz Uddin', 'Jalaluddin'), 'মিনতি রানী শীল।', True),
    ('Mohammad Mafiz Uddin was —', 'an assistant teacher at Kalsindur Government Primary School', W('the coach of the national team', 'an Assistant Professor of History', 'the Team Manager'), 'সহকারী শিক্ষক।', True),
    ('Mala Rani Sarkar, who later became Team Manager, was —', 'an Assistant Professor of History', W('the head teacher of the primary school', 'a national team player', 'a local politician'), 'ইতিহাসের সহকারী অধ্যাপক।', True),
    ('The coach of the Bangladesh Women\'s National Football Team who mentored the girls was —', 'Golam Robbani Choton', W('Juel Mia', 'Jalaluddin', 'Mafiz Uddin'), 'গোলাম রব্বানী ছোটন।', True),
    ('In the lesson, the word "counterpart" is closest in meaning to —', 'peer', [('enemy', 'Enemy = শত্রু।'), ('competitor', 'প্রতিযোগী — সমকক্ষতার অর্থ বোঝায় না।'), ('opponent', 'প্রতিপক্ষ।')], 'Counterpart = অন্য পক্ষের সমকক্ষ ব্যক্তি।', False),
    ('Which word is an antonym of "clinch" as listed in the lesson\'s exercise?', 'disown', [('confirm', 'সমার্থক।'), ('approve', 'প্রায় সমার্থক।'), ('secure', 'সমার্থক — clinch a title = secure a title।')], 'Clinch = নিশ্চিত করা/জিতে নেওয়া; বইয়ের অনুশীলনে antonym disown।', False),
    ('Choose the correct indirect speech: Mala Rani Sarkar says, "It\'s a small token of recognition."', 'Mala Rani Sarkar says that it is a small token of recognition.', [('Mala Rani Sarkar says that it was a small token of recognition.', 'Reporting verb present (says) — tense বদলায় না।'), ('Mala Rani Sarkar said that it is a small token of recognition.', 'Reporting verb বদলানো যাবে না।'), ('Mala Rani Sarkar says it had been a small token of recognition.', 'Past perfect অপ্রয়োজনীয়।')], 'Reporting verb present/future হলে reported speech-এর tense অপরিবর্তিত থাকে।', True),
])

# =====================================================================
# U8·L1 Family Relationship  (en-5-10)
# =====================================================================
B.lesson('en-5-10', [
    H('Family Relationship — এক নজরে'),
    P('গ্রিক দার্শনিক **Aristotle** বলেছেন, মানুষ স্বভাবতই **সামাজিক জীব (social animals)** — অর্থাৎ সহজাত প্রবৃত্তিতে মানুষ সঙ্গ খোঁজে, সম্পর্ক গড়ে; বন্য প্রাণীর মতো সঙ্গ, শারীরিক ও আবেগিক সহায়তার জন্য। তবে প্রাণীর সঙ্গে পার্থক্য — মানুষের সম্পর্ক তার অস্তিত্বকে অর্থ দেয় এবং পড়াশোনা, কর্মক্ষেত্র ও পেশায় ভালো করতে অনুপ্রাণিত করে।'),
    TABLE('সম্পর্কের ধরন (পাঠ অনুযায়ী)', ['ধরন', 'উদাহরণ'],
          ('familial ও intimate', 'রক্ত ও বিবাহসূত্রে'), ('social', 'বন্ধুদের সঙ্গে'), ('স্কুলে', 'সহপাঠীদের সঙ্গে ঘনিষ্ঠ বন্ধন'),
          ('কর্মক্ষেত্রে', 'পেশাগত থেকে দ্রুত সামাজিক হয়ে উঠতে পারে'), ('অন্যান্য', 'মানুষ ও প্রাণী; শিশু ও তার খেলনা যা সে হাতছাড়া করতে পারে না')),
    UL('পরিবারহীন মানুষ **একাকীত্ব ও বিচ্ছিন্নতার** কষ্ট পায় — হাসি-কান্না ভাগ করার কেউ থাকে না', 'আনন্দ ভাগ করলে তা **দ্বিগুণ (redoubles)** হয়; দুঃখ ভাগ করলে **কমে** — তাই সম্পর্ক আবেগিক স্বাস্থ্যের জন্য প্রয়োজন',
       'সম্পর্ক গড়ার শর্ত: পারস্পরিক **trust, respect**, প্রয়োজনে **love**; **selfish ও possessive** হলে কার্যকর সম্পর্ক হয় না', 'ঝগড়া-বিবাদ সবার জন্যই দুঃখ ও ক্ষতি আনে'),
    WORDS(('familial', 'পারিবারিক'), ('intimate', 'ঘনিষ্ঠ'), ('instinct', 'সহজাত প্রবৃত্তি'), ('foster', 'লালন/গড়ে তোলা'), ('redouble', 'দ্বিগুণ হওয়া'), ('possessive', 'অধিকারপরায়ণ'), ('isolation', 'বিচ্ছিন্নতা'), h='শব্দার্থ'),
    SUMMARY('Aristotle: Humans are by nature social animals', 'সম্পর্ক: familial/intimate, social, school, workplace, মানুষ-প্রাণী', 'শর্ত: trust, respect, love; selfish/possessive নয়', 'আনন্দ ভাগে দ্বিগুণ, দুঃখ ভাগে কমে'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-10', 'এই লেসনে তথ্য কম — উক্তি, সম্পর্কের ধরন ও শব্দার্থে জোর দিন।', 'Family Relationship।', [
    ('"Humans are by nature social animals" — EFT attributes this to —', 'Aristotle', [('Plato', 'Plato Aristotle-এর শিক্ষক; উক্তিটি Aristotle-এর।'), ('Socrates', 'উক্তিটি তাঁর নয়।'), ('Charles Darwin', 'জীববিজ্ঞানী; উক্তিটি তাঁর নয়।')], 'Aristotle — গ্রিক দার্শনিক।', True),
    ('According to Aristotle\'s idea in the lesson, human beings seek the company of others —', 'by instinct', W('only for money', 'only when they are sick', 'because laws force them'), 'সহজাত প্রবৃত্তিতে।', False),
    ('Unlike animals, human relationships —', 'give meaning to their existence and inspire them to do well', W('are formed only for food', 'never change', 'are only formed by blood'), 'অস্তিত্বের অর্থ ও অনুপ্রেরণা।', False),
    ('Relationships formed by blood and by marriage are called —', 'familial and intimate', W('professional', 'social only', 'temporary'), 'Familial and intimate।', True),
    ('According to the lesson, relationships formed in workplaces may quickly change from —', 'professional to social', W('social to hostile', 'familial to professional', 'intimate to formal'), 'Professional → social।', False),
    ('According to the lesson, a person who has no family feels the pain of —', 'loneliness and isolation', W('poverty only', 'too many responsibilities', 'physical illness'), 'একাকীত্ব ও বিচ্ছিন্নতা।', True),
    ('When we share our joy with someone, it —', 'redoubles', W('lessens', 'disappears', 'remains the same'), 'আনন্দ দ্বিগুণ; দুঃখ কমে।', True),
    ('When someone shares our sorrow, it —', 'lessens', W('redoubles', 'turns into anger', 'becomes permanent'), 'দুঃখ কমে।', False),
    ('Which is NOT mentioned as a precondition of a good relationship?', 'wealth', [('trust', 'পাঠে উল্লিখিত শর্ত।'), ('respect', 'পাঠে উল্লিখিত শর্ত।'), ('love', 'প্রয়োজনে love — উল্লিখিত।')], 'শর্ত: trust, respect, love; সম্পদের কথা নেই।', True),
    ('According to the lesson, we cannot establish an effective relationship if we are —', 'selfish and possessive', W('kind and caring', 'honest and trustworthy', 'patient and polite'), 'Selfish ও possessive হলে নয়।', False),
    ('The word "familial" means —', 'related to a family', [('familiar or well known', 'Familiar ≠ familial — বানানের ফাঁদ।'), ('friendly to strangers', 'অপ্রাসঙ্গিক।'), ('related to fame', 'Fame-এর সঙ্গে সম্পর্ক নেই।')], 'Familial = পারিবারিক।', True),
    ('"Relationships can also be fostered in workplaces." Here "fostered" means —', 'developed or encouraged', [('destroyed', 'উল্টো অর্থ।'), ('adopted as a child', 'Foster child অর্থ এখানে প্রযোজ্য নয়।'), ('forbidden', 'নিষেধ অর্থ নয়।')], 'Foster = লালন করা, গড়ে তোলা।', False),
    ('"Possessive" in a relationship means —', 'wanting to control someone completely', [('generous', 'উল্টো স্বভাব।'), ('owning a lot of property', 'আক্ষরিক অর্থ, এখানে প্রযোজ্য নয়।'), ('very polite', 'অপ্রাসঙ্গিক।')], 'Possessive = অধিকারপরায়ণ।', False),
    ('The antonym of "intimate" is —', 'distant', [('close', 'সমার্থক।'), ('familiar', 'প্রায় সমার্থক।'), ('friendly', 'প্রায় সমার্থক।')], 'Intimate = ঘনিষ্ঠ; বিপরীত distant/remote।', False),
    ('Choose the correct sentence (relationships, emotional health).', 'Relationships are needed for our emotional health.', [('Relationships is needed for our emotional health.', 'Plural subject → are।'), ('Relationships are need for our emotional health.', 'Passive-এ V3 needed।'), ('Relationships are needing for our emotional health.', 'Passive অর্থে continuous ভুল।')], 'Plural subject + are + V3 (passive)।', False),
])

# =====================================================================
# U8·L2 Warmth in Relationships  (en-5-11)
# =====================================================================
B.lesson('en-5-11', [
    H('Warmth in Relationships — "Those Winter Sundays"'),
    FACTS('কবি: **Robert Hayden** — জন্ম **১৯১৩, Detroit, USA**, দরিদ্র পরিবারে; দৃষ্টিশক্তির সমস্যায় কঠিন শৈশব; আংশিক **foster parents**-এর কাছে বড় হন; মৃত্যু **১৯৮০**',
          'কৃষ্ণাঙ্গ আমেরিকান — কৃষ্ণাঙ্গ অভিজ্ঞতা ও ইতিহাস নিয়ে লিখেছেন', 'কবিতাটি একটি **sonnet** (১৪ লাইন) — শৈশবের স্মৃতি', h='কবি ও কবিতা'),
    P('বক্তা (প্রাপ্তবয়স্ক ছেলে) শৈশবের কথা মনে করছে: রবিবারেও — বিশ্রামের দিনেও — বাবা নীলচে-কালো ঠান্ডায় সবার আগে উঠে, সারা সপ্তাহের খাটুনিতে ফাটা হাতে চাপা-দেওয়া আগুন জ্বালাতেন; কেউ কখনো তাঁকে ধন্যবাদ দেয়নি। ঘর গরম হলে বাবা ডাকতেন, ছেলে ধীরে উঠত — বাড়ির "দীর্ঘস্থায়ী রাগ"-এর ভয়ে বাবার সঙ্গে নির্লিপ্তভাবে কথা বলত, অথচ বাবা ঠান্ডা তাড়িয়েছেন, ছেলের ভালো জুতাও পালিশ করেছেন। শেষে আক্ষেপ: ভালোবাসার কঠোর ও নিঃসঙ্গ দায়িত্বের কথা তখন সে কী বুঝত!'),
    MATCH('কবিতার শব্দ ↔ প্রসঙ্গগত অর্থ (পাঠের Activity C)',
          ('blueblack', 'নীলের আভাযুক্ত গাঢ় কালো'), ('banked (fires)', 'বইয়ের অর্থ: চারপাশে দেয়ালে ঘেরা/সুরক্ষিত — অর্থাৎ ছাই চাপা দিয়ে রাখা আগুন'),
          ('chronic', 'দীর্ঘস্থায়ী, নিরাময়হীন রোগের মতো'), ('indifferently', 'আবেগহীনভাবে'), ('austere', 'নিরাভরণ, সাদামাটা, আনন্দহীন'), ('offices', 'দায়িত্ব ও কর্তব্য')),
    TABLE('Alliteration (একই ব্যঞ্জনধ্বনির পুনরাবৃত্তি)', ['লাইন', 'ধ্বনি', 'উদাহরণ'],
          ('২–৩', '/k/', 'clothes, cold, cracked'), ('৪', 'w', 'weekday weather'), ('৫', 'b', 'banked … blaze'), ('৭', 'w', 'When … warm … would (পাঠের সংকেত W-w-w)'), ('১৪', 'l', 'love\'s … lonely')),
    UL('মূল theme: প্রাপ্তবয়স্ক **perspective** থেকে বক্তা বোঝে বাবাকে সে taken for granted করেছিল; এখন বোঝে অন্যের জন্য **sacrifice** কী', 'নিজের **childhood**-এর দিকে তাকিয়ে বাবাকে **appreciate** করে; কবিতাটি একই সঙ্গে nostalgic ও **regretful**',
       '"Sundays too" = সপ্তাহের ছুটির দিনেও বাবা ভোরে উঠতেন — একঘেয়ে পরিশ্রমী জীবনের ইঙ্গিত', 'কবিতাটি ১৯৬০-এর দশকে প্রকাশিত, কপিরাইটভুক্ত — তাই এখানে পূর্ণ পাঠ দেওয়া হয়নি; বই থেকে পড়ুন'),
    SUMMARY('Robert Hayden (1913–1980), Detroit; কৃষ্ণাঙ্গ আমেরিকান কবি', 'Those Winter Sundays — sonnet; বাবার নীরব ভালোবাসা ও ছেলের আক্ষেপ', 'শব্দ: blueblack, banked, chronic, indifferently, austere, offices', 'Alliteration: clothes-cold-cracked (/k/)'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-11', 'কবি, জন্মস্থান ও alliteration-এর উদাহরণ একসঙ্গে মনে রাখুন।', 'Those Winter Sundays।', [
    ('"Those Winter Sundays" was written by —', 'Robert Hayden', [('Robert Frost', 'Frost-এর কবিতা নয় — নামের মিলে ফাঁদ।'), ('Langston Hughes', 'Hughes-এর কবিতা "Dreams" (U6·L2)।'), ('Robert Burns', 'স্কটিশ কবি; অন্য লেসন।')], 'Robert Hayden।', True),
    ('Robert Hayden was born in —', 'Detroit, USA', W('Harlem, New York', 'Chicago, USA', 'London, UK'), 'Detroit, ১৯১৩।', True),
    ('Robert Hayden\'s birth and death years given in EFT are —', '1913 and 1980', W('1902 and 1967', '1896 and 1953', '1913 and 1990'), '১৯১৩–১৯৮০।', True),
    ('In his childhood, Robert Hayden was raised in part by —', 'foster parents', W('his grandparents only', 'his teachers', 'an orphanage'), 'Foster parents।', False),
    ('"Those Winter Sundays" is described in EFT as —', 'a sonnet', W('a ballad', 'an elegy', 'an epic'), 'Sonnet, শৈশবের স্মৃতি।', True),
    ('The speaker of "Those Winter Sundays" is —', 'a grown-up son remembering his father', W('the father himself', 'a neighbour', 'the mother'), 'প্রাপ্তবয়স্ক ছেলে।', True),
    ('In the poem, the phrase "Sundays too" suggests that the father —', 'got up early even on his day of rest', W('worked only on Sundays', 'went to church on Sundays', 'slept late on Sundays'), 'ছুটির দিনেও কাজ।', False),
    ('In the poem, the father\'s hands were cracked because of —', 'labour in the weekday weather', W('an accident', 'old age only', 'polishing shoes'), 'সপ্তাহভর খাটুনি।', False),
    ('According to the poem, how was the father thanked for his work?', 'No one ever thanked him.', W('His son thanked him every Sunday.', 'His wife gave him gifts.', 'The neighbours praised him.'), 'কেউ ধন্যবাদ দেয়নি।', True),
    ('In the context of the poem, "offices" means —', 'duties and responsibilities', [('workplaces', 'আক্ষরিক অর্থ; প্রসঙ্গে নয়।'), ('government posts', 'প্রসঙ্গে নয়।'), ('rooms', 'প্রসঙ্গে নয়।')], 'Love\'s austere and lonely offices = ভালোবাসার কঠোর, নিঃসঙ্গ দায়িত্ব।', True),
    ('In the context of the poem, "austere" means —', 'plain and without pleasure', [('rich and colourful', 'উল্টো অর্থ।'), ('very cold', 'Austere ঠান্ডা বোঝায় না।'), ('angry', 'অপ্রাসঙ্গিক।')], 'Austere = সাদামাটা, কঠোর, আনন্দহীন।', False),
    ('In the poem, "chronic angers" refers to anger that is —', 'ongoing and persistent', [('sudden and brief', 'উল্টো অর্থ।'), ('hidden', 'Chronic লুকানো বোঝায় না।'), ('funny', 'অপ্রাসঙ্গিক।')], 'Chronic = দীর্ঘস্থায়ী।', False),
    ('The son spoke "indifferently" to his father, which means —', 'without emotional engagement', [('very lovingly', 'উল্টো অর্থ।'), ('loudly', 'আওয়াজের কথা নয়।'), ('in a different language', 'Different শব্দের সঙ্গে মিলের ফাঁদ।')], 'Indifferently = নির্লিপ্তভাবে।', True),
    ('The words "clothes", "cold" and "cracked" in the poem are an example of —', 'alliteration', [('simile', 'Like/as দিয়ে তুলনা নেই।'), ('personification', 'মানুষের গুণ আরোপ করা হয়নি।'), ('rhyme', 'শব্দের শেষ ধ্বনি মিলছে না, শুরুর ধ্বনি মিলছে।')], 'শুরুর একই ব্যঞ্জনধ্বনি (/k/) = alliteration।', True),
    ('The main feeling of the speaker at the end of the poem is —', 'regret for not understanding his father\'s love', W('anger at his father', 'joy at winter', 'fear of the cold'), 'Regretful ও nostalgic।', False),
    ('"Blueblack" in the poem describes —', 'a deep black colour with a hint of blue', W('a bruise', 'a blue sky', 'a black dog'), 'Blueblack cold — ভোরের নীলচে-কালো ঠান্ডা।', False),
])

# =====================================================================
# U8·L3 A Mother in Mannville  (en-5-12)
# =====================================================================
B.lesson('en-5-12', [
    H('A Mother in Mannville — লেখক'),
    TABLE('Marjorie Kinnan Rawlings (পাঠ অনুযায়ী)', ['বিষয়', 'তথ্য'],
          ('জন্ম', '**৮ আগস্ট ১৮৯৬, Washington, D.C.**'), ('শৈশবের সাফল্য', '১৯০৭-এ Washington Post-এ ছোটগল্পের জন্য **২ ডলার** পুরস্কার'),
          ('শিক্ষা', '**University of Wisconsin** — ইংরেজিতে BA'), ('বিবাহ', 'Charles Rawlings (লেখক) — নিউইয়র্কে সাংবাদিকতা; **১৯৩৩**-এ বিচ্ছেদ; **১৯৪১**-এ St. Augustine, Florida-র হোটেলমালিক **Norton Baskin**'),
          ('ধারা', '**local/regional literature** — গ্রামীণ দক্ষিণ আমেরিকা; বিষয় সরল, কিন্তু theme সর্বজনীন'), ('মৃত্যু', '**১৪ ডিসেম্বর ১৯৫৩**, cerebral hemorrhage')),
    H('গল্পের সারাংশ (নিজের ভাষায়)'),
    OL('শরতে লেখিকা (কথক, **first person**) Carolina পাহাড়ের এক এতিমখানার খামারের আধা মাইল দূরে কেবিন ভাড়া নেন — নির্জনে লেখা, উপক্রান্তীয় অঞ্চলে দীর্ঘদিন থাকার ম্যালেরিয়া সারানো, আর অক্টোবরের ম্যাপল-কুমড়া-আখরোটের টানে',
       'কাঠ কাটতে আসে প্রায় বারো বছরের ছোটখাটো, খালি পায়ের ছেলে **Jerry** — তার যুক্তি, কাঠ কাটায় আকার কোনো ব্যাপার না; লেখিকার পয়েন্টার কুকুর **Pat** তাকে দেখে ঘেউ করেনি',
       'ঘণ্টা দেড়েকে একজন পূর্ণবয়স্ক মানুষের সমান কাঠ কাটে; লেখিকা এক **quarter** দেন। চার বছর বয়স থেকে সে এতিমখানায়; লেখিকার মনে আসে একটি শব্দ — **integrity**',
       'কুঠারের হাতল ভাঙলে Jerry নিজে দাম দিতে চায় ("আমি অসাবধানে নামিয়েছি"); লেখিকা বলেন দোষ কাঠের — তখনই সে টাকা নেয়। না বলেও আগুনের পাশে খুপরিতে শুকনো কাঠ রাখে, আলগা পাথর বসিয়ে দেয় — "great of heart"-এর অপ্রয়োজনীয়, সদয় কাজ',
       'লেখিকা সপ্তাহান্তে বাইরে গেলে Pat-এর দায়িত্ব Jerry-র; কুয়াশায় সোমবার দুপুরে ফেরেন; Jerry নিজের নাশতা থেকে Pat-কে খাইয়েছে। এক **ডলার** পায়',
       'আগুনের পাশে Jerry বলে, লেখিকাকে দেখতে কিছুটা তার মায়ের মতো — মা থাকেন **Mannville**-এ; প্রতি গ্রীষ্মে দেখা হয়; মা স্কেট ও স্যুট পাঠিয়েছেন; ডলারে মায়ের জন্য **সাদা দস্তানা** কিনবে। লেখিকা মনে মনে মায়ের ওপর ক্ষুব্ধ হন',
       'বিদায়ের দিন Jerry আসে না; এতিমখানার **Miss Clark**-কে লেখিকা টাকা দিয়ে বলেন মা যা পাঠান তা যেন দ্বিগুণ না হয় — Miss Clark অবাক: "ওর মা নেই। ওর স্কেটও নেই।"'),
    UL('মোচড়: Jerry মা ও উপহারের গল্প বানিয়েছিল — মায়ের ভালোবাসার শূন্যতা ও লেখিকার প্রতি টান থেকে', 'Point of view: **first person** (I, we) — কথক ঘটনার অংশ', 'Setting: শরৎ, Carolina পাহাড়, laurel ঝোপ, অক্টোবরের লাল ম্যাপল'),
    WORDS(('integrity', 'সততা ও নীতিনিষ্ঠা'), ('subterfuge', 'ছল, সত্য লুকানোর কৌশল'), ('kindling', 'আগুন ধরানোর শুকনো কাঠকুটো'), ('parturition', 'সন্তান প্রসব'), ('vermilion', 'উজ্জ্বল লাল'),
          ('impelled', 'তাড়িত, বাধ্য'), ('ecstasy', 'পরমানন্দ'), ('duplicate', 'পুনরাবৃত্তি করা/নকল করা'), ('treacherously', 'বিপজ্জনকভাবে'), ('predicated', 'ভিত্তিক'), h='শব্দার্থ'),
    SUMMARY('Rawlings: ৮ আগস্ট ১৮৯৬ — ১৪ ডিসেম্বর ১৯৫৩; regional literature', 'Jerry — ১২ বছর, এতিম, integrity; কুকুর Pat; Miss Clark', 'Twist: "He has no mother. He has no skates."', 'First person point of view'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-12', 'চরিত্রের নাম (Jerry, Pat, Miss Clark) ও টাকার পরিমাণ (quarter, dollar) গুলিয়ে ফেলবেন না।', 'A Mother in Mannville।', [
    ('"A Mother in Mannville" was written by —', 'Marjorie Kinnan Rawlings', W('Robert Hayden', 'Chen Qiyou', 'Elizabeth Barrett Browning'), 'Marjorie Kinnan Rawlings।', True),
    ('Marjorie Kinnan Rawlings was born in —', 'Washington, D.C.', W('St. Augustine, Florida', 'New York', 'Wisconsin'), '৮ আগস্ট ১৮৯৬।', True),
    ('Rawlings received her Bachelor of Arts degree in English from —', 'the University of Wisconsin', W('Harvard University', 'the University of Florida', 'Columbia University'), 'University of Wisconsin।', False),
    ('Rawlings is considered a writer of —', 'local or regional literature', W('science fiction', 'detective fiction', 'war poetry'), 'গ্রামীণ দক্ষিণ আমেরিকা।', True),
    ('According to EFT, Rawlings died in —', '1953', W('1941', '1933', '1896'), '১৪ ডিসেম্বর ১৯৫৩, cerebral hemorrhage।', True),
    ('The orphanage in the story is located —', 'high in the Carolina mountains', W('in the subtropics', 'in Mannville', 'on the coast of Florida'), 'Carolina পাহাড়ে।', True),
    ('The story "A Mother in Mannville" is told from the —', 'first person point of view', W('third person point of view', 'second person point of view', 'point of view of Jerry'), 'কথক "I"।', True),
    ('The name of the narrator\'s pointer dog is —', 'Pat', W('Jerry', 'Clark', 'Mannville'), 'Pat।', True),
    ('When the boy first came to chop wood, he was probably —', 'twelve years old', W('four years old', 'eight years old', 'sixteen years old'), 'প্রায় বারো, কিন্তু ছোটখাটো।', False),
    ('For his first day\'s work, the narrator paid Jerry —', 'a quarter', W('a dollar', 'nothing', 'ten dollars'), 'Quarter; Pat-এর দেখাশোনায় পরে এক ডলার।', True),
    ('The word that came to the narrator\'s mind about Jerry was —', 'integrity', W('poverty', 'loneliness', 'cleverness'), 'Integrity।', True),
    ('When the ax handle broke, Jerry wanted to —', 'pay for the repair himself', W('blame the narrator', 'run away', 'buy a new ax'), 'নিজের দোষ মেনে দাম দিতে চায়।', False),
    ('Jerry said he would use the dollar to buy his mother —', 'a pair of white gloves', W('a pair of skates', 'a puppy', 'a new suit'), 'সাদা দস্তানা।', True),
    ('The person at the orphanage to whom the narrator left money was —', 'Miss Clark', W('Mrs. Rawlings', 'the superintendent', 'Jerry\'s mother'), 'Miss Clark।', True),
    ('The surprising truth revealed at the end of the story is that Jerry —', 'had no mother and no skates', W('was the narrator\'s son', 'had run away to Mannville', 'had stolen the money'), '"He has no mother. He has no skates."', True),
    ('"Size don\'t matter, chopping wood." The standard form of this sentence is —', 'Size doesn\'t matter in chopping wood.', [('Size don\'t matters in chopping wood.', 'Don\'t + matters — দুই ভুল।'), ('Size not matter in chopping wood.', 'Auxiliary বাদ গেছে।'), ('Size didn\'t matters in chopping wood.', 'Did-এর পরে base form matter।')], 'Singular subject (size) → doesn\'t + base verb। Jerry-র কথায় আঞ্চলিক কথ্যরূপ।', True),
    ('In the story, "subterfuge" means —', 'a trick to hide the truth', [('a shelter', 'আশ্রয় নয়।'), ('a reward', 'পুরস্কার নয়।'), ('a confession', 'উল্টো অর্থ — স্বীকারোক্তি।')], 'Subterfuge = ছলচাতুরী।', False),
    ('"Kindling" refers to —', 'small pieces of dry wood used to start a fire', [('a kind of tree', 'গাছ নয়।'), ('kindness', 'Kind শব্দের মিলের ফাঁদ।'), ('a large log', 'বড় গুঁড়ি নয়, ছোট টুকরো।')], 'Kindling = আগুন ধরানোর কাঠকুটো।', False),
    ('"Fog filled the mountain passes so treacherously…" Here "treacherously" means —', 'dangerously', [('beautifully', 'উল্টো ভাব।'), ('slowly', 'গতি নয়।'), ('happily', 'অপ্রাসঙ্গিক।')], 'Treacherous = বিশ্বাসঘাতক; প্রকৃতির ক্ষেত্রে = বিপজ্জনক।', False),
])

# =====================================================================
# U8·L4 Love  (en-5-13)
# =====================================================================
B.lesson('en-5-13', [
    H('Love — প্রজাপতির প্রতীক'),
    UL('প্রজাপতি পরিবর্তন ও বৃদ্ধির প্রতীক — **caterpillar → cocoon → butterfly**', 'গ্রিক পুরাণে **psyche** (অর্থ **"soul"/আত্মা**) প্রজাপতির ডানায় আঁকা হয় — তাই প্রজাপতি আত্মা এবং প্রেম ও সৌন্দর্যের অন্বেষণের সঙ্গে যুক্ত',
       'এশিয়ার কিছু সংস্কৃতিতে প্রেম, রোমান্স, সৌন্দর্য ও স্বাধীনতার প্রতীক; আবার জীবনের **ক্ষণস্থায়িত্বেরও** প্রতীক'),
    H('Butterfly Forever — Chen Qiyou'),
    FACTS('লেখক: **Chen Qiyou**', 'ইংরেজি অনুবাদ: **Shouhua Qi** (বইয়ে ছাপা "Shouhna Qi")', 'বর্ণনাভঙ্গি: **first person**, পুরুষ কথকের দৃষ্টিতে', h='মূল তথ্য'),
    P('বৃষ্টির দিনে কথক ও **Yingzi** বারান্দার নিচে দাঁড়িয়ে; রাস্তার ওপারে সবুজ ডাকবাক্স। কথকের সাদা windbreaker-এর পকেটে দক্ষিণে থাকা মায়ের জন্য চিঠি। ছাতা একটাই, ছোট — Yingzi হেসে চিঠিটা নিয়ে রাস্তা পার হতে যায়। হঠাৎ গাড়ির তীক্ষ্ণ ব্রেকের শব্দ — Yingzi রাতের প্রজাপতির মতো শূন্যে উড়ে ভেজা রাস্তায় পড়ে যায়। বসন্ত, তবু মনে হয় গভীর শরৎ। মাত্র পাঁচ মিটার দূরে, তবু কত দূরে! শেষে চিঠির বিষয় প্রকাশ পায় — কথক মাকে লিখেছিলেন, আগামী মাসে তিনি Yingzi-কে বিয়ে করবেন।'),
    UL('**Imagery**: পাঁচ ইন্দ্রিয়ের (স্বাদ, গন্ধ, স্পর্শ, শ্রবণ, দৃষ্টি) কাছে আবেদনময় বর্ণনা — যেমন ভেজা অ্যাসফল্টে সবুজ-হলুদ-লাল আলোর প্রতিফলন, চশমায় বৃষ্টির ফোঁটা, ব্রেকের তীক্ষ্ণ শব্দ',
       '**Butterfly Effect**: ছোট, তুচ্ছ ঘটনার বড়, অপ্রত্যাশিত ফল — পাঠের উদাহরণে বাংলাদেশে প্রজাপতির ডানা ঝাপটানো থেকে পেরুতে টর্নেডো; গল্পে "একটা মাত্র ছাতা" থেকে ট্র্যাজেডি'),
    H('How Do I Love Thee? — Elizabeth Barrett Browning'),
    QUOTE('How do I love thee? Let me count the ways. / I love thee to the depth and breadth and height / My soul can reach…', 'Elizabeth Barrett Browning, Sonnets from the Portuguese, Sonnet 43 (1850)', '১৮৫০-এ প্রকাশিত — কপিরাইটমুক্ত।',
          'ভালোবাসার গভীরতা-বিস্তার-উচ্চতা মেপে দেখানো; শেষ লাইনে — ঈশ্বর চাইলে মৃত্যুর পরে আরও বেশি ভালোবাসবেন: ভালোবাসা সময় ও স্থান ছাড়িয়ে যায়।'),
    MATCH('কবিতার শব্দ ↔ অর্থ (Activity I)', ('depth', 'ওপর থেকে নিচ পর্যন্ত দূরত্ব'), ('breadth', 'প্রস্থ'), ('ideal grace', 'নিখুঁত সদ্গুণের অবস্থা'), ('strive', 'কোনো কিছুর জন্য প্রবল চেষ্টা'),
          ('faith', 'পূর্ণ আস্থা'), ('saints', 'পবিত্রতার জন্য শ্রদ্ধেয় ধর্মীয় ব্যক্তি'), ('passion', 'তীব্র অনুভূতি'), ('praise', 'প্রশংসা')),
    SUMMARY('Psyche = soul (গ্রিক); প্রজাপতি = আত্মা, প্রেম, ক্ষণস্থায়িত্ব', 'Butterfly Forever — Chen Qiyou; Yingzi; একটি ছাতা; "Ma, I am going to marry Yingzi next month."', 'Imagery = ইন্দ্রিয়গ্রাহ্য বর্ণনা; Butterfly Effect',
            'How Do I Love Thee? — E. B. Browning, Sonnet 43, Sonnets from the Portuguese (1850)'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-13', 'গল্প (Chen Qiyou) আর কবিতা (E. B. Browning) — দুটোর তথ্য আলাদা ছকে রাখুন।', 'Love।', [
    ('In Greek mythology, "psyche" means —', 'soul', W('love', 'butterfly', 'beauty'), 'Psyche = আত্মা; প্রজাপতির ডানায় চিত্রিত।', True),
    ('The correct order of a butterfly\'s transformation mentioned in the lesson is —', 'caterpillar → cocoon → butterfly', W('cocoon → caterpillar → butterfly', 'butterfly → cocoon → caterpillar', 'caterpillar → butterfly → cocoon'), 'Caterpillar → cocoon → butterfly।', False),
    ('"Butterfly Forever" was written by —', 'Chen Qiyou', W('Naguib Mahfouz', 'Shouhua Qi', 'Robert Hayden'), 'Chen Qiyou; অনুবাদ Shouhua Qi।', True),
    ('In "Butterfly Forever", the letter was meant for —', 'the narrator\'s mother in the South', W('Yingzi\'s father', 'a friend abroad', 'the narrator\'s teacher'), 'দক্ষিণে থাকা মা।', True),
    ('Why did Yingzi cross the road?', 'to mail the narrator\'s letter', W('to buy an umbrella', 'to catch a bus', 'to meet a friend'), 'চিঠি পোস্ট করতে।', True),
    ('The colour of the mailbox in the story is —', 'green', W('red', 'yellow', 'white'), 'সবুজ ডাকবাক্স; সাদা ছিল windbreaker।', False),
    ('Though it was spring, the narrator felt it was like —', 'deep autumn', W('a hot summer', 'early winter', 'the rainy season'), 'বিষাদ বোঝাতে "deep autumn"।', True),
    ('At the moment of the accident, Yingzi was only — away from the narrator.', 'five meters', W('fifty meters', 'one meter', 'five kilometres'), 'পাঁচ মিটার।', False),
    ('The content of the letter was —', '"Ma, I am going to marry Yingzi next month."', W('"Ma, I am coming home next month."', '"Ma, Yingzi is ill."', '"Ma, please send me money."'), 'বিয়ের খবর।', True),
    ('"Butterfly Forever" is narrated from —', 'a man\'s first-person perspective', W('Yingzi\'s point of view', 'a third-person omniscient narrator', 'the mother\'s point of view'), 'পুরুষ কথক, first person।', False),
    ('A literary device that uses vivid descriptions appealing to the senses is called —', 'imagery', [('alliteration', 'ধ্বনির পুনরাবৃত্তি, ইন্দ্রিয়চিত্র নয়।'), ('irony', 'প্রত্যাশা ও বাস্তবের বৈপরীত্য।'), ('onomatopoeia', 'ধ্বন্যাত্মক শব্দ — imagery-র অংশ হতে পারে, কিন্তু সংজ্ঞা আলাদা।')], 'Imagery = ইন্দ্রিয়গ্রাহ্য চিত্রকল্প।', True),
    ('The "butterfly effect" suggests that —', 'small actions can have large, unpredictable consequences', W('butterflies cause storms directly', 'big events have no causes', 'only large actions matter'), 'ছোট কারণ, বড় ফল।', True),
    ('"How Do I Love Thee?" was written by —', 'Elizabeth Barrett Browning', [('Robert Browning', 'Elizabeth-এর স্বামী — নামের ফাঁদ।'), ('Emily Dickinson', 'আমেরিকান কবি, অন্য লেসনে।'), ('Christina Rossetti', 'ভিন্ন ভিক্টোরীয় কবি।')], 'E. B. Browning।', True),
    ('"How Do I Love Thee?" is Sonnet 43 from —', 'Sonnets from the Portuguese', [('Songs of Innocence', 'William Blake-এর সংকলন।'), ('Lyrical Ballads', 'Wordsworth ও Coleridge-এর সংকলন।'), ('The Golden Treasury', 'F. T. Palgrave সম্পাদিত সংকলন।')], 'Sonnets from the Portuguese (1850)।', True),
    ('In the last line of "How Do I Love Thee?", the speaker says that, if God chooses, she shall love —', 'better after death', W('less after death', 'only in her childhood', 'only by sun-light'), 'ভালোবাসা মৃত্যু ছাড়িয়ে যায়।', True),
    ('In "I love thee to the depth and breadth and height", "breadth" means —', 'width', [('breath', 'Breath (শ্বাস) — বানানের ফাঁদ।'), ('height', 'একই লাইনে আলাদা মাত্রা।'), ('length', 'দৈর্ঘ্য নয়, প্রস্থ।')], 'Breadth = প্রস্থ; breath = শ্বাস।', True),
    ('"I love thee freely, as men strive for right." Here "strive" means —', 'make a great effort', [('fight physically', 'আক্ষরিক যুদ্ধ নয়।'), ('give up', 'উল্টো অর্থ।'), ('pray', 'প্রার্থনা নয়।')], 'Strive = প্রাণপণ চেষ্টা।', False),
])

# =====================================================================
# U9·L1 Storms and Stresses of Adolescence  (en-5-14)
# =====================================================================
B.lesson('en-5-14', [
    H('Storms and Stresses of Adolescence — এক নজরে'),
    TABLE('জীবনের ধাপ (পাঠ অনুযায়ী)', ['ধাপ', 'বয়স'],
          ('infancy', 'জন্ম থেকে **২** বছর'), ('early childhood', '**৩–৮** বছর'), ('later childhood', '**৯–১২** বছর'), ('adolescence', '**১৩–১৮** বছর'), ('adult (আমাদের সমাজে)', '**১৮ ও তার বেশি**')),
    UL('**WHO**: adolescence = শৈশবের পরে ও প্রাপ্তবয়সের আগের সময়; দ্রুত বৃদ্ধি ও পরিবর্তন — গতিতে **শুধু infancy-র পরেই** দ্বিতীয়', '**Puberty**-র সূচনা শৈশব থেকে কৈশোরে প্রবেশ চিহ্নিত করে; জৈবিক নির্ধারক মোটামুটি সর্বজনীন, কিন্তু সময়কাল ও বৈশিষ্ট্য সংস্কৃতি ও আর্থসামাজিক অবস্থাভেদে ভিন্ন',
       'গত শতকে পরিবর্তন: puberty আগে আসে, বিয়ে দেরিতে, দৃষ্টিভঙ্গি ভিন্ন — কারণ **education, urbanization ও global communication**',
       'মূল উন্নয়ন: শারীরিক ও যৌন পরিপক্বতা, সামাজিক-অর্থনৈতিক স্বাধীনতার দিকে যাত্রা, **identity** গঠন, প্রাপ্তবয়স্ক ভূমিকার দক্ষতা, **abstract reasoning**-এর সামর্থ্য',
       'ঝুঁকি: অ্যালকোহল, সিগারেট, মাদক; HIV-সহ যৌনবাহিত সংক্রমণ; মানসিক স্বাস্থ্য সমস্যা — এ সময়ের অভ্যাস ভবিষ্যৎ স্বাস্থ্যে দীর্ঘ প্রভাব ফেলে',
       'কিশোরেরা জটিল ধারণা, আচরণ ও পরিণতির সম্পর্ক পুরোপুরি বোঝে না — তাই **vulnerable**; আইন ও সেবাদাতাদের মনোভাবও বাধা হতে পারে',
       'পরিবার, সমাজ, স্কুল, স্বাস্থ্যসেবা ও কর্মক্ষেত্র — সবার সম্মিলিত দায়িত্ব'),
    MATCH('অনুচ্ছেদ ↔ উপযুক্ত শিরোনাম (Activity C — একটি সম্ভাব্য সমাধান)', ('i', 'Stages of human life'), ('ii', 'An observation by World Health Organisation'), ('iii', 'A journey towards adulthood'),
          ('iv', 'Potential health hazards'), ('v', 'A vulnerable age'), ('vi', 'Need for collective efforts')),
    WORDS(('adolescence', 'কৈশোর — puberty থেকে পরিপক্বতা পর্যন্ত'), ('determinant', 'নির্ধারক'), ('acquisition', 'অর্জন'), ('tremendous', 'বিপুল'), ('exert', 'প্রয়োগ করা (প্রভাব/প্রচেষ্টা)'),
          ('consequence', 'পরিণতি'), ('vulnerable', 'ঝুঁকিপূর্ণ, সহজে আক্রান্ত'), ('intervene', 'হস্তক্ষেপ করা'), ('transition', 'রূপান্তর, এক অবস্থা থেকে অন্যটিতে যাওয়া'), h='শব্দার্থ (Activity D)'),
    P('প্রসঙ্গ: কৈশোরকে "storm and stress"-এর সময় বলার ধারণাটি মার্কিন মনোবিজ্ঞানী G. Stanley Hall-এর Adolescence (1904) গ্রন্থের সঙ্গে যুক্ত — শিরোনামটি সেই ধারণারই প্রতিধ্বনি।'),
    SUMMARY('Infancy 0–2, early childhood 3–8, later childhood 9–12, adolescence 13–18; adult 18+', 'WHO: বৃদ্ধির গতি infancy-র পরেই; puberty = সূচনা', 'পরিবর্তনের কারণ: education, urbanization, global communication', 'Vulnerable age; collective efforts'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-14', 'বয়সসীমার সংখ্যাগুলো (২, ৩-৮, ৯-১২, ১৩-১৮) টেবিল আকারে মনে রাখুন।', 'Storms and Stresses of Adolescence।', [
    ('According to EFT, infancy lasts from birth to age —', '2', W('3', '5', '1'), 'জন্ম–২।', True),
    ('According to EFT, early childhood covers the ages —', '3 to 8 years', W('2 to 6 years', '9 to 12 years', '5 to 10 years'), '৩–৮।', True),
    ('According to EFT, later childhood covers the ages —', '9 to 12 years', W('8 to 13 years', '10 to 14 years', '13 to 18 years'), '৯–১২।', True),
    ('According to EFT, adolescence covers the ages —', '13 to 18 years', W('12 to 20 years', '10 to 19 years', '15 to 21 years'), '১৩–১৮ (পাঠ অনুযায়ী)।', True),
    ('In our society, persons — are considered adults.', '18 and over', W('16 and over', '21 and over', '13 and over'), '১৮+।', True),
    ('According to WHO, the growth and change in adolescence are second only to those at —', 'infancy', W('old age', 'adulthood', 'later childhood'), 'Infancy-র পরেই।', True),
    ('The passage from childhood to adolescence is marked by the onset of —', 'puberty', W('marriage', 'employment', 'education'), 'Puberty।', True),
    ('Which is NOT given as a factor responsible for changes in adolescence over the past century?', 'religion', [('education', 'পাঠে উল্লিখিত।'), ('urbanization', 'পাঠে উল্লিখিত।'), ('spread of global communication', 'পাঠে উল্লিখিত।')], 'তিনটি কারণ: education, urbanization, global communication।', True),
    ('Which key development of adolescence is mentioned in the passage?', 'the capacity for abstract reasoning', W('retirement planning', 'loss of identity', 'decline in physical growth'), 'Abstract reasoning, identity ইত্যাদি।', False),
    ('According to the passage, adolescents are vulnerable to high-risk behaviours because they —', 'are not fully capable of understanding complex concepts and consequences', W('are physically weak', 'have too much money', 'are always alone'), 'জটিল ধারণা ও পরিণতি বোঝে না।', False),
    ('Who, according to the passage, has the responsibility to promote adolescent development?', 'parents, community members, service providers and social institutions', W('only the government', 'only teachers', 'adolescents alone'), 'সম্মিলিত দায়িত্ব।', False),
    ('The most suitable heading for the paragraph about the stages of growth is —', 'Stages of human life', W('Adolescence and education', 'The adverse effects of taking drugs', 'Influence of culture on adolescents'), 'অনুচ্ছেদ i।', False),
    ('"Vulnerable" means —', 'susceptible to injury or harm', [('very strong', 'উল্টো অর্থ।'), ('valuable', 'বানানের মিলের ফাঁদ।'), ('violent', 'অপ্রাসঙ্গিক।')], 'Vulnerable = ঝুঁকিপূর্ণ।', True),
    ('"Intervene" means —', 'to become involved in order to influence what happens', [('to ignore', 'উল্টো অর্থ।'), ('to interview', 'বানানের মিলের ফাঁদ।'), ('to delay', 'অপ্রাসঙ্গিক।')], 'Intervene = হস্তক্ষেপ করা।', False),
    ('"Determinants" are —', 'factors that cause something to happen', [('decisions already taken', 'Determination ≠ determinant।'), ('results of an action', 'সেটি consequence।'), ('kinds of medicine', 'অপ্রাসঙ্গিক।')], 'Determinant = নির্ধারক উপাদান।', False),
    ('"Transition" means —', 'a change from one state to another', [('translation', 'বানানের মিলের ফাঁদ।'), ('a permanent state', 'উল্টো অর্থ।'), ('a journey by train', 'Transit-এর সঙ্গে গুলিয়ে ফেলা।')], 'Transition = রূপান্তর।', False),
])

# =====================================================================
# U9·L2 Adolescence and Some (Related) Problems in Bangladesh  (en-5-15)
# =====================================================================
B.lesson('en-5-15', [
    H('Adolescence and Some (Related) Problems in Bangladesh — এক নজরে'),
    TABLE('মূল সংখ্যা (পাঠ অনুযায়ী)', ['বিষয়', 'তথ্য'],
          ('বাংলাদেশে কিশোর-কিশোরী', '**৩ কোটি ১০ লাখের বেশি** (more than 31 million); মেয়ে **১৩.৭ মিলিয়ন**, ছেলে **১৪.৩ মিলিয়ন**'),
          ('বিয়ের আইনি বয়স', 'মেয়ে **১৮**, ছেলে **২১**'), ('বাল্যবিবাহ', 'কিশোরী মেয়েদের **৩৩%**-এর বিয়ে **১৫ বছরের আগে**; **৬০%** মা হয় **১৯ বছরের মধ্যে**'),
          ('মাতৃমৃত্যু', 'কিশোরীদের মাতৃমৃত্যুর হার জাতীয় হারের **দ্বিগুণ**'), ('HIV সচেতনতা', 'মাত্র প্রায় **পাঁচজনে তিনজন** HIV-র নাম শুনেছে'),
          ('পুষ্টি', '**৫০%-এর বেশি** কিশোরী অপুষ্ট ও রক্তস্বল্পতায় (anaemia) ভোগে'), ('adolescent fertility', 'মোট প্রজনন হারে অবদান **১৯৯৩-এ ২০.৩%** থেকে **২০০৭-এ ২৪.৪%**')),
    UL('কিশোরীদের অবস্থা: পরিবার ও সমাজে বৈষম্য ও অধীনতা → বাল্যবিবাহ, স্বাস্থ্য-শিক্ষা-অর্থনৈতিক সুযোগ থেকে বঞ্চনা, সহিংসতা ও যৌন নিপীড়নের ঝুঁকি',
       'বিয়ের পর সাধারণত স্কুল ছেড়ে শ্বশুরবাড়িতে পূর্ণ সময়ের কাজ; প্রান্তিক অবস্থান; **dowry** আইনত নিষিদ্ধ হলেও প্রচলিত — **বিয়ের পরেও** দাবি চলতে পারে',
       'বেশি শিক্ষিত ও সচ্ছল পরিবারের কিশোরীরা দেরিতে বিয়ে করে', 'স্কুল ছাড়লে mobility, বন্ধু ও সামাজিক মর্যাদা হারায়; নবজাতকের মৃত্যুও (neonatal mortality) একটি উদ্বেগ',
       'ছেলেদের অবস্থা তুলনামূলক ভালো, তবু সিদ্ধান্ত নেওয়ার ক্ষমতা কম; স্কুলবহির্ভূত বা বেকার ছেলেরা **অপরাধ** ও **মাদক-অ্যালকোহলের** ঝুঁকিতে'),
    FACTS('Health Profile of Adolescents and Youth in Bangladesh — বাংলাদেশ সরকার, **২০০৭**', 'Adolescent Empowerment Project in Bangladesh — **UNICEF, ২০০৯**', h='পাঠের উৎস'),
    MATCH('কারণ ↔ ফল (Activity D) — as/since/because দিয়ে জোড়া লাগান', ('Some girls have higher education', 'They tend to marry at a later age'), ('Boys are more concerned about financial independence', 'They marry several years after adolescence'),
          ('Many girls drop out after marriage', 'They work all day in their in-laws\' household'), ('Married girls have no status in in-laws\' house', 'They become victims of domestic violence'),
          ('Most adolescent brides lack reproductive health knowledge', 'Mortality rises among them during childbirth'), ('Many boys are unemployed and unaware', 'They risk crime and drug abuse')),
    VERIFY('পাঠের পরিসংখ্যান ২০০৭–২০০৯ সালের উৎস থেকে নেওয়া; বর্তমান অবস্থা ভিন্ন হতে পারে। EFT-ভিত্তিক প্রশ্নে বইয়ের সংখ্যাই লিখুন। লক্ষ করুন, বইয়ে ছেলে (১৪.৩) ও মেয়ে (১৩.৭) মিলিয়নের যোগফল ২৮ মিলিয়ন — "৩১ মিলিয়নের বেশি" সংখ্যার সঙ্গে মেলে না; বইয়ে যেভাবে ছাপা সেভাবেই রাখা হয়েছে।'),
    SUMMARY('৩১ মিলিয়নের বেশি কিশোর-কিশোরী; ছেলে ১৪.৩ > মেয়ে ১৩.৭', 'বিয়ের বয়স: মেয়ে ১৮, ছেলে ২১; ৩৩% বিয়ে ১৫-র আগে; ৬০% মা ১৯-এর মধ্যে', 'মাতৃমৃত্যু দ্বিগুণ; ৫০%+ অপুষ্ট; ৩/৫ জন HIV শুনেছে; ২০.৩% → ২৪.৪%', 'ছেলেরা: অপরাধ ও মাদকের ঝুঁকি'),
    UNI(UNIT_EFT),
], SRC)
FQ('en-5-15', 'শতাংশগুলো (৩৩, ৬০, ৫০, ২০.৩→২৪.৪) আলাদা রঙে লিখে মনে রাখুন।', 'Adolescence and Problems in Bangladesh।', [
    ('According to EFT, Bangladesh has more than — adolescents.', '31 million', W('13.7 million', '50 million', '21 million'), '৩১ মিলিয়নের বেশি।', True),
    ('According to EFT, the number of adolescent girls in Bangladesh is —', '13.7 million', W('14.3 million', '31 million', '17.3 million'), 'মেয়ে ১৩.৭, ছেলে ১৪.৩।', True),
    ('"In Bangladesh there are more adolescent boys than adolescent girls." According to EFT, this is —', 'true', W('false', 'not mentioned', 'true only in cities'), '১৪.৩ > ১৩.৭ মিলিয়ন।', False),
    ('The legal age of marriage in Bangladesh for girls and boys is —', '18 and 21', W('16 and 18', '18 and 18', '21 and 25'), 'মেয়ে ১৮, ছেলে ২১।', True),
    ('According to EFT, — percent of adolescent girls are married before the age of 15.', '33', W('60', '50', '24'), '৩৩%।', True),
    ('According to EFT, — percent of adolescent girls become mothers by the age of 19.', '60', W('33', '50', '20'), '৬০%।', True),
    ('According to EFT, the maternal mortality rate for adolescents is —', 'double the national rate', W('half the national rate', 'equal to the national rate', 'triple the national rate'), 'দ্বিগুণ।', True),
    ('According to EFT, more than 50 percent of adolescent girls —', 'are undernourished and suffer from anaemia', W('have heard of HIV', 'are married before 15', 'go to college'), 'অপুষ্টি ও রক্তস্বল্পতা।', True),
    ('According to a study cited in EFT, how many adolescents have heard of HIV?', 'only about three in five', W('almost all', 'only one in ten', 'about half'), 'পাঁচজনে তিনজন।', False),
    ('The contribution of adolescent fertility to the total fertility rate rose from 20.3% in 1993 to —', '24.4% in 2007', W('33% in 2007', '24.4% in 2009', '30.4% in 2007'), '২৪.৪% (২০০৭)।', True),
    ('"A bride\'s family has to pay dowry only before the wedding." According to EFT, this statement is —', 'false', W('true', 'not mentioned', 'true only in villages'), 'বিয়ের পরেও দাবি চলতে পারে।', False),
    ('According to EFT, adolescents with higher education and from affluent families tend to —', 'marry at a later age', W('marry earlier', 'never marry', 'drop out of school'), 'দেরিতে বিয়ে।', False),
    ('According to EFT, adolescent boys who are unemployed are at considerable risk of —', 'being drawn into criminal activities', W('early marriage', 'maternal mortality', 'anaemia'), 'অপরাধ ও মাদক।', False),
    ('One of the sources of the lesson, "Adolescent Empowerment Project in Bangladesh" (2009), was published by —', 'UNICEF', W('WHO', 'the World Bank', 'BRAC'), 'UNICEF, ২০০৯।', False),
    ('Join using "since": Many girls drop out of school after marriage. They have to work all day in their in-laws\' household.', 'Since many girls drop out of school after marriage, they have to work all day in their in-laws\' household.', [('Since many girls have to work all day in their in-laws\' household, they drop out of school after marriage.', 'কারণ-ফল উল্টে গেছে।'), ('Many girls drop out of school after marriage since, they have to work all day.', 'Comma-র অবস্থান ভুল ও অর্থ বদলেছে।'), ('Since many girls drop out of school after marriage so they have to work all day in their in-laws\' household.', 'Since-এর সঙ্গে so বাহুল্য (redundant)।')], 'Since + কারণ, ফল। Since/as/because-এর সঙ্গে so বসে না।', True),
    ('"Dowry" means —', 'money or goods given by a bride\'s family to the groom\'s family', [('a gift from the government', 'অপ্রাসঙ্গিক।'), ('a wedding ceremony', 'অনুষ্ঠান নয়।'), ('a bride\'s salary', 'বেতন নয়।')], 'Dowry = যৌতুক।', False),
    ('"Mobility" in the passage refers to the ability to —', 'move freely from place to place', [('use a mobile phone', 'আক্ষরিক মিলের ফাঁদ।'), ('earn money', 'অর্থনৈতিক সুযোগ আলাদা বিষয়।'), ('stay at home', 'উল্টো অর্থ।')], 'Mobility = চলাচলের স্বাধীনতা।', False),
])

B.autofill_cards(12)
B.save('eft3', 'en-eft3')
