#!/usr/bin/env python3
"""English — Block 6 (U–Z): Preposition, Idioms, Vocabulary, Spelling, Group Verbs"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('enb6b', 'en', 9611)
L = 'en-6-'
R = 'U–Z'

prep_lesson(B, L + '11', R, [
    ('unaware', 'of', 'He was unaware ___ the danger.', 'অজ্ঞাত', ()), ('unfit', 'for', 'He is unfit ___ the job.', 'অযোগ্য', ()),
    ('make use', 'of', 'Make good use ___ your time.', 'ব্যবহার করা', ()), ('vain', 'of', 'She is vain ___ her beauty.', 'অহংকারী', ()),
    ('versed', 'in', 'He is well versed ___ law.', 'পারদর্শী', ()), ('vexed (person)', 'with', 'Father was vexed ___ me.', '(কারও ওপর) বিরক্ত', ()),
    ('vexed (thing)', 'at', 'He was vexed ___ the delay.', '(কোনো কিছুতে) বিরক্ত', ('about',)), ('victim', 'of', 'He fell a victim ___ fraud.', 'শিকার', ()),
    ('void', 'of', 'His speech was void ___ meaning.', 'শূন্য', ()), ('vote', 'for', 'I will vote ___ the best candidate.', 'ভোট দেওয়া (পক্ষে)', ()),
    ('wait (expect)', 'for', 'I waited ___ the bus.', 'অপেক্ষা করা', ()), ('wait (serve)', 'on', 'The waiter waited ___ the guests.', 'পরিবেশন/সেবা করা', ('upon',)),
    ('for want', 'of', 'The plant died for want ___ water.', 'অভাবে', ()), ('warn', 'against', 'He warned me ___ smoking.', 'সতর্ক করা (কোনো কাজ না করতে)', ('about',)),
    ('weak', 'in', 'He is weak ___ English.', '(কোনো বিষয়ে) দুর্বল', ()), ('wish', 'for', 'Everyone wishes ___ happiness.', 'কামনা করা', ()),
    ('wonder', 'at', 'We wondered ___ his courage.', 'বিস্মিত হওয়া', ()), ('worthy', 'of', 'He is worthy ___ praise.', 'যোগ্য', ()),
    ('yearn', 'for', 'She yearns ___ her homeland.', 'আকুলভাবে চাওয়া', ()), ('yield', 'to', 'Never yield ___ temptation.', 'নতি স্বীকার করা', ()),
    ('zeal', 'for', 'He has great zeal ___ work.', 'উদ্যম', ()), ('witness', 'to', 'He was a witness ___ the accident.', 'সাক্ষী', ('of',))],
    9100,
    contrast=(('vexed with + ব্যক্তি, at + বিষয়', 'vexed with me at the delay'), ('wait for', 'অপেক্ষা: wait for the bus'), ('wait on', 'সেবা: wait on guests')),
    mnem=(('"of-দল: unaware, vain, victim, void, want, worthy"', '"of" লাগে', 'সবগুলো U–Z-এর।'),),
    mistakes=('"worthy for" ✗ → worthy **of**।', '"weak at English" — পরীক্ষার প্রচলিত উত্তর weak **in** English।', '"yield before temptation" ✗ → yield **to**।'))

idiom_lesson(B, L + '12', R, [
    ('under a cloud', 'সন্দেহ বা বদনামের মধ্যে', 'under suspicion; in disgrace', 'মেঘের ছায়ায় ঢাকা — সুনাম অন্ধকার।', 'He left the job under a cloud.'),
    ('under the weather', 'শরীর খারাপ লাগা', 'slightly unwell', 'প্রচলিত ব্যাখ্যা: জাহাজে খারাপ আবহাওয়ায় অসুস্থ যাত্রীদের ডেকের নিচে পাঠানো হতো।', 'I am feeling a bit under the weather.'),
    ('ups and downs', 'উত্থান-পতন', 'good and bad times', 'জীবনের চড়াই-উতরাই।', 'Life has its ups and downs.'),
    ('up to the mark', 'মানসম্মত', 'of the required standard', 'নির্ধারিত দাগ পর্যন্ত পৌঁছানো।', 'His work is not up to the mark.'),
    ('the upper hand', 'প্রাধান্য, সুবিধাজনক অবস্থান', 'advantage or control', 'ওপরের হাত — নিয়ন্ত্রণ যার।', 'Our team gained the upper hand.'),
    ('Utopia', 'কাল্পনিক আদর্শ রাষ্ট্র', 'an imaginary perfect society', 'Thomas More-এর ১৫১৬ সালের বই Utopia থেকে; গ্রিক ou (না) + topos (স্থান) — "যে স্থান নেই"।', 'A world without crime is a Utopia.'),
    ('a vexed question', 'বহুবিতর্কিত প্রশ্ন', 'a much-debated problem', 'vexed = বারবার আলোড়িত।', 'Dowry is a vexed question.'),
    ('vice versa', 'উল্টোটাও (একইভাবে)', 'the other way round', 'Latin — "অবস্থান বদলে"।', 'He helps me and vice versa.'),
    ('viva voce', 'মৌখিক পরীক্ষা', 'an oral examination', 'Latin — "জীবন্ত কণ্ঠে"।', 'The viva voce is next week.'),
    ('a wild goose chase', 'বৃথা অন্বেষণ', 'a hopeless search', 'Shakespeare-এর Romeo and Juliet-এ পাওয়া যায় — একধরনের ঘোড়দৌড়; পরে "অর্থহীন পিছু ধাওয়া" অর্থে।', 'Looking for him there was a wild goose chase.'),
    ('a white elephant', 'ব্যয়বহুল অথচ অকেজো জিনিস', 'a costly but useless possession', 'প্রচলিত গল্প: শ্যামদেশের রাজা অপছন্দের সভাসদকে সাদা হাতি উপহার দিতেন — পবিত্র বলে কাজে লাগানো যেত না, পুষতে গিয়ে সে ফতুর হতো।', 'The new stadium became a white elephant.'),
    ('a white lie', 'নির্দোষ মিথ্যা', 'a harmless lie told to be polite', 'সাদা = নিরীহ।', 'She told a white lie to avoid hurting him.'),
    ('a wolf in sheep\'s clothing', 'ভেড়ার ছদ্মবেশে নেকড়ে', 'an enemy pretending to be a friend', 'বাইবেলে (Matthew) ভণ্ড নবিদের এভাবে বর্ণনা করা হয়েছে।', 'Beware of him; he is a wolf in sheep\'s clothing.'),
    ('with a grain of salt', 'সন্দেহের সঙ্গে গ্রহণ করা', 'with some doubt', 'প্রচলিত ব্যাখ্যা: রোমান লেখক Pliny-র এক বর্ণনায় বিষের প্রতিষেধক এক দানা লবণসহ খাওয়ার কথা আছে।', 'Take his promises with a grain of salt.'),
    ('a wet blanket', 'আনন্দ মাটি করা লোক', 'a person who spoils others\' fun', 'ভেজা কম্বলে আগুন নিভিয়ে দেওয়া।', 'Don\'t be a wet blanket; join the party.'),
    ('worth its weight in gold', 'অত্যন্ত মূল্যবান', 'extremely valuable', 'ওজনের সমান সোনার মূল্য।', 'A good teacher is worth her weight in gold.'),
    ('the writing on the wall', 'আসন্ন বিপর্যয়ের লক্ষণ', 'a sign of coming disaster', 'বাইবেলের Daniel: রাজা Belshazzar-এর ভোজসভায় দেয়ালে রহস্যময় লেখা ফুটে ওঠে — পতনের ভবিষ্যদ্বাণী।', 'The losses were the writing on the wall.'),
    ('word of mouth', 'মুখে মুখে', 'by people telling each other', 'লিখিত নয়, মৌখিক প্রচার।', 'The shop grew by word of mouth.'),
    ('yeoman\'s service', 'মূল্যবান সেবা', 'excellent, useful service', 'প্রচলিত ব্যাখ্যা: ইংল্যান্ডের yeoman (স্বাধীন কৃষক-সৈনিক) তীরন্দাজদের বীরত্বপূর্ণ সেবা থেকে।', 'He did yeoman\'s service during the flood.'),
    ('year in, year out', 'বছরের পর বছর', 'continuously for years', 'বছর আসে, বছর যায়।', 'He works hard year in, year out.'),
    ('zero hour', 'চূড়ান্ত মুহূর্ত', 'the time an important event begins', 'প্রথম বিশ্বযুদ্ধের সামরিক পরিভাষা — আক্রমণ শুরুর নির্ধারিত সময়।', 'Zero hour for the exam is 10 am.')],
    9200, traps=('a white elephant', 'under the weather', 'viva voce', 'a vexed question'),
    mnem=(('"দুই সাদা: white elephant (দামি অথচ অকেজো), white lie (নিরীহ মিথ্যা)"', 'রং দিয়ে', 'একসাথে মনে রাখুন।'),),
    mistakes=('**white elephant** = দামি অথচ অকেজো — দুর্লভ প্রাণী নয়।', '**under the weather** = অসুস্থ — আবহাওয়ার খবর নয়।'))

vocab_lesson(B, L + '13', R, [
    ('ubiquitous', 'adj', 'সর্বব্যাপী', 'present everywhere', ['omnipresent', 'pervasive', 'universal'], ['rare', 'scarce'], 'every'),
    ('unanimous', 'adj', 'সর্বসম্মত', 'fully in agreement', ['united', 'agreed', 'concordant'], ['divided', 'split'], 'agree'),
    ('unprecedented', 'adj', 'নজিরবিহীন', 'never done or known before', ['unparalleled', 'unheard-of', 'novel'], ['common', 'usual'], 'new'),
    ('vague', 'adj', 'অস্পষ্ট', 'unclear', ['hazy', 'unclear', 'ambiguous'], ['clear', 'precise'], 'unclear'),
    ('valiant', 'adj', 'বীর', 'showing courage', ['brave', 'courageous', 'heroic'], ['cowardly', 'timid'], 'brave'),
    ('vanity', 'n', 'অহমিকা; অসারতা', 'excessive pride in oneself', ['conceit', 'pride', 'egotism'], ['modesty', 'humility'], 'pride'),
    ('venerable', 'adj', 'শ্রদ্ধেয়', 'respected because of age or wisdom', ['revered', 'respected', 'honoured'], ['disreputable'], 'respect'),
    ('verbose', 'adj', 'বাগাড়ম্বরপূর্ণ', 'using too many words', ['wordy', 'long-winded', 'prolix'], ['concise', 'succinct'], 'words'),
    ('versatile', 'adj', 'বহুমুখী প্রতিভাসম্পন্ন', 'able to do many things', ['adaptable', 'all-round', 'flexible'], ['limited', 'inflexible'], 'many'),
    ('vigilant', 'adj', 'সজাগ, সতর্ক', 'keeping careful watch', ['watchful', 'alert', 'attentive'], ['careless', 'negligent'], 'alert'),
    ('vindictive', 'adj', 'প্রতিহিংসাপরায়ণ', 'wanting revenge', ['revengeful', 'spiteful', 'vengeful'], ['forgiving', 'merciful'], 'revenge'),
    ('virtuous', 'adj', 'গুণী, সৎ', 'having high moral standards', ['moral', 'righteous', 'upright'], ['wicked', 'immoral'], 'good'),
    ('volatile', 'adj', 'অস্থির; উদ্বায়ী', 'liable to change rapidly', ['unstable', 'explosive', 'unpredictable'], ['stable', 'calm'], 'change'),
    ('voracious', 'adj', 'অতিভোজী; অতৃপ্ত', 'wanting great quantities', ['insatiable', 'greedy', 'ravenous'], ['abstemious', 'moderate'], 'greed'),
    ('vulnerable', 'adj', 'অরক্ষিত, ঝুঁকিপূর্ণ', 'exposed to harm', ['exposed', 'defenceless', 'susceptible'], ['protected', 'invulnerable'], 'weak'),
    ('wary', 'adj', 'সতর্ক, সন্দিগ্ধ', 'feeling cautious', ['cautious', 'careful', 'guarded'], ['unwary', 'careless'], 'alert'),
    ('wane', 'v', 'ক্ষয় পাওয়া, কমে আসা', 'to decrease gradually', ['decline', 'diminish', 'fade'], ['wax', 'grow'], 'less'),
    ('whimsical', 'adj', 'খেয়ালি', 'playfully unusual', ['capricious', 'fanciful', 'playful'], ['serious', 'sober'], 'odd'),
    ('wily', 'adj', 'ধূর্ত', 'skilled at clever deceit', ['cunning', 'crafty', 'sly'], ['naive', 'ingenuous'], 'cunning'),
    ('wrath', 'n', 'প্রচণ্ড ক্রোধ', 'extreme anger', ['fury', 'rage', 'anger'], ['calmness', 'pleasure'], 'anger'),
    ('yearn', 'v', 'আকুলভাবে কামনা করা', 'to long for', ['long', 'crave', 'pine'], ['dislike', 'spurn'], 'want'),
    ('zealous', 'adj', 'উদ্যমী, উৎসাহী', 'full of eager enthusiasm', ['eager', 'fervent', 'ardent'], ['apathetic', 'indifferent'], 'eager'),
    ('zenith', 'n', 'চরম শিখর', 'the highest point', ['peak', 'pinnacle', 'summit'], ['nadir', 'bottom'], 'top'),
    ('zest', 'n', 'উদ্দীপনা', 'great enthusiasm', ['enthusiasm', 'gusto', 'relish'], ['apathy', 'indifference'], 'eager')],
    9300,
    roots={'ubiquitous': 'Latin ubique (সর্বত্র)।', 'unanimous': 'Latin unus (এক) + animus (মন) — এক মন।', 'unprecedented': 'precedent (নজির) নেই।',
           'verbose': 'Latin verbum (শব্দ) — verbal একই মূল।', 'vindictive': 'Latin vindicta (প্রতিশোধ) — vengeance একই পরিবার।',
           'voracious': 'Latin vorare (গিলে খাওয়া) — carnivore, herbivore একই মূল।', 'zenith': 'আরবি থেকে মধ্যযুগীয় লাতিন হয়ে এসেছে; বিপরীত nadir-ও আরবি উৎসের।',
           'venerable': 'Latin venerari (শ্রদ্ধা/পূজা করা) — veneration।', 'volatile': 'Latin volare (ওড়া) — যা উড়ে যায় (উদ্বায়ী)।'},
    traps=('wane', 'volatile', 'venerable', 'whimsical', 'zenith'),
    mnem=(('"zenith ↔ nadir: চূড়া ↔ তলা"', 'antonym জোড়া', 'দুটোই আরবি উৎসের জ্যোতির্বিদ্যার শব্দ।'), ('"wax ↔ wane: চাঁদ বাড়ে ↔ চাঁদ কমে"', 'antonym জোড়া', 'চাঁদের কলা।')),
    mistakes=('**venerable** (শ্রদ্ধেয়) ≠ **vulnerable** (অরক্ষিত)।', '**wane** = কমা, "want" নয়।'))

spelling_lesson(B, L + '14', R, [
    ('unanimous', 'সর্বসম্মত', 'un-an-i-mous', ['unanimus', 'unanimuos', 'unanamous']),
    ('unnecessary', 'অপ্রয়োজনীয়', 'un + necessary (nn, c এক, ss)', ['unneccessary', 'unecessary', 'unnecesary']),
    ('until', 'যতক্ষণ না', 'l একটি (till-এ দুটি)', ['untill', 'unntil', 'antil']),
    ('usually', 'সাধারণত', 'usual + ly (ll)', ['usualy', 'usally', 'ususally']),
    ('vacuum', 'শূন্যস্থান', 'c একটি, uu দুটি', ['vaccum', 'vaccuum', 'vacume']),
    ('vegetable', 'সবজি', 'veg-e-table', ['vegtable', 'vegitable', 'vegetible']),
    ('vehicle', 'যানবাহন', 've-hi-cle (নীরব h)', ['vehical', 'vehicel', 'veicle']),
    ('vengeance', 'প্রতিশোধ', 'venge + ance (e থাকে)', ['vengence', 'vengance', 'vengeence']),
    ('veterinary', 'পশুচিকিৎসা-সংক্রান্ত', 'vet-er-in-ary', ['vetinary', 'veternary', 'veterenary']),
    ('villain', 'খলনায়ক', 'vill-ain (ai)', ['villian', 'vilain', 'villein']),
    ('visible', 'দৃশ্যমান', '-ible', ['visable', 'visibel', 'vissible']),
    ('Wednesday', 'বুধবার', 'Wed-nes-day (নীরব d)', ['Wensday', 'Wednsday', 'Wendesday']),
    ('weird', 'অদ্ভুত', 'ei (ব্যতিক্রম)', ['wierd', 'weerd', 'wiered']),
    ('withhold', 'আটকে রাখা', 'with + hold (hh)', ['withold', 'withhould', 'witthold']),
    ('wholly', 'সম্পূর্ণভাবে', 'whole-এর e বাদ, ll', ['wholy', 'wholey', 'wholely']),
    ('writing', 'লেখা', 't একটি', ['writting', 'wrighting', 'writeing']),
    ('written', 'লিখিত', 'tt দুটি', ['writen', 'writtin', 'wrritten']),
    ('yacht', 'প্রমোদতরী', 'y-a-c-h-t', ['yatch', 'yaght', 'yahct']),
    ('yield', 'ফলন; নতি স্বীকার', 'ie', ['yeild', 'yeeld', 'yiled']),
    ('zealous', 'উদ্যমী', 'zeal + ous', ['zelous', 'zealus', 'zeallous'])],
    traps=('writing', 'written', 'until', 'withhold', 'villain', 'wholly'),
    mnem=(('"writing-এ t একা, written-এ t জোড়া"', 'writing/written', 'write-এর i দীর্ঘ → t একটি; writ-ten ছোট → tt।'), ('"villAIn-এর মধ্যে AI আছে"', 'villain', '-ian নয়।')),
    mistakes=('"untill" ✗ → **until**।', '"wierd" ✗ → **weird**।', '"withold" ✗ → **withhold**।'))

gv_lesson(B, L + '15', R, [
    ('use up', 'শেষ করে ফেলা', 'consume completely'), ('urge on', 'উৎসাহ দিয়ে এগিয়ে নেওয়া', 'encourage to continue'),
    ('wait on', 'সেবা করা', 'serve'), ('walk out', 'প্রতিবাদে বেরিয়ে যাওয়া', 'leave in protest'), ('ward off', 'প্রতিহত করা', 'prevent; fend off'),
    ('wash away', 'ভাসিয়ে নেওয়া', 'carry away by water'), ('watch out', 'সাবধান থাকা', 'be careful'), ('wear out', 'জীর্ণ হওয়া; ক্লান্ত করা', 'become useless through use; exhaust'),
    ('wind up', 'গুটিয়ে ফেলা; শেষ করা', 'close down; end'), ('wipe out', 'নিশ্চিহ্ন করা', 'destroy completely'), ('work out', 'সমাধান করা; ব্যায়াম করা', 'solve; exercise'),
    ('write off', 'বাতিল/অকেজো বলে ধরে নেওয়া', 'regard as lost'), ('vouch for', 'নিশ্চয়তা দেওয়া', 'guarantee'), ('vote down', 'ভোটে নাকচ করা', 'reject by voting'),
    ('wear off', '(প্রভাব) কমে যাওয়া', 'gradually disappear'), ('zero in on', 'লক্ষ্য স্থির করা', 'focus on'), ('yield to', 'নতি স্বীকার করা', 'give way to'), ('weigh up', 'বিবেচনা করা', 'assess')],
    [('The flood ___ many houses.', 'washed away', ['wore out', 'wound up', 'warded off'], 'ভাসিয়ে নেওয়া'),
     ('My shoes have ___ .', 'worn out', ['worn off', 'washed away', 'used up'], 'জীর্ণ হওয়া'),
     ('The effect of the medicine will soon ___ .', 'wear off', ['wear out', 'wind up', 'work out'], 'প্রভাব কমা'),
     ('Can you ___ this sum?', 'work out', ['wipe out', 'wind up', 'wear out'], 'সমাধান'),
     ('The company was ___ due to losses.', 'wound up', ['worked out', 'washed away', 'waited on'], 'গুটিয়ে ফেলা'),
     ('The opposition ___ of Parliament in protest.', 'walked out', ['warded off', 'wore off', 'wound up'], 'প্রতিবাদে বেরিয়ে যাওয়া'),
     ('I can ___ his honesty.', 'vouch for', ['vote down', 'wait on', 'yield to'], 'নিশ্চয়তা'),
     ('The epidemic ___ the whole village.', 'wiped out', ['worked out', 'wore off', 'urged on'], 'নিশ্চিহ্ন')],
    9400, traps=('wear out', 'wear off', 'wind up', 'work out'),
    mnem=(('"WEAR: out = জিনিস জীর্ণ, off = প্রভাব কমে যাওয়া"', 'wear', 'out-জুতো, off-ওষুধ।'), ('"W-out পরিবার: walk out, wear out, wipe out, work out"', 'out', 'চারটির অর্থ আলাদা — একসাথে পড়ুন।')),
    mistakes=('**wear out** (জীর্ণ) ≠ **wear off** (প্রভাব কমা)।', '**wipe out** (নিশ্চিহ্ন) ≠ **work out** (সমাধান)।'))

B.autofill_cards(12)
B.save('b6b', 'en-b6b')
