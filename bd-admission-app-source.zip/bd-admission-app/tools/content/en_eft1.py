#!/usr/bin/env python3
"""EFT (English For Today, Classes XI-XII & Alim, NCTB, সংশোধিত ২০২৪-২৫) — Block 1-এর লেসন:
U1·L1 The Parrot's Tale, U1·L2 Education and Technology, U1·L3 Children in School, U1·L4 Civic Engagement,
U2·L1 What is Beauty?, U2·L2 Folk Music
নীতি: পাঠ্যবইয়ের গদ্য হুবহু তোলা হয়নি — বাংলায় সারাংশ ও নিজের ভাষায় প্রশ্ন। কেবল কপিরাইটমুক্ত (১৯২৯-এর আগে প্রকাশিত) কবিতার দু-এক লাইন উদ্ধৃত।"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from en_common import *

B = Bank('eneft1', 'en', 9901)
Q = B.q
SRC = ['English For Today, Classes XI-XII & Alim (NCTB, সংশোধিত ২০২৪-২৫ সংস্করণ)']
UNIT_EFT = ('ঢাবি B ইউনিটসহ বিভিন্ন ভর্তি পরীক্ষার English অংশে HSC-র English For Today পাঠ্যবই থেকে লেখক, উৎস, চরিত্র, ঘটনা ও শব্দার্থধর্মী প্রশ্ন আসার প্রবণতা আছে — '
            'নির্দিষ্ট বছরের সংখ্যা যাচাইকৃত PYQ যুক্ত না হওয়া পর্যন্ত দেওয়া হচ্ছে না। সর্বশেষ সংস্করণের সূচি মিলিয়ে নিন।')
def FQ(lid, tip, fact, rows):
    for s, a, w, r, trap in rows:
        Q(lid, 2, s, a, w, r, tip, fact, trap=trap)
L = 'en-1-'

# =====================================================================
# U1·L1 The Parrot's Tale
# =====================================================================
B.lesson(L + '10', [
    H('The Parrot\'s Tale — এক নজরে'),
    FACTS('লেখক: **Rabindranath Tagore**; ইংরেজি অনুবাদ: **Kaiser Haq**', 'Unit One: Education and Life, Lesson 1', 'ধরন: **satire** (ব্যঙ্গ) — শিক্ষাব্যবস্থার যান্ত্রিকতা ও লোক-দেখানো আয়োজনের সমালোচনা', h='মূল তথ্য'),
    H('কাহিনির সারাংশ (নিজের ভাষায়)'),
    OL('এক পাখি গান গায়, লাফায়, ওড়ে — কিন্তু শাস্ত্র আওড়াতে পারে না, আদবকায়দাও জানে না। রাজা বললেন এমন পাখি অকেজো, উল্টো বনের ফল খেয়ে ফলবিক্রেতাদের লাভ কমায়; তিনি মন্ত্রীকে পাখিকে শিক্ষিত করার হুকুম দিলেন।',
       'দায়িত্ব পড়ল রাজার ভাগনেদের ওপর। পণ্ডিতরা সিদ্ধান্তে এলেন — খড়কুটোর বাসায় বেশি বিদ্যা ধরে না, তাই প্রথমেই চাই ভালো খাঁচা।',
       'স্বর্ণকার সোনালি খাঁচা বানাল; লোকে বলল, "শিখুক না শিখুক, খাঁচা তো পেয়েছে!" লিপিকাররা পুঁথির পাহাড় বানাল; খাঁচা মেরামতে বিরাট বাহিনী — সবাই মোটা বেতন পেল।',
       'নিন্দুকেরা প্রশ্ন তুলল — খাঁচা তো সুন্দর, কিন্তু পাখির খবর কেউ রাখে? ভাগনে রাজাকে বোঝাল এরা ভাগ না পেয়ে নিন্দা করছে; রাজা ভাগনেকে সোনার হার দিলেন।',
       'রাজা নিজে দেখতে এলেন; ঢাকঢোল আর স্তুতির শোরগোলে মুগ্ধ হলেন। খাঁচায় দানা-পানি নেই, শুধু পুঁথির পাতা ছিঁড়ে কলমের ডগায় পাখির মুখে গুঁজে দেওয়া হচ্ছে।',
       'পাখি দিন দিন দুর্বল হলো, তবু মাঝে মাঝে আলোর দিকে তাকিয়ে ডানা ঝাপটাত, ঠোঁট দিয়ে খাঁচার তার কাটতে চাইত। কামার এসে পায়ে শিকল দিল, ডানা ছেঁটে দিল; কোতোয়াল পদক পেল।',
       'পাখি মারা গেল। ভাগনে বলল, "পাখির শিক্ষা সম্পূর্ণ হয়েছে।" রাজা পাখিকে টিপলেন — শব্দ নেই, শুধু পেটের ভেতরে শুকনো কাগজের খসখস। বাইরে বসন্তের বাতাস বইছিল।'),
    TABLE('চরিত্র ও প্রতীক', ['চরিত্র/বস্তু', 'কী বোঝায়'],
          ('পাখি', 'স্বাধীন, প্রাকৃতিক প্রতিভাসম্পন্ন শিক্ষার্থী'), ('সোনার খাঁচা', 'জাঁকালো কিন্তু প্রাণহীন শিক্ষাব্যবস্থা/প্রতিষ্ঠান'),
          ('পুঁথির পাতা গুঁজে দেওয়া', 'মুখস্থনির্ভর, চাপিয়ে দেওয়া শিক্ষা'), ('ভাগনে, পণ্ডিত, স্বর্ণকার, লিপিকার', 'শিক্ষাকে ঘিরে লাভবান গোষ্ঠী'),
          ('নিন্দুক (fault-finders)', 'সত্য বলা সমালোচক — যাদের কথা শোনা হয়নি'), ('পেটে কাগজের খসখস', 'শিক্ষার নামে প্রাণশক্তির মৃত্যু')),
    WORDS(('detractors', 'নিন্দুক, সমালোচক'), ('veritable mountain', 'সত্যিকারের পাহাড় (বিপুল স্তূপ)'), ('gilded cage', 'সোনালি খাঁচা'),
          ('negligible', 'নগণ্য'), ('impudence', 'ঔদ্ধত্য, বেয়াদবি'), ('wistful melancholy', 'আকুল বিষণ্নতা'), ('scripture', 'শাস্ত্রগ্রন্থ'), ('snuff', 'নস্যি'), h='শব্দার্থ'),
    SUMMARY('Tagore-এর গল্প, অনুবাদ Kaiser Haq', 'Satire — খাঁচা (ব্যবস্থা) বড়, পাখি (শিক্ষার্থী) উপেক্ষিত', 'শিক্ষা "সম্পূর্ণ" = পাখির মৃত্যু'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '10', 'গল্পের ঘটনাক্রম ও প্রতীক মনে রাখুন।', 'The Parrot\'s Tale — সারাংশ ও প্রতীক সারণি।', [
    ('"The Parrot\'s Tale" was written by —', 'Rabindranath Tagore', [('Kaiser Haq', 'তিনি অনুবাদক।'), ('Kazi Nazrul Islam', 'মেলে না।'), ('Syed Waliullah', 'মেলে না।')], 'লেখক রবীন্দ্রনাথ ঠাকুর।', True),
    ('The English translation of "The Parrot\'s Tale" in EFT is by —', 'Kaiser Haq', [('Rabindranath Tagore', 'মূল লেখক।'), ('Fakrul Alam', 'পাঠ্যবইয়ের সংকলকদের একজন, অনুবাদক নন।'), ('Buddhadeva Bose', 'মেলে না।')], 'অনুবাদক: Kaiser Haq।', True),
    ('"The Parrot\'s Tale" is best described as a —', 'satire', [('tragedy', 'করুণ সমাপ্তি থাকলেও মূল উদ্দেশ্য ব্যঙ্গ।'), ('comedy', 'সুখী সমাপ্তি নেই।'), ('biography', 'মেলে না।')], 'ব্যঙ্গের মাধ্যমে সমাজের দোষ দেখানো = satire।', True),
    ('Why did the King think the bird was useless?', 'It could not recite scripture and lacked manners.', [('It could not sing.', 'পাখি গান গাইত।'), ('It could not fly.', 'পাখি উড়ত।'), ('It was sick.', 'শুরুতে পাখি সুস্থ।')], 'গাইত, উড়ত — কিন্তু শাস্ত্র জানত না।', True),
    ('The task of educating the bird fell on —', 'the King\'s nephews', [('the Minister alone', 'মন্ত্রীকে হুকুম দেওয়া হয়, দায়িত্ব পায় ভাগনেরা।'), ('the goldsmith', 'খাঁচা বানিয়েছে।'), ('the Police Inspector', 'মেলে না।')], 'রাজার বোনের ছেলেরা (nephews)।', False),
    ('According to the scholars, why was the bird ignorant?', 'Its nest of straw and twigs could not hold much knowledge.', [('It had no teacher.', 'পণ্ডিতদের যুক্তি ছিল বাসা।'), ('It was too old.', 'মেলে না।'), ('It ate too much fruit.', 'রাজার অভিযোগ, পণ্ডিতদের সিদ্ধান্ত নয়।')], 'তাই প্রথম প্রয়োজন খাঁচা।', True),
    ('What was considered the first thing needed to educate the bird?', 'a proper cage', [('good books', 'পরে এসেছে।'), ('a good teacher', 'পরে এসেছে।'), ('more food', 'উল্টো — খাবার বন্ধ ছিল।')], 'ব্যঙ্গ: আসল কাজের চেয়ে কাঠামো আগে।', False),
    ('Who made the gilded cage?', 'a goldsmith', [('a blacksmith', 'শিকল দিয়েছে।'), ('a scribe', 'পুঁথি নকল করেছে।'), ('a carpenter', 'মেলে না।')], 'স্বর্ণকার।', False),
    ('Seeing the cage, some people said, "Even if it learns nothing, it has got the cage." This shows —', 'people valued outward show over real learning', [('people loved the bird', 'মেলে না।'), ('the bird was learning fast', 'মেলে না।'), ('the cage was cheap', 'উল্টো।')], 'বাহ্যিক জাঁকজমকের প্রতি মোহ।', True),
    ('What did the scribes produce?', 'a veritable mountain of copied texts', [('a new cage', 'স্বর্ণকারের কাজ।'), ('a song for the bird', 'মেলে না।'), ('a report to the King', 'মেলে না।')], 'পুঁথির পাহাড় — বিদ্যার পরিমাণ, মান নয়।', False),
    ('How did the King reward the nephew who answered the fault-finders?', 'with a gold chain', [('with a medal', 'কোতোয়াল পেয়েছে।'), ('with land', 'মেলে না।'), ('with a cage', 'মেলে না।')], 'সোনার হার।', True),
    ('During the King\'s visit, what was inside the cage?', 'no grain or water, only pages of texts', [('plenty of fruit', 'উল্টো।'), ('another bird', 'মেলে না।'), ('a golden bell', 'মেলে না।')], 'পাতা ছিঁড়ে কলমের ডগায় মুখে গুঁজে দেওয়া হচ্ছিল।', True),
    ('When the bird tried to cut the wires of the cage, the blacksmith —', 'chained its foot and trimmed its wings', [('set it free', 'উল্টো।'), ('built a bigger cage', 'মেলে না।'), ('fed it', 'মেলে না।')], 'স্বাধীনতার চেষ্টা দমন।', False),
    ('Who earned a medal for his "alertness"?', 'the Police Inspector', [('the goldsmith', 'টাকা পেয়েছে।'), ('the nephew', 'সোনার হার পেয়েছে।'), ('the teacher', 'মেলে না।')], 'কোতোয়ালের পদক।', True),
    ('When the bird died, the nephew said that —', 'the bird\'s education had been completed', [('the bird had escaped', 'মেলে না।'), ('the bird was sleeping', 'মেলে না।'), ('the teachers had failed', 'উল্টো দাবি।')], 'চরম ব্যঙ্গ: মৃত্যু = শিক্ষা সম্পূর্ণ।', True),
    ('When the King pressed the dead bird, he heard —', 'the rustling of dry paper in its stomach', [('a sweet song', 'উল্টো।'), ('a loud screech', '"not even a squeak"।'), ('the scripture being recited', 'মেলে না।')], 'মুখস্থ বিদ্যার প্রতীক।', True),
    ('The central message of the story is that —', 'mechanical, imposed education kills natural talent', [('birds should be kept in cages', 'উল্টো।'), ('kings are always wise', 'উল্টো।'), ('scripture is useless', 'অতিরিক্ত দাবি।')], 'শিক্ষার নামে প্রাণশক্তি ধ্বংস।', False),
    ('The word "detractors" in the story means —', 'critics or fault-finders', [('teachers', 'মেলে না।'), ('relatives', 'মেলে না।'), ('musicians', 'মেলে না।')], 'detractor = নিন্দুক।', False),
    ('Who were the real beneficiaries of the bird\'s "education"?', 'the nephews, scholars, goldsmith, scribes and their relatives', [('the bird', 'পাখি মারা গেছে।'), ('the fruit-sellers', 'মেলে না।'), ('the common people', 'মেলে না।')], 'শিক্ষাকে ঘিরে লাভবান গোষ্ঠী।', True),
])

# =====================================================================
# U1·L2 Education and Technology
# =====================================================================
B.lesson(L + '11', [
    H('Education and Technology — এক নজরে'),
    FACTS('মূল পাঠ: **"AI in The Classroom: Pros, Cons and The Role Of EdTech Companies"**', 'লেখক: **Olufemi Shonubi**; উৎস: **Forbes** (২১ ফেব্রুয়ারি ২০২৩)', 'পাঠের দ্বিতীয় অংশ: **How to Paraphrase** (উৎস: Grammarly Blog, M. Ellis, ২০২৪)', h='মূল তথ্য'),
    TABLE('AI-এর সুবিধা ও অসুবিধা', ['সুবিধা (Advantages)', 'অসুবিধা (Downsides)'],
          ('Personalised learning — ছাত্রের তথ্য বিশ্লেষণ করে আলাদা সহায়তা', 'শিক্ষকদের চাকরি হারানোর আশঙ্কা'),
          ('Instant feedback — তাৎক্ষণিক ভুল ধরা', 'উচ্চ খরচ'), ('Repetitive কাজ (খাতা দেখা, কুইজ গ্রেডিং) স্বয়ংক্রিয়', 'মানবিক সংযোগ ও মানসিক সহায়তার অভাব'), ('—', 'গোপনীয়তা (privacy) ও নিরাপত্তার ঝুঁকি')),
    TABLE('পাঠে উল্লিখিত AI টুল', ['টুল', 'কাজ'],
          ('Ahura', 'মনোযোগ ও সম্পৃক্ততা দেখে শেখার অভ্যাস ট্র্যাক করে'), ('Knewton', 'adaptive learning platform'), ('Querium', 'গণিতে ধাপে ধাপে টিউটরিং'),
          ('ALEKS', 'দুর্বলতা-সক্ষমতা অনুযায়ী আলাদা শেখার পথ'), ('Carnegie Learning', 'গণিতের AI টিউটর'), ('Smart Sparrow', 'প্রতিটি ছাত্রের জন্য আলাদা গঠনমূলক feedback'), ('Gradescope', 'স্বয়ংক্রিয় গ্রেডিং')),
    TABLE('EdTech কোম্পানির করণীয় (৫টি)', ['বিষয়', 'সারকথা'], ('Cost', 'খরচ কমানো, অনুদান/অংশীদারি'), ('Human interaction', 'শিক্ষকের জায়গা নয়, সহায়ক হওয়া'),
          ('Privacy and security', 'ছাত্রের তথ্য সুরক্ষা'), ('Improved AI capabilities', 'সৃজনশীলতা ও প্রসঙ্গ-বোঝার ঘাটতি দূর করা'), ('Ethical considerations', 'স্বচ্ছ, ন্যায্য, আইনসম্মত ব্যবহার')),
    H('Paraphrasing'),
    P('**Paraphrase** = মূল লেখার অর্থ ঠিক রেখে নিজের ভাষায় নতুন করে লেখা; **summary**-র মতো ছোট করা নয় — প্রায় একই পরিমাণ তথ্য থাকে। মূল লেখার খুব কাছাকাছি থেকে গেলে তাকে **patchwriting** বলে। শেষে অবশ্যই **citation** (APA, MLA বা Chicago) দিতে হয়।'),
    OL('মূল লেখা ভালো করে পড়া', 'স্মৃতি থেকে নতুন করে লেখা', 'শব্দ (synonym) ও বাক্যগঠন বদলানো', 'যথেষ্ট আলাদা হয়েছে কি না যাচাই (patchwriting এড়ানো)', 'অর্থ ঠিক আছে কি না ও proofread', 'Citation যোগ'),
    SUMMARY('AI: personalised learning, instant feedback, automation', 'ঝুঁকি: চাকরি, খরচ, মানবিক সংযোগ, privacy', 'AI শিক্ষকের বিকল্প নয়, সহায়ক', 'Paraphrase ≠ summary; patchwriting এড়ান; citation দিন'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '11', 'সুবিধা-অসুবিধা ও টুলের কাজ আলাদা করে মনে রাখুন।', 'Education and Technology সারণি।', [
    ('The article on AI in the classroom in EFT is written by —', 'Olufemi Shonubi', [('M. Ellis', 'Paraphrasing অংশের উৎস।'), ('Shona McCombes', 'পরের লেসনের paragraph অংশের উৎস।'), ('Kaiser Haq', 'মেলে না।')], 'লেখক Olufemi Shonubi।', True),
    ('The article was originally published in —', 'Forbes', [('The Daily Star', 'মেলে না।'), ('Banglapedia', 'Folk Music লেসনের উৎস।'), ('Scribbr', 'Paragraph অংশের উৎস।')], 'উৎস Forbes (২০২৩)।', True),
    ('Which is mentioned as a main advantage of AI in the classroom?', 'personalised learning', [('replacing teachers completely', 'লেখক উল্টো বলেছেন।'), ('lower internet use', 'মেলে না।'), ('ending all exams', 'মেলে না।')], 'Personalised learning, instant feedback, automation।', False),
    ('According to the article, AI can free up teachers\' time by —', 'grading assignments and quizzes automatically', [('teaching all classes', 'মেলে না।'), ('writing textbooks', 'মেলে না।'), ('replacing the principal', 'মেলে না।')], 'Repetitive কাজ স্বয়ংক্রিয়।', False),
    ('Ahura is described as an AI tool that —', 'tracks learning habits by observing attention and engagement', [('grades exam papers', 'Gradescope।'), ('tutors students in maths step by step', 'Querium।'), ('offers an adaptive platform only', 'Knewton।')], 'Ahura = attention ও engagement।', True),
    ('Which AI tool automates the grading process?', 'Gradescope', [('Ahura', 'শেখার অভ্যাস ট্র্যাক।'), ('ALEKS', 'আলাদা শেখার পথ।'), ('Smart Sparrow', 'feedback।')], 'Gradescope = grading।', True),
    ('Querium provides —', 'step-by-step tutoring in maths', [('automatic grading', 'Gradescope।'), ('attention tracking', 'Ahura।'), ('music lessons', 'মেলে না।')], 'Querium = গণিত টিউটর।', False),
    ('Which is NOT listed as a downside of AI in the classroom?', 'improved students\' handwriting', [('cost', 'উল্লেখ আছে।'), ('privacy concerns', 'উল্লেখ আছে।'), ('lack of human interaction', 'উল্লেখ আছে।')], 'চারটি অসুবিধা: চাকরি, খরচ, মানবিক সংযোগ, privacy।', True),
    ('The writer\'s view about AI and teachers is that AI should —', 'assist teachers, not replace them', [('replace teachers', 'উল্টো।'), ('be banned in schools', 'উল্টো।'), ('be used only by teachers', 'মেলে না।')], '"not meant to replace teachers but rather to assist"।', True),
    ('Current AI tools are said to lack —', 'creativity, originality and understanding of context', [('speed', 'মেলে না।'), ('data', 'মেলে না।'), ('popularity', 'মেলে না।')], 'Improved AI capabilities অংশ।', True),
    ('True or false: "AI is always beneficial for students and teachers."', 'False', [('True', 'লেখক সীমাবদ্ধতা ও ঝুঁকি দেখিয়েছেন।'), ('Not mentioned', 'আলোচিত।'), ('Partly true for teachers only', 'মেলে না।')], 'সুবিধা আছে, তবে "always" নয়।', True),
    ('"Paraphrasing" means —', 'restating a text in new words while keeping its meaning', [('shortening a text to its main points', 'এটি summarizing।'), ('copying a text exactly', 'Plagiarism।'), ('translating into another language', 'মেলে না।')], 'Paraphrase ≈ একই তথ্য, নতুন ভাষা।', True),
    ('How is paraphrasing different from summarizing?', 'A paraphrase keeps roughly the same amount of detail.', [('A paraphrase is always shorter.', 'Summary ছোট হয়।'), ('A paraphrase needs no citation.', 'Citation লাগবে।'), ('A paraphrase copies the original words.', 'উল্টো।')], 'Summary = সংক্ষেপ; paraphrase = সমান বিস্তার।', True),
    ('Paraphrased text that stays too close to the original is called —', 'patchwriting', [('ghostwriting', 'মেলে না।'), ('copywriting', 'মেলে না।'), ('freewriting', 'মেলে না।')], 'Patchwriting এড়াতে হবে।', True),
    ('Which citation style is mentioned in the paraphrasing steps?', 'APA', [('ISBN', 'বইয়ের নম্বর, citation style নয়।'), ('HTML', 'মেলে না।'), ('IPA', 'ধ্বনিবিজ্ঞান।')], 'APA, MLA, Chicago।', False),
    ('The last step of paraphrasing is to —', 'add the citation', [('read the source', 'প্রথম ধাপ।'), ('change the meaning', 'অর্থ বদলানো যাবে না।'), ('copy key sentences', 'মেলে না।')], 'ধাপ ৬: Add the citations।', False),
    ('According to the article, edtech companies should make AI tools —', 'accessible, secure, ethical and supportive of teachers', [('expensive and exclusive', 'উল্টো।'), ('free from all laws', 'উল্টো।'), ('a full replacement for schools', 'উল্টো।')], 'পাঁচ করণীয়: cost, human interaction, privacy, capability, ethics।', False),
])

# =====================================================================
# U1·L3 Children in School
# =====================================================================
B.lesson(L + '12', [
    H('Children in School — এক নজরে'),
    FACTS('উৎস: স্মৃতিকথা **Totto-chan: The Little Girl at the Window**', 'লেখক: **Tetsuko Kuroyanagi** — জাপানি টেলিভিশন ব্যক্তিত্ব ও **UNICEF Goodwill Ambassador**', 'পটভূমি: দ্বিতীয় বিশ্বযুদ্ধকালীন **Tokyo**-র স্কুল', 'অংশ দুটি: **The New School** ও **The Headmaster**', h='মূল তথ্য'),
    H('ঘটনার সারাংশ (নিজের ভাষায়)'),
    OL('নতুন স্কুলের গেট দেখে তোত্তো-চান থমকে যায় — দুটি ছোট খুঁটি, তাতে তখনও ডালপাতা; আসলে শিকড়সহ গাছ। সে ভাবে গেটটা বাড়ছে!',
       'স্কুলের নাম **Tomoe Gakuen**। মাঠে দাঁড়িয়ে **ছয়টি পরিত্যক্ত রেলগাড়ির কামরা** — এগুলোই ক্লাসরুম। তোত্তো-চান আনন্দে দৌড় দেয়; মা (একসময় বাস্কেটবল দলে খেলতেন) তাকে ধরে ফেলেন।',
       'প্রধান শিক্ষকের অফিস একতলা ভবনে, প্রায় সাতটি অর্ধবৃত্তাকার পাথরের সিঁড়ির ওপরে। তোত্তো-চান ভাবে, এত ট্রেনের মালিক নিশ্চয়ই stationmaster! মা বলেন, বাবা বেহালা বাজান বলে তো বাড়িটা বেহালার দোকান নয়।',
       'প্রধান শিক্ষক **Sosaku Kobayashi** মাকে বাড়ি যেতে বলেন, তারপর তোত্তো-চানকে যা খুশি বলতে দেন। সে ট্রেন, কুকুর Rocky, আগের স্কুল, জামা ছেঁড়ার গল্প — সব বলে।',
       'সকাল আটটা থেকে দুপুরের খাবার পর্যন্ত — **চার ঘণ্টা** — তিনি একবারও হাই না তুলে শোনেন। তারপর বলেন, "এখন থেকে তুমি এই স্কুলের ছাত্রী।"',
       'সাত বছরের তোত্তো-চান জানত না যে আগের স্কুল থেকে তাকে **বহিষ্কার** করা হয়েছিল। জীবনে প্রথমবার কেউ তার কথা এত মন দিয়ে শুনল — সে নিরাপদ ও খুশি বোধ করল।'),
    H('Paragraph লেখার ধাপ (পাঠের দ্বিতীয় অংশ)'),
    P('উৎস: Scribbr-এ **Shona McCombes**-এর "Academic Paragraph Structure"। প্রতিটি paragraph হবে **Unified, Coherent, Relevant**। ধাপ: ১. purpose ঠিক করা (topic sentence) → ২. প্রাসঙ্গিকতা দেখানো → ৩. প্রমাণ দেওয়া → ৪. প্রমাণের ব্যাখ্যা → ৫. উপসংহার → ৬. পুরোটা পড়ে দেখা। উদাহরণ হিসেবে Braille পদ্ধতির স্বীকৃতির কথা আছে — ফরাসি সরকার প্রায় ৩০ বছর পর তা অনুমোদন করে।'),
    WORDS(('squat', 'উবু হয়ে বসা'), ('peer', 'খুঁটিয়ে তাকানো'), ('askew', 'বাঁকা, তেরছা'), ('glimpse', 'এক ঝলক দেখা'), ('abandoned', 'পরিত্যক্ত'), ('whoop', 'উল্লাসের চিৎকার'),
          ('shabby', 'জীর্ণ'), ('burrow', 'গর্ত খুঁড়ে/নিচ দিয়ে ঢোকা'), ('disposition', 'স্বভাব'), h='শব্দার্থ'),
    SUMMARY('Totto-chan — Tetsuko Kuroyanagi; স্কুল Tomoe Gakuen, Tokyo', 'ছয়টি রেলকামরা = ক্লাসরুম', 'Headmaster Sosaku Kobayashi — চার ঘণ্টা মন দিয়ে শোনেন', 'Paragraph: unified, coherent, relevant; ৬ ধাপ'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '12', 'নাম, সংখ্যা ও ঘটনাক্রম মনে রাখুন।', 'Children in School — সারাংশ।', [
    ('The excerpt "The New School" is taken from —', 'Totto-chan: The Little Girl at the Window', [('The Diary of a Young Girl', 'মেলে না।'), ('Pather Panchali', 'মেলে না।'), ('Little Women', 'মেলে না।')], 'Tetsuko Kuroyanagi-র স্মৃতিকথা।', True),
    ('The author of "Totto-chan" is —', 'Tetsuko Kuroyanagi', [('Sosaku Kobayashi', 'তিনি প্রধান শিক্ষক চরিত্র।'), ('Haruki Murakami', 'মেলে না।'), ('Kenzaburo Oe', 'মেলে না।')], 'লেখক = Tetsuko Kuroyanagi।', True),
    ('Tetsuko Kuroyanagi is described as a Japanese television personality and —', 'a UNICEF Goodwill Ambassador', [('a Nobel laureate in Physics', 'মেলে না।'), ('a former prime minister', 'মেলে না।'), ('a railway engineer', 'মেলে না।')], 'UNICEF Goodwill Ambassador।', False),
    ('The school in the excerpt was in —', 'Tokyo', [('Kyoto', 'মেলে না।'), ('Osaka', 'মেলে না।'), ('Hiroshima', 'মেলে না।')], 'দ্বিতীয় বিশ্বযুদ্ধকালীন Tokyo।', False),
    ('The name of the new school was —', 'Tomoe Gakuen', [('Tokyo Gakuen', 'মেলে না।'), ('Totto Gakuen', 'মেলে না।'), ('Kobayashi School', 'মেলে না।')], 'To-mo-e Ga-ku-en।', True),
    ('The gateposts of the new school were actually —', 'two short trees with roots', [('concrete pillars', 'আগের স্কুলের গেট।'), ('iron rods', 'মেলে না।'), ('telephone poles', 'তোত্তো-চান তুলনা করেছিল মাত্র।')], 'তাই সে বলেছিল "gate\'s growing"।', True),
    ('What were used as classrooms in the school?', 'six abandoned railroad cars', [('six tents', 'মেলে না।'), ('old buses', 'মেলে না।'), ('a single big hall', 'মেলে না।')], 'ছয়টি পরিত্যক্ত রেলকামরা।', True),
    ('Mother could catch Totto-chan quickly because she —', 'had once been on a basketball team', [('was a teacher', 'মেলে না।'), ('was riding a bicycle', 'মেলে না।'), ('knew a shortcut', 'মেলে না।')], 'বাস্কেটবল দলে খেলার অভিজ্ঞতা।', True),
    ('Totto-chan thought the headmaster must be a stationmaster because —', 'he seemed to own all the trains', [('he wore a uniform', 'মেলে না।'), ('he had a whistle', 'মেলে না।'), ('Mother told her so', 'মা উল্টো বোঝান।')], 'শিশুসুলভ যুক্তি।', False),
    ('To explain, Mother said that Daddy plays the violin, but that does not make their house —', 'a violin shop', [('a music school', 'মেলে না।'), ('a concert hall', 'মেলে না।'), ('a railway station', 'মেলে না।')], 'বেহালা থাকলেই বেহালার দোকান নয়।', False),
    ('The headmaster\'s name was —', 'Sosaku Kobayashi', [('Tetsuko Kuroyanagi', 'লেখক।'), ('Rocky', 'কুকুরের নাম।'), ('Tomoe', 'স্কুলের নামের অংশ।')], 'Headmaster Sosaku Kobayashi।', True),
    ('How long did the headmaster listen to Totto-chan?', 'about four hours', [('about four minutes', 'অনেক বেশি।'), ('about one hour', 'মেলে না।'), ('the whole day', 'আটটা থেকে দুপুরের খাবার পর্যন্ত।')], 'সকাল ৮টা → lunch = চার ঘণ্টা।', True),
    ('What does the long listening tell us about the headmaster?', 'He was patient and genuinely interested in children.', [('He was bored and sleepy.', '"hadn\'t yawned once"।'), ('He wanted to reject her.', 'উল্টো।'), ('He was in a hurry.', 'উল্টো।')], 'শিশুর কথা শোনার মূল্য।', False),
    ('The name of Totto-chan\'s dog was —', 'Rocky', [('Tomoe', 'স্কুল।'), ('Snowy', 'মেলে না।'), ('Tiger', 'মেলে না।')], 'বাদামি কুকুর Rocky।', False),
    ('What did Totto-chan not know at that time?', 'that she had been expelled from her previous school', [('that her father played the violin', 'জানত।'), ('the name of the school', 'পড়েছিল।'), ('that the classrooms were trains', 'দেখেছিল।')], 'আগের স্কুল থেকে বহিষ্কার।', True),
    ('Totto-chan was about how old when she joined the new school?', 'seven', [('five', 'মেলে না।'), ('ten', 'মেলে না।'), ('twelve', 'মেলে না।')], '"a seven-year-old child"।', False),
    ('According to the paragraph-writing guide in the lesson, every paragraph should be —', 'unified, coherent and relevant', [('long, poetic and personal', 'মেলে না।'), ('short, funny and informal', 'মেলে না।'), ('only one sentence long', 'মেলে না।')], 'Unified, Coherent, Relevant।', True),
    ('In the Braille example, the French government approved the Braille system after about —', '30 years', [('3 years', 'কম।'), ('100 years', 'বেশি।'), ('10 years', 'কম।')], 'প্রায় ৩০ বছর।', False),
])

# =====================================================================
# U1·L4 Civic Engagement
# =====================================================================
B.lesson(L + '13', [
    H('Civic Engagement — এক নজরে'),
    P('শিক্ষার লক্ষ্য শুধু গ্রেড বা সনদ নয় — শ্রেণিকক্ষে শেখা জ্ঞান, দক্ষতা ও মূল্যবোধ সমাজের কল্যাণে কাজে লাগানো। পাঠে তিনটি ধারণা পাশাপাশি রাখা হয়েছে।'),
    TABLE('তিন ধারণা', ['ধারণা', 'অর্থ', 'বৈশিষ্ট্য'],
          ('Civic engagement', 'জ্ঞান, দক্ষতা, মূল্যবোধ ও প্রেরণা দিয়ে সমাজজীবনে (civic life) ইতিবাচক পরিবর্তন আনা', 'প্রতিবাদ, মানববন্ধন, স্বাক্ষর সংগ্রহ, পিটিশন, স্কুলের সামনে যানজট নিয়ন্ত্রণ, পার্ক/সৈকত পরিষ্কার, প্রবীণদের সেবা'),
          ('Service learning', 'Civic engagement যখন কোনো **academic programme**-এর অংশ এবং নির্দিষ্ট মানদণ্ডে **মূল্যায়ন** করা হয়', 'পরিকল্পনা, বাজেট, বাস্তবায়ন, পর্যবেক্ষণ'),
          ('Volunteerism', 'Civic engagement যখন **স্বতঃস্ফূর্ত** কিন্তু **অনিয়মিত**, এবং কোনো academic programme-এর অংশ নয়', 'নিজ উদ্যোগে সহায়তা')),
    H('দুটি কাহিনি'),
    TABLE('Scenario', ['বিষয়', 'Scenario 1', 'Scenario 2'],
          ('কারা', 'কলেজছাত্র Ahmed, Swapan, Rakib, Niladri', 'California-র ১১ বছরের Alex ও তার সহপাঠীরা'),
          ('কোথায়/কী', 'সুনামগঞ্জের বন্যা — পানীয় জল, পরিচ্ছন্নতা, স্বাস্থ্যবিধি', 'রোমানিয়ার এক প্রত্যন্ত শহরে তীব্র শীত, ঘর গরম রাখার ব্যবস্থা নেই'),
          ('উদ্যোগ', 'নিজেদের, সহপাঠী, শিক্ষক, অভিভাবকদের চাঁদা — প্রায় ৩,০০,০০০ টাকা; শুকনো খাবার, পানি বিশুদ্ধকরণ ট্যাবলেট ইত্যাদি; অগ্রাধিকার ৭০-ঊর্ধ্ব প্রবীণ ও শিশু; এক সপ্তাহের বেশি কাজ', 'এক মাসের হাতখরচ দান; শিক্ষকের নির্দেশনায় প্রকল্প; স্থানীয় পৌরসভা ও আইনপ্রণেতাদের সঙ্গে যোগাযোগ; কয়েক সপ্তাহ সেখানে থেকে সহায়তা'),
          ('ধরন', 'Volunteerism (স্বতঃস্ফূর্ত, প্রাতিষ্ঠানিক মূল্যায়ন নেই)', 'Service learning (স্কুলের কর্মসূচি, পুরো প্রক্রিয়া পর্যবেক্ষণ ও মূল্যায়ন)')),
    P('দুই কাহিনির **মিল**: দুটিই civic engagement। Alex নিজের দেশের বাইরের মানুষের জন্য কাজ করে প্রমাণ করেছে সে একজন **global citizen**।'),
    MNEM(('"Service learning = School-এ Score হয়; Volunteerism = নিজের ইচ্ছায়"', 'পার্থক্য', 'মূল্যায়ন আছে কি না দেখুন।'),),
    SUMMARY('Civic engagement = সমাজে ইতিবাচক পরিবর্তনের কাজ', 'Service learning = academic programme + মূল্যায়ন', 'Volunteerism = স্বতঃস্ফূর্ত, অনিয়মিত', 'সুনামগঞ্জ (volunteerism) / Alex-রোমানিয়া (service learning)'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '13', 'তিন ধারণার পার্থক্য: academic programme ও মূল্যায়ন আছে কি না।', 'Civic Engagement সারণি।', [
    ('Civic engagement means —', 'working to make a difference in the civic life of a community', [('getting good grades only', 'পাঠে উল্টো বলা হয়েছে।'), ('working only for one\'s family', 'Private life, civic নয়।'), ('joining a political party', 'আবশ্যক নয়।')], 'জ্ঞান, দক্ষতা, মূল্যবোধ দিয়ে সমাজে পরিবর্তন।', False),
    ('When civic engagement is part of an academic programme and is assessed, it is called —', 'service learning', [('volunteerism', 'Academic নয়।'), ('civic duty', 'মেলে না।'), ('internship', 'মেলে না।')], 'Academic + assessment = service learning।', True),
    ('Civic engagement that is spontaneous but irregular and not part of any academic programme is —', 'volunteerism', [('service learning', 'Academic ও মূল্যায়িত।'), ('employment', 'মেলে না।'), ('citizenship test', 'মেলে না।')], 'স্বতঃস্ফূর্ত = volunteerism।', True),
    ('Which is given as an example of civic engagement?', 'helping children cross the road in front of a school', [('watching TV at home', 'মেলে না।'), ('playing video games', 'মেলে না।'), ('shopping', 'মেলে না।')], 'যা সরাসরি সমাজকে প্রভাবিত করে।', False),
    ('Protesting against an unjust municipal decision through rallies or petitions is —', 'a form of civic engagement', [('a private matter', 'জনস্বার্থের বিষয়।'), ('always illegal', 'মেলে না।'), ('service learning by default', 'Academic নয়।')], 'জনস্বার্থে সক্রিয়তা।', False),
    ('In Scenario 1, the flood took place in —', 'Sunamganj', [('Kurigram', 'মেলে না।'), ('Sirajganj', 'মেলে না।'), ('Feni', 'মেলে না।')], 'সুনামগঞ্জ।', True),
    ('Which was the biggest challenge in the flood shelters?', 'drinking water, cleanliness and hygiene', [('electricity', 'মেলে না।'), ('internet access', 'মেলে না।'), ('transport', 'মেলে না।')], 'পাঠে স্পষ্টভাবে উল্লিখিত।', False),
    ('About how much money did the college students collect?', 'Taka 3,00,000', [('Taka 30,000', 'কম।'), ('Taka 30,00,000', 'বেশি।'), ('Taka 3,000', 'অনেক কম।')], 'প্রায় তিন লাখ টাকা।', True),
    ('Whom did the students give priority to?', 'senior citizens over 70 and children', [('young men', 'মেলে না।'), ('shopkeepers', 'মেলে না।'), ('government officials', 'মেলে না।')], 'প্রবীণ ও শিশু।', False),
    ('Scenario 1 (the college students in Sunamganj) is an example of —', 'volunteerism', [('service learning', 'Academic programme বা মূল্যায়ন নেই।'), ('paid employment', 'মেলে না।'), ('a school exam', 'মেলে না।')], 'স্বতঃস্ফূর্ত উদ্যোগ।', True),
    ('Alex, in Scenario 2, was from —', 'California', [('Romania', 'সেখানে সাহায্য করতে গিয়েছিল।'), ('London', 'মেলে না।'), ('Toronto', 'মেলে না।')], 'California-র ১১ বছরের ছেলে।', True),
    ('The people Alex wanted to help were suffering from —', 'severe winter without proper heating', [('a flood', 'Scenario 1।'), ('an earthquake', 'মেলে না।'), ('a drought', 'মেলে না।')], 'রোমানিয়ার শীত।', False),
    ('Before this project, teachers were worried about Alex because he was —', 'an introvert who kept to himself', [('very naughty', 'মেলে না।'), ('often absent', 'মেলে না।'), ('weak in maths', 'মেলে না।')], 'Introvert।', False),
    ('Alex and his classmates first decided to donate —', 'a month of their pocket money', [('their books', 'মেলে না।'), ('their bicycles', 'মেলে না।'), ('a year\'s savings', 'মেলে না।')], 'এক মাসের হাতখরচ।', False),
    ('Scenario 2 is an example of service learning because —', 'it was a school project that was monitored and assessed', [('Alex was eleven years old', 'বয়স কারণ নয়।'), ('it happened abroad', 'স্থান কারণ নয়।'), ('it involved money', 'কারণ নয়।')], 'Academic + মূল্যায়ন।', True),
    ('By helping people in another country, Alex proved himself to be —', 'a global citizen', [('a tourist', 'মেলে না।'), ('a politician', 'মেলে না।'), ('a businessman', 'মেলে না।')], 'পাঠের T/F-এ সত্য।', False),
    ('What do both scenarios have in common?', 'Both are examples of civic engagement.', [('Both are service learning.', 'প্রথমটি volunteerism।'), ('Both took place in Bangladesh.', 'দ্বিতীয়টি রোমানিয়া।'), ('Both involved floods.', 'দ্বিতীয়টি শীত।')], 'সাধারণ সূত্র = civic engagement।', True),
])

# =====================================================================
# U2·L1 What is Beauty?
# =====================================================================
B.lesson(L + '14', [
    H('What is Beauty? — এক নজরে'),
    P('সৌন্দর্য উপভোগ করা সহজ, সংজ্ঞায়িত করা কঠিন — সৌন্দর্য কি বস্তুতে, নাকি দর্শকের চোখে ("in the eye of the beholder")? পাঠে দুটি কবিতা পাশাপাশি: **Byron** আদর্শায়িত এক নারীর মধ্যে নিখুঁত সৌন্দর্য দেখেন; **Dickinson** বলেন সৌন্দর্য ও সত্য অবিচ্ছেদ্য।'),
    TABLE('দুই কবিতা', ['বিষয়', 'She Walks in Beauty', 'I Died for Beauty'],
          ('কবি', 'Lord Byron (1788–1824)', 'Emily Dickinson (1830–1886)'), ('দৃষ্টিভঙ্গি', 'দৈহিক সৌন্দর্য, যা অন্তরের শুদ্ধতার প্রতিফলন', 'দার্শনিক — সৌন্দর্য ও সত্য এক'),
          ('চিত্রকল্প', 'মেঘহীন তারাভরা রাত; আলো-আঁধারের মিলন; কালো চুল (raven tress)', 'কবর; পাশের কামরায় সত্যের জন্য মৃত একজন; শ্যাওলা ঠোঁট ও নাম ঢেকে দেয়'),
          ('শেষ বার্তা', 'বাইরের রূপ অন্তরের শান্তি ও নিষ্পাপ ভালোবাসার সাক্ষ্য', 'সৌন্দর্য ও সত্যের সাধকেরা "brethren" — মৃত্যুর পরও আত্মীয়')),
    QUOTE('She walks in beauty, like the night / Of cloudless climes and starry skies;', 'Lord Byron, "She Walks in Beauty"',
          'কবিতার প্রথম দুই চরণ (কপিরাইটমুক্ত)।', 'নারীর সৌন্দর্যকে মেঘহীন, তারাভরা রাতের সঙ্গে তুলনা — আলো ও আঁধারের সমন্বয়।'),
    QUOTE('"And I for truth – the two are one; / We brethren are," he said.', 'Emily Dickinson, "I Died for Beauty"',
          'সত্যের জন্য মৃত ব্যক্তির উক্তি (কপিরাইটমুক্ত)।', 'সৌন্দর্য ও সত্য একই — তাই দুই সাধক ভাই।'),
    WORDS(('aspect', 'মুখভঙ্গি, চেহারা (countenance)'), ('gaudy', 'চটকদার, সস্তা ঝলমলে'), ('impair', 'ক্ষতি করা, দুর্বল করা'), ('scarce', 'সবেমাত্র, কদাচিৎ (barely)'),
          ('adjoining', 'পাশাপাশি, সংলগ্ন'), ('brethren', 'brother-এর বহুবচন (ভ্রাতৃগণ)'), ('moss', 'শ্যাওলা — স্যাঁতসেঁতে জায়গার ফুলহীন উদ্ভিদ'), ('climes', 'জলবায়ু/অঞ্চল (climates)'), ('raven', 'চকচকে কালো'), h='শব্দার্থ (পাঠের Column A–B অনুযায়ী)'),
    SUMMARY('Byron (1788–1824): She Walks in Beauty — বাহ্যিক রূপ = অন্তরের শুদ্ধতা', 'Dickinson (1830–1886): I Died for Beauty — beauty = truth', 'শব্দ: aspect, gaudy, impair, brethren, moss, climes, raven'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '14', 'কবি, সাল, চিত্রকল্প ও শব্দার্থ মিলিয়ে নিন।', 'What is Beauty? সারণি।', [
    ('"She Walks in Beauty" was written by —', 'Lord Byron', [('Emily Dickinson', '"I Died for Beauty"-এর কবি।'), ('John Keats', 'মেলে না।'), ('William Wordsworth', 'মেলে না।')], 'Byron।', True),
    ('"I Died for Beauty" was written by —', 'Emily Dickinson', [('Lord Byron', '"She Walks in Beauty"-এর কবি।'), ('Robert Burns', 'Auld Lang Syne।'), ('Christina Rossetti', 'মেলে না।')], 'Dickinson।', True),
    ('Lord Byron\'s life span as given in EFT is —', '1788–1824', [('1830–1886', 'Dickinson।'), ('1759–1796', 'Robert Burns।'), ('1770–1850', 'Wordsworth।')], 'Byron: ১৭৮৮–১৮২৪।', True),
    ('Emily Dickinson\'s life span as given in EFT is —', '1830–1886', [('1788–1824', 'Byron।'), ('1812–1870', 'মেলে না।'), ('1861–1941', 'রবীন্দ্রনাথ।')], 'Dickinson: ১৮৩০–১৮৮৬।', False),
    ('In "She Walks in Beauty", the woman\'s beauty is compared to —', 'a cloudless, starry night', [('a bright sunny day', 'রাত।'), ('a stormy sea', 'মেলে না।'), ('a red rose', 'মেলে না।')], '"like the night / Of cloudless climes and starry skies"।', True),
    ('In Byron\'s poem, the woman\'s outer beauty reflects her —', 'inner goodness and innocence', [('wealth', 'মেলে না।'), ('pride', 'মেলে না।'), ('sadness', 'মেলে না।')], 'শেষ স্তবক: mind at peace, innocent heart।', True),
    ('According to Dickinson\'s poem, beauty and truth are —', 'one and the same', [('opposites', 'উল্টো।'), ('unrelated', 'উল্টো।'), ('both useless', 'মেলে না।')], '"the two are one"।', True),
    ('In "I Died for Beauty", the speakers are —', 'two dead people in adjoining tombs', [('two lovers in a garden', 'মেলে না।'), ('a king and a soldier', 'মেলে না।'), ('two children at school', 'মেলে না।')], 'কবরের পাশাপাশি কামরা।', True),
    ('The man in the adjoining room had died for —', 'truth', [('beauty', 'বক্তা নিজে।'), ('love', 'মেলে না।'), ('his country', 'মেলে না।')], '"one who died for truth"।', False),
    ('In Dickinson\'s poem, what finally covers their names?', 'moss', [('snow', 'মেলে না।'), ('flowers', 'মেলে না।'), ('sand', 'মেলে না।')], '"Until the moss had reached our lips, / And covered up our names"।', True),
    ('The word "brethren" means —', 'brothers (plural of brother)', [('enemies', 'উল্টো।'), ('neighbours', 'মেলে না।'), ('strangers', 'মেলে না।')], 'brethren = brothers।', False),
    ('In the poems, "gaudy" means —', 'cheap and showy', [('dark and quiet', 'মেলে না।'), ('honest and simple', 'মেলে না।'), ('sad and lonely', 'মেলে না।')], 'gaudy = চটকদার।', True),
    ('"Climes" in Byron\'s poem means —', 'climates or regions', [('climbs', 'বানানের ফাঁদ।'), ('crimes', 'মেলে না।'), ('clouds', 'মেলে না।')], 'climes = climates।', True),
    ('"Raven", describing hair in Byron\'s poem, means —', 'glossy black', [('grey', 'মেলে না।'), ('golden', 'মেলে না।'), ('curly', 'মেলে না।')], 'raven tress = কালো চুল।', False),
    ('"Aspect" in Byron\'s poem refers to —', 'facial expression or countenance', [('direction', 'অন্য অর্থ — প্রসঙ্গে নয়।'), ('opinion', 'মেলে না।'), ('clothing', 'মেলে না।')], 'aspect = মুখভঙ্গি।', True),
    ('The word "adjoining" means —', 'next to one another', [('far away', 'উল্টো।'), ('above', 'মেলে না।'), ('empty', 'মেলে না।')], 'adjoining = সংলগ্ন।', False),
    ('Which view of beauty is more philosophical?', 'Dickinson\'s, linking beauty with truth', [('Byron\'s, praising a woman\'s face', 'দৈহিক সৌন্দর্যকেন্দ্রিক।'), ('Neither poem discusses beauty', 'উল্টো।'), ('Both are only about nature', 'মেলে না।')], 'পাঠ: Dickinson offers a more philosophical perspective।', False),
    ('The saying "beauty lies in the eye of the beholder" suggests that beauty is —', 'shaped by individual perception', [('the same for everyone', 'উল্টো।'), ('only found in nature', 'মেলে না।'), ('impossible to see', 'মেলে না।')], 'দর্শকভেদে সৌন্দর্য।', False),
])

# =====================================================================
# U2·L2 Folk Music
# =====================================================================
B.lesson(L + '15', [
    H('Folk Music — এক নজরে'),
    FACTS('মূল পাঠ: **Banglapedia** (Asiatic Society of Bangladesh)-তে প্রয়াত **Mridul Kanti Chakravarty**-র লোকসংগীত বিষয়ক নিবন্ধের সম্পাদিত অংশ', 'সঙ্গে: **Lalon Shah** সম্পর্কে পাঠ ও Robert Burns-এর **Auld Lang Syne**', h='মূল তথ্য'),
    P('**লোকসংগীত** = কোনো সম্প্রদায়ের গান ও সুর, যা শাস্ত্রীয় বা আধুনিক নিয়মে প্রভাবিত নয়; সাধারণ মানুষের ঐতিহ্য থেকে উৎসারিত গান, সুর ও নাচের সমন্বয়। বাংলাদেশে ধর্মীয় ও ধর্মনিরপেক্ষ — দুই ধরনের লোকসংগীতই আছে।'),
    UL('গ্রামীণ মানুষের রচিত, মৌখিকভাবে চলে আসা প্রাচীন রীতিতে', 'শাস্ত্রীয় বা আধুনিক সংগীতের প্রভাবমুক্ত', 'একক বা দলগতভাবে গাওয়া যায়; নিয়মিত রেওয়াজ লাগে না',
       'নিরক্ষর বা স্বল্পশিক্ষিত মানুষের রচনা ও পরিবেশনা', 'সহজ ভাষা, আঞ্চলিক উপভাষা, সরল সুর; প্রকৃতি ও গ্রামীণ পরিবেশনির্ভর', 'দৈনন্দিন সুখ-দুঃখ, প্রেম ও বিরহের আবেগময় প্রকাশ'),
    TABLE('অঞ্চল ও ধরন', ['গান', 'অঞ্চল (পাঠ অনুযায়ী)'],
          ('Baul ও আধ্যাত্মিক গান', 'Kushtia, Birbhum, West Bengal'), ('Jarigan', 'Dhaka, Mymensingh, Sylhet, Faridpur, Murshidabad'),
          ('Bhawaiya', 'Rajshahi, Dinajpur, Rangpur, Pabna, Cooch Bihar'), ('Gambhira', 'Rajshahi, Malda'), ('Sari', 'Sylhet ও Mymensingh-এর নিচু জলাভূমি অঞ্চল'),
          ('Bhatiyali', 'বাংলাদেশের প্রায় সব অঞ্চল'), ('Roof-beating songs', 'উত্তরাঞ্চল'), ('Pastoral songs', 'Dhaka, Mymensingh, Faridpur, Sylhet, Habiganj'), ('Wedding songs', 'সব অঞ্চল')),
    TABLE('একক বনাম সমবেত', ['ধরন', 'গান'], ('একক (individually)', 'Baul, Bhatiyali, Murshidi, Marfati'), ('সমবেত (chorus)', 'Kabigan, Leto, Alkap, Gambhira'),
          ('শুধু নারীরা রচনা ও গায়', 'Bratagan, Meyeli Git'), ('নারী-পুরুষ উভয়ে', 'roof-beating songs (ছাদ পেটানোর গান)')),
    P('আঞ্চলিক ভিন্নতা: উত্তরে **Bhawaiya**, পূর্বে **Bhatiyali**, দক্ষিণ-পশ্চিমে **Baul**। নদীমাতৃক দেশ বলে **Bhatiyali** গুরুত্বপূর্ণ ধারা। চাকমা, মণিপুরি, সাঁওতাল, ত্রিপুরা জনগোষ্ঠীর সংস্কৃতিও লোকসংগীতকে সমৃদ্ধ করেছে।'),
    H('Lalon Shah'),
    UL('পাঠে জীবৎকাল **1774–1890**; Baul ঐতিহ্যের প্রতীক, দার্শনিক ও সমাজসংস্কারক', 'ধর্মীয় সহনশীলতা প্রচার; শ্রেণি, বর্ণ, জাতপাতের ভেদাভেদ অস্বীকার', 'প্রাতিষ্ঠানিক শিক্ষা ছিল না',
       'প্রচলিত কাহিনি: তীর্থযাত্রায় বসন্তে আক্রান্ত হলে সঙ্গীরা ফেলে যায়; মুসলিম ফকির **Siraj Sain** সেবা করে সুস্থ করেন', 'কুষ্টিয়ার কাছে **Chheuriya**-য় আখড়া স্থাপন; একতারা/দোতারার সঙ্গে শিষ্যরা গান গাইতেন',
       'রবীন্দ্রনাথ ও নজরুল তাঁর **sahajiya** দর্শনের অনুরাগী ছিলেন — নিজের দেহ-মনের সরল সত্যে সাধনার মাধ্যমে আত্মোপলব্ধি', 'শিষ্য (পাঠ অনুযায়ী): Kangal Harinath Majumder, Pagla Kanai, Dudu Shah'),
    H('Auld Lang Syne'),
    P('**Robert Burns**-এর গান, একটি স্কটিশ লোকগানের ভিত্তিতে রচিত; পৃথিবীজুড়ে **৩১ ডিসেম্বর** পুরোনো বছরকে বিদায় ও নতুন বছরকে স্বাগত জানাতে গাওয়া হয়। শিরোনামের অর্থ মোটামুটি "পুরোনো দিনের জন্য" (old long since)। রবীন্দ্রনাথের **"পুরানো সেই দিনের কথা"** এই গানের বাংলা রূপ হিসেবে পরিচিত।'),
    QUOTE('Should old acquaintance be forgot, / And never brought to mind?', 'Robert Burns, "Auld Lang Syne"', 'গানের প্রথম দুই চরণ (কপিরাইটমুক্ত)।', 'পুরোনো বন্ধুত্ব কি ভুলে যাওয়া উচিত? — উত্তর: না, পুরোনো দিনের স্মরণে বন্ধুত্বের পেয়ালা।'),
    SUMMARY('লোকসংগীত: মৌখিক, প্রকৃতিনির্ভর, আঞ্চলিক ভাষা', 'উত্তর-Bhawaiya, পূর্ব-Bhatiyali, দক্ষিণ-পশ্চিম-Baul', 'একক: Baul, Bhatiyali, Murshidi, Marfati; সমবেত: Kabigan, Leto, Alkap, Gambhira', 'Lalon (1774–1890), Siraj Sain, Chheuriya; Auld Lang Syne — Robert Burns'),
    UNI(UNIT_EFT),
], SRC)
FQ(L + '15', 'অঞ্চল, ধরন ও নাম আলাদা সারণিতে মুখস্থ রাখুন।', 'Folk Music সারণি।', [
    ('The Folk Music excerpt in EFT is taken from an article published in —', 'Banglapedia', [('Forbes', 'আগের লেসন।'), ('The Daily Star', 'মেলে না।'), ('Scribbr', 'মেলে না।')], 'Banglapedia (Asiatic Society of Bangladesh)।', True),
    ('The writer of the Folk Music article is the late —', 'Mridul Kanti Chakravarty', [('Lalon Shah', 'বিষয়, লেখক নন।'), ('Kaiser Haq', 'মেলে না।'), ('Fakrul Alam', 'মেলে না।')], 'প্রয়াত Mridul Kanti Chakravarty।', True),
    ('According to the excerpt, folk music is NOT influenced by —', 'classical or modern music rules', [('nature', 'প্রকৃতিনির্ভর।'), ('local dialect', 'উপভাষা ব্যবহার করে।'), ('daily joys and sorrows', 'এগুলোই বিষয়।')], 'শাস্ত্রীয়/আধুনিক নিয়মমুক্ত।', False),
    ('Which folk song is associated with the northern region?', 'Bhawaiya', [('Bhatiyali', 'পূর্বাঞ্চল।'), ('Baul', 'দক্ষিণ-পশ্চিম।'), ('Sari', 'সিলেট-ময়মনসিংহের জলাভূমি।')], 'উত্তরে Bhawaiya।', True),
    ('The eastern folk tradition mentioned is —', 'Bhatiyali', [('Bhawaiya', 'উত্তর।'), ('Baul', 'দক্ষিণ-পশ্চিম।'), ('Gambhira', 'রাজশাহী-মালদা।')], 'পূর্বে Bhatiyali।', True),
    ('Why is Bhatiyali an important genre in Bangladesh?', 'because the country is basically riverine', [('because it is sung only by women', 'Bratagan/Meyeli Git।'), ('because it is classical music', 'লোকসংগীত।'), ('because it comes from Malda', 'Gambhira।')], 'নদীমাতৃক দেশ।', False),
    ('Which of these is sung in chorus?', 'Kabigan', [('Baul', 'একক।'), ('Murshidi', 'একক।'), ('Marfati', 'একক।')], 'সমবেত: Kabigan, Leto, Alkap, Gambhira।', True),
    ('Which songs are composed and sung only by women?', 'Bratagan and Meyeli Git', [('Kabigan and Leto', 'সমবেত।'), ('Baul and Marfati', 'একক।'), ('Roof-beating songs', 'নারী-পুরুষ উভয়ে।')], 'শুধু নারীরা।', True),
    ('Gambhira songs belong to —', 'Rajshahi and Malda', [('Kushtia and Birbhum', 'Baul।'), ('Sylhet and Mymensingh', 'Sari।'), ('Rangpur and Dinajpur', 'Bhawaiya।')], 'Gambhira: Rajshahi, Malda।', True),
    ('According to the excerpt, Sari songs belong to —', 'the lower marshy regions of Sylhet and Mymensingh', [('the northern regions', 'Roof-beating।'), ('Kushtia', 'Baul।'), ('all regions', 'Wedding songs।')], 'Sari = সিলেট-ময়মনসিংহের নিচু জলাভূমি।', True),
    ('Lalon Shah\'s life span as given in EFT is —', '1774–1890', [('1861–1941', 'রবীন্দ্রনাথ।'), ('1899–1976', 'নজরুল।'), ('1759–1796', 'Robert Burns।')], 'পাঠ অনুযায়ী ১৭৭৪–১৮৯০।', True),
    ('Who nursed Lalon back to health after he was abandoned?', 'Siraj Sain', [('Dudu Shah', 'শিষ্য।'), ('Pagla Kanai', 'পাঠে শিষ্য হিসেবে উল্লিখিত।'), ('Kangal Harinath', 'শিষ্য।')], 'মুসলিম ফকির Siraj Sain।', True),
    ('Lalon set up his akhrah (monastery) at —', 'Chheuriya near Kushtia', [('Birbhum', 'মেলে না।'), ('Sylhet', 'মেলে না।'), ('Malda', 'মেলে না।')], 'কুষ্টিয়ার ছেঁউড়িয়া।', True),
    ('The essence of Lalon\'s sahajiya philosophy is —', 'attaining the self through simple truths within one\'s own body and soul', [('following strict rituals', 'উল্টো।'), ('renouncing music', 'উল্টো।'), ('worshipping kings', 'মেলে না।')], 'আত্মোপলব্ধি নিজের ভেতরে।', False),
    ('Which two great poets admired Lalon, according to the text?', 'Rabindranath Tagore and Kazi Nazrul Islam', [('Jasimuddin and Jibanananda Das', 'পাঠে উল্লেখ নেই।'), ('Byron and Burns', 'মেলে না।'), ('Michael Madhusudan and Bankim', 'মেলে না।')], 'রবীন্দ্রনাথ ও নজরুল।', False),
    ('"Auld Lang Syne" was written by —', 'Robert Burns', [('Lord Byron', 'মেলে না।'), ('Emily Dickinson', 'মেলে না।'), ('Rabindranath Tagore', 'তিনি বাংলা রূপ দেন।')], 'Robert Burns, স্কটিশ লোকগানের ভিত্তিতে।', True),
    ('"Auld Lang Syne" is traditionally sung —', 'on 31st December to bid farewell to the old year', [('at weddings only', 'মেলে না।'), ('on 21st February', 'মেলে না।'), ('at harvest time', 'মেলে না।')], 'নববর্ষের প্রাক্কালে।', False),
    ('The phrase "auld lang syne" roughly means —', 'old times long past', [('a long journey', 'মেলে না।'), ('a new beginning', 'উল্টো।'), ('an old song', 'আংশিক — অর্থ "পুরোনো দিন"।')], 'old long since = পুরোনো দিন।', True),
    ('Which ethnic communities are mentioned as influencing folk music?', 'Chakmas, Manipuris, Santals and Tripuris', [('Rohingyas only', 'মেলে না।'), ('Marmas only', 'মেলে না।'), ('none', 'উল্লেখ আছে।')], 'চাকমা, মণিপুরি, সাঁওতাল, ত্রিপুরা।', False),
])

B.autofill_cards(12)
B.save('eft1', 'en-eft1')
