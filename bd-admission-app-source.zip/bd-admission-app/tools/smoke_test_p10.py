#!/usr/bin/env python3
"""smoke_test_p10.py — Phase 10: Mega Mock (DU B সম্মিলিত, RU নম্বর-স্কেল), Subject Final, Gamification, ৬টি গেম, রিপোর্ট পাতা, PWA (http), অফলাইন"""
import os, sys, threading, functools, http.server, socketserver
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DIST = os.path.join(ROOT, 'src' if 'src' in sys.argv[1:] else 'dist')
URL = 'file://' + os.path.join(DIST, 'index.html')
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h, url=None):
    page.goto('about:blank'); page.goto((url or URL) + h); page.wait_for_function('window.__APP_READY === true', timeout=15000)
def shot(page, n):
    if SHOTS: page.screenshot(path=f'{SHOTS}/{n}.png', full_page=True)
def answer_all(page, frac=0.7):
    # প্রতিটি প্রশ্নে: frac অংশ সঠিক, বাকিগুলো ভুল উত্তর (JS দিয়ে দ্রুত) — আগে টেস্ট পাতা ছেড়ে যাই যেন চলমান সেভ ওভাররাইট না করে
    boot(page, '#/home'); page.wait_for_timeout(300)
    page.evaluate("""(frac) => { const a = Store.get('test:active'); a.qids.forEach((id, i) => { const q = QB.get(id); a.ans[id] = (i < a.qids.length * frac) ? q.a : (q.a + 1) % q.o.length; }); Store.set('test:active', a, 0); }""", frac)
    page.wait_for_timeout(200)

with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))

    # ---- Mega Mock hub ----
    boot(page, '#/mega')
    check('Mega Mock: প্রতিটি ইউনিটের কার্ড (১০টি — শাবিপ্রবি B ও জাবি E-সহ)', page.locator('.mega-card').count() == 10, str(page.locator('.mega-card').count()))
    check('আমার ইউনিট (DU B) প্রথমে ও লিখিত ৪০ দেখায়', 'আমার ইউনিট' in page.locator('.mega-card').first.inner_text() and 'লিখিত ৪০' in page.locator('.mega-card').first.inner_text())
    ru = page.locator('.mega-card', has_text='রাজশাহী').first.inner_text()
    check('RU A: অফিসিয়াল বণ্টন নেই — সমান ভাগ স্পষ্টভাবে জানানো', 'সমান ভাগে' in ru and '৮০টি MCQ' in ru, ru[:120])
    shot(page, 'p10-mega')
    # ---- DU B: MCQ ----
    page.click('[data-start="du-b"]'); page.click('#mo'); page.wait_for_selector('#tsubmit')
    n = page.evaluate("Store.get('test:active').qids.length")
    secs = page.evaluate("Store.get('test:active').qids.map(id=>QB.get(id).sub)")
    check('DU B Mega: ৬০টি প্রশ্ন, ৪৫ মিনিট', n == 60 and page.evaluate("Store.get('test:active').total") == 45 * 60, str(n))
    order_ok = all(s in ('bn1', 'bn2') for s in secs[:15]) and all(s == 'en' for s in secs[15:30]) and all(s in ('gkbd', 'gkint', 'ca') for s in secs[30:])
    check('অংশের ক্রম: বাংলা ১৫ → ইংরেজি ১৫ → সাধারণ জ্ঞান ৩০', order_ok)
    answer_all(page, 0.7)
    boot(page, '#/test/run'); page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')
    sc = page.evaluate("Store.get('tests')[0].score")
    check('নম্বর = সঠিক − ০.২৫×ভুল (৪২ − ৪.৫ = ৩৭.৫)', abs(sc - 37.5) < 0.01, str(sc))
    t = page.inner_text('main')
    check('ফলাফলে "ধাপ ২: লিখিত অংশ" বাটন', page.locator('a[href="#/written/full"]').count() >= 1 and 'ধাপ ২' in t)
    shot(page, 'p10-mega-result')
    # ---- DU B: লিখিত ----
    page.click('a[href="#/written/full"]'); page.wait_for_selector('.wl-text')
    page.locator('.wl-text').first.fill('পরীক্ষার জন্য লেখা একটি অনুচ্ছেদ')
    page.click('#wl-sub'); page.wait_for_selector('.wl-rev')
    check('লিখিত রিভিউতে Mega সংযোগ ব্যানার', 'Mega Mock-এর লিখিত অংশ' in page.inner_text('main'))
    for i in range(page.locator('.wl-score').count()):
        page.locator('.wl-score').nth(i).fill('৩')
    page.wait_for_timeout(700)
    boot(page, '#/mega/du-b')
    t = page.inner_text('main')
    # লিখিত: ৭ অংশ × ৩ = ২১ ; মোট ৩৭.৫ + ২১ = ৫৮.৫
    check('সম্মিলিত ফল: MCQ ৩৭.৫ + লিখিত ২১ = ৫৮.৫/১০০', '৫৮.৫' in t and '২১' in t and '৩৭.৫' in t, t[:200])
    check('পাস নম্বরের শর্ত দেখায় (Verify-সহ)', 'পাস নম্বরের শর্ত পূরণ হয়েছে' in t)
    shot(page, 'p10-mega-combo')
    # ---- RU A: ৮০ প্রশ্ন, ১০০ নম্বর ----
    boot(page, '#/mega')
    page.click('[data-start="ru-a"]'); page.click('#mo'); page.wait_for_selector('#tsubmit')
    check('RU A: ৮০ প্রশ্ন, ৬০ মিনিট', page.evaluate("Store.get('test:active').qids.length") == 80 and page.evaluate("Store.get('test:active').total") == 3600)
    answer_all(page, 0.5)
    boot(page, '#/test/run'); page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')
    r = page.evaluate("Store.get('tests')[0]")
    check('RU: প্রতি প্রশ্ন ১.২৫ নম্বর, সর্বোচ্চ ১০০ (৪০×১.২৫ − ৪০×০.২৫ = ৪০)', r['max'] == 100 and abs(r['score'] - 40) < 0.01, f"{r['score']}/{r['max']}")
    check('RU পাস নম্বর ৪০ যাচাই দেখায়', 'পাস নম্বর ৪০' in page.inner_text('main'))

    # ---- Subject Final ----
    boot(page, '#/final')
    check('Final হাবে সব বিষয়', page.locator('.final-row').count() == page.evaluate('Core.SUBJ.length'))
    boot(page, '#/final/gkbd'); page.click('#fs'); page.wait_for_selector('#tsubmit')
    q = page.evaluate("Store.get('test:active').qids.map(id=>QB.get(id).cid)")
    check('Final: ১০০ প্রশ্ন, সব অধ্যায় থেকে', len(q) == 100 and len(set(q)) == page.evaluate("new Set(QB.forSubject('gkbd').map(q=>q.cid)).size"), f'{len(q)}, {len(set(q))}')
    check('Final: সময় ৭৫ মিনিট', page.evaluate("Store.get('test:active').total") == 75 * 60)
    answer_all(page, 0.55)
    boot(page, '#/test/run'); page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')
    t = page.inner_text('main')
    check('Final রিপোর্ট: LQS, Mastery, অধ্যায়ভিত্তিক, রিভিশন প্ল্যান', 'Learning Quality Score' in t and 'Mastery' in t and 'অধ্যায়ভিত্তিক' in t and 'দিন ১' in t)
    check('রিভিশন প্ল্যানে পাঠ/Quiz/Flashcard লিংক', page.locator('.plan-item a[href^="#/quiz/l/"]').count() >= 1 and page.locator('.plan-item a[href^="#/flash/review?lid="]').count() >= 1)
    shot(page, 'p10-final-result')

    # ---- গেম ----
    boot(page, '#/games')
    check('৬টি গেম, সবগুলো চালুযোগ্য', page.locator('.game-tile').count() == 6 and page.locator('.game-tile.off').count() == 0)
    # মিলাও: সঠিক জোড়া খুঁজে খেলা শেষ
    boot(page, '#/games/match')
    for _ in range(5):
        l = page.locator('[data-l]:not([disabled])').first
        i = l.get_attribute('data-l'); l.click()
        page.locator(f'[data-r="{i}"]').click(); page.wait_for_timeout(80)
    check('মিলাও: সব জোড়া মেলালে জয়', 'জয়' in page.inner_text('main') and 'নতুন ব্যক্তিগত সেরা' in page.inner_text('main'))
    # ভুল জোড়া → ভুলের খাতা
    boot(page, '#/games/match')
    page.locator('[data-l]').first.click()
    i = page.locator('[data-l]').first.get_attribute('data-l')
    page.locator(f'[data-r]:not([data-r="{i}"])').first.click(); page.wait_for_timeout(600)
    check('মিলাও: ভুল জোড়া গেমের ভুলে জমা', len(page.evaluate("Store.get('gmist', [])")) >= 1)
    # জোড়া খোঁজো
    boot(page, '#/games/memory')
    for _ in range(6):
        idx = page.evaluate("""() => { const b=[...document.querySelectorAll('.mem:not(.got)')]; return b.length ? +b[0].dataset.k : -1; }""")
        if idx < 0: break
        page.locator(f'[data-k="{idx}"]').click()
        # সঙ্গী খুঁজতে একে একে চেষ্টা (ভুল হলে ৯০০ms অপেক্ষা)
        found = False
        for k in page.evaluate("[...document.querySelectorAll('.mem:not(.got):not(.up)')].map(b=>+b.dataset.k)"):
            page.locator(f'[data-k="{k}"]').click(); page.wait_for_timeout(60)
            if page.locator(f'[data-k="{idx}"].got').count() or 'জয়' in page.inner_text('main') or 'আরেকবার' in page.inner_text('main'): found = True; break
            page.wait_for_timeout(950); page.locator(f'[data-k="{idx}"]').click()
        if 'চাল' not in page.inner_text('main'): break
    check('জোড়া খোঁজো: খেলা শেষ হয়', page.locator('.game-end').count() == 1)
    # সাল অনুযায়ী
    boot(page, '#/games/timeline'); page.click('#tlchk'); page.wait_for_selector('.game-end', timeout=4000)
    check('সাল অনুযায়ী সাজাও: মিলিয়ে দেখার পর সঠিক ক্রম দেখায়', page.locator('.game-end ol li').count() == 5)
    # শ্রেণি
    boot(page, '#/games/sort')
    for _ in range(8):
        if page.locator('.game-end').count(): break
        page.locator('[data-c]').first.click(); page.wait_for_timeout(40)
    check('শ্রেণিতে ভাগ: ৮টি শেষে ফল', page.locator('.game-end').count() == 1)
    # Speed Quiz (ঘড়ি দ্রুত শেষ করা)
    boot(page, '#/games/speed')
    for _ in range(3): page.locator('.opt').first.click(); page.wait_for_timeout(60)
    page.wait_for_timeout(200)
    check('Speed Quiz: উত্তর দিলে QB-তে রেকর্ড হয়', page.evaluate("Object.keys(Store.get('qstat',{})).length") >= 1)
    # Word builder: সঠিক অক্ষর ক্রমে
    boot(page, '#/games/word')
    w = page.evaluate("Gami.pools().words.length")
    for _ in range(5):
        if page.locator('.game-end').count(): break
        word = page.evaluate("""() => { const m=document.querySelector('.sort-item').textContent; const x=Gami.pools().words.find(w=>w.m===m); return x?x.w:''; }""")
        if not word: page.click('#wbskip'); page.wait_for_timeout(1300); continue
        for ch in word:
            page.locator(f'.wb-tile:not([disabled]):text-is("{ch}")').first.click()
        page.wait_for_timeout(900)
    check('Word Builder: সঠিক বানানে ৫ রাউন্ড শেষ, জয়', page.locator('.game-end').count() == 1 and 'জয়' in page.inner_text('main'), f'{w} words')

    # ---- অর্জন ----
    boot(page, '#/achieve')
    t = page.inner_text('main')
    check('অর্জন: লেভেল, XP, চ্যালেঞ্জ, ব্যাজ, লিডারবোর্ড', all(x in t for x in ['লেভেল', 'XP', 'আজকের চ্যালেঞ্জ', 'ব্যাজ', 'লোকাল লিডারবোর্ড']))
    check('ব্যাজ পাওয়া গেছে (প্রথম টেস্ট, Mega যোদ্ধা, লেখক)', page.locator('.badge.on').count() >= 3, str(page.locator('.badge.on').count()))
    check('লিডারবোর্ডে Mega ও গেমের সেরা', 'Mega Mock' in t and 'মিলাও' in t)
    xp = page.evaluate('Gami.xp()')
    check('XP > ০', xp > 0, str(xp))
    shot(page, 'p10-achieve')
    boot(page, '#/home')
    check('হোমে লেভেল কার্ড ও প্রেরণার বাক্য', page.locator('.gami-home').count() == 1 and '“' in page.inner_text('.gami-home'))
    boot(page, '#/mistakes')
    check('ভুলের খাতায় "গেমের ভুল" অংশ', page.locator('#gmist').count() == 1)

    # ---- রিপোর্ট ----
    boot(page, '#/about')
    t = page.inner_text('main')
    check('রিপোর্ট পাতা: Coverage, QC, APK গাইড, আকার', all(x in t for x in ['Coverage Checklist', 'QC রিপোর্ট', 'APK', 'আকার']))
    check('ফাইল থেকে চালালে অফলাইন বার্তা ও কোনো manifest নয়', 'ইন্টারনেট ছাড়াই' in t and page.locator('link[rel=manifest]').count() == 0)
    nl = page.evaluate("Core.SUBJ.reduce(function(a,s){return a+s.ch.reduce(function(b,c){return b+c.l.length},0)},0)")
    nb = str(nl).translate(str.maketrans('0123456789', '০১২৩৪৫৬৭৮৯'))
    check(f'Coverage: সব পাঠে কনটেন্ট ({nb}/{nb})', f'{nb}/{nb}' in t, str(nl))
    shot(page, 'p10-about')
    check('৩৬০px-এ অনুভূমিক স্ক্রল নেই (রিপোর্ট)', page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1"))
    check('JS error নেই', not errs, '; '.join(errs[:3]))
    ctx.close()

    # ---- PWA: HTTP সার্ভারে ----
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a): pass
    Handler = functools.partial(Quiet, directory=DIST)
    srv = socketserver.TCPServer(('127.0.0.1', 0), Handler); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True)
    page = ctx.new_page(); errs2 = []
    page.on('pageerror', lambda e: errs2.append(str(e)))
    boot(page, '#/home', f'http://127.0.0.1:{port}/index.html')
    man = page.evaluate("""async () => { const l=document.querySelector('link[rel=manifest]'); if(!l) return null; const r=await fetch(l.href); return await r.json(); }""")
    check('হোস্ট করলে manifest যোগ হয় (নাম, standalone, ১৯২/৫১২ আইকন)', man and man['display'] == 'standalone' and len(man['icons']) >= 2 and man['icons'][0]['src'].startswith('data:image/png'), str(man and man.get('short_name')))
    sw = page.evaluate("AboutApp.swSource()")
    open(os.path.join(DIST, 'sw.js'), 'w').write(sw)
    boot(page, '#/home', f'http://127.0.0.1:{port}/index.html')
    page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.ready.then(()=>true)", timeout=10000)
    page.wait_for_timeout(800)
    boot(page, '#/home', f'http://127.0.0.1:{port}/index.html')
    ctrl = page.evaluate("!!navigator.serviceWorker.controller")
    check('sw.js পাশে রাখলে Service Worker চালু হয়', ctrl)
    srv.shutdown(); srv.server_close()
    ctx.set_offline(True)
    try:
        boot(page, '#/l/bn1-1-1', f'http://127.0.0.1:{port}/index.html')
        off = 'অপরিচিতা' in page.inner_text('main')
    except Exception as e:
        off = False
    check('সার্ভার বন্ধ ও অফলাইনেও (SW ক্যাশ থেকে) পাঠ খোলে', off)
    os.remove(os.path.join(DIST, 'sw.js'))
    check('HTTP-তে JS error নেই', not errs2, '; '.join(errs2[:3]))
    ctx.close(); br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
