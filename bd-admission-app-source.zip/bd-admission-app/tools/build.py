#!/usr/bin/env python3
"""
build.py — A7: সোর্স (আলাদা CSS/JS/JSON) থেকে
  1) src/data/js/*.js  — ডেভ মোডের জন্য (src/index.html সরাসরি file:// থেকে খোলা যায়)
  2) dist/index.html   — একটিই স্বয়ংসম্পূর্ণ ফাইল: CSS, JS, ডেটা, ফন্ট সব ইনলাইন;
                         কোনো CDN/ইন্টারনেট লাগে না। ডেটা <script type="application/json">
                         হিসেবে থাকে, প্রয়োজনে পার্স হয় (Lazy Parse)।
ব্যবহার:  python3 tools/build.py
"""
import base64, glob, json, os, re, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
SRC = os.path.join(ROOT, 'src')
DATA = os.path.join(SRC, 'data')
DIST = os.path.join(ROOT, 'dist')
FONTS = os.path.join(ROOT, 'tools', 'fonts')

WARN_MB = 8      # এর বেশি হলে ধীর ফোন/কনভার্টারে সমস্যা হতে পারে — সতর্কতা
LIMIT_MB = 15    # এর বেশি হলে Track-ভিত্তিক ভাগ নিয়ে সিদ্ধান্ত চাই


def data_name(path):
    """src/data/pyq/du-b-2024.json -> 'pyq/du-b-2024'"""
    rel = os.path.relpath(path, DATA)
    return rel[:-5].replace(os.sep, '/')


def collect_data():
    files = [p for p in glob.glob(os.path.join(DATA, '**', '*.json'), recursive=True)
             if os.sep + 'js' + os.sep not in p]
    out = {}
    errors = []
    for p in sorted(files):
        try:
            with open(p, encoding='utf-8') as f:
                out[data_name(p)] = json.load(f)
        except Exception as e:
            errors.append(f'{os.path.relpath(p, ROOT)}: {e}')
    if errors:
        print('✗ JSON ত্রুটি:\n  ' + '\n  '.join(errors))
        sys.exit(1)
    return out


def min_json(obj):
    s = json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
    # HTML-এ <script> ভেতরে নিরাপদ রাখতে
    # সব "<" → \u003c: </script ও <!-- দুটোই নিরাপদ, আর JSON.parse-এ বৈধ escape
    return s.replace('<', '\\u003c')


def lesson_words(lesson):
    n = 0
    def cnt(v):
        nonlocal n
        if isinstance(v, str): n += len(v.split())
        elif isinstance(v, list):
            for x in v: cnt(x)
        elif isinstance(v, dict):
            for k, x in v.items():
                if k not in ('k', 'g'): cnt(x)
    cnt(lesson.get('b', []))
    return n


def add_lesson_meta(data):
    """শব্দসংখ্যা থেকে পড়ার সময় (বাংলা ≈ ১৫০ শব্দ/মিনিট) — PART C নিয়ম"""
    wpm = data['toc'].get('wpm_bn', 150)
    meta = {}
    qn = {}
    for name, obj in data.items():
        if name.startswith('questions/') and isinstance(obj, dict):
            for q in obj.get('q', []):
                if q.get('lid'): qn[q['lid']] = qn.get(q['lid'], 0) + 1
    for name, obj in data.items():
        if name.startswith('lessons/'):
            for lid, lesson in obj.items():
                # [পড়ার মিনিট, পাঠভিত্তিক MCQ সংখ্যা] — অ্যাপ এ দিয়ে মোট প্রস্তুতির সময় হিসাব করে
                meta[lid] = [max(1, round(lesson_words(lesson) / wpm)), qn.get(lid, 0)]
    data['lesson-meta'] = meta
    return meta


def write_dev_js(data):
    jsdir = os.path.join(DATA, 'js')
    os.makedirs(jsdir, exist_ok=True)
    for old in glob.glob(os.path.join(jsdir, '**', '*.js'), recursive=True):
        os.remove(old)
    for name, obj in data.items():
        p = os.path.join(jsdir, name + '.js')
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            f.write('(window.__D=window.__D||{})[' + json.dumps(name) + ']=' + min_json(obj) + ';\n')
    # ডেভ index.html-এর ডেটা ব্লক হালনাগাদ (নতুন ফাইল যোগ হলে)
    idx = os.path.join(SRC, 'index.html')
    html = open(idx, encoding='utf-8').read()
    tags = '\n'.join(f'<script src="data/js/{n}.js"></script>' for n in data)
    html = re.sub(r'(<!-- @build:data-start -->)(.*?)(<!-- @build:data-end -->)',
                  lambda m: m.group(1) + '\n' + tags + '\n' + m.group(3), html, flags=re.S)
    open(idx, 'w', encoding='utf-8').write(html)


def min_css(css):
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    css = re.sub(r'\s+', ' ', css)
    css = re.sub(r'\s*([{};,>])\s*', r'\1', css)
    css = css.replace(';}', '}')
    return css.strip()


def min_js(js):
    # নিরাপদ হালকা মিনিফাই: শুধু পুরো-লাইন মন্তব্য ও ব্লক-হেডার মন্তব্য, খালি লাইন ও সামনের ফাঁকা বাদ।
    # (স্ট্রিং/রেজেক্স ভাঙার ঝুঁকি এড়াতে inline মন্তব্য রাখা হয়েছে)
    js = re.sub(r'^\s*/\*[\s\S]*?\*/\s*$', '', js, flags=re.M)
    lines = []
    for ln in js.split('\n'):
        s = ln.strip()
        if not s or s.startswith('//'):
            continue
        lines.append(s)
    return '\n'.join(lines)


def font_css():
    """বাংলা ফন্ট (সব OFL): ডিফল্ট AppBangla = Hind Siliguri; বাকিগুলো সেটিংস থেকে বাছাই করা যায়।
    data-URI-তে থাকলেও ব্রাউজার শুধু ব্যবহৃত ফন্টটি ডিকোড করে।"""
    fams = [('AppBangla', ((400, 'HindSiliguri-Regular.woff'), (600, 'HindSiliguri-SemiBold.woff'))),
            ('BnNotoSans', ((400, 'NotoSansBengali-400.woff'), (600, 'NotoSansBengali-600.woff')))]
    # Serif, Tiro ও Baloo বাদ (WebIntoApp Free: ZIP ≤ ২ MB) — নতুন বিষয়ের জায়গা করতে
    faces = []
    for fam, files in fams:
        for weight, fn in files:
            p = os.path.join(FONTS, fn)
            if not os.path.exists(p):
                print(f'  ! ফন্ট নেই: {fn} (সিস্টেম ফন্টে চলবে)')
                continue
            b64 = base64.b64encode(open(p, 'rb').read()).decode()
            faces.append("@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;"
                         "src:url(data:font/woff;base64,%s) format('woff')}" % (fam, weight, b64))
    # 700 (bold) অনুরোধে ৬০০-ই ব্যবহার হবে (ব্রাউজার নিকটতম ওজন নেয়); Tiro-তে শুধু ৪০০ (ব্রাউজার কৃত্রিম বোল্ড করে)
    return '<style>' + ''.join(faces) + '</style>'


def build_single(data):
    html = open(os.path.join(SRC, 'index.html'), encoding='utf-8').read()

    # ফন্ট
    html = html.replace('<!-- @build:fonts -->', font_css())

    # CSS ইনলাইন
    def css_sub(m):
        css = open(os.path.join(SRC, m.group(1)), encoding='utf-8').read()
        return '<style>' + min_css(css) + '</style>'
    html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', css_sub, html)

    # ডেটা: application/json ব্লক (Lazy Parse)
    blocks = '\n'.join(f'<script type="application/json" id="d-{n}">{min_json(o)}</script>' for n, o in data.items())
    html = re.sub(r'<!-- @build:data-start -->.*?<!-- @build:data-end -->', lambda m: blocks, html, flags=re.S)

    # JS ইনলাইন
    def js_sub(m):
        js = open(os.path.join(SRC, m.group(1)), encoding='utf-8').read()
        return '<script>' + min_js(js).replace('</script', '<\\/script') + '</script>'
    html = re.sub(r'<script src="([^"]+)"></script>', js_sub, html)

    # বাকি থাকা বাইরের রিসোর্স আছে কি না যাচাই
    ext = re.findall(r'(?:src|href)="(https?:[^"]+|[^"#][^"]*\.(?:js|css|json|woff2?|ttf|png|jpg|svg))"', html)
    if ext:
        print('✗ বাইরের রিসোর্স রয়ে গেছে:', ext)
        sys.exit(1)

    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, 'index.html')
    # বিল্ড-তথ্য (আকার, ZIP আকার) — রিপোর্ট পাতার জন্য; দুই ধাপে মাপা
    import zipfile, io, datetime
    def info(h):
        raw = h.encode('utf-8')
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z: z.writestr('index.html', raw)
        fonts = sum(len(m) for m in re.findall(r'url\(data:font/[^)]+\)', h))
        data_b = sum(len(m.encode('utf-8')) for m in re.findall(r'<script type="application/json"[^>]*>.*?</script>', h, flags=re.S))
        return {'date': datetime.date.today().isoformat(), 'bytes': len(raw), 'zip': buf.tell(),
                'parts': {'fonts': fonts, 'data': data_b, 'code': len(raw) - fonts - data_b}}
    tag = '<script>window.__BUILD__=%s;</script></head>'
    h1 = html.replace('</head>', tag % json.dumps(info(html)), 1)
    h2 = html.replace('</head>', tag % json.dumps(info(h1)), 1)
    open(out, 'w', encoding='utf-8').write(h2)
    return out


def main():
    t0 = time.time()
    data = collect_data()
    meta = add_lesson_meta(data)
    write_dev_js(data)
    out = build_single(data)
    size = os.path.getsize(out)
    mb = size / 1024 / 1024
    parts = {
        'ফন্ট': sum(os.path.getsize(os.path.join(FONTS, f)) for f in os.listdir(FONTS) if f.endswith('.woff')) * 4 / 3,
        'ডেটা': sum(len(min_json(o).encode()) for o in data.values()),
    }
    print(f'✓ dist/index.html  {size/1024:.0f} KB ({mb:.2f} MB)  [{time.time()-t0:.1f}s]')
    for k, v in parts.items():
        print(f'    {k}: ~{v/1024:.0f} KB')
    print(f'    বাকি (CSS+JS+HTML): ~{(size - sum(parts.values()))/1024:.0f} KB')
    print(f'  ডেটা ফাইল: {", ".join(data)}')
    if meta: print(f'  কনটেন্টসহ পাঠ: {len(meta)}টি, শব্দ অনুযায়ী মোট পড়ার সময় ≈ {sum(v[0] for v in meta.values())} মিনিট, পাঠভিত্তিক MCQ {sum(v[1] for v in meta.values())}টি')
    # আনুমানিক লোড সময়: ফাইল লোকাল, তাই মূলত পার্স সময় — মাঝারি ফোনে ~১০–২০ MB/s HTML পার্স ধরে
    print(f'  আনুমানিক খোলার সময় (মাঝারি Android): ~{max(0.3, mb/12):.1f}–{max(0.6, mb/6):.1f} সেকেন্ড')
    if mb > LIMIT_MB:
        print(f'  ⚠️ {LIMIT_MB} MB ছাড়িয়েছে — Track-ভিত্তিক আলাদা Single-file নিয়ে সিদ্ধান্ত দরকার (A7)')
    elif mb > WARN_MB:
        print(f'  ⚠️ {WARN_MB} MB ছাড়িয়েছে — ধীর ফোনে খুলতে দেরি হতে পারে')


if __name__ == '__main__':
    main()
