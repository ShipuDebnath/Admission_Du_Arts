#!/usr/bin/env python3
"""smoke_test_p3.py — Phase 3: পাঠ রেন্ডারার ও ইন্টারেক্টিভ ফিগার, পাঠ-শেষ অনুশীলন, সার্চে পাঠের লেখা
ব্যবহার:  python3 tools/smoke_test_p3.py [dist|src] [--shots DIR]"""
import os, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
target = 'src' if 'src' in sys.argv[1:] else 'dist'
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
URL = 'file://' + os.path.join(ROOT, target, 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok)))
    print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)

with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, device_scale_factor=2, is_mobile=True, has_touch=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    print(f'লক্ষ্য: {URL}')

    boot(page, '#/l/bn1-1-1')
    body = page.inner_text('#lbody')
    check('পাঠ কনটেন্ট রেন্ডার হয় (অপরিচিতা: মূলভাব)', 'সবুজপত্র' in body and page.locator('.lh').count() >= 3)
    chip = page.locator('.chip').first.inner_text()
    check('প্রস্তুতির সময় = পড়া + MCQ (শব্দসংখ্যা থেকে)', 'প্রস্তুতি' in chip and 'পড়া' in chip and 'MCQ' in chip, chip)
    check('Facts / Mistakes / Tricks / Summary বক্স', all(page.locator(c).count() for c in ['.box.facts', '.box.warnbox', '.box.tricks', '.box.summary']))
    shot = (lambda n, full=True: page.screenshot(path=f'{SHOTS}/{n}.png', full_page=full) if SHOTS else None)
    shot('p3-1-lesson')
    # টাইমলাইন
    tl = page.locator('[data-fig="timeline"]').first
    tl.locator('.tl-btn').first.click()
    check('টাইমলাইন: ট্যাপে বিবরণ খোলে', not tl.locator('.tl-d').first.is_hidden())
    tl.locator('.tl-hide').click()
    check('টাইমলাইন: "সাল লুকাও"', 'nodates' in tl.get_attribute('class'))
    tl.locator('.tl-hide').click()
    tl.locator('.tl-order').click()
    check('টাইমলাইন: "ক্রম মেলাও" এলোমেলো করে', 'ordering' in tl.get_attribute('class'))
    # সঠিক ক্রমে সাজানো (অদলবদল দিয়ে)
    n = tl.locator('.tl-i').count()
    for target_j in range(n):
        items = tl.locator('.tl-i')
        cur = [int(items.nth(k).get_attribute('data-j')) for k in range(n)]
        if cur[target_j] != target_j:
            src = cur.index(target_j)
            items.nth(target_j).locator('.tl-btn').click(); items.nth(src).locator('.tl-btn').click()
    tl.locator('.tl-order').click()
    check('টাইমলাইন: অদলবদলে সঠিক ক্রম যাচাই (সব সবুজ)', tl.locator('.tl-i.ok').count() == n, tl.locator('.tl-order').inner_text())
    shot('p3-2-timeline', False) if SHOTS else None

    # সারণি: সর্ট, ফিল্টার, Label Hide
    boot(page, '#/l/bn1-1-5')
    fg = page.locator('[data-fig="table"]').first
    rows = fg.locator('tbody tr').count()
    fg.locator('.tfilter').fill('কানপুর')
    vis = fg.locator('tbody tr:not([hidden])').count()
    check('সারণি: ফিল্টার', 0 < vis < rows, f'{rows} → {vis}')
    fg.locator('.tfilter').fill('')
    fg.locator('.thide').click()
    cell = fg.locator('td.hidecell').first
    hidden_color = cell.evaluate('e => getComputedStyle(e).color')
    cell.click()
    check('সারণি: Label Hide ও ট্যাপে উত্তর দেখা', 'lblhide' in fg.get_attribute('class') and 'shown' in cell.get_attribute('class'))
    first = fg.locator('tbody tr td').first.inner_text()
    fg.locator('.tsort').first.click()
    check('সারণি: শিরোনামে ট্যাপে সাজায়', fg.locator('tbody tr td').first.inner_text() != first or rows < 2)
    # মিলকরণ
    mf = page.locator('[data-fig="match"]').first
    pairs = mf.locator('.m-l .m-it').count()
    for j in range(pairs):
        mf.locator(f'.m-l .m-it[data-j="{j}"]').click(); mf.locator(f'.m-r .m-it[data-j="{j}"]').click()
    check('মিলকরণ ফিগার: সব জোড়া মেলানো যায়', mf.locator('.m-l .m-it.ok').count() == pairs, mf.locator('.m-score').inner_text())
    shot('p3-3-mcqfocus')

    # কবিতার পাঠ (উদ্ধৃতি ব্লক)
    boot(page, '#/l/bn1-2-3')
    check('সোনার তরী: ৬টি স্তবক উদ্ধৃতি-ব্লকে', page.locator('figure.quote').count() == 6)
    shot('p3-4-poem')

    order = page.evaluate("(()=>{const a=[...document.querySelectorAll('#view > *, main > *')];const i=a.findIndex(e=>e.textContent.includes('পাঠ-শেষ অনুশীলন')&&e.tagName==='SECTION');const j=a.findIndex(e=>e.querySelector&&e.querySelector('#donechk'));return [i,j]})()")
    check('পাঠ-শেষ অনুশীলন "পাঠ সম্পন্ন"-এর আগে', order[0] >= 0 and order[1] >= 0 and order[0] < order[1], str(order))
    page.evaluate('window.scrollTo(0, document.documentElement.scrollHeight)'); page.wait_for_timeout(250)
    sp = page.evaluate("(()=>{const b=document.querySelector('.topbar #scrollprog span');return b?b.style.transform:''})()")
    check('হেডারের নিচে স্ক্রল-অগ্রগতি রেখা — নিচে স্ক্রল করলে পূর্ণ হয়', sp.startswith('scaleX(1') or sp.startswith('scaleX(0.9'), sp)
    page.evaluate('window.scrollTo(0, 0)'); page.wait_for_timeout(150)
    # পাঠ-শেষ অনুশীলন
    boot(page, '#/l/bn1-1-4')
    btn = page.locator('a.btn:has-text("MCQ")')
    check('পাঠ-শেষ MCQ বাটনে প্রশ্নসংখ্যা', btn.count() == 1)
    btn.click(); page.wait_for_selector('.qcard')
    check('অপরিচিতার প্রশ্ন দিয়ে Quiz চলে', 'bn1' in page.evaluate("QB.all().find(q=>q.q===document.querySelector('.qtext').textContent).sub"))
    boot(page, '#/flash/review?lid=bn1-3-2')
    check('পাঠভিত্তিক Flashcard (আলাওল)', page.locator('#card').count() == 1)

    # সার্চ: পাঠের ভেতরের লেখা
    boot(page, '#/search?q=' + 'মাগন ঠাকুর')
    page.wait_for_selector('#res .result')
    check('সার্চ পাঠের ভেতরের লেখাতেও খোঁজে (মাগন ঠাকুর)', 'আলাওল' in page.inner_text('#res') or 'ঋতু-বর্ণন' in page.inner_text('#res'))

    # পাঠ্যসূচিতে সময়
    boot(page, '#/s/bn1')
    check('বিষয়-পাতা (#/s/bn1) খোলে: শিরোনাম, অধ্যায় ও একটি খোলা অধ্যায়, JS error নেই',
          'বাংলা ১ম পত্র' in page.inner_text('main h1') and page.locator('details.chap').count() >= 14 and page.locator('details.chap[open]').count() >= 1 and not errs, '; '.join(errs[:2]))
    boot(page, '#/home')
    page.locator('a.subj-link').first.click(); page.wait_for_timeout(300)
    check('হোমের "অগ্রগতি — বিষয়ভিত্তিক" থেকে বিষয়-পাতা খোলে', page.evaluate('location.hash').startswith('#/s/') and page.locator('main h1').count() == 1)
    ctx.close()

    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, offline=True)
    page = ctx.new_page(); e2 = []
    page.on('pageerror', lambda e: e2.append(str(e)))
    for lid in ['bn1-1-1', 'bn1-1-2', 'bn1-1-3', 'bn1-1-4', 'bn1-1-5', 'bn1-2-1', 'bn1-2-3', 'bn1-2-4', 'bn1-3-2', 'bn1-3-4', 'bn1-3-5']:
        boot(page, '#/l/' + lid)
        w = page.evaluate('document.documentElement.scrollWidth')
        if w > 320: e2.append(f'{lid} scrollWidth={w}')
    check('৩২০px + অফলাইন: সব পাঠ ও ফিগার ফিট করে', not e2, '; '.join(e2[:3]))
    ctx.close(); br.close()

fails = [r for r in results if not r[1]]
print(f'\nফলাফল: {len(results) - len(fails)}/{len(results)} পাস')
sys.exit(1 if fails else 0)
