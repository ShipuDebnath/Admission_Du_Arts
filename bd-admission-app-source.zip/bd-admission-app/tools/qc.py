#!/usr/bin/env python3
"""
qc.py — A6 QC Checklist (প্রতিটি ব্লক/ফাইল শেষে চালানো হবে)
  ১. তথ্য মিলিয়ে দেখা ও Verify ট্যাগ গণনা
  ২. প্রশ্নের উত্তর ও ব্যাখ্যা মেলে কি না
  ৩. ডুপ্লিকেট/প্রায়-একই প্রশ্ন
  ৪. বানান ও যুক্তাক্ষর (স্বয়ংক্রিয় সম্ভাব্য-ত্রুটি ধরা; চূড়ান্ত যাচাই মানুষের চোখে)
  ৫. JSON স্কিমা বৈধ ও সব ফিল্ড আছে
  ৬. পাঠের সময় ≈ শব্দসংখ্যা/১৫০
  ৭. যাচাইকৃত নয় এমন PYQ-কে "PYQ" বলা হয়নি
  + থিম কনট্রাস্ট (WCAG AA)
ব্যবহার:  python3 tools/qc.py   (ত্রুটি থাকলে exit code 1)
"""
import glob, json, os, re, sys, unicodedata
from difflib import SequenceMatcher

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DATA = os.path.join(ROOT, 'src', 'data')
WPM_BN = 150

errors, warns, info = [], [], []
def E(m): errors.append(m)
def W(m): warns.append(m)
def I(m): info.append(m)


def load(name):
    p = os.path.join(DATA, name)
    with open(p, encoding='utf-8') as f:
        return json.load(f)


# ---------- ৫. JSON বৈধতা ----------
all_json = [p for p in glob.glob(os.path.join(DATA, '**', '*.json'), recursive=True) if os.sep + 'js' + os.sep not in p]
bad = 0
for p in all_json:
    try:
        json.load(open(p, encoding='utf-8'))
    except Exception as e:
        bad += 1
        E(f'JSON অবৈধ: {os.path.relpath(p, ROOT)} — {e}')
I(f'JSON ফাইল: {len(all_json)}টি, অবৈধ {bad}টি')

toc = load('toc.json')
cfg = load('exam-config.json')

# ---------- toc স্কিমা ----------
ids, n_less, n_verify, n_pending = set(), 0, 0, 0
subj_ids = set()
for s in toc.get('subjects', []):
    for k in ('id', 't', 'en', 'ch'):
        if k not in s: E(f'বিষয়ে ফিল্ড নেই: {k} ({s.get("id")})')
    subj_ids.add(s['id'])
    titles = {}
    for c in s['ch']:
        if not c.get('t') or not c.get('id') or 'l' not in c: E(f'অধ্যায় ফিল্ড অসম্পূর্ণ: {c.get("id")}')
        for l in c['l']:
            n_less += 1
            for k in ('id', 't', 'm'):
                if k not in l: E(f'পাঠে ফিল্ড নেই: {k} ({l.get("id")})')
            if l['id'] in ids: E(f'ডুপ্লিকেট id: {l["id"]}')
            ids.add(l['id'])
            if not isinstance(l['m'], (int, float)) or l['m'] < 0: E(f'সময় অবৈধ: {l["id"]}')
            if l.get('st') == 'pending': n_pending += 1
            elif l['m'] == 0: E(f'সক্রিয় পাঠের সময় ০: {l["id"]}')
            if l.get('v'): n_verify += 1
            key = re.sub(r'\s+', ' ', l['t']).strip()
            if l.get('st') != 'pending':
                if key in titles: W(f'একই বিষয়ে একই শিরোনাম: "{key}" ({titles[key]}, {l["id"]})')
                titles[key] = l['id']
I(f'পাঠ্যসূচি: {len(subj_ids)} বিষয়, {n_less} পাঠ (সিলেবাস-অপেক্ষমাণ {n_pending}), Verify ট্যাগ {n_verify}')

# ---------- exam-config ----------
cfg_verify = 0
def count_unverified(o):
    global cfg_verify
    if isinstance(o, dict):
        for k, v in o.items():
            if k.endswith('erified') and v is False: cfg_verify += 1
            count_unverified(v)
    elif isinstance(o, list):
        for v in o: count_unverified(v)
count_unverified(cfg)
unit_ids = set()
for t in cfg.get('tracks', []):
    for k in ('id', 'name', 'units'):
        if k not in t: E(f'Track ফিল্ড নেই: {k}')
    for u in t['units']:
        if u['id'] in unit_ids: E(f'ডুপ্লিকেট ইউনিট id: {u["id"]}')
        unit_ids.add(u['id'])
        for sid in u.get('subjects', []):
            if sid not in subj_ids: E(f'{u["id"]}: অজানা বিষয় "{sid}"')
        mcq = u.get('mcq', {})
        secs = mcq.get('sections') or []
        if secs and mcq.get('marks') and sum(x['marks'] for x in secs) != mcq['marks']:
            E(f'{u["id"]}: বিভাগভিত্তিক নম্বরের যোগফল ({sum(x["marks"] for x in secs)}) ≠ মোট ({mcq["marks"]})')
        for x in secs:
            for sid in x.get('subjects', []):
                if sid not in subj_ids: E(f'{u["id"]}: বিভাগে অজানা বিষয় "{sid}"')
        if u.get('date') and not re.match(r'^\d{4}-\d{2}-\d{2}$', u['date']): E(f'{u["id"]}: তারিখ ফরম্যাট ভুল')
I(f'পরীক্ষা-কনফিগ: {len(cfg["tracks"])} Track, {len(unit_ids)} ইউনিট, যাচাই-বাকি (Verified=false) {cfg_verify}টি ঘর')

# ---------- ৪. বানান/যুক্তাক্ষর হিউরিস্টিক ----------
BN = re.compile(r'[ঀ-৿]')
DEP_VOWEL = 'ািীুূৃৄেৈোৌৗ'
def bn_issues(text):
    out = []
    if re.search(r'্্', text): out.append('পরপর দুই হসন্ত')
    if re.search(r'(^|[\s(\-—,।])[' + DEP_VOWEL + r'্]', text): out.append('শব্দের শুরুতে কার/হসন্ত')
    if re.search(r'[' + DEP_VOWEL + r'][' + DEP_VOWEL + r']', text): out.append('পরপর দুই কার')
    if re.search(r'[‌‍]{2,}', text): out.append('অপ্রয়োজনীয় ZWJ/ZWNJ')
    if unicodedata.normalize('NFC', text) != text: out.append('NFC নয় (য়/ড়/ঢ় ইত্যাদি ভিন্ন এনকোডিং)')
    if re.search(r'  +', text): out.append('ডাবল স্পেস')
    return out
def walk_strings(o, path=''):
    if isinstance(o, str): yield path, o
    elif isinstance(o, dict):
        for k, v in o.items(): yield from walk_strings(v, path + '.' + k)
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from walk_strings(v, path + f'[{i}]')
sp = 0
for p in all_json:
    try: obj = json.load(open(p, encoding='utf-8'))
    except Exception: continue
    for path, s in walk_strings(obj):
        if BN.search(s):
            for iss in bn_issues(s):
                sp += 1
                W(f'বানান/এনকোডিং? {os.path.relpath(p, DATA)}{path}: {iss} — "{s[:40]}"')
I(f'বানান/যুক্তাক্ষর স্বয়ংক্রিয় পরীক্ষা: সন্দেহজনক {sp}টি')

# ---------- ২, ৩. প্রশ্ন ----------
qfiles = glob.glob(os.path.join(DATA, 'questions', '*.json')) + glob.glob(os.path.join(DATA, 'pyq', '*.json')) + glob.glob(os.path.join(DATA, 'current-affairs', '*.json'))
nq, seen, tmpl_count, other_raw = 0, [], {}, {}
lmap_all = {l['id'] for s_ in toc['subjects'] for c in s_['ch'] for l in c['l']}
for p in qfiles:
    obj = json.load(open(p, encoding='utf-8'))
    items = obj if isinstance(obj, list) else obj.get('q') or obj.get('items') or []
    for q in items:
        if 'question' not in q and 'q' not in q: continue
        nq += 1
        qt = q.get('question') or q.get('q')
        opts = q.get('options') or q.get('o') or []
        ans = q.get('answer', q.get('a'))
        exp = q.get('explanation') or q.get('e')
        qid = q.get('id', '?')
        if len(opts) < 2: E(f'{qid}: অপশন কম')
        if isinstance(ans, int):
            if not 0 <= ans < len(opts): E(f'{qid}: উত্তর সূচক অপশনের বাইরে')
        elif ans not in opts: E(f'{qid}: উত্তর অপশনে নেই')
        if not exp: E(f'{qid}: ব্যাখ্যা নেই')
        if isinstance(exp, dict):
            if not exp.get('r'): E(f'{qid}: মূল নিয়ম (r) নেই')
            for k, lbl in (('t', 'Similar Question Tip'), ('f', 'Related Facts')):
                if not exp.get(k): W(f'{qid}: {lbl} নেই')
            if 'w' not in exp: W(f'{qid}: ভুল অপশনের কারণ (w) নেই')
            elif len(exp['w']) != len(opts) or not all(exp['w']): E(f'{qid}: অপশনভিত্তিক কারণের সংখ্যা/ঘর অসম্পূর্ণ')
        if q.get('lid') and q['lid'] not in lmap_all: E(f'{qid}: অজানা পাঠ id {q["lid"]}')
        if q.get('d') not in (1, 2, 3): E(f'{qid}: কঠিনতা (d) ১–৩ নয়')
        if len(set(map(str, opts))) != len(opts): E(f'{qid}: একই অপশন দুবার')
        if any(re.search(r'সবগুলো|কোনোটি(ই)? নয়|all of the above|none of the above', str(o), re.I) for o in opts): W(f'{qid}: "সবগুলো/কোনোটি নয়" অপশন — প্রয়োজন কি না দেখুন')
        # ৭. PYQ সততা
        tag = (q.get('src') or q.get('source') or '')
        if tag == 'PYQ' and not (q.get('verified') is True and q.get('sourceNote')):
            E(f'{qid}: "PYQ" ট্যাগ কিন্তু verified/sourceNote নেই')
        # শুধু ফাঁকা ও বিরামচিহ্ন বাদ; বাংলা কার-চিহ্ন ও গাণিতিক প্রতীক (+ ′ ( )) রাখা হয়
        norm = re.sub(r'[\s?।,.!:;"\'“”‘’—–-]+', '', str(qt).lower())
        tmpl = re.sub(r'[0-9০-৯a-f]+', '#', norm)
        for other_id, other, otmpl in seen:
            if norm == other:
                E(f'হুবহু একই প্রশ্ন: {qid} = {other_id}'); break
            if tmpl == otmpl:
                tmpl_count[tmpl] = tmpl_count.get(tmpl, 1) + 1; break
            # উদ্ধৃতিচিহ্নের ভেতরের পদ (যেমন "ছিনু" বনাম "রহিনু") আলাদা হলে প্রশ্ন আলাদা
            if set(re.findall(r'"([^"]+)"', str(qt))) != set(re.findall(r'"([^"]+)"', other_raw.get(other_id, ''))):
                continue
            if len(norm) > 20 and SequenceMatcher(None, norm, other).ratio() > .92:
                W(f'প্রায়-একই প্রশ্ন: {qid} ≈ {other_id}'); break
        seen.append((qid, norm, tmpl)); other_raw[qid] = str(qt)
big = {k: v for k, v in tmpl_count.items() if v > 4}
for k, v in big.items(): W(f'একই ছাঁচে (শুধু সংখ্যা বদলে) {v}টি প্রশ্ন — বৈচিত্র্য বাড়ান')
I(f'প্রশ্ন: {nq}টি' + (f' · একই ছাঁচে ভিন্ন সংখ্যার প্রশ্ন-গুচ্ছ {len(tmpl_count)}টি (সর্বোচ্চ {max(tmpl_count.values())}টি করে)' if tmpl_count else '') + (' (এখনো কোনো প্রশ্ন ফাইল নেই — Phase 2/3 থেকে প্রযোজ্য)' if not nq else ''))

# ---------- Flashcard ----------
nf, fids = 0, set()
for p_ in glob.glob(os.path.join(DATA, 'flashcards', '*.json')):
    for c in json.load(open(p_, encoding='utf-8')).get('cards', []):
        nf += 1
        if not c.get('id') or not c.get('f') or not c.get('b'): E(f'Flashcard অসম্পূর্ণ: {c.get("id")}')
        if c.get('id') in fids: E(f'ডুপ্লিকেট Flashcard id: {c["id"]}')
        fids.add(c.get('id'))
        if c.get('lid') and c['lid'] not in lmap_all: E(f'Flashcard {c["id"]}: অজানা পাঠ')
I(f'Flashcard: {nf}টি')

# ---------- ৬. পাঠ কনটেন্ট: স্কিমা, শব্দসংখ্যা → সময়, কপিরাইট ----------
KINDS = {'h': ['x'], 'p': ['x'], 'list': ['x'], 'facts': ['x'], 'summary': ['x'], 'mistakes': ['x'], 'tricks': ['x'],
         'uni': ['x'], 'verify': ['x'], 'mnemonic': ['x'], 'quote': ['q', 'e'], 'words': ['x'], 'table': ['h', 'c', 'r'],
         'timeline': ['h', 'x'], 'match': ['h', 'x'], 'entries': ['h', 'x']}
# ১৯২৯-এর পরে প্রথম প্রকাশিত রচনার অধ্যায় — এগুলোতে মূল পাঠ থেকে উদ্ধৃতি (quote ব্লক) নিষেধ
NO_QUOTE = {'bn1-6', 'bn1-7', 'bn1-9', 'bn1-10', 'bn1-11', 'bn1-13', 'bn1-14'}  # ১৯২৯-এর পরে প্রকাশিত রচনা (যৌবনের গান ১৯৩২)
lmap = {l['id']: l for s in toc['subjects'] for c in s['ch'] for l in c['l']}
lfiles = glob.glob(os.path.join(DATA, 'lessons', '**', '*.json'), recursive=True)
def lwords(v):
    if isinstance(v, str): return len(v.split())
    if isinstance(v, list): return sum(lwords(x) for x in v)
    if isinstance(v, dict): return sum(lwords(x) for k, x in v.items() if k not in ('k', 'g'))
    return 0
nl, thin, tot_new, tot_old = 0, 0, 0, 0
for p in lfiles:
    for lid, les in json.load(open(p, encoding='utf-8')).items():
        nl += 1
        if lid not in lmap: E(f'{os.path.relpath(p, DATA)}: অজানা পাঠ id {lid}'); continue
        for i, bl in enumerate(les.get('b', [])):
            k = bl.get('k')
            if k not in KINDS: E(f'{lid} ব্লক {i}: অজানা ধরন "{k}"'); continue
            for f in KINDS[k]:
                if not bl.get(f): E(f'{lid} ব্লক {i} ({k}): "{f}" নেই')
            if k == 'table':
                for r in bl.get('r', []):
                    if len(r) != len(bl['c']): E(f'{lid}: সারণি "{bl["h"]}"-এ কলামসংখ্যা মেলে না')
            if k == 'quote' and lmap[lid].get('cid', '-'.join(lid.split('-')[:2])) in NO_QUOTE:
                E(f'{lid}: ১৯২৯-পরবর্তী রচনা — মূল পাঠ থেকে উদ্ধৃতি দেওয়া যাবে না')
            if k == 'mnemonic':
                for m in bl['x']:
                    if not (m.get('m') and m.get('f') and m.get('how')): E(f'{lid}: Mnemonic-এ m/f/how অসম্পূর্ণ')
        if not les.get('src'): W(f'{lid}: তথ্যসূত্র (src) নেই')
        w = lwords(les.get('b', []))
        new_m = max(1, round(w / WPM_BN))
        tot_new += new_m; tot_old += lmap[lid]['m']
        if new_m < lmap[lid]['m'] * 0.4:
            thin += 1
            W(f'{lid}: কনটেন্ট পাতলা — {w} শব্দ (≈{new_m} মি.), আনুমানিক ছিল {lmap[lid]["m"]} মি.')
I(f'পাঠ কনটেন্ট: {nl}টি পাঠ' + (f'; শব্দ অনুযায়ী মোট ≈{tot_new} মি. (আনুমানিক ছিল {tot_old} মি.), পাতলা {thin}টি' if nl else ' (এখনো নেই)'))

# ---------- থিম কনট্রাস্ট ----------
css = open(os.path.join(ROOT, 'src', 'css', 'themes.css'), encoding='utf-8').read()
def hx(c): c = c.strip().lstrip('#'); return [int(c[i:i + 2], 16) / 255 for i in (0, 2, 4)]
def lum(c):
    r = [x / 12.92 if x <= .03928 else ((x + .055) / 1.055) ** 2.4 for x in hx(c)]
    return .2126 * r[0] + .7152 * r[1] + .0722 * r[2]
def cr(a, b): A, B = sorted([lum(a), lum(b)], reverse=True); return (A + .05) / (B + .05)
PAIRS = [('text', 'bg'), ('text', 'surface-solid'), ('text-2', 'surface-solid'), ('text-2', 'bg'), ('on-primary', 'primary'),
         ('primary', 'surface-solid'), ('ok', 'surface-solid'), ('bad', 'surface-solid'), ('ok', 'ok-bg'), ('bad', 'bad-bg'), ('warn', 'warn-bg')]
themes = re.findall(r'data-theme="(\w+)"\]\s*\{(.*?)\}', css, re.S)
worst = 99
for name, body in themes:
    v = dict(re.findall(r'--([\w-]+):\s*([^;]+);', body))
    for a, b in PAIRS:
        if a in v and b in v and v[a].startswith('#') and v[b].startswith('#'):
            r = cr(v[a], v[b]); worst = min(worst, r)
            if r < 4.5: E(f'থিম {name}: {a}/{b} কনট্রাস্ট {r:.2f} < 4.5')
I(f'থিম: {len(themes)}টি, সর্বনিম্ন কনট্রাস্ট {worst:.1f}:১ (Glass থিমের আধা-স্বচ্ছ রং --surface-solid দিয়ে মাপা)')

# ---------- রিপোর্ট ----------
def _cat(m):
    for key, lbl in (('প্রায়-একই', 'প্রায়-একই প্রশ্ন (মানুষের চোখে দেখা দরকার)'), ('একই ছাঁচে', 'একই ছাঁচে সংখ্যা-বদলানো প্রশ্নগুচ্ছ'), ('পাতলা', 'পাঠ্যসূচির আনুমানিক সময়ের চেয়ে সংক্ষিপ্ত পাঠ'),
                     ('তথ্যসূত্র', 'তথ্যসূত্র (src) নেই'), ('বানান', 'বানান/এনকোডিং সন্দেহ'), ('সবগুলো', '"সবগুলো/কোনোটি নয়" অপশন'), ('শিরোনাম', 'একই শিরোনাম'), ('নেই', 'ব্যাখ্যার ঐচ্ছিক অংশ নেই')):
        if key in m: return lbl
    return 'অন্যান্য'
_cats = {}
for m in warns: _cats[_cat(m)] = _cats.get(_cat(m), 0) + 1
json.dump({'info': info, 'warns': len(warns), 'errors': errors, 'warnCats': _cats, 'nq': nq, 'nf': nf, 'nl': nl, 'thin': thin,
           'verifyToc': n_verify, 'verifyCfg': cfg_verify, 'spell': sp, 'worstContrast': round(worst, 1)},
          open(os.path.join(ROOT, 'tools', '.qc.json'), 'w', encoding='utf-8'), ensure_ascii=False)
print('=== QC রিপোর্ট ===')
for m in info: print('  •', m)
if warns:
    print(f'\n  সতর্কতা ({len(warns)}):')
    for m in warns[:40]: print('   ⚠', m)
    if len(warns) > 40: print(f'   … আরও {len(warns) - 40}টি')
if errors:
    print(f'\n  ত্রুটি ({len(errors)}):')
    for m in errors: print('   ✗', m)
    sys.exit(1)
print('\n  ✓ কোনো ত্রুটি নেই')
