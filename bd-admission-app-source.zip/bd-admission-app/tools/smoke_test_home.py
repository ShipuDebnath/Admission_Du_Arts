#!/usr/bin/env python3
"""smoke_test_home.py — হোম সাজানো (টেনে/বোতামে, লুকানো), সংক্ষিপ্ত অংশ, সর্বশেষ ৩টি অধ্যায়,
বিষয়ের পাতার ক্লিকযোগ্য চিপ, ICT-র ছয় অধ্যায়, সব ডেটা ব্লক পার্স হয়"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=15000)
def secs(page): return page.evaluate("[...document.querySelectorAll('.hsec')].map(e=>e.dataset.sec)")
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True, has_touch=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    boot(page, '#/home')
    bad = page.evaluate("Data.list('').filter(n => { try { return !Data.get(n); } catch (e) { return true; } })")
    check('সব ডেটা ব্লক ঠিকমতো পার্স হয়', not bad, ', '.join(bad[:5]))
    s = secs(page)
    check('ডিফল্ট ক্রম: ইউনিট → তৈরি কনটেন্ট → বিষয়ভিত্তিক অগ্রগতি (ওপরের দিকে)', s[:3] == ['unit', 'ready', 'progress'], ','.join(s))
    check('আলাদা "শুরু করুন/চালিয়ে যান" কার্ড নেই', page.locator('main a.card:has-text("চালিয়ে যান →"), main a.card:has-text("শুরু →")').count() == 0)
    check('সংক্ষিপ্ত পরিসংখ্যান এক সারিতে (৪টি টাইল)', page.locator('.mini-stats .ms').count() >= 3)
    # সর্বশেষ শুরু করা ৩টি
    boot(page, '#/l/bn1-2-1'); boot(page, '#/l/gkbd-6-4'); boot(page, '#/l/ict-6-3'); boot(page, '#/home')
    items = page.evaluate("[...document.querySelectorAll('.rs-item')].map(a=>a.getAttribute('href'))")
    check('তৈরি কনটেন্টে সর্বশেষ শুরু করা ৩টি — শেষটি আগে, ঠিক সেই পাঠে নিয়ে যায়', items == ['#/l/ict-6-3', '#/l/gkbd-6-4', '#/l/bn1-2-1'], str(items))
    check('লেবেল: "সর্বশেষ শুরু করা ৩টি"', 'সর্বশেষ শুরু করা ৩টি' in page.inner_text('.ready-home'))
    # সাজানো মোড
    page.click('#homeedit'); page.wait_for_selector('#harr')
    n = page.locator('#harr li').count()
    check('সাজানো মোডে সব অংশের তালিকা', n >= 8, str(n))
    # ▼ বোতাম: unit নিচে
    page.locator('#harr li[data-id="unit"] [data-mv="1"]').click()
    check('▼ চাপলে এক ধাপ নিচে নামে', page.evaluate("[...document.querySelectorAll('#harr li')].map(l=>l.dataset.id).slice(0,2).join()") == 'ready,unit')
    # টেনে আনা: week-কে একদম ওপরে (পুরো তালিকা পর্দায় রাখতে উঁচু ভিউপোর্ট)
    page.set_viewport_size({'width': 360, 'height': 1100}); page.evaluate('window.scrollTo(0,0)'); page.wait_for_timeout(100)
    h = page.locator('#harr li[data-id="week"] .h-handle').bounding_box()
    top = page.locator('#harr li').first.bounding_box()
    page.mouse.move(h['x'] + h['width'] / 2, h['y'] + h['height'] / 2); page.mouse.down()
    page.mouse.move(h['x'] + h['width'] / 2, top['y'] + 5, steps=12); page.mouse.up(); page.wait_for_timeout(200)
    order = page.evaluate("[...document.querySelectorAll('#harr li')].map(l=>l.dataset.id)")
    check('টেনে (drag) ওপরে আনা যায়', order[0] == 'week', ','.join(order))
    page.set_viewport_size({'width': 360, 'height': 760})
    page.locator('#harr li[data-id="level"] [data-eye]').click()
    page.click('#hdone'); page.wait_for_timeout(200)
    s = secs(page)
    check('সংরক্ষিত ক্রম হোমে প্রয়োগ হয় ও লুকানো অংশ দেখায় না', s[0] == 'week' and 'level' not in s, ','.join(s))
    boot(page, '#/home')
    check('রিলোডের পরও ক্রম থাকে', secs(page)[0] == 'week')
    if SHOTS: page.screenshot(path=f'{SHOTS}/home-custom.png', full_page=True)
    page.click('#homeedit'); page.click('#hreset'); page.wait_for_timeout(150); page.click('#hdone')
    check('"ডিফল্টে ফেরান" কাজ করে', secs(page)[:3] == ['unit', 'ready', 'progress'] and 'level' in secs(page))
    # বিষয়ের পাতা
    boot(page, '#/s/bn1')
    t = page.inner_text('.subj-head')
    check('বিষয়ের পাতায় "আপনার ইউনিটে" ও "অধ্যায় প্রস্তুত" নেই', 'আপনার ইউনিটে' not in t and 'অধ্যায় প্রস্তুত' not in t, t[:120])
    check('MCQ, কার্ড, Final চিপ ক্লিকযোগ্য', page.locator('.subj-actions a.act-chip[href="#/quiz/s/bn1"]').count() == 1 and page.locator('.subj-actions a.act-chip[href^="#/flash/review?sub=bn1"]').count() == 1 and page.locator('.subj-actions a.act-chip[href="#/final/bn1"]').count() == 1)
    check('অধ্যায়ের সারিতে "✅ প্রস্তুত" চিপ নেই', page.locator('details.chap .chip.ready').count() == 0)
    page.click('.subj-actions a.act-chip[href="#/quiz/s/bn1"]'); page.wait_for_selector('.qcard')
    check('MCQ চিপে চাপলে কুইজ খোলে', page.locator('.qcard').count() == 1)
    # সম্পন্ন চিহ্ন
    boot(page, '#/s/eco')
    page.evaluate("""() => { const d = {}; Core.SMAP.eco.ch.forEach(c => c.l.forEach(l => d[l.id] = Date.now())); Store.set('done', d, 0); }""")
    boot(page, '#/s/eco')
    check('বিষয় সম্পন্ন হলে ✓ চিহ্ন দেখায়', 'বিষয় সম্পন্ন' in page.inner_text('.subj-head') and page.locator('details.chap .done-mark').count() >= 1)
    boot(page, '#/syllabus')
    check('পাঠ্যসূচিতে "✅ প্রস্তুত" ফিল্টার/চিপ নেই', page.locator('[data-f="ready"]').count() == 0 and page.locator('.chip.ready').count() == 0)
    # ICT
    boot(page, '#/s/ict')
    chs = page.evaluate("[...document.querySelectorAll('details.chap summary .txt')].map(e=>e.childNodes[0].textContent.trim())")
    want = ['অধ্যায় ১', 'অধ্যায় ২', 'অধ্যায় ৩', 'অধ্যায় ৪', 'অধ্যায় ৫', 'অধ্যায় ৬']
    check('ICT: পাঠ্যবইয়ের ৬টি অধ্যায় ক্রমানুসারে + অতিরিক্ত', [c.split(':')[0] for c in chs[:6]] == want and len(chs) == 7, ' | '.join(c[:12] for c in chs))
    nq = page.evaluate("['ict-4','ict-5','ict-6','ict-7'].map(c=>QB.all().filter(q=>{const l=Core.LMAP[q.lid]; return l && l.cid===c;}).length)")
    check('নতুন অধ্যায়ে MCQ আছে (২, ৪, ৫, ৬ নং অধ্যায়)', all(x >= 30 for x in nq), str(nq))
    check('প্রতিটি নতুন ICT পাঠে কনটেন্ট ও MCQ', page.evaluate("Object.keys(Core.LMAP).filter(k=>/^ict-[4-7]-/.test(k)).every(k=>Core.LMAP[k].has && QB.forLesson(k).length>=8)"))
    boot(page, '#/l/ict-7-4')
    check('ICT পাঠ (ডেটাবেজ নিরাপত্তা) খোলে, সারণি আছে', 'সিজার সাইফার' in page.inner_text('main') and page.locator('[data-fig="table"]').count() >= 1)
    boot(page, '#/l/ict-5-2')
    check('HTML পাঠে ট্যাগগুলো লেখা হিসেবে দেখায় (<title>, <!-- -->)', '<title>' in page.inner_text('main') and '<!--' in page.inner_text('main'))
    # সাপ্তাহিক পড়া → ৩০ দিন
    boot(page, '#/home')
    page.evaluate("Store.set('days', (function(){var d={},k=new Date();k=k.getFullYear()+'-'+('0'+(k.getMonth()+1)).slice(-2)+'-'+('0'+k.getDate()).slice(-2);d[k]=75*60;return d;})(), 0)")
    boot(page, '#/home')
    check('সাপ্তাহিক পড়ায় "৩০ দিন ›" তীর আছে', page.locator('.home-week a.hw-head[href="#/study"]').count() == 1)
    page.click('.home-week .hw-head'); page.wait_for_timeout(300)
    check('তীরে চাপলে ৩০ দিনের পাতা, ৩০টি দিনের ঘর', page.evaluate('location.hash') == '#/study' and page.locator('.hm-grid button').count() == 30)
    check('আজকের ঘর সবচেয়ে গাঢ় (লক্ষ্য পূরণ ✓)', page.locator('.hm-grid button.today.lv4 em').count() == 1)
    page.click('.hm-grid button[data-i="0"]'); page.wait_for_timeout(100)
    check('দিনে চাপলে বিস্তারিত দেখায়', 'পড়া হয়নি' in page.inner_text('#hmd'))
    check('৩৬০px-এ অনুভূমিক স্ক্রল নেই (৩০ দিন)', page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1"))
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close(); br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
