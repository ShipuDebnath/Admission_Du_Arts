#!/usr/bin/env python3
"""
release.py — চূড়ান্ত রিলিজ: QC (A6) → Build → সব ব্রাউজার টেস্ট → সামঞ্জস্য স্ক্যান →
             src/data/qc-report.json লেখা → আবার Build (রিপোর্টসহ) → dist/index.html
ব্যবহার: python3 tools/release.py
"""
import datetime, glob, json, os, re, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
T = os.path.join(ROOT, 'tools')
BND = str.maketrans('0123456789', '০১২৩৪৫৬৭৮৯')
def bn(x): return str(x).translate(BND)
def run(args, timeout=1200):
    r = subprocess.run([sys.executable] + args, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr

print('১. QC …')
code, out = run(['tools/qc.py'])
print(out[-800:])
if code: sys.exit('✗ QC ত্রুটি — রিলিজ বন্ধ')
qc = json.load(open(os.path.join(T, '.qc.json'), encoding='utf-8'))

print('২. Build …')
code, out = run(['tools/build.py']); print(out.splitlines()[0])
if code: sys.exit(out)

print('৩. ব্রাউজার টেস্ট …')
NAMES = {'smoke_test.py': 'Phase 1: কোর (নেভিগেশন, সংরক্ষণ, থিম, ব্যাকআপ)', 'smoke_test_p2.py': 'Phase 2: টেস্ট ইঞ্জিন, Quiz, Flashcard, ভুলের খাতা, PYQ',
         'smoke_test_p3.py': 'Phase 3: বাংলা পাঠ ও ফিগার', 'smoke_test_p6.py': 'Phase 6: সাম্প্রতিক হাব', 'smoke_test_p7.py': 'Phase 7: ICT',
         'smoke_test_p8.py': 'Phase 8: DU Unit Mode ও লিখিত ল্যাব', 'smoke_test_p9.py': 'Phase 9: JU/RU/CU/GST, গণিত, অর্থনীতি',
         'smoke_test_save.py': 'সংরক্ষণ (পাঠ/MCQ/Flashcard/লিখিত)', 'smoke_test_p10.py': 'Phase 10: Mega Mock, Final, গেম, PWA, অফলাইন',
         'smoke_test_home.py': 'হোম সাজানো, বিষয়ের পাতা, ICT-র ছয় অধ্যায়',
         'smoke_test_charts.py': 'চার্ট ও ডায়াগ্রাম: ৫১ চার্ট + কনসেপ্ট ম্যাপ, পিন, অনুসন্ধান',
         'smoke_test_layout.py': 'লেআউট: ৩২০/৩৬০/৭৬৮/১২৮০px × ৩৬ পাতা'}
tests, total_ok, total_n, failed = [], 0, 0, []
for f in NAMES:
    code, out = run(['tools/' + f])
    m = re.findall(r'(\d+)/(\d+) পাস', out)
    ok, n = (int(m[-1][0]), int(m[-1][1])) if m else (0, 1)
    total_ok += ok; total_n += n
    tests.append([NAMES[f], bn(f'{ok}/{n}')])
    print(f'   {f}: {ok}/{n}')
    if code or ok != n: failed.append(f); print(out[-1500:])

print('৪. সামঞ্জস্য স্ক্যান (Android ৭ WebView/পুরোনো ব্রাউজার) …')
modern = {}
for p in glob.glob(os.path.join(ROOT, 'src', 'js', '*.js')):
    src = open(p, encoding='utf-8').read()
    code_only = re.sub(r"'(?:\\.|[^'\\\n])*'|\"(?:\\.|[^\"\\\n])*\"|//[^\n]*|/\*.*?\*/", '', src, flags=re.S)
    for name, rx in (('arrow =>', r'=>'), ('let/const', r'\b(?:let|const)\s'), ('template `', r'`'), ('class', r'\bclass\s+\w'), ('?. / ??', r'\?\.|\?\?'), ('async/await', r'\basync\b|\bawait\b')):
        n = len(re.findall(rx, code_only))
        if n: modern.setdefault(name, []).append(f'{os.path.basename(p)}:{n}')
print('   ', modern or 'কোনো ES2015+ সিনট্যাক্স নেই')

wc = qc['warnCats']
checks = [
    ['১. তথ্য যাচাই ও Verify ট্যাগ', f"পাঠ্যসূচিতে Verify {bn(qc['verifyToc'])}; পরীক্ষা-কনফিগে যাচাই-বাকি ঘর {bn(qc['verifyCfg'])}টি — অ্যাপে প্রতিটির পাশে Verify চিহ্ন দেখায়; সাম্প্রতিক তথ্য ওয়েবে মিলিয়ে সূত্রসহ"],
    ['২. উত্তর ও ব্যাখ্যা মেলে', f"{bn(qc['nq'])}টি প্রশ্নের প্রতিটিতে বৈধ উত্তর, মূল নিয়ম ও প্রতিটি অপশনের কারণ আছে (ত্রুটি ০); গণিত/ICT হিসাবের উত্তর কোডে গণনা"],
    ['৩. ডুপ্লিকেট/প্রায়-একই', f"হুবহু ডুপ্লিকেট ০; প্রায়-একই সতর্কতা {bn(wc.get('প্রায়-একই প্রশ্ন (মানুষের চোখে দেখা দরকার)', 0))}টি (মূলত ব্যাকরণের একই ছাঁচে ভিন্ন শব্দ)"],
    ['৪. বানান ও যুক্তাক্ষর', f"স্বয়ংক্রিয় পরীক্ষায় সন্দেহজনক {bn(qc['spell'])}টি; চূড়ান্ত প্রুফরিড মানুষের চোখে করা ভালো"],
    ['৫. JSON স্কিমা', next((x for x in qc['info'] if x.startswith('JSON')), '') + ' — সব ফিল্ড আছে (ত্রুটি ০)'],
    ['৬. পাঠের সময় ≈ শব্দসংখ্যা', f"অ্যাপ শব্দসংখ্যা (১৫০ শব্দ/মি.) + MCQ ধরে সময় দেখায়; {bn(qc['thin'])}টি পাঠ পাঠ্যসূচির পুরোনো আনুমানিক সময়ের চেয়ে সংক্ষিপ্ত (রিভিশন-নোট ধাঁচ)"],
    ['৭. যাচাইহীন প্রশ্নে "PYQ" ট্যাগ নেই', 'ত্রুটি ০; যাচাইকৃত MCQ-PYQ এখনো নেই (উত্তর-কী-সহ নির্ভরযোগ্য সূত্র মেলেনি) — Import দিয়ে যোগ করা যায়'],
    ['থিম কনট্রাস্ট (WCAG AA)', f"সর্বনিম্ন {bn(qc['worstContrast'])}:১ (প্রয়োজন ≥৪.৫:১)"],
]
compat = [
    'Headless Chromium (Playwright) — মোবাইল টাচ মোডে ৩২০, ৩৬০, ৭৬৮px ও ডেস্কটপ ১২৮০px; ৩৩টি প্রধান পাতায় অনুভূমিক স্ক্রল ও JS error নেই',
    'file:// থেকে সম্পূর্ণ চলে (কোনো fetch/CDN নেই); ইন্টারনেট বন্ধ রেখে খোলা পরীক্ষিত',
    'HTTP হোস্টে manifest যোগ হয়; পাশে sw.js রাখলে Service Worker চালু হয় ও সার্ভার বন্ধ থাকলেও ক্যাশ থেকে খোলে',
    'সংরক্ষণ: IndexedDB → localStorage → মেমরি (Private Mode-এ সতর্কবার্তা); ব্যাকআপ ফাইল ও কপি-কোড দুটোই',
    ('পুরোনো ব্রাউজার: সব কোড ES5 ধাঁচে (arrow/let/const/class/template নেই)' if not modern else 'ES2015+ সিনট্যাক্স পাওয়া গেছে: ' + '; '.join(f'{k} ({", ".join(v)})' for k, v in modern.items())),
    'পরীক্ষা করা যায়নি (এই পরিবেশে নেই): আসল Android ফোন/APK WebView, iPhone Safari, Firefox — ব্যবহারের আগে একবার নিজে খুলে দেখুন',
]
warn_summary = [f'{k}: {bn(v)}টি' for k, v in sorted(wc.items(), key=lambda x: -x[1])]
rep = {'date': datetime.date.today().isoformat(), 'info': qc['info'], 'checks': checks, 'warns': qc['warns'], 'warnSummary': warn_summary,
       'tests': tests + [['মোট', bn(f'{total_ok}/{total_n}')]], 'compat': compat}
json.dump(rep, open(os.path.join(ROOT, 'src', 'data', 'qc-report.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('৫. রিপোর্টসহ চূড়ান্ত Build …')
code, out = run(['tools/build.py']); print(out)
print(f'\nটেস্ট মোট: {total_ok}/{total_n}' + (f' — ব্যর্থ: {failed}' if failed else ' ✓'))
sys.exit(1 if failed else 0)
