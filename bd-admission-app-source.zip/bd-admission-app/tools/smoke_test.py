#!/usr/bin/env python3
"""
smoke_test.py — A7 যাচাই: হেডলেস Chromium-এ file:// থেকে অ্যাপ চালিয়ে মূল ফ্লো পরীক্ষা।
ব্যবহার:  python3 tools/smoke_test.py [dist|src] [--shots DIR]
"""
import os, sys, json
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
target = 'src' if 'src' in sys.argv[1:] else 'dist'
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
URL = 'file://' + os.path.join(ROOT, target, 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')

results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))

def boot(page, hash_='#/home'):
    # about:blank হয়ে যাওয়া = সত্যিকারের পুনরায় খোলা (শুধু hash বদল নয়)
    page.goto('about:blank')
    page.goto(URL + hash_)
    page.wait_for_function('window.__APP_READY === true', timeout=10000)

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=EXE, args=['--allow-file-access-from-files'])
    ud = os.path.join(os.environ.get('TMPDIR', '/tmp'), 'bdadm-profile')
    ctx = browser.new_context(viewport={'width': 360, 'height': 760}, device_scale_factor=2, is_mobile=True, has_touch=True)
    page = ctx.new_page()
    errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    # নেটওয়ার্ক অনুরোধ লগ (file:// ছাড়া কিছু থাকা উচিত নয়)
    net = []
    page.on('request', lambda r: net.append(r.url) if not r.url.startswith(('file:', 'data:', 'blob:')) else None)

    print(f'লক্ষ্য: {URL}')
    boot(page)
    check('অ্যাপ লোড হয়, JS error নেই', not errs, '; '.join(errs[:3]))
    check('কোনো নেটওয়ার্ক অনুরোধ নেই (সম্পূর্ণ অফলাইন)', not net, ', '.join(net[:3]))
    mode = page.evaluate('Store.mode')
    check('সংরক্ষণ মোড IndexedDB + localStorage', mode == 'idb+ls', mode)
    font_ok = page.evaluate("document.fonts.check('16px AppBangla', 'বাংলা')") if target == 'dist' else True
    if target == 'dist':
        page.evaluate("document.fonts.load('16px AppBangla','বাংলা')")
        page.wait_for_timeout(300)
        font_ok = page.evaluate("document.fonts.check('16px AppBangla', 'বাংলা')")
    check('এম্বেড করা বাংলা ফন্ট লোড হয়', font_ok)
    sw = page.evaluate('document.documentElement.scrollWidth')
    check('৩৬০px-এ অনুভূমিক স্ক্রল নেই', sw <= 360, f'scrollWidth={sw}')
    if SHOTS: page.screenshot(path=f'{SHOTS}/1-home.png', full_page=True)

    # পাঠ্যসূচি
    page.click('nav a[href="#/syllabus"]')
    page.wait_for_selector('details.subj')
    nsubj_all = page.locator('details.subj').count()
    ntoc = page.evaluate("Core.SUBJ.length")
    check(f'পাঠ্যসূচি ডিফল্টে সব বিষয় দেখায় (ICT ও ইউনিটভিত্তিক বিষয়সহ, {ntoc}টি)', nsubj_all == ntoc >= 9 and all(page.locator(f'details.subj[data-sid="{x}"]').count() == 1 for x in ['ict', 'math', 'eco']) and page.locator('details.subj[data-sid="acc"]').count() == 0, f'{nsubj_all}টি')
    page.click('.seg button[data-f="unit"]')
    nsubj = page.locator('details.subj').count()
    check('"আমার ইউনিট" ফিল্টারে DU B-এর ৬টি', nsubj == 6, f'{nsubj}টি')
    page.click('.seg button[data-f="all"]')
    # টপবারের থিম বাটন
    page.click('#themebtn'); page.click('#modal [data-theme-opt="ocean"]')
    check('টপবারের 🎨 বাটনে থিম বদলায়', page.evaluate('document.documentElement.getAttribute("data-theme")') == 'ocean')
    page.click('#thx'); page.click('#themebtn'); page.click('#modal [data-theme-opt="vanilla"]'); page.click('#thx')
    page.locator('details.subj[data-sid="bn2"] > summary').click()
    page.locator('details.chap[data-cid="bn2-4"] > summary').click()
    if SHOTS: page.screenshot(path=f'{SHOTS}/2-syllabus.png')
    page.locator('details.chap[data-cid="bn2-4"] .tick').first.click()
    page.wait_for_timeout(150)
    st = page.evaluate('App.stats()')
    check('টিক দিলে Progress বাড়ে', st['done'] == 1, json.dumps(st))
    still_open = page.evaluate('''!!document.querySelector('details.chap[data-cid="bn2-4"]').open''')
    check('টিকের পর অধ্যায় খোলা থাকে', still_open)

    # পাঠ
    page.goto(URL + '#/l/bn2-4-2')
    page.wait_for_selector('#lbody')
    check('পাঠ পেজ খোলে', 'বাগধারা' in page.inner_text('h1'))
    page.click('#bmbtn')
    page.check('#donechk')
    page.fill('#note', 'বাগধারার পরীক্ষা নোট: "অকাল কুষ্মাণ্ড"')
    page.wait_for_timeout(900)
    check('নোট স্বয়ংক্রিয় সংরক্ষণ', 'সংরক্ষিত' in page.inner_text('#saveind'))
    # হাইলাইট: প্লেসহোল্ডার লেখার অংশ সিলেক্ট
    page.evaluate('''() => {
      const el = document.querySelector('#lbody .placeholder p b, #lbody p b'); const r = document.createRange();
      const t = el.firstChild; r.setStart(t, 0); r.setEnd(t, 10);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); document.dispatchEvent(new Event('selectionchange'));
    }''')
    page.wait_for_timeout(100)
    btn = page.locator('button:has-text("হাইলাইট")')
    if btn.count() and btn.is_visible():
        btn.click(); page.wait_for_timeout(200)
    check('হাইলাইট সংরক্ষিত ও দেখায়', page.locator('#lbody mark.hl').count() == 1)
    page.click('a:has-text("পরবর্তী পাঠ")')
    page.wait_for_selector('h1:has-text("প্রবাদ")')
    check('পরবর্তী পাঠ বাটন কাজ করে', True)
    page.mouse.wheel(0, 400); page.wait_for_timeout(900)
    if SHOTS:
        page.goto(URL + '#/l/bn2-4-2'); page.wait_for_selector('#lbody'); page.wait_for_timeout(300)
        page.screenshot(path=f'{SHOTS}/3-lesson.png', full_page=True)

    # রিলোড → সব টিকে আছে? (IndexedDB/localStorage)
    boot(page, '#/home')
    st2 = page.evaluate('App.stats()')
    bm = page.evaluate("Store.get('bm', {})")
    notes = page.evaluate("Store.get('notes', {})")
    check('রিলোডের পর Progress থাকে', st2['done'] == 2, json.dumps(st2))
    check('রিলোডের পর বুকমার্ক ও নোট থাকে', 'bn2-4-2' in bm and 'bn2-4-2' in notes)
    resume = page.inner_text('main')
    last_t = page.evaluate("(()=>{const l=Store.get('last');return l?l.lid:''})()")
    exp = 'বাগধারা' if SHOTS else 'প্রবাদ'
    first_recent = page.evaluate("(document.querySelector('.rs-item')||{}).getAttribute ? document.querySelector('.rs-item').getAttribute('href') : ''")
    check('হোমের "সর্বশেষ শুরু করা" অংশের প্রথমটি শেষ খোলা পাঠে নিয়ে যায়', 'সর্বশেষ শুরু করা' in resume and first_recent == '#/l/' + last_t, f'{last_t} {first_recent}')
    # IndexedDB-তে আসলেই লেখা হয়েছে কি না (localStorage মুছে রিলোড)
    page.evaluate("Object.keys(localStorage).filter(k=>k.startsWith('bdadm:')).forEach(k=>localStorage.removeItem(k))")
    boot(page, '#/home')
    check('শুধু IndexedDB থেকেও ফেরত আসে', page.evaluate('App.stats()')['done'] == 2)
    check('বুটে localStorage আবার ভরাট হয় (ব্যাকআপ সিঙ্ক)', page.evaluate("!!localStorage.getItem('bdadm:done')"))

    # সার্চ
    boot(page, '#/search?q=' + 'সমাস')
    page.wait_for_selector('.result')
    check('সার্চ "সমাস" ফল দেয়', 'সমাস' in page.inner_text('#res'))
    page.fill('#q', 'অকাল'); page.wait_for_timeout(300)
    check('নোটের লেখাতেও সার্চ হয়', 'নোটে পাওয়া' in page.inner_text('#res'))
    page.fill('#q', 'voice'); page.wait_for_timeout(300)
    check('ইংরেজি সার্চ (ছোট/বড় হাতের অক্ষর নির্বিশেষে)', 'Voice' in page.inner_text('#res'))

    # সংরক্ষিত
    boot(page, '#/saved/bm')
    check('সংরক্ষিত → বুকমার্ক তালিকা', page.locator('.result').count() == 1)

    # থিম
    boot(page, '#/settings')
    if SHOTS: page.screenshot(path=f'{SHOTS}/4-settings.png', full_page=True)
    themes = ['vanilla', 'ocean', 'forest', 'sky', 'volcano', 'glass', 'aurora', 'rainbow', 'forestglass', 'dark']
    ok = True
    for th in themes:
        page.click(f'[data-theme-opt="{th}"]')
        page.wait_for_timeout(60)
        if page.evaluate('document.documentElement.getAttribute("data-theme")') != th: ok = False
    check('৮টি থিম বদলায়', ok)
    page.click('[data-theme-opt="auto"]')
    check('Auto থিম সিস্টেম অনুযায়ী (লাইট → aurora)', page.evaluate('document.documentElement.getAttribute("data-theme")') == 'aurora')
    page.click('[data-theme-opt="aurora"]')
    boot(page, '#/home')
    check('থিম রিলোডের পর থাকে', page.evaluate('document.documentElement.getAttribute("data-theme")') == 'aurora')
    if SHOTS: page.screenshot(path=f'{SHOTS}/5-home-aurora.png', full_page=True)
    page.goto(URL + '#/settings'); page.wait_for_function('window.__APP_READY === true')
    page.click('[data-lang="en"]')
    check('ভাষা English-এ বদলায়', 'Settings' in page.inner_text('#title'))
    page.click('[data-lang="bn"]')
    page.click('[data-theme-opt="dark"]')
    page.goto(URL + '#/syllabus'); page.wait_for_function('window.__APP_READY === true')
    if SHOTS: page.screenshot(path=f'{SHOTS}/6-syllabus-dark.png')
    page.goto(URL + '#/settings'); page.wait_for_function('window.__APP_READY === true')
    page.click('[data-theme-opt="vanilla"]')

    # ইউনিট বদল
    page.select_option('#unitsel', 'gst-b')
    page.goto(URL + '#/syllabus'); page.wait_for_function('window.__APP_READY === true')
    page.click('.seg button[data-f="unit"]')
    n = page.locator('details.subj').count()
    want = page.evaluate("Core.UNITS['gst-b'].subjects.length")
    check(f'ইউনিট (গুচ্ছ মানবিক) বদলালে বিষয় তালিকা বদলায় ({want}টি, গণিত নেই)', n == want and page.locator('details.subj[data-sid="math"]').count() == 0, f'{n}টি')

    # ব্যাকআপ: কোড → মুছে → ফেরানো
    code = page.evaluate('Store.flushAll().then(()=>Store.exportCode())')
    check('ব্যাকআপ কোড তৈরি হয়', code.startswith('BDADM1:'), f'{len(code)} অক্ষর')
    page.evaluate("Promise.all(['done','bm','notes','hl','last','days'].map(k=>Store.del(k)))")
    check('রিসেটের পর Progress ০', page.evaluate('App.stats()')['done'] == 0)
    n_imp = page.evaluate('(c)=>Store.importBackup(c, "replace")', code)
    check('কোড থেকে ব্যাকআপ ফেরে', page.evaluate('App.stats()')['done'] == 2 and n_imp > 0, f'{n_imp}টি অংশ')
    # ডাউনলোড বাটন (Playwright download ইভেন্ট)
    page.goto(URL + '#/settings'); page.wait_for_function('window.__APP_READY === true')
    try:
        with page.expect_download(timeout=4000) as dl:
            page.click('#bk-dl')
        d = dl.value
        fn = d.suggested_filename
        txt = open(d.path(), encoding='utf-8').read()
        check('ব্যাকআপ JSON ফাইল ডাউনলোড হয়', fn.endswith('.json') and '"bd-admission-superapp"' in txt, fn)
    except Exception as e:
        check('ব্যাকআপ JSON ফাইল ডাউনলোড হয়', False, str(e)[:80])

    check('পুরো সেশনে কোনো JS error নেই', not errs, '; '.join(errs[:3]))
    ctx.close()

    # ---- ৩২০px ও অফলাইন ----
    ctx = browser.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, has_touch=True, offline=True)
    page = ctx.new_page()
    e2 = []
    page.on('pageerror', lambda e: e2.append(str(e)))
    for h in ['#/home', '#/syllabus', '#/l/en-2-2', '#/search?q=noun', '#/saved', '#/settings']:
        boot(page, h)
        w = page.evaluate('document.documentElement.scrollWidth')
        if w > 320: e2.append(f'{h} scrollWidth={w}')
    check('৩২০px + অফলাইন: সব পেজ চলে, অনুভূমিক স্ক্রল নেই', not e2, '; '.join(e2[:3]))
    ctx.close()

    # ---- সংরক্ষণ ফলব্যাক ----
    ctx = browser.new_context(viewport={'width': 360, 'height': 700})
    ctx.add_init_script('try{Object.defineProperty(window,"indexedDB",{value:undefined})}catch(e){}')
    page = ctx.new_page()
    boot(page)
    check('IndexedDB না থাকলে localStorage-এ চলে', page.evaluate('Store.mode') == 'ls')
    ctx.close()
    ctx = browser.new_context(viewport={'width': 360, 'height': 700})
    ctx.add_init_script('''try{Object.defineProperty(window,"indexedDB",{value:undefined});
      Storage.prototype.setItem=function(){throw new Error("blocked")};}catch(e){}''')
    page = ctx.new_page()
    e3 = []
    page.on('pageerror', lambda e: e3.append(str(e)))
    boot(page)
    check('কোনো সংরক্ষণ না চললে অ্যাপ ভাঙে না ও সতর্কবার্তা দেখায়',
          page.evaluate('Store.mode') == 'memory' and 'সংরক্ষণ কাজ করছে না' in page.inner_text('main') and not e3)
    ctx.close()
    browser.close()

fails = [r for r in results if not r[1]]
print(f'\nফলাফল: {len(results) - len(fails)}/{len(results)} পাস')
sys.exit(1 if fails else 0)
