#!/usr/bin/env python3
"""smoke_test_p9.py — Phase 9: JU/RU/CU/GST কাঠামো, ইউনিটভিত্তিক বিষয়, গাণিতিক যুক্তি"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'src' if 'src' in sys.argv[1:] else 'dist', 'index.html')
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)
def subs(page): return page.evaluate("Core.unitSubjects().map(s=>s.id).join(',')")
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    boot(page, '#/settings')
    page.select_option('#unitsel', 'ju-b'); page.wait_for_timeout(250)
    info = page.inner_text('main')
    check('জাবি B: ৮০ নম্বর, সাধারণ গণিত ও যৌক্তিক বিশ্লেষণ দেখায়', '৮০' in info and 'সাধারণ গণিত' in info and 'যৌক্তিক বিশ্লেষণ' in info)
    check('জাবি B-তে গাণিতিক যুক্তি আমার বিষয়ে', 'math' in subs(page) and 'acc' not in subs(page), subs(page))
    units = page.evaluate("Object.keys(Core.UNITS).join(',')")
    check('ব্যবসায় শিক্ষার ইউনিট নেই (DU C, GST C, RU B, CU C); জাবি E শুধু বিজ্ঞান/মানবিক শাখার অংশে', not any(u in units.split(',') for u in ['du-c', 'gst-c', 'ru-b', 'cu-c']) and page.evaluate("Core.UNITS['ju-e'].subjects.join(',')") == 'bn1,bn2,en,math', units)
    check('শাবিপ্রবি B: ঐচ্ছিক পৌরনীতি/সমাজবিজ্ঞান/ইতিহাস/অর্থনীতি আছে', all(x in page.evaluate("Core.UNITS['sust-b'].subjects.join(',')") for x in ['civ', 'soc', 'hist', 'eco', 'ict', 'math']))
    check('ব্যবসায় বিষয় (হিসাববিজ্ঞান ইত্যাদি) নেই', page.evaluate("Core.SUBJ.filter(s=>['acc','bom','fbi','mkt'].includes(s.id)).length") == 0)
    page.select_option('#unitsel', 'cu-d'); page.wait_for_timeout(250)
    check('চবি D: অর্থনীতি ও গণিত (ঐচ্ছিক) আছে', 'eco' in subs(page) and 'math' in subs(page), subs(page))
    page.select_option('#unitsel', 'du-b'); page.wait_for_timeout(250)
    check('ঢাবি B-তে গণিত বা অর্থনীতি নেই', not any(x in subs(page) for x in ['math', 'eco']), subs(page))
    boot(page, '#/s/math')
    check('গাণিতিক যুক্তি: ৩টি অধ্যায় (মাধ্যমিক সাধারণ গণিতসহ), সব পাঠে কনটেন্ট', page.locator('details.chap').count() == 3 and page.evaluate("Core.SMAP.math.ch.every(c=>c.l.every(l=>l.has))"))
    boot(page, '#/s/eco')
    check('অর্থনীতি: ১টি অধ্যায়, সব পাঠে কনটেন্ট', page.locator('details.chap').count() == 1 and page.evaluate("Core.SMAP.eco.ch.every(c=>c.l.every(l=>l.has))"))
    boot(page, '#/l/eco-1-5')
    if SHOTS: page.screenshot(path=f'{SHOTS}/p9-eco.png', full_page=True)
    check('বাংলাদেশের অর্থনীতি পাঠে সারণি ও MCQ', page.locator('[data-fig="table"]').count() >= 1 and page.locator('a.btn:has-text("MCQ")').count() == 1)
    boot(page, '#/quiz/s/math'); page.wait_for_selector('.qcard')
    check('গাণিতিক যুক্তির কুইজ চলে', page.evaluate("QB.all().find(q=>q.q===document.querySelector('.qtext').textContent).sub") == 'math')
    n = page.evaluate("QB.all().filter(q=>q.sub==='math').length"); a = page.evaluate("QB.all().filter(q=>q.sub==='eco').length")
    check('MCQ: গাণিতিক যুক্তি ≥ ১৫০, অর্থনীতি ≥ ৩০; ব্যবসায় বিষয়ের প্রশ্ন ০', n >= 150 and a >= 30 and page.evaluate("QB.all().filter(q=>['acc','bom','fbi','mkt'].includes(q.sub)).length") == 0, f'{n}, {a}')
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close()
    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, offline=True)
    page = ctx.new_page(); w = []
    for lid in [f'math-1-{i}' for i in range(1, 7)] + [f'math-2-{i}' for i in range(1, 5)] + [f'eco-1-{i}' for i in range(1, 6)]:
        boot(page, '#/l/' + lid)
        sw = page.evaluate('document.documentElement.scrollWidth')
        if sw > 320: w.append(f'{lid}={sw}')
    check('৩২০px + অফলাইনে গণিত ও অর্থনীতির ১৫টি পাঠ ফিট করে', not w, ', '.join(w))
    br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
