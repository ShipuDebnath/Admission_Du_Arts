#!/usr/bin/env python3
"""
smoke_test_p2.py — Phase 2 যাচাই: Quiz, Test Engine (Auto-Save/Resume/Auto-Submit),
Flashcard SRS, ভুলের খাতা ও Retry, PYQ Hub ও Import — হেডলেস Chromium, file://
ব্যবহার:  python3 tools/smoke_test_p2.py [dist|src] [--shots DIR]
"""
import os, sys, json
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
target = 'src' if 'src' in sys.argv[1:] else 'dist'
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
URL = 'file://' + os.path.join(ROOT, target, 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok)))
    print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))

BN = '০১২৩৪৫৬৭৮৯'
def bn(n): return ''.join(BN[int(c)] if c.isdigit() else c for c in str(n))
def boot(page, h='#/home'):
    page.goto('about:blank'); page.goto(URL + h)
    page.wait_for_function('window.__APP_READY === true', timeout=10000)
def nav(page, h):
    page.evaluate('h => { location.hash = h; }', h); page.wait_for_timeout(250)
def shot(page, name, full=False):
    if SHOTS: page.screenshot(path=f'{SHOTS}/{name}.png', full_page=full)
def click_correct(page):
    """বর্তমান প্রশ্নের সঠিক অপশনে ক্লিক (qtext দিয়ে প্রশ্ন খুঁজে)"""
    a = page.evaluate('''() => { const t = document.querySelector('.qtext').textContent;
       const q = QB.all().find(x => x.q === t); return q ? q.a : -1; }''')
    page.click(f'.opt[data-oi="{a}"]')
def click_wrong(page):
    a = page.evaluate('''() => { const t = document.querySelector('.qtext').textContent;
       const q = QB.all().find(x => x.q === t); return q ? q.a : -1; }''')
    page.click(f'.opt:not([data-oi="{a}"])')

with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, device_scale_factor=2, is_mobile=True, has_touch=True)
    page = ctx.new_page()
    errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    print(f'লক্ষ্য: {URL}')

    # ---------- হাব ----------
    boot(page, '#/practice')
    txt = page.inner_text('main')
    total = page.evaluate('QB.all().length')
    check(f'অনুশীলন হাব খোলে ও প্রশ্নসংখ্যা দেখায় ({total})', f'মোট {bn(total)}টি প্রশ্ন' in txt)
    check('নিচের মেনুতে "অনুশীলন" ট্যাব সক্রিয়', page.locator('nav a[aria-current="page"]').inner_text().strip().endswith('অনুশীলন'))
    shot(page, 'p2-1-hub', True)

    # ---------- পাঠ → Adaptive Quiz ----------
    boot(page, '#/l/ict-2-2')
    btn = page.locator('a.btn:has-text("MCQ")')
    nq = page.evaluate("QB.forLesson('ict-2-2').length")
    bnq = str(nq).translate(str.maketrans('0123456789', '০১২৩৪৫৬৭৮৯'))
    check(f'পাঠ পেজে MCQ বাটন সক্রিয় ({bnq}টি প্রশ্ন)', btn.count() == 1 and bnq in btn.inner_text() and nq >= 26, btn.inner_text() if btn.count() else '')
    btn.click(); page.wait_for_selector('.qcard')
    levels = []
    for i in range(10):
        levels.append(page.locator('.chip:has-text("স্তর")').inner_text())
        if i == 1:
            page.click('#qprev'); v1 = page.locator('.verdict').count()
            page.click('#qnext'); v2 = page.locator('.verdict').count()
            check('MCQ অনুশীলনে ← পূর্ববর্তী / পরবর্তী → (আগের প্রশ্ন উত্তরসহ দেখায়, ফিরে এলে অসমাপ্ত প্রশ্ন)', v1 == 1 and v2 == 0 and page.locator('#qprev').is_enabled())
        (click_correct if i < 6 else click_wrong)(page)
        page.wait_for_selector('.verdict')
        if i == 0:
            check('উত্তরের পর Instant Feedback ও ব্যাখ্যা (নিয়ম/কৌশল/অপশনের কারণ)', page.locator('.explain dt').count() >= 3 and page.locator('.opt .why').count() == 4)
            shot(page, 'p2-2-quiz-feedback', True)
        page.click('#qnext')
    check('Adaptive: সঠিক হলে স্তর বাড়ে (সহজ → কঠিন)', levels[0].endswith('সহজ') and levels[2].endswith('কঠিন'), ' → '.join(l.split(': ')[1] for l in levels[:4]))
    page.wait_for_selector('.score-ring')
    check('Quiz ফলাফল: ৬/১০ সঠিক ও রিভিশন পরামর্শ', '৬/১০' in page.inner_text('main') and 'রিভিশন পরামর্শ' in page.inner_text('main'))
    shot(page, 'p2-3-quiz-result')
    st = page.evaluate("Object.keys(Store.get('qstat',{})).length")
    mist = page.evaluate("QB.mistakes().length")
    check('প্রশ্ন-পরিসংখ্যান ও ভুলের খাতায় জমা হয়', st == 10 and mist == 4, f'qstat={st}, mistakes={mist}')

    # ---------- সার্চে প্রশ্ন ----------
    boot(page, '#/search?q=' + 'গ্রে')
    page.wait_for_selector('#res .result')
    check('সার্চ প্রশ্নব্যাংকেও খোঁজে', 'প্রশ্নে পাওয়া' in page.inner_text('#res'))
    page.locator('#res a[href^="#/q/"]').first.click(); page.wait_for_selector('.qcard')
    page.locator('.opt').first.click()
    check('একক প্রশ্ন পেজে উত্তর ও ব্যাখ্যা', page.locator('.verdict').count() == 1)

    # ---------- Test Builder → Run → Auto-Save → Resume → Submit ----------
    boot(page, '#/test/build?preset=exam')
    page.fill('#tn', '6'); page.dispatch_event('#tn', 'input'); page.wait_for_timeout(100)
    want = page.evaluate("QB.filter({subs: Array.from(document.querySelectorAll('input[name=sub]:checked')).map(i=>i.value), noExpired: true}).length")
    check('Builder: পাওয়া প্রশ্নের সংখ্যা দেখায়', f'{bn(want)}টি' in page.inner_text('#avail'), page.inner_text('#avail'))
    neg = page.input_value('#tneg')
    check('ইউনিটের নেগেটিভ মার্কিং ডিফল্ট (DU B = ০.২৫)', neg == '0.25', neg)
    page.click('#tstart'); page.wait_for_selector('.testbar')
    check('টেস্ট শুরু, টাইমার ও প্রশ্ন তালিকা দেখায়', page.locator('.palette button').count() == 6)
    click_correct(page); page.click('#tnext')
    click_wrong(page); page.click('#tmark'); page.click('#tnext')
    shot(page, 'p2-4-test-run', True)
    page.wait_for_timeout(5600)  # ৫ সেকেন্ড Auto-Save
    a1 = page.evaluate("Store.get('test:active')")
    check('প্রতি ৫ সেকেন্ডে Auto-Save (উত্তর, চিহ্ন, বাকি সময়)', len(a1['ans']) == 2 and len(a1['mark']) == 1 and a1['left'] < a1['total'] - 4, f"left={a1['left']:.0f}/{a1['total']}")
    left_before = a1['left']
    boot(page, '#/home')   # অ্যাপ বন্ধ করে আবার খোলা
    check('হোমে চলমান টেস্টের Resume ব্যানার', 'চলমান টেস্ট' in page.inner_text('main'))
    page.click('a.banner:has-text("চলমান টেস্ট")'); page.wait_for_selector('.testbar')
    a2 = page.evaluate("Store.get('test:active')")
    check('Resume: আগের প্রশ্নে, উত্তর ও সময় অক্ষত', a2['cur'] == 2 and len(a2['ans']) == 2 and abs(a2['left'] - left_before) < 2)
    page.click('[data-go="0"]')
    check('প্রশ্ন তালিকা থেকে লাফ', page.evaluate("Store.get('test:active').cur") == 0)
    page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')
    t = page.inner_text('main')
    check('ফলাফল: নেগেটিভসহ নম্বর (১ − ০.২৫ = ০.৭৫), সঠিক/ভুল/বাদ ১/১/৪', '০.৭৫' in t and '১ / ১ / ৪' in t)
    check('OMR রিভিউ ও বিষয়ভিত্তিক বিশ্লেষণ', page.locator('.omr').count() == 6 and 'বিষয়ভিত্তিক' in t)
    shot(page, 'p2-5-result', True)
    page.click('.seg [data-f="wrong"]'); page.wait_for_timeout(150)
    check('OMR ফিল্টার: শুধু ভুল', page.locator('.omr').count() == 1)
    check('চলমান টেস্ট মুছে যায়, ইতিহাসে জমা', page.evaluate("Store.get('test:active', null) === null && Store.get('tests').length === 1"))

    # Auto-Submit
    boot(page, '#/test/build?preset=speed')
    check('Speed Drill: ১০ প্রশ্ন, ৫ মিনিট', page.input_value('#tn') == '10' and page.input_value('#tmin') == '5')
    page.click('#tstart'); page.wait_for_selector('.testbar')
    boot(page, '#/home')   # টেস্ট পেজ ছেড়ে (তখন চলমান অবস্থা সেভ হয়) তারপর বাকি সময় কমিয়ে দেওয়া
    page.evaluate("(() => { const a = Store.get('test:active'); a.left = 2; return Store.set('test:active', a, 0); })()")
    nav(page, '#/test/run'); page.wait_for_selector('.testbar')
    page.wait_for_selector('.score-ring', timeout=6000)
    check('সময় শেষে Auto-Submit', page.evaluate("Store.get('tests').length") == 2)

    # Instant feedback (Practice)
    boot(page, '#/test/build?preset=practice')
    page.fill('#tn', '3'); page.dispatch_event('#tn', 'input'); page.click('#tstart'); page.wait_for_selector('.testbar')
    click_wrong(page)
    check('Practice মোডে সাথে সাথে ফিডব্যাক', page.locator('.verdict').count() == 1 and page.locator('.palette button.wrong').count() == 1)
    page.click('#tpausebtn')
    l1 = page.evaluate("Store.get('test:active').left"); page.wait_for_timeout(2200)
    check('Pause করলে টাইমার থামে', abs(page.evaluate("Store.get('test:active').left") - l1) < 0.5)
    page.click('#resume')
    page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')

    # Mock: DU B-তে প্রশ্ন নেই → বার্তা; গুচ্ছ মানবিকে ICT অংশ
    boot(page, '#/test/build?preset=mock')
    check('Mock (DU B): ব্যাংকে প্রশ্নসংখ্যা দেখায় (বাংলা/ইংরেজি/GK = ০)', page.locator('#mockplan td.n').count() == 6)
    page.select_option('#tunit', 'gst-b'); page.wait_for_timeout(150)
    page.click('#tstart'); page.wait_for_selector('.testbar')
    n = page.locator('.palette button').count()
    want = page.evaluate("Core.UNITS['gst-b'].mcq.sections.reduce((s,x)=>s+Math.min(x.marks, QB.filter({subs:x.subjects, noExpired:true}).length),0)")
    check(f'Mock (গুচ্ছ মানবিক): প্রতি অংশে min(নম্বর, ব্যাংকে আছে) = {want}টি, সময় ৬০ মিনিট', n == want and page.evaluate("Store.get('test:active').total") == 3600, f'{n}টি')
    page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')

    # ---------- Flashcard ----------
    boot(page, '#/flash')
    ncard = page.evaluate('QB.cards().length')
    check(f'Flashcard: আজ Due {ncard} (সব নতুন কার্ড)', page.locator('.stat b').first.inner_text() == bn(ncard))
    page.click('#fgo'); page.wait_for_selector('#card')
    shot(page, 'p2-6-flash-front')
    check('নতুন নকশা: শিরোনাম, অংশ-নির্বাচন, আয়ত্ত, "কার্ড ১/N", জানি/আবার দেখব আগে থেকেই দৃশ্যমান',
          page.locator('.fc-h1').inner_text() == 'ফ্ল্যাশকার্ড' and page.locator('#fpart').count() == 1 and 'আয়ত্ত ০/' in page.inner_text('.fc-mast')
          and f'কার্ড ১/{bn(ncard)}' in page.inner_text('.flash-face.front small') and page.locator('#grades').is_visible())
    page.click('#card'); page.wait_for_timeout(500)
    check('ট্যাপে কার্ড উল্টায়', page.locator('#card.flipped').count() == 1)
    shot(page, 'p2-7-flash-back')
    page.click('[data-g="2"]')                           # জানি (Good)
    page.click('[data-g="0"]')                           # আবার দেখব (Again)
    fc = page.evaluate("Store.get('fc', {})")
    good = [k for k, v in fc.items() if v['ivl'] == 1 and v['reps'] == 1]
    again = [k for k, v in fc.items() if v['lapses'] == 1]
    check('SRS: জানি → ১ দিন পরে, আবার দেখব → lapse; কার্ড ৩/N-এ এগোয়', len(good) == 1 and len(again) == 1 and f'কার্ড ৩/{bn(ncard)}' in page.inner_text('.flash-face.front small'))
    front = lambda: page.evaluate("document.querySelector('.flash-face.front .fc-txt').textContent")
    a0 = front(); page.click('#fnext'); a1 = front(); page.click('#fprev'); a2 = front()
    page.click('#fshuf'); a3 = front()
    check('Flashcard: পরের / আগের / এলোমেলো করো কাজ করে (বর্তমান কার্ড থাকে)', a0 != a1 and a2 == a0 and a3 == a0)
    opts = page.locator('#fpart option').count()
    page.select_option('#fpart', index=1); page.wait_for_timeout(200)
    check('অংশ বদলালে ডেক ছোট হয় ও কার্ড ১ থেকে শুরু', opts > 2 and 'কার্ড ১/' in page.inner_text('.flash-face.front small') and f'/{bn(ncard)}' not in page.inner_text('.flash-face.front small'))
    boot(page, '#/flash')
    due_txt = page.locator('.stat b').first.inner_text()
    check(f'রিভিউর পর Due কমে ({ncard} → {ncard - 2}: Good ১ দিন পরে, Again ১ মিনিট পরে)', due_txt == bn(ncard - 2), due_txt)
    boot(page, '#/flash/add')
    page.fill('#nf', 'পরীক্ষামূলক কার্ড — সামনে'); page.fill('#nb', 'পেছনে')
    page.click('#nsave'); page.wait_for_timeout(300)
    check('নিজের Flashcard যোগ হয়', 'পরীক্ষামূলক কার্ড' in page.inner_text('main'))
    page.click('[data-rm]'); page.wait_for_timeout(200)

    # ---------- ভুলের খাতা ও Retry ----------
    boot(page, '#/mistakes')
    nm = page.locator('[data-reason]').count()
    check('ভুলের খাতায় জমা প্রশ্ন দেখায়', nm >= 4, f'{nm}টি')
    page.locator('[data-reason]').first.select_option('careless'); page.wait_for_timeout(100)
    qid = page.locator('[data-reason]').first.get_attribute('data-reason')
    check('ভুলের কারণ ট্যাগ সংরক্ষিত', page.evaluate(f"Store.get('mist')['{qid}'].reason") == 'careless')
    shot(page, 'p2-8-mistakes', True)
    before = page.evaluate("QB.mistakes().length")
    for rnd in range(3):
        boot(page, '#/mistakes'); page.click('#retry'); page.wait_for_selector('.qcard')
        while page.locator('.qcard').count() and page.locator('#qnext, #qskip').count():
            if page.locator('#qskip').count():
                click_correct(page); page.wait_for_selector('#qnext')
            page.click('#qnext'); page.wait_for_timeout(50)
            if page.locator('.score-ring').count(): break
    after = page.evaluate("QB.mistakes().length")
    check('Retry: পরপর ৩ বার সঠিক হলে "আয়ত্ত" হয়ে সরে যায়', after == 0 and before > 0, f'{before} → {after}')

    # ---------- PYQ Hub ও Import ----------
    boot(page, '#/pyq')
    check('PYQ Hub: যাচাইকৃত PYQ না থাকায় সৎ খালি অবস্থা', 'এখনো কোনো PYQ নেই' in page.inner_text('main'))
    page.click('a:has-text("PYQ Import")'); page.wait_for_selector('#itext')
    # শুধু টেস্টের জন্য কৃত্রিম সারি (অ্যাপের ডেটায় যায় না; শেষে মুছে ফেলা হয়)
    csv = ('id,exam,unit,session,year,subject,topicId,type,question,option1,option2,option3,option4,answer,explanation,sourceNote,verified,difficulty\n'
           't1,DU,B,2024-25,2024,ict,ict-2-2,mcq,টেস্ট প্রশ্ন এক,ক,খ,গ,ঘ,2,টেস্ট ব্যাখ্যা,টেস্ট সূত্র,true,1\n'
           't2,DU,B,2024-25,2024,ict,ict-2-2,mcq,টেস্ট প্রশ্ন দুই,ক,খ,গ,ঘ,গ,টেস্ট ব্যাখ্যা,,false,2\n'
           't3,DU,B,2024-25,2024,ict,,mcq,ভুল সারি,ক,খ,,,ঙ,,,,\n')
    page.fill('#itext', csv); page.click('#icheck')
    out = page.inner_text('#iout')
    check('Import যাচাই: ২টি বৈধ (PYQ ১), ১টি বাতিল', 'বৈধ ২টি (PYQ ১' in out and 'বাতিল ১টি' in out, out.split('\n')[0])
    page.click('#iadd'); page.wait_for_selector('h2:has-text("Year-wise")')
    t = page.inner_text('main')
    check('PYQ Hub: ফিল্টার, Year-wise পেপার ও Frequency চার্ট', 'Year-wise Full Paper' in t and 'Frequency' in t)
    tags = page.evaluate("QB.all().filter(q=>q.exam).map(q=>QB.srcLabel(q)).sort().join(',')")
    check('যাচাইকৃত = "PYQ", যাচাইহীন = "PYQ-Style" (সততার নিয়ম)', tags == 'PYQ,PYQ-Style', tags)
    shot(page, 'p2-9-pyq', True)
    page.click('[data-paper]'); page.wait_for_selector('.testbar')
    check('Year-wise পেপার টেস্ট হিসেবে শুরু হয়', page.locator('.palette button').count() == 2)
    page.click('#tsubmit'); page.click('#cy'); page.wait_for_selector('.score-ring')
    boot(page, '#/pyq/import'); page.click('#iclear'); page.click('#y'); page.wait_for_timeout(200)
    check('Import করা প্রশ্ন মোছা যায়', page.evaluate("QB.all().filter(q=>q.exam).length") == 0)

    # ---------- ব্যাকআপে Phase 2 ডেটা ----------
    keys = page.evaluate("Object.keys(Store.exportObject().data).sort().join(',')")
    check('ব্যাকআপে qstat, mist, fc, tests অন্তর্ভুক্ত', all(k in keys for k in ['qstat', 'mist', 'fc', 'tests']), keys)
    boot(page, '#/home')
    check('হোমে আয়ত্ত % দেখায় (ICT)', 'আয়ত্ত' in page.inner_text('main'))
    check('পুরো সেশনে কোনো JS error নেই', not errs, '; '.join(errs[:3]))
    ctx.close()

    # ---------- ৩২০px ----------
    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, offline=True)
    page = ctx.new_page(); e2 = []
    page.on('pageerror', lambda e: e2.append(str(e)))
    for h in ['#/practice', '#/test/build', '#/flash', '#/mistakes', '#/pyq', '#/pyq/import', '#/quiz/l/ict-2-5', '#/test/history']:
        boot(page, h)
        w = page.evaluate('document.documentElement.scrollWidth')
        if w > 320: e2.append(f'{h} scrollWidth={w}')
    page.goto('about:blank'); page.goto(URL + '#/test/build'); page.wait_for_function('window.__APP_READY === true')
    page.click('#tstart'); page.wait_for_selector('.testbar')
    w = page.evaluate('document.documentElement.scrollWidth')
    if w > 320: e2.append(f'test/run scrollWidth={w}')
    check('৩২০px + অফলাইন: সব অনুশীলন পেজ চলে, অনুভূমিক স্ক্রল নেই', not e2, '; '.join(e2[:3]))
    ctx.close(); br.close()

fails = [r for r in results if not r[1]]
print(f'\nফলাফল: {len(results) - len(fails)}/{len(results)} পাস')
sys.exit(1 if fails else 0)
