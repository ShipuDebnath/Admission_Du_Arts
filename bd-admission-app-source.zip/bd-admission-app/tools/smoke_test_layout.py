#!/usr/bin/env python3
"""smoke_test_layout.py — ৩২০/৩৬০/৭৬৮/১২৮০px-এ প্রধান পাতাগুলো: অনুভূমিক স্ক্রল নেই, JS error নেই, ছোট টাচ-টার্গেট নেই"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
ROUTES = ['#/home', '#/syllabus', '#/s/bn1', '#/l/bn1-1-1', '#/l/gkbd-6-4', '#/l/en-1-1', '#/practice', '#/quiz/s/en', '#/test/build', '#/test/build?preset=mock',
          '#/flash', '#/flash/review?mode=all', '#/mistakes', '#/pyq', '#/ca', '#/written', '#/written/t/bn-bhab', '#/written/full', '#/mega', '#/final', '#/final/en',
          '#/games', '#/games/match', '#/games/memory', '#/games/timeline', '#/games/sort', '#/games/speed', '#/games/word', '#/achieve', '#/saved/q', '#/settings', '#/about', '#/search?q=ভাষা', '#/charts', '#/charts/bn1-character-maps', '#/charts/map/ict-2', '#/study']
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    print('  Chromium', br.version)
    for w, h, mob in ((320, 640, True), (360, 760, True), (768, 1024, True), (1280, 800, False)):
        ctx = br.new_context(viewport={'width': w, 'height': h}, is_mobile=mob, has_touch=mob)
        page = ctx.new_page(); errs = []; wide = []; small = []
        page.on('pageerror', lambda e: errs.append(str(e)))
        for r in ROUTES:
            page.goto('about:blank'); page.goto(URL + r); page.wait_for_function('window.__APP_READY === true', timeout=15000); page.wait_for_timeout(150)
            if page.evaluate('document.documentElement.scrollWidth > innerWidth + 1'): wide.append(r)
            if mob:
                s = page.evaluate("""() => [...document.querySelectorAll('main button:not([disabled]), main .btn, nav a, header button, header a')].filter(e => { const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0 && b.height < 32; }).map(e => (e.textContent||e.getAttribute('aria-label')||'').trim().slice(0,20))""")
                if s: small.append(r + ':' + ','.join(s[:3]))
        check(f'{w}px: অনুভূমিক স্ক্রল নেই ({len(ROUTES)}টি পাতা)', not wide, ', '.join(wide))
        if mob: check(f'{w}px: টাচ-টার্গেট ≥৩২px (বাটন ৪৪px লক্ষ্য)', not small, '; '.join(small[:4]))
        check(f'{w}px: JS error নেই', not errs, '; '.join(errs[:2]))
        ctx.close()
    br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
