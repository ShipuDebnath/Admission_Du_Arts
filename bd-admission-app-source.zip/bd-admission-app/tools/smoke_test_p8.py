#!/usr/bin/env python3
"""smoke_test_p8.py — Phase 8: DU লিখিত ল্যাব ও Unit Mode"""
import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'src' if 'src' in sys.argv[1:] else 'dist', 'index.html')
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True, has_touch=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    shot = (lambda n, full=True: page.screenshot(path=f'{SHOTS}/{n}.png', full_page=full) if SHOTS else None)

    boot(page, '#/home')
    check('হোমে DU লিখিত ল্যাবের কার্ড (ডিফল্ট ইউনিট DU B)', page.locator('#wl-home').count() == 1)
    boot(page, '#/written')
    st = page.inner_text('#wl-struct')
    check('হাবে লিখিত কাঠামো: ৪০ নম্বর, ৪৫ মিনিট, বাংলা ২০ + English ২০', '৪০' in st and '৪৫' in st and st.count('২০') >= 2, st[:80])
    n = page.locator('.wl-topic').count()
    check('বাংলা ও English টপিক তালিকা (≥১০)', n >= 10, str(n))
    check('PYQ-তে আসা টপিকে চিহ্ন', page.locator('.wl-topic .chip.ok').count() >= 6)
    shot('p8-1-hub')

    boot(page, '#/written/t/bn-bhab')
    b = page.inner_text('main')
    check('টপিক-পাতা: কৌশল, মানদণ্ড, পরীক্ষকের নোট, মডেল, চেকলিস্ট', all(x in b for x in ['লেখার কৌশল', 'মানদণ্ড', 'পরীক্ষকের চোখে', 'মডেল উত্তর', 'মিলিয়ে দেখুন']))
    page.locator('#wl-check input').first.check()
    boot(page, '#/written/t/bn-bhab')
    check('চেকলিস্টের টিক রিলোডের পরও থাকে', page.locator('#wl-check input').first.is_checked())
    shot('p8-2-topic')

    # টাইমড লেখা: টাইমার, শব্দ গণনা, Auto-Save, রিলোড, জমা
    boot(page, '#/written/full')
    nparts = page.locator('.wl-text').count()
    check('পূর্ণ অনুশীলনে ৭টি অংশ (২০২৩-২৪-এর ধারা)', nparts == 7, str(nparts))
    t0 = page.inner_text('#wl-left')
    check('টাইমার ৪৫:০০ থেকে শুরু', t0 == '৪৫:০০', t0)
    page.locator('.wl-text').first.fill('সবার উপরে মানুষ সত্য এই কথাটি চিরন্তন')
    page.wait_for_timeout(2300)
    t1 = page.inner_text('#wl-left')
    check('লিখতে শুরু করলে টাইমার চলে', t1 != '৪৫:০০', t1)
    check('শব্দ গণনা (৭ শব্দ)', '৭' in page.inner_text('#wl-c0'), page.inner_text('#wl-c0'))
    page.wait_for_timeout(2300)
    boot(page, '#/written/full')
    check('রিলোডের পর লেখা ও সময় ফিরে আসে (Auto-Save)', 'চিরন্তন' in page.locator('.wl-text').first.input_value() and page.inner_text('#wl-left') != '৪৫:০০')
    shot('p8-3-pad', False)
    page.click('#wl-sub'); page.wait_for_selector('.wl-rev')
    check('জমার পর মিলিয়ে দেখার পাতা: নিজের লেখা + চেকলিস্ট + নম্বর', page.locator('.wl-rev').count() == 7 and page.locator('.wl-score').count() == 7)
    page.locator('.wl-score').first.fill('৪')
    page.wait_for_timeout(600)
    boot(page, '#/written/mine')
    m = page.inner_text('main')
    check('আমার লেখা: সংরক্ষিত ও নিজের নম্বর দেখায়', page.locator('.wl-saved').count() == 1 and 'নিজের নম্বর ৪/' in m, m[:100])
    boot(page, '#/written/pyq')
    check('আগের বছরের প্রশ্ন: ২০২৩-২৪ (সূত্রসহ)', '২০২৩-২৪' in page.inner_text('main') and 'Satt Academy' in page.inner_text('main'))
    page.click('#wpq-add summary'); page.fill('#wq-ses', '2022-23'); page.fill('#wq-q', 'পরীক্ষামূলক লিখিত প্রশ্ন'); page.click('#wq-go')
    check('নিজে আগের বছরের প্রশ্ন যোগ করা যায়', 'পরীক্ষামূলক লিখিত প্রশ্ন' in page.inner_text('main'))
    boot(page, '#/written/analysis')
    check('প্রশ্নধারা বিশ্লেষণ: সীমাবদ্ধতা স্পষ্ট', 'একটি বছরের ভিত্তিতে' in page.inner_text('main'))

    # Unit Mode: নাম ও বিষয় কাস্টমাইজ
    boot(page, '#/settings')
    page.evaluate("document.getElementById('ucust').open = true"); page.fill('#ucname', 'আমার কাস্টম ইউনিট')
    page.locator('#ucsubs input[value="gkint"]').uncheck(); page.click('#ucsave')
    page.wait_for_timeout(300)
    boot(page, '#/home')
    hn = page.inner_text('main')
    subs = page.evaluate("Core.unitSubjects().map(s=>s.id).join(',')")
    check('Unit Mode: কাস্টম নাম হোমে, বিষয় থেকে gkint বাদ', 'আমার কাস্টম ইউনিট' in hn and 'gkint' not in subs, subs)
    boot(page, '#/settings'); page.evaluate("document.getElementById('ucust').open = true"); page.click('#ucreset'); page.wait_for_timeout(300)
    check('Unit Mode: ডিফল্টে ফেরানো যায়', 'gkint' in page.evaluate("Core.unitSubjects().map(s=>s.id).join(',')"))
    # অন্য ইউনিটে লিখিত নেই
    page.select_option('#unitsel', 'gst-b'); page.wait_for_timeout(300)
    boot(page, '#/home')
    check('গুচ্ছ ইউনিটে হোমে লিখিত কার্ড নেই', page.locator('#wl-home').count() == 0)
    boot(page, '#/written')
    check('অ-DU ইউনিটে লিখিত ল্যাবে "শুধু DU" নোট', page.locator('#wl-note').count() == 1)
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close()

    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True, offline=True)
    page = ctx.new_page(); w = []
    for h in ['#/written', '#/written/t/bn-gram', '#/written/t/en-letter', '#/written/p/en-trans', '#/written/pyq', '#/written/analysis', '#/settings']:
        boot(page, h)
        sw = page.evaluate('document.documentElement.scrollWidth')
        if sw > 320: w.append(f'{h}={sw}')
    check('৩২০px + অফলাইনে লিখিত ল্যাবের সব পাতা ফিট করে', not w, ', '.join(w))
    br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
