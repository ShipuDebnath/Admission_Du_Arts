#!/usr/bin/env python3
"""smoke_test_charts.py — চার্ট হাব (৫১ + কনসেপ্ট ম্যাপ), প্রতিটি চার্ট পাতা, ব্যতিক্রম অংশ, পিন → হোম, পাঠে চার্ট, অনুসন্ধান, সাইফার, কনসেপ্ট ম্যাপ"""
import os, sys, json, glob
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
CH = [c for f in sorted(glob.glob(os.path.join(ROOT, 'src', 'data', 'charts', '*.json'))) for c in json.load(open(f, encoding='utf-8'))['charts']]
results = []
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def go(page, r):
    page.goto('about:blank'); page.goto(URL + r); page.wait_for_function('window.__APP_READY === true', timeout=15000); page.wait_for_timeout(120)

check('ডেটা: ৫১টি চার্ট, নম্বর ১–৫১ একবার করে', sorted(c['n'] for c in CH) == list(range(1, 52)), str(len(CH)))
check('ডেটা: প্রতিটিতে ব্যতিক্রম (ex), মনে রাখুন (keys) ও কৌশল (tip)', all(c.get('ex') and c.get('keys') and c.get('tip') for c in CH),
      ', '.join(c['id'] for c in CH if not (c.get('ex') and c.get('keys') and c.get('tip'))))
with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True, has_touch=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    go(page, '#/charts')
    check('হাব: ৫১টি চার্ট টাইল', page.locator('.cht').count() == 51, str(page.locator('.cht').count()))
    check('হাব: কনসেপ্ট ম্যাপ (৫২) লিংক আছে', page.locator('a[href^="#/charts/map/"], a[href="#/charts?s=map"]').count() > 0)
    go(page, '#/charts?q=' + 'সমাস')
    check('হাব অনুসন্ধান: "সমাস" → সমাস চার্ট', page.locator('a[href="#/charts/bn-samas-tree"]').count() > 0)
    bad, wide = [], []
    for c in CH:
        go(page, '#/charts/' + c['id'])
        t = page.locator('main').inner_text()
        if c['t'] not in t or page.locator('.ch-part').count() < len(c['parts']) or page.locator('.ch-box.exc li').count() < len(c['ex']): bad.append(c['id'])
        if page.evaluate('document.documentElement.scrollWidth > innerWidth + 1'): wide.append(c['id'])
    check('৫১টি চার্ট পাতা: শিরোনাম, সব অংশ ও ব্যতিক্রম দেখায়', not bad, ', '.join(bad[:5]))
    check('৫১টি চার্ট পাতা: ৩৬০px-এ অনুভূমিক স্ক্রল নেই', not wide, ', '.join(wide[:5]))
    go(page, '#/charts/ict-logic-gates')
    check('লজিক গেট: ৭টি সত্যক সারণি', page.locator('.ch-tt').count() == 7)
    go(page, '#/charts/ict-cipher')
    page.fill('#cpin', 'XYZ'); page.wait_for_timeout(100)
    check('সাইফার: XYZ (শিফট ৩) → ABC', page.locator('#cpout').inner_text().strip() == 'ABC', page.locator('#cpout').inner_text())
    go(page, '#/charts/bn-natva-satva')
    check('ণত্ব-ষত্ব: দুটি সিদ্ধান্ত-বৃক্ষ, ধাপ নম্বরসহ', page.locator('.fl').count() == 2 and page.locator('.fl-step').count() >= 10)
    page.click('#chpin'); page.wait_for_timeout(150)
    go(page, '#/home')
    check('পিন করা চার্ট হোমে দেখায়', page.locator('.home-charts a[href="#/charts/bn-natva-satva"]').count() > 0)
    go(page, '#/l/bn2-3-4')
    check('পাঠের পাতায় "এই পাঠের চার্ট" লিংক', page.locator('main a[href="#/charts/bn-natva-satva"]').count() > 0)
    go(page, '#/search?q=' + 'টপোলজি')
    check('গ্লোবাল অনুসন্ধানে চার্ট', page.locator('a[href="#/charts/ict-topology"]').count() > 0)
    go(page, '#/charts/map/gkbd-6')
    check('কনসেপ্ট ম্যাপ (অধ্যায়): পাঠের লিংকসহ', page.locator('main a[href^="#/l/gkbd-6-"]').count() >= 3)
    go(page, '#/s/ict')
    check('বিষয়ের পাতায় চার্টের চিপ', page.locator('a[href="#/charts?s=ict"]').count() > 0)
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close(); br.close()
print(f'\nফলাফল: {sum(results)}/{len(results)} পাস'); sys.exit(0 if all(results) else 1)
