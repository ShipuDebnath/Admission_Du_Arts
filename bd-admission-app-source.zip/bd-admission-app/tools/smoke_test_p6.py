#!/usr/bin/env python3
"""smoke_test_p6.py — Phase 6: সাম্প্রতিক হাব, মাসিক প্যাক, Quiz/Flashcard, Import, পুরোনো-সতর্কতা
ব্যবহার:  python3 tools/smoke_test_p6.py [dist|src] [--shots DIR]"""
import os, sys, json, datetime
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
target = 'src' if 'src' in sys.argv[1:] else 'dist'
SHOTS = sys.argv[sys.argv.index('--shots') + 1] if '--shots' in sys.argv else None
URL = 'file://' + os.path.join(ROOT, target, 'index.html')
EXE = os.environ.get('CHROME', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
PACK = json.load(open(os.path.join(ROOT, 'src', 'data', 'ca', 'packs.json'), encoding='utf-8'))
results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok)))
    print(('  ✓ ' if ok else '  ✗ ') + name + (f' — {detail}' if detail else ''))
def boot(page, h):
    page.goto('about:blank'); page.goto(URL + h); page.wait_for_function('window.__APP_READY === true', timeout=10000)

with sync_playwright() as p:
    br = p.chromium.launch(executable_path=EXE)
    ctx = br.new_context(viewport={'width': 360, 'height': 760}, is_mobile=True, has_touch=True)
    page = ctx.new_page(); errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    shot = (lambda n, full=True: page.screenshot(path=f'{SHOTS}/{n}.png', full_page=full) if SHOTS else None)
    print(f'লক্ষ্য: {URL}')

    boot(page, '#/ca')
    up = page.inner_text('#caupd')
    check('হাবে "সর্বশেষ হালনাগাদ" ব্যানার', 'সর্বশেষ হালনাগাদ' in up, up[:60])
    nm = page.locator('#calist .ca-month').count()
    months = sorted({i['date'][:7] for i in PACK['items']})
    check('মাসভিত্তিক প্যাকের তালিকা (প্যাকের সব মাস)', nm >= len(months), f'{nm} ≥ {len(months)}')
    shot('p6-1-hub')
    check('প্রতিটি মাসে Quiz বাটন (MCQ থাকলে)', page.locator('#calist a[href^="#/quiz/ca/"]').count() >= len(months) - 2)

    boot(page, '#/ca/m/2026-10')
    body = page.inner_text('main')
    check('মাসের পাতা (অক্টোবর ২০২৬): ঘটনা, তারিখ, সূত্র', 'নোবেল' in body and 'সূত্র:' in body and page.locator('.ca-item').count() >= 8)
    shot('p6-2-month')
    page.locator('a[href="#/quiz/ca/2026-10"]').first.click(); page.wait_for_selector('.qcard')
    qca = page.evaluate("(QB.all().find(q=>q.q===document.querySelector('.qtext').textContent)||{}).ca")
    check('মাসের Quiz — প্রশ্ন ঐ মাসেরই (ca তারিখ)', bool(qca) and qca.startswith('2026-10'), str(qca))
    shot('p6-3-quiz', False)

    boot(page, '#/flash/review?cam=2026-02')
    check('মাসের Flashcard (ফেব্রুয়ারি ২০২৬)', page.locator('#card').count() == 1 and 'ফেব্রুয়ারি' in page.inner_text('#title, .topbar h1, header'))

    boot(page, '#/l/ca-1-1')
    lb = page.inner_text('#lbody')
    check('পাঠ ca-1-1: হালনাগাদ নোট, সময়রেখা, সূত্র', 'সর্বশেষ হালনাগাদ' in lb and page.locator('[data-fig="timeline"] .tl-i').count() >= 6 and 'সূত্র' in lb)
    n = page.evaluate("QB.all().filter(q=>q.sub==='ca').length")
    nca = page.evaluate("QB.all().filter(q=>q.sub==='ca' && q.ca && q.exp).length")
    check('সব সাম্প্রতিক MCQ-তে ca ও exp', n > 100 and n == nca, f'{nca}/{n}')

    boot(page, '#/s/ca')
    check('বিষয়-পাতা থেকে হাবের লিংক', page.locator('#cahublink').count() == 1)
    boot(page, '#/practice')
    check('অনুশীলন হাবে "সাম্প্রতিক হাব"', page.locator('.hub a[href="#/ca"]').count() == 1)

    # Import: ঘটনা + প্রশ্ন
    boot(page, '#/ca/import')
    data = {'items': [{'date': '2026-11-05', 't': 'পরীক্ষামূলক ঘটনা ক', 'd': 'বিস্তারিত', 'src': 'টেস্ট', 'lid': 'ca-1-1'},
                      {'t': 'তারিখহীন — বাদ যাবে'}],
            'q': [{'q': 'পরীক্ষামূলক সাম্প্রতিক প্রশ্ন?', 'o': ['এক', 'দুই', 'তিন', 'চার'], 'a': 1, 'explanation': 'কারণ', 'lid': 'ca-1-1', 'ca': '2026-11-05', 'exp': '2028-11-30'}]}
    page.fill('#catext', json.dumps(data, ensure_ascii=False))
    page.click('#cago')
    res = page.inner_text('#cares')
    check('Import: ঘটনা ও প্রশ্ন যোগ, ত্রুটিপূর্ণটি বাদ', '১টি ঘটনা' in res and '১টি প্রশ্ন' in res and 'বাদ' in res, res[:90])
    boot(page, '#/ca/m/2026-11')
    check('Import করা ঘটনা ঐ মাসের প্যাকে (চিপসহ)', 'পরীক্ষামূলক ঘটনা ক' in page.inner_text('main') and page.locator('.ca-item .chip').count() >= 1)
    check('Import করা প্রশ্ন মাসের Quiz-এ', page.locator('a[href="#/quiz/ca/2026-11"]').count() == 1)
    boot(page, '#/ca')
    check('রিলোডের পরও Import থাকে (হাবে নভেম্বর ২০২৬)', 'নভেম্বর ২০২৬' in page.inner_text('#calist'))
    check('JS error নেই', not errs, '; '.join(errs[:2]))
    ctx.close()

    # পুরোনো-সতর্কতা: ঘড়ি ৯০ দিন এগিয়ে
    ctx = br.new_context(viewport={'width': 320, 'height': 640}, is_mobile=True)
    page = ctx.new_page()
    d = datetime.datetime.fromisoformat(PACK['updated']) + datetime.timedelta(days=90)
    page.clock.set_fixed_time(d)
    boot(page, '#/ca')
    t = page.inner_text('#caupd')
    check('প্যাক পুরোনো হলে সতর্কতা (৯০ দিন পর)', 'পুরোনো' in t and 'warn' in page.get_attribute('#caupd', 'class'), t[:80])
    w = []
    for h in ['#/ca', '#/ca/m/2026-10', '#/ca/import', '#/l/ca-2-5', '#/l/ca-1-6']:
        boot(page, h)
        sw = page.evaluate('document.documentElement.scrollWidth')
        if sw > 320: w.append(f'{h} {sw}')
    check('৩২০px-এ হাব, মাস, Import ও পাঠ ফিট করে', not w, '; '.join(w))
    ctx.close(); br.close()

fails = [r for r in results if not r[1]]
print(f'\nফলাফল: {len(results) - len(fails)}/{len(results)} পাস')
sys.exit(1 if fails else 0)
