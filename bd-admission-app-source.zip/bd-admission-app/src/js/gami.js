/* =========================================================
   gami.js — PART M: Gamification ও Practice Mini-Games
   XP/লেভেল/ব্যাজ বিদ্যমান অগ্রগতি থেকে হিসাব হয় (আলাদা করে "পয়েন্ট" জমাতে হয় না),
   Daily Challenge, লোকাল লিডারবোর্ড (এই ডিভাইসে ব্যক্তিগত সেরা), প্রেরণার বাক্য।
   গেম-টেমপ্লেট (নতুন কনটেন্ট লেখা হয়নি; বিদ্যমান ডেটা থেকে তৈরি):
     match (মিলাও) · memory (জোড়া খোঁজো) · timeline (সাল অনুযায়ী সাজাও)
     sort (শ্রেণিতে ভাগ করো) · speed (Speed Quiz) · word (Word Builder)
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast, LMAP = C.LMAP, SMAP = C.SMAP;
  function $v() { return C.view(); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function shuffle(a) { return QB.shuffle(a); }
  function clean(s) { return String(s == null ? '' : s).replace(/\*\*|==/g, '').trim(); }
  function today() { return C.todayKey(); }
  // ফিগারের শিরোনাম থেকে নির্দেশনা-অংশ বাদ ("— ট্যাপ করে…", "(কলাম-লুকাও…)")
  function title(h) { return clean(h).replace(/\s*[—–-]\s*ট্যাপ.*$/, '').replace(/\s*\((?:কলাম|ট্যাপ|পাঠের)[^)]*\)/g, '').trim(); }

  /* ---------------- কাউন্টার (দৈনিক ও মোট) ---------------- */
  function G() { return Store.get('gami', {}) || {}; }
  function bump(k, n) {
    var g = JSON.parse(JSON.stringify(G()));
    var t = today();
    g[k] = (g[k] || 0) + (n || 1);
    g.day = g.day && g.day.d === t ? g.day : { d: t };
    g.day[k] = (g.day[k] || 0) + (n || 1);
    Store.set('gami', g, 800);
    return g;
  }
  function dayCount(k) { var g = G(); return g.day && g.day.d === today() ? (g.day[k] || 0) : 0; }
  // প্রশ্নের উত্তর ও Flashcard রিভিউ গোনা (মূল ফাংশন অপরিবর্তিত, শুধু গণনা যোগ)
  var _rec = QB.record, _rev = QB.review;
  QB.record = function (qid, chosen) { var r = _rec.apply(QB, arguments); if (chosen >= 0) bump('ans'); return r; };
  QB.review = function () { var r = _rev.apply(QB, arguments); bump('cards'); return r; };
  if (window.Practice) Practice.onSubmit(function () { bump('tests'); });

  /* ---------------- XP ও লেভেল ---------------- */
  var LEVELS = ['নবীন', 'শিক্ষার্থী', 'অনুসন্ধানী', 'অধ্যবসায়ী', 'দক্ষ', 'প্রস্তুত', 'মেধাবী', 'অভিজ্ঞ', 'বিশেষজ্ঞ', 'চ্যাম্পিয়ন', 'কিংবদন্তি'];
  function totals() {
    var st = Store.get('qstat', {}) || {}, att = 0, cor = 0;
    for (var k in st) { att += st[k].n || 0; cor += st[k].c || 0; }
    var done = Object.keys(C.doneMap() || {}).length;
    var mist = Store.get('mist', {}) || {}, mastered = 0; for (var m in mist) if (mist[m].mastered) mastered++;
    var g = G();
    var saved = ['bm', 'saveq', 'savefc', 'savewt'].reduce(function (s, k) { return s + Object.keys(Store.get(k, {}) || {}).length; }, 0);
    var fc = Store.get('fc', {}) || {}, rv = 0; for (var f in fc) rv += (fc[f].reps || 0) + (fc[f].lapses || 0);
    return { att: att, cor: cor, done: done, cards: Math.max(g.cards || 0, rv), tests: Math.max(g.tests || 0, (Store.get('tests', []) || []).length), games: g.games || 0, gwin: g.gwin || 0,
      written: (Store.get('wsaved', []) || []).length, chal: (g.chal || []).length, streak: C.streak(), mastered: mastered, saved: saved,
      mega: Object.keys(Store.get('mega', {}) || {}).reduce(function (s, u) { return s + (Store.get('mega', {})[u] || []).length; }, 0),
      finals: Store.get('finals', {}) || {} };
  }
  function xpOf(t) {
    return t.done * 10 + t.cor * 2 + (t.att - t.cor) + t.cards + t.tests * 15 + t.games * 5 + t.gwin * 5 + t.written * 20 + t.chal * 30;
  }
  function levelOf(xp) {
    var L = 1; while (xp >= 50 * (L + 1) * L) L++;
    var lo = 50 * L * (L - 1), hi = 50 * (L + 1) * L;
    return { n: L, name: LEVELS[Math.min(L - 1, LEVELS.length - 1)], lo: lo, hi: hi, pct: Math.round((xp - lo) * 100 / (hi - lo)) };
  }

  /* ---------------- ব্যাজ ---------------- */
  var BADGES = [
    ['l1', '📖', 'প্রথম পাঠ', 'একটি পাঠ সম্পন্ন', function (t) { return t.done >= 1; }],
    ['l25', '📚', 'পাঠপ্রেমী', '২৫টি পাঠ সম্পন্ন', function (t) { return t.done >= 25; }],
    ['l100', '🏛', 'জ্ঞানের ভান্ডার', '১০০টি পাঠ সম্পন্ন', function (t) { return t.done >= 100; }],
    ['q100', '✅', 'শতক', '১০০টি সঠিক উত্তর', function (t) { return t.cor >= 100; }],
    ['q500', '🎯', 'লক্ষ্যভেদী', '৫০০টি সঠিক উত্তর', function (t) { return t.cor >= 500; }],
    ['q2000', '💎', 'হীরক', '২০০০টি সঠিক উত্তর', function (t) { return t.cor >= 2000; }],
    ['s3', '🔥', 'শুরুর আগুন', '৩ দিনের Streak', function (t) { return t.streak >= 3; }],
    ['s7', '⚡', 'সপ্তাহজয়ী', '৭ দিনের Streak', function (t) { return t.streak >= 7; }],
    ['s30', '🌟', 'অবিচল', '৩০ দিনের Streak', function (t) { return t.streak >= 30; }],
    ['c100', '🃏', 'কার্ড মাস্টার', '১০০টি Flashcard রিভিউ', function (t) { return t.cards >= 100; }],
    ['m10', '🩹', 'ভুল থেকে শেখা', 'ভুলের খাতার ১০টি প্রশ্ন আয়ত্ত', function (t) { return t.mastered >= 10; }],
    ['t1', '⏱', 'প্রথম টেস্ট', 'একটি টাইমড টেস্ট সম্পন্ন', function (t) { return t.tests >= 1; }],
    ['mm', '🎓', 'Mega যোদ্ধা', 'একটি Mega Mock সম্পন্ন', function (t) { return t.mega >= 1; }],
    ['f80', '🏁', 'বিষয় বিজয়ী', 'কোনো Subject Final-এ LQS ৮০+', function (t) { return Object.keys(t.finals).some(function (s) { return t.finals[s].some(function (r) { return r.lqs >= 80; }); }); }],
    ['w1', '✍️', 'লেখক', 'একটি লিখিত উত্তর জমা', function (t) { return t.written >= 1; }],
    ['g5', '🎮', 'খেলোয়াড়', '৫টি গেমে জয়', function (t) { return t.gwin >= 5; }],
    ['dc', '🏅', 'চ্যালেঞ্জার', 'একদিনের সব চ্যালেঞ্জ শেষ', function (t) { return t.chal >= 1; }],
    ['sv', '★', 'সংগ্রাহক', '১০টি জিনিস সংরক্ষিত', function (t) { return t.saved >= 10; }]
  ];

  /* ---------------- আজকের চ্যালেঞ্জ ---------------- */
  function lessonsToday() {
    var d = C.doneMap() || {}, t = today(), n = 0;
    for (var k in d) if (C.todayKey(new Date(d[k])) === t) n++;
    return n;
  }
  function challenge() {
    var items = [
      ['ans', '২০টি প্রশ্নের উত্তর দাও', dayCount('ans'), 20, '#/quiz/daily'],
      ['cards', '১০টি Flashcard রিভিউ করো', dayCount('cards'), 10, '#/flash/review?mode=due'],
      ['lesson', '১টি পাঠ সম্পন্ন করো', lessonsToday(), 1, '#/home'],
      ['games', '১টি অনুশীলন গেম খেলো', dayCount('games'), 1, '#/games']
    ];
    var all = items.every(function (x) { return x[2] >= x[3]; });
    if (all) {
      var g = G();
      if ((g.chal || []).indexOf(today()) < 0) {
        g = JSON.parse(JSON.stringify(g)); g.chal = (g.chal || []).concat([today()]).slice(-400);
        Store.set('gami', g, 0);
        setTimeout(function () { toast('🏅 আজকের চ্যালেঞ্জ সম্পূর্ণ! +৩০ XP'); }, 300);
      }
    }
    return { items: items, all: all };
  }

  /* ---------------- প্রেরণার বাক্য (মৌলিক) ---------------- */
  var QUOTES = [
    'প্রতিদিন একটু একটু করে — ভর্তি পরীক্ষা জেতে ধারাবাহিকতা, এক রাতের পরিশ্রম নয়।',
    'আজ যে প্রশ্নটা ভুল হলো, সেটাই পরীক্ষার হলে তোমার একটা নম্বর বাঁচাবে।',
    'নেগেটিভ মার্কিং মানে সাহস নয়, হিসাব — নিশ্চিত না হলে ছেড়ে দেওয়াও দক্ষতা।',
    'দশ মিনিটের রিভিশন, দশ ঘণ্টার নতুন পড়ার চেয়েও বেশি মনে থাকে।',
    'তুলনা করো গতকালের নিজের সাথে, অন্যের সাথে নয়।',
    'কঠিন অধ্যায়টা আগে শেষ করো; বাকি দিনটা হালকা লাগবে।',
    'ঘুম কম মানে পড়া বেশি নয় — ক্লান্ত মাথা ভুলে যায় দ্রুত।',
    'প্রতিটি Mock একটি মহড়া; আসল দিনে শুধু অভ্যাসটাই কাজ করে।',
    'যা পারো না তা লিখে রাখো — খাতাটাই তোমার ব্যক্তিগত সিলেবাস।',
    'সময় ধরে লেখো; পরীক্ষার হলে ঘড়ি কারও জন্য থামে না।',
    'বানান, বাগধারা, তারিখ — ছোট জিনিসেই বড় পার্থক্য হয়।',
    'আজকের লক্ষ্য ছোট রাখো, কিন্তু পূরণ করো।',
    'বুঝে পড়লে মুখস্থ সহজ হয়; মুখস্থ করে বোঝা কঠিন।',
    'একটা বিষয়ের Final দাও — দুর্বল জায়গাগুলো নিজেরাই সামনে আসবে।',
    'বিরতি নেওয়া হার মানা নয়; পাঁচ মিনিট হেঁটে আবার বসো।',
    'প্রশ্নের শেষ শব্দটা পর্যন্ত পড়ো — "নয়" শব্দটাই অনেক সময় উত্তর বদলে দেয়।',
    'আগে নিশ্চিতগুলো, তারপর দ্বিধার প্রশ্ন — পরীক্ষার হলে এটাই কৌশল।',
    'আজ যা শিখলে, ঘুমানোর আগে একবার মনে মনে বলে দেখো।',
    'স্বপ্নের বিশ্ববিদ্যালয় দূরে নয় — প্রতিদিনের একটা করে পাঠ সেই পথ।',
    'ধীরে চলাও চলা; থেমে থাকাটাই শুধু পিছিয়ে পড়া।'
  ];
  function quote() { var d = new Date(); var i = (d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate()) % QUOTES.length; return QUOTES[i]; }

  /* ---------------- হোম কার্ড ---------------- */
  C.addHome(function () {
    var t = totals(), xp = xpOf(t), L = levelOf(xp), ch = challenge();
    var doneN = ch.items.filter(function (x) { return x[2] >= x[3]; }).length;
    return '<a class="card tight gami-home" href="#/achieve" style="text-decoration:none;color:inherit">' +
      '<div class="row"><span class="lvl-badge" aria-hidden="true">' + num(L.n) + '</span><div class="spacer"><b>লেভেল ' + num(L.n) + ' · ' + esc(L.name) + '</b>' +
      '<div class="pbar sm" style="margin:.3rem 0"><span style="width:' + L.pct + '%"></span></div><div class="small muted">' + num(xp) + ' XP · পরের লেভেল ' + num(L.hi) + ' XP-এ</div></div>' +
      '<div class="chal-mini" title="আজকের চ্যালেঞ্জ"><b>' + num(doneN) + '/' + num(ch.items.length) + '</b><span class="small muted">চ্যালেঞ্জ</span></div></div>' +
      '<p class="quote-line">“' + esc(quote()) + '”</p></a>';
  }, false, 'level', 'লেভেল, চ্যালেঞ্জ ও প্রেরণা');

  /* ---------------- অর্জন পাতা ---------------- */
  function viewAchieve() {
    C.setTop('অর্জন', { back: true });
    var t = totals(), xp = xpOf(t), L = levelOf(xp), ch = challenge();
    var html = '<section class="card"><div class="row"><span class="lvl-badge big" aria-hidden="true">' + num(L.n) + '</span><div class="spacer"><div class="small muted">লেভেল ' + num(L.n) + '</div><h2 style="margin:0">' + esc(L.name) + '</h2>' +
      '<div class="pbar" style="margin:.4rem 0"><span style="width:' + L.pct + '%"></span></div><div class="small muted">' + num(xp) + ' XP · পরের লেভেল ' + num(L.hi) + ' XP</div></div></div>' +
      '<details class="small" style="margin-top:.5rem"><summary>XP কীভাবে আসে</summary><p>পাঠ সম্পন্ন +১০ · সঠিক উত্তর +২ · ভুল/চেষ্টা +১ · Flashcard রিভিউ +১ · টেস্ট +১৫ · গেম +৫ (জয়ে আরও +৫) · লিখিত উত্তর +২০ · দিনের চ্যালেঞ্জ +৩০</p></details></section>';
    html += '<section class="card"><h2>🏅 আজকের চ্যালেঞ্জ</h2>' + ch.items.map(function (x) {
      var ok = x[2] >= x[3];
      return '<a class="chal-row' + (ok ? ' ok' : '') + '" href="' + x[4] + '"><span class="ck" aria-hidden="true">' + (ok ? '✓' : '') + '</span><span class="spacer">' + esc(x[1]) + '</span><b>' + num(Math.min(x[2], x[3])) + '/' + num(x[3]) + '</b></a>';
    }).join('') + (ch.all ? '<p class="banner ok" style="margin-top:.6rem">আজকের সব চ্যালেঞ্জ শেষ — +৩০ XP যোগ হয়েছে!</p>' : '') +
      '<p class="small muted" style="margin:.5rem 0 0">মোট ' + num(t.chal) + ' দিন চ্যালেঞ্জ সম্পূর্ণ · Streak ' + num(t.streak) + ' দিন</p></section>';
    html += '<section class="card"><h2>ব্যাজ (' + num(BADGES.filter(function (b) { return b[4](t); }).length) + '/' + num(BADGES.length) + ')</h2><div class="badge-grid">' + BADGES.map(function (b) {
      var on = b[4](t);
      return '<div class="badge' + (on ? ' on' : '') + '"><span class="bi" aria-hidden="true">' + b[1] + '</span><b>' + esc(b[2]) + '</b><span class="small muted">' + esc(b[3]) + '</span>' + (on ? '' : '<span class="sr-only">(এখনো পাওয়া হয়নি)</span>') + '</div>';
    }).join('') + '</div></section>';
    html += '<section class="card"><h2>🏆 লোকাল লিডারবোর্ড</h2><p class="small muted">এই ডিভাইসে আপনার নিজের সেরা ফল (অনলাইন তুলনা নেই — অ্যাপ সম্পূর্ণ অফলাইন)।</p>' + boardHTML() + '</section>';
    html += '<section class="card"><h2>পরিসংখ্যান</h2><div class="grid2">' +
      [['পাঠ সম্পন্ন', t.done], ['সঠিক উত্তর', t.cor], ['মোট উত্তর', t.att], ['Flashcard রিভিউ', t.cards], ['টেস্ট', t.tests], ['গেম (জয়)', t.games + ' (' + t.gwin + ')'], ['লিখিত উত্তর', t.written], ['আয়ত্ত ভুল', t.mastered]]
        .map(function (x) { return '<div class="stat"><span class="small muted">' + x[0] + '</span><b>' + num(x[1]) + '</b></div>'; }).join('') + '</div></section>';
    $v().innerHTML = html;
  }
  function boardHTML() {
    var b = Store.get('best', {}) || {}, rows = [];
    Object.keys(b).forEach(function (k) {
      var p = k.split(':'), label;
      if (p[0] === 'mega') { var u = C.UNITS[p[1]]; label = '🎓 Mega Mock ' + (u ? u.track.name.split(' (')[0] + ' ' + u.code : p[1]); }
      else if (p[0] === 'final') label = '🏁 Final — ' + (SMAP[p[1]] ? SMAP[p[1]].t : p[1]) + ' (LQS)';
      else if (p[0] === 'game') label = (GAMES[p[1]] ? GAMES[p[1]].icon + ' ' + GAMES[p[1]].t : p[1]);
      else return;
      rows.push([label, b[k]]);
    });
    var tests = (Store.get('tests', []) || []).filter(function (r) { return r.qids.length >= 10; })
      .map(function (r) { return [r, r.c * 100 / r.qids.length]; }).sort(function (a, z) { return z[1] - a[1]; }).slice(0, 5);
    if (!rows.length && !tests.length) return '<p class="muted">এখনো কোনো রেকর্ড নেই — একটি গেম, Mega Mock বা Final দিয়ে শুরু করুন।</p>';
    return (rows.length ? '<table class="data"><tr><th>বিভাগ</th><th class="n">সেরা</th><th class="n">তারিখ</th></tr>' + rows.map(function (r) {
      return '<tr><td>' + esc(r[0]) + '</td><td class="n">' + num(r[1].score) + (r[1].max ? '/' + num(r[1].max) : '') + '</td><td class="n small">' + new Date(r[1].at).toLocaleDateString('bn-BD') + '</td></tr>';
    }).join('') + '</table>' : '') +
      (tests.length ? '<h3>সেরা ৫ টেস্ট (সঠিকের হার, ১০+ প্রশ্ন)</h3><ol class="small">' + tests.map(function (x) {
        return '<li><a href="#/test/result/' + x[0].id + '">' + esc(x[0].cfg.title) + '</a> — ' + C.pct(x[1]) + ' <span class="muted">(' + new Date(x[0].at).toLocaleDateString('bn-BD') + ')</span></li>';
      }).join('') + '</ol>' : '');
  }

  /* ================= গেমের ডেটা (বিদ্যমান পাঠ থেকে) ================= */
  var POOL = null;
  function pools() {
    if (POOL) return POOL;
    POOL = { pairs: [], tl: [], sort: [], words: [] };
    Data.list('lessons/').forEach(function (n) {
      var d = Data.get(n) || {};
      Object.keys(d).forEach(function (lid) {
        if (!LMAP[lid]) return;
        (d[lid].b || []).forEach(function (b) {
          var k = b.k;
          if (k === 'match' && b.x && b.x.length >= 4) POOL.pairs.push({ h: title(b.h), lid: lid, p: b.x.map(function (x) { return [clean(x[0]), clean(x[1])]; }) });
          else if (k === 'entries' && b.x && b.x.length >= 4) {
            POOL.pairs.push({ h: title(b.h), lid: lid, p: b.x.filter(function (e) { return e.w && e.bn; }).map(function (e) { return [clean(e.w), clean(e.bn)]; }) });
            b.x.forEach(function (e) { if (/^[A-Za-z]{4,10}$/.test(e.w || '') && e.bn) POOL.words.push({ w: e.w.toLowerCase(), m: clean(e.bn), lid: lid }); });
          } else if (k === 'words' && b.x && b.x.length >= 4) {
            POOL.pairs.push({ h: title(b.h || 'শব্দার্থ'), lid: lid, p: b.x.map(function (x) { return [clean(x[0]), clean(x[1])]; }) });
            b.x.forEach(function (x) { if (/^[A-Za-z]{4,10}$/.test(String(x[0]))) POOL.words.push({ w: String(x[0]).toLowerCase(), m: clean(x[1]), lid: lid }); });
          } else if (k === 'timeline' && b.x) {
            var ev = [], seen = {};
            b.x.forEach(function (e) { var y = yearOf(e.y); if (y !== null && !seen[y]) { seen[y] = 1; ev.push({ y: clean(e.y), n: y, t: clean(e.t) }); } });
            if (ev.length >= 5) POOL.tl.push({ h: title(b.h), lid: lid, ev: ev });
            var gs = {}; b.x.forEach(function (e) { if (e.g) (gs[e.g] = gs[e.g] || []).push(clean(e.t)); });
            var gk = Object.keys(gs);
            if (gk.length >= 2 && gk.length <= 4 && b.x.length >= 6) POOL.sort.push({ h: title(b.h), q: 'ঘটনাটি কোন পর্বের?', lid: lid, cats: gk, items: [].concat.apply([], gk.map(function (g) { return gs[g].map(function (t) { return [t, g]; }); })) });
          } else if (k === 'table' && b.r && b.r.length >= 6 && b.c) {
            for (var ci = 1; ci < b.c.length; ci++) {
              var cnt = {}, okc = true;
              b.r.forEach(function (r) { var v = clean(r[ci]); if (!v || v.length > 30 || /^[\d০-৯.,\s%]+$/.test(v)) okc = false; cnt[v] = (cnt[v] || 0) + 1; });
              var cats = Object.keys(cnt);
              if (okc && cats.length >= 2 && cats.length <= 5 && b.r.length / cats.length >= 1.5 && clean(b.c[ci]).length > 1 && b.r.every(function (r) { return clean(r[0]).length && clean(r[0]).length <= 60; })) {
                POOL.sort.push({ h: title(b.h), q: '‘' + clean(b.c[0]) + '’ → ‘' + clean(b.c[ci]) + '’ কোনটি?', lid: lid, cats: cats, items: b.r.map(function (r) { return [clean(r[0]), clean(r[ci])]; }) });
                break;
              }
            }
          }
        });
      });
    });
    POOL.pairs = POOL.pairs.filter(function (g) { return g.p.length >= 4; });
    return POOL;
  }
  function yearOf(y) {
    var s = String(y || '').replace(/[০-৯]/g, function (d) { return '০১২৩৪৫৬৭৮৯'.indexOf(d); });
    var m = s.match(/(\d{3,4})/); if (!m) return null;
    var n = +m[1];
    if (/খ্রিস্টপূর্ব|খ্রি\.?\s*পূ|BC|BCE/i.test(s)) n = -n;
    return n;
  }
  function gmist(text, lid) {
    var l = (Store.get('gmist', []) || []).slice();
    l.unshift({ t: text, lid: lid || '', at: Date.now() });
    Store.set('gmist', l.slice(0, 100), 500);
  }

  /* ================= গেম কাঠামো ================= */
  var GAMES = {
    match: { icon: '🔗', t: 'মিলাও (Match Pairs)', d: 'বাম পাশের সাথে ডান পাশের সঠিক জোড়া মেলাও', ok: function () { return pools().pairs.length; } },
    memory: { icon: '🧠', t: 'জোড়া খোঁজো (Memory Flip)', d: 'কার্ড উল্টে জোড়া মেলাও — কম চালে বেশি স্কোর', ok: function () { return memGroups().length; } },
    timeline: { icon: '📅', t: 'সাল অনুযায়ী সাজাও', d: 'ঘটনাগুলো আগের থেকে পরের ক্রমে সাজাও', ok: function () { return pools().tl.length; } },
    sort: { icon: '🗂', t: 'শ্রেণিতে ভাগ করো', d: 'প্রতিটি জিনিস সঠিক ভাগে রাখো', ok: function () { return pools().sort.length; } },
    speed: { icon: '⚡', t: 'Speed Quiz', d: '৬০ সেকেন্ডে যত বেশি সঠিক — পরপর সঠিকে Combo বোনাস', ok: function () { return QB.all().length; } },
    word: { icon: '🔤', t: 'Word Builder', d: 'অর্থ দেখে ইংরেজি শব্দের বানান গড়ো', ok: function () { return pools().words.length; } }
  };
  function memGroups() { return pools().pairs.filter(function (g) { return g.p.filter(function (x) { return x[0].length <= 26 && x[1].length <= 26; }).length >= 6; }); }

  function viewGames() {
    C.setTop('অনুশীলন গেম', { back: true });
    var b = Store.get('best', {}) || {};
    $v().innerHTML = '<p class="small muted">সব গেম অ্যাপের বিদ্যমান পাঠ, প্রশ্ন ও শব্দার্থ থেকে তৈরি হয় — কনটেন্ট বাড়লে গেমও বাড়ে। ভুলগুলো ভুলের খাতায় জমা হয়।</p><div class="game-grid">' +
      Object.keys(GAMES).map(function (k) {
        var g = GAMES[k], n = g.ok(), best = b['game:' + k];
        return '<a class="game-tile' + (n ? '' : ' off') + '" href="' + (n ? '#/games/' + k : '#/games') + '"><span class="gi" aria-hidden="true">' + g.icon + '</span><b>' + esc(g.t) + '</b><span class="small">' + esc(g.d) + '</span>' +
          (best ? '<span class="small muted">সেরা: ' + num(best.score) + '</span>' : '') + '</a>';
      }).join('') + '</div>';
  }
  function finish(type, score, win, detail) {
    var g = bump('games'); if (win) bump('gwin');
    var prev = (Store.get('best', {}) || {})['game:' + type];
    if (window.Mega) Mega.bumpBest('game:' + type, score, 0);
    var rec = !prev || score > prev.score;
    $v().innerHTML = '<section class="card game-end"><div class="gi" aria-hidden="true">' + (win ? '🎉' : '💪') + '</div><h2>' + (win ? 'জয়!' : 'আরেকবার চেষ্টা করো') + '</h2>' +
      '<p class="score-big">' + num(score) + '</p><p class="small muted">' + (rec ? '🏆 নতুন ব্যক্তিগত সেরা!' : 'সেরা: ' + num(prev.score)) + ' · +' + num(win ? 10 : 5) + ' XP</p>' + (detail || '') +
      '<div class="grid2" style="margin-top:.8rem"><a class="btn" href="#/games">সব গেম</a><button class="btn primary" id="gagain">আবার খেলো</button></div></section>';
    qs('#gagain').onclick = function () { C.route(); };
  }
  function head(type, extra) {
    return '<div class="game-head"><span>' + GAMES[type].icon + ' <b>' + esc(GAMES[type].t) + '</b></span><span class="spacer"></span>' + (extra || '') + '</div>';
  }
  function src(lid, h) { return lid && LMAP[lid] ? '<p class="small muted">উৎস: <a href="#/l/' + lid + '">' + esc(LMAP[lid].t) + '</a>' + (h ? ' — ' + esc(h) : '') + '</p>' : ''; }

  /* ---- ১. মিলাও ---- */
  function gMatch() {
    var gr = shuffle(pools().pairs)[0], pairs = shuffle(gr.p).slice(0, 5);
    var left = shuffle(pairs.map(function (p, i) { return i; })), right = shuffle(pairs.map(function (p, i) { return i; }));
    var sel = null, done = {}, miss = 0;
    function draw() {
      $v().innerHTML = head('match', '<span class="chip">ভুল ' + num(miss) + '</span>') + '<p class="small"><b>' + esc(gr.h) + '</b></p>' +
        '<div class="match-cols"><div>' + left.map(function (i) { return '<button class="mbtn' + (done[i] ? ' done' : '') + (sel === i ? ' sel' : '') + '" data-l="' + i + '"' + (done[i] ? ' disabled' : '') + '>' + esc(pairs[i][0]) + '</button>'; }).join('') + '</div>' +
        '<div>' + right.map(function (i) { return '<button class="mbtn' + (done[i] ? ' done' : '') + '" data-r="' + i + '"' + (done[i] ? ' disabled' : '') + '>' + esc(pairs[i][1]) + '</button>'; }).join('') + '</div></div>' +
        '<p class="small muted">বাম পাশ থেকে একটি, তারপর ডান পাশ থেকে তার জোড়া বাছো।</p>' + src(gr.lid);
      qsa('[data-l]').forEach(function (b) { b.onclick = function () { sel = +b.getAttribute('data-l'); draw(); }; });
      qsa('[data-r]').forEach(function (b) {
        b.onclick = function () {
          if (sel === null) { toast('আগে বাম পাশ থেকে একটি বাছো'); return; }
          var r = +b.getAttribute('data-r');
          if (r === sel) { done[r] = 1; sel = null; if (Object.keys(done).length === pairs.length) return end(); draw(); }
          else { miss++; gmist(pairs[sel][0] + ' → ' + pairs[sel][1], gr.lid); b.classList.add('bad'); setTimeout(function () { sel = null; draw(); }, 450); }
        };
      });
    }
    function end() {
      var score = Math.max(0, pairs.length * 20 - miss * 5);
      finish('match', score, miss <= 1, '<p class="small">' + num(pairs.length) + 'টি জোড়া · ভুল ' + num(miss) + '</p>' + src(gr.lid, gr.h));
    }
    draw();
  }

  /* ---- ২. জোড়া খোঁজো ---- */
  function gMemory() {
    var gr = shuffle(memGroups())[0];
    var pairs = shuffle(gr.p.filter(function (x) { return x[0].length <= 26 && x[1].length <= 26; })).slice(0, 6);
    var cards = shuffle([].concat.apply([], pairs.map(function (p, i) { return [{ i: i, t: p[0], s: 'a' }, { i: i, t: p[1], s: 'b' }]; })));
    var open = [], got = {}, moves = 0, lock = false;
    function draw() {
      $v().innerHTML = head('memory', '<span class="chip">চাল ' + num(moves) + '</span>') + '<p class="small"><b>' + esc(gr.h) + '</b></p>' +
        '<div class="mem-grid">' + cards.map(function (c, k) {
          var up = got[c.i] || open.indexOf(k) >= 0;
          return '<button class="mem' + (up ? ' up' : '') + (got[c.i] ? ' got' : '') + '" data-k="' + k + '"' + (got[c.i] ? ' disabled' : '') + ' aria-label="' + (up ? esc(c.t) : 'বন্ধ কার্ড') + '">' + (up ? esc(c.t) : '?') + '</button>';
        }).join('') + '</div>' + src(gr.lid);
      qsa('[data-k]').forEach(function (b) {
        b.onclick = function () {
          var k = +b.getAttribute('data-k');
          if (lock || open.indexOf(k) >= 0 || got[cards[k].i]) return;
          open.push(k);
          if (open.length === 2) {
            moves++;
            var a = cards[open[0]], z = cards[open[1]];
            if (a.i === z.i && a.s !== z.s) { got[a.i] = 1; open = []; if (Object.keys(got).length === pairs.length) return end(); draw(); }
            else { lock = true; draw(); setTimeout(function () { open = []; lock = false; draw(); }, 900); }
          } else draw();
        };
      });
    }
    function end() { var score = Math.max(10, 120 - Math.max(0, moves - 6) * 6); finish('memory', score, moves <= 12, '<p class="small">' + num(moves) + ' চালে ' + num(pairs.length) + 'টি জোড়া</p>' + src(gr.lid, gr.h)); }
    draw();
  }

  /* ---- ৩. সাল অনুযায়ী সাজাও ---- */
  function gTimeline() {
    var tl = shuffle(pools().tl)[0];
    var ev = shuffle(tl.ev).slice(0, 5);
    var right = ev.slice().sort(function (a, b) { return a.n - b.n; });
    var cur = shuffle(ev);
    for (var guard = 0; guard < 5 && cur.every(function (e, i) { return e === right[i]; }); guard++) cur = shuffle(ev);
    var checked = false;
    function draw() {
      $v().innerHTML = head('timeline') + '<p class="small"><b>' + esc(tl.h) + '</b> — ওপরে সবচেয়ে আগের ঘটনা রাখো।</p><ol class="tl-order">' + cur.map(function (e, i) {
        var cls = checked ? (e === right[i] ? ' ok' : ' bad') : '';
        return '<li class="tlo' + cls + '"><span class="spacer">' + esc(e.t) + (checked ? ' <b class="small">(' + esc(e.y) + ')</b>' : '') + '</span>' +
          (checked ? '' : '<button class="icon-btn" data-up="' + i + '" aria-label="ওপরে"' + (i ? '' : ' disabled') + '>▲</button><button class="icon-btn" data-dn="' + i + '" aria-label="নিচে"' + (i < cur.length - 1 ? '' : ' disabled') + '>▼</button>') + '</li>';
      }).join('') + '</ol>' + (checked ? '' : '<button class="btn primary block" id="tlchk">মিলিয়ে দেখো</button>') + src(tl.lid);
      qsa('[data-up]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-up'); var t = cur[i - 1]; cur[i - 1] = cur[i]; cur[i] = t; draw(); }; });
      qsa('[data-dn]').forEach(function (b) { b.onclick = function () { var i = +b.getAttribute('data-dn'); var t = cur[i + 1]; cur[i + 1] = cur[i]; cur[i] = t; draw(); }; });
      var ck = qs('#tlchk'); if (ck) ck.onclick = function () {
        checked = true; draw();
        var ok = cur.filter(function (e, i) { return e === right[i]; }).length;
        cur.forEach(function (e, i) { if (e !== right[i]) gmist(e.t + ' — ' + e.y, tl.lid); });
        setTimeout(function () {
          finish('timeline', ok * 20, ok === cur.length, '<p class="small">' + num(ok) + '/' + num(cur.length) + ' সঠিক অবস্থানে</p><ol class="small">' + right.map(function (e) { return '<li><b>' + esc(e.y) + '</b> — ' + esc(e.t) + '</li>'; }).join('') + '</ol>' + src(tl.lid, tl.h));
        }, 1400);
      };
    }
    draw();
  }

  /* ---- ৪. শ্রেণিতে ভাগ করো ---- */
  function gSort() {
    var sp = shuffle(pools().sort)[0];
    var items = shuffle(sp.items).slice(0, 8), i = 0, ok = 0, fb = '';
    function draw() {
      if (i >= items.length) return finish('sort', ok * 10, ok >= Math.ceil(items.length * 0.75), '<p class="small">' + num(ok) + '/' + num(items.length) + ' সঠিক</p>' + src(sp.lid, sp.h));
      var it = items[i];
      $v().innerHTML = head('sort', '<span class="chip">' + num(i + 1) + '/' + num(items.length) + '</span><span class="chip ok">' + num(ok) + ' ✓</span>') +
        '<p class="small"><b>' + esc(sp.h) + '</b><br>' + esc(sp.q) + '</p><div class="sort-item">' + esc(it[0]) + '</div>' +
        '<div class="sort-cats">' + sp.cats.map(function (c) { return '<button class="btn" data-c="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' + fb + src(sp.lid);
      qsa('[data-c]').forEach(function (b) {
        b.onclick = function () {
          var c = b.getAttribute('data-c');
          if (c === it[1]) { ok++; fb = '<p class="verdict ok">✓ সঠিক</p>'; }
          else { fb = '<p class="verdict bad">✗ সঠিক: ' + esc(it[1]) + '</p>'; gmist(it[0] + ' → ' + it[1], sp.lid); }
          i++; draw();
        };
      });
    }
    draw();
  }

  /* ---- ৫. Speed Quiz ---- */
  function gSpeed() {
    var subs = C.unitSubjects().map(function (s) { return s.id; });
    var pool = QB.all().filter(function (q) { return !QB.isExpired(q) && (q.d || 2) <= 2 && q.o.length <= 4 && q.q.length <= 160 && subs.indexOf(q.sub) >= 0; });
    if (pool.length < 30) pool = QB.all().filter(function (q) { return !QB.isExpired(q) && (q.d || 2) <= 2 && q.o.length <= 4; });
    pool = shuffle(pool);
    var LET = ['ক', 'খ', 'গ', 'ঘ'];
    var left = 60, score = 0, combo = 0, best = 0, k = 0, log = [], t0 = Date.now(), ended = false, flash = '';
    var iv = setInterval(function () {
      left--; var el = qs('#sqt'); if (el) { el.textContent = num(left); el.classList.toggle('low', left <= 10); }
      if (left <= 0) end();
    }, 1000);
    C.setCleanup(function () { clearInterval(iv); });
    function draw() {
      var q = pool[k % pool.length], ord = shuffle(q.o.map(function (_, i) { return i; }));
      $v().innerHTML = head('speed', '<span class="chip timer" id="sqt">' + num(left) + '</span>') +
        '<div class="row" style="margin-bottom:.5rem"><b class="spacer">স্কোর ' + num(score) + '</b>' + (combo >= 3 ? '<span class="chip ok">Combo ×' + num(Math.min(3, 1 + Math.floor(combo / 3))) + '</span>' : '') + '</div>' + flash +
        '<div class="card qcard"><div class="qtext">' + esc(q.q) + '</div><div class="opts">' + ord.map(function (oi, j) {
          return '<button class="opt" data-oi="' + oi + '"><span class="ol">' + LET[j] + '</span><span>' + esc(q.o[oi]) + '</span></button>';
        }).join('') + '</div></div>';
      qsa('[data-oi]').forEach(function (b) {
        b.onclick = function () {
          if (ended) return;
          var oi = +b.getAttribute('data-oi'), ok = oi === q.a;
          QB.record(q.id, oi, (Date.now() - t0) / 1000); t0 = Date.now();
          if (ok) { combo++; best = Math.max(best, combo); score += 10 * Math.min(3, 1 + Math.floor(combo / 3)); flash = '<p class="verdict ok sq-flash">✓ +' + num(10 * Math.min(3, 1 + Math.floor(combo / 3))) + '</p>'; }
          else { combo = 0; flash = '<p class="verdict bad sq-flash">✗ ' + esc(q.o[q.a]) + '</p>'; }
          log.push({ q: q, ok: ok, oi: oi }); k++; draw();
        };
      });
    }
    function end() {
      if (ended) return; ended = true; clearInterval(iv);
      var c = log.filter(function (x) { return x.ok; }).length, wrong = log.filter(function (x) { return !x.ok; });
      finish('speed', score, score >= 100, '<p class="small">' + num(c) + '/' + num(log.length) + ' সঠিক · সর্বোচ্চ Combo ' + num(best) + '</p>' +
        (wrong.length ? '<details class="small"><summary>ভুলগুলো (' + num(wrong.length) + ') — ভুলের খাতায় জমা হয়েছে</summary><ul>' + wrong.map(function (x) { return '<li>' + esc(x.q.q) + ' — <b>' + esc(x.q.o[x.q.a]) + '</b></li>'; }).join('') + '</ul></details>' : ''));
    }
    draw();
  }

  /* ---- ৬. Word Builder ---- */
  function gWord() {
    var words = shuffle(pools().words).slice(0, 5), r = 0, ok = 0, pts = 0;
    function round() {
      if (r >= words.length) return finish('word', pts, ok >= 3, '<p class="small">' + num(ok) + '/' + num(words.length) + ' শব্দ সঠিক</p><ul class="small">' + words.map(function (w) { return '<li><b>' + esc(w.w) + '</b> — ' + esc(w.m) + '</li>'; }).join('') + '</ul>');
      var w = words[r], letters = w.w.split('').map(function (ch, i) { return { ch: ch, i: i }; });
      var tiles = shuffle(letters); for (var g = 0; g < 5 && tiles.map(function (x) { return x.ch; }).join('') === w.w; g++) tiles = shuffle(letters);
      var picked = [], hint = false;
      function draw(msg) {
        $v().innerHTML = head('word', '<span class="chip">' + num(r + 1) + '/' + num(words.length) + '</span><span class="chip ok">' + num(pts) + '</span>') +
          '<p class="small muted">অর্থ:</p><div class="sort-item">' + esc(w.m) + '</div>' +
          '<div class="wb-slots" aria-live="polite">' + w.w.split('').map(function (_, i) { return '<span class="wb-slot">' + (picked[i] ? esc(picked[i].ch) : (hint && i === 0 ? '<i>' + esc(w.w[0]) + '</i>' : '')) + '</span>'; }).join('') + '</div>' +
          '<div class="wb-tiles">' + tiles.map(function (t, j) { var used = picked.indexOf(t) >= 0; return '<button class="wb-tile" data-j="' + j + '"' + (used ? ' disabled' : '') + '>' + esc(t.ch) + '</button>'; }).join('') + '</div>' +
          (msg || '') + '<div class="row wrap"><button class="btn" id="wbdel">⌫ মুছুন</button><button class="btn" id="wbhint"' + (hint ? ' disabled' : '') + '>💡 প্রথম অক্ষর (−৫)</button><button class="btn" id="wbskip">বাদ দাও</button></div>' + src(w.lid);
        qsa('[data-j]').forEach(function (b) {
          b.onclick = function () {
            picked.push(tiles[+b.getAttribute('data-j')]);
            if (picked.length === w.w.length) {
              var got = picked.map(function (x) { return x.ch; }).join('');
              if (got === w.w) { ok++; pts += hint ? 15 : 20; r++; draw('<p class="verdict ok">✓ ' + esc(w.w) + '</p>'); setTimeout(round, 700); return; }
              picked = []; draw('<p class="verdict bad">✗ হয়নি, আবার চেষ্টা করো</p>'); return;
            }
            draw();
          };
        });
        qs('#wbdel').onclick = function () { picked.pop(); draw(); };
        qs('#wbhint').onclick = function () { hint = true; draw(); };
        qs('#wbskip').onclick = function () { gmist(w.w + ' — ' + w.m, w.lid); r++; draw('<p class="verdict bad">সঠিক বানান: <b>' + esc(w.w) + '</b></p>'); setTimeout(round, 1100); };
      }
      draw();
    }
    round();
  }
  var RUNNERS = { match: gMatch, memory: gMemory, timeline: gTimeline, sort: gSort, speed: gSpeed, word: gWord };

  /* ---------------- ভুলের খাতায় গেমের ভুল ---------------- */
  function mistakesHTML() {
    var l = Store.get('gmist', []) || [];
    if (!l.length) return '';
    return '<section class="card" id="gmist"><div class="row"><h2 class="spacer" style="margin:0">🎮 গেমের ভুল (' + num(l.length) + ')</h2><button class="btn sm" id="gmclear">মুছুন</button></div>' +
      '<p class="small muted">মিলাও/সাজাও/শব্দ গেমে যেগুলো ভুল হয়েছিল — সঠিক জোড়াসহ। পাঠে গিয়ে আরেকবার দেখে নিন।</p><ul class="gm-list">' + l.slice(0, 50).map(function (x) {
        return '<li>' + esc(x.t) + (x.lid && LMAP[x.lid] ? ' <a class="small" href="#/l/' + x.lid + '">📖 পাঠ</a>' : '') + '</li>';
      }).join('') + '</ul></section>';
  }
  function bindMistakes(root) {
    var b = qs('#gmclear', root); if (b) b.onclick = function () { Store.del('gmist'); var s = qs('#gmist', root); if (s) s.remove(); toast('গেমের ভুল মুছে ফেলা হয়েছে'); };
  }

  C.addRoute(/^#\/achieve/, viewAchieve, 'practice');
  C.addRoute(/^#\/games\/(\w+)/, function (m) {
    var g = GAMES[m[1]];
    if (!g || !g.ok()) { location.replace('#/games'); return; }
    C.setTop(g.t, { back: true });
    RUNNERS[m[1]]();
  }, 'practice');
  C.addRoute(/^#\/games/, viewGames, 'practice');

  window.Gami = { totals: totals, xp: function () { return xpOf(totals()); }, level: levelOf, pools: pools, mistakesHTML: mistakesHTML, bindMistakes: bindMistakes, GAMES: GAMES, challenge: challenge };
})();
