/* =========================================================
   practice.js — Phase 2
   অনুশীলন হাব · Adaptive Quiz (PART H) · Test Builder ও Timed Test (PART G)
   Flashcard SRS (F2) · ভুলের খাতা ও Retry (F3) · PYQ Hub ও Import (PART E)
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast, modal = C.modal, closeModal = C.closeModal;
  var SMAP = C.SMAP, CMAP = C.CMAP, LMAP = C.LMAP, UNITS = C.UNITS;
  var LET = ['ক', 'খ', 'গ', 'ঘ', 'ঙ', 'চ'];
  var DLABEL = { 1: 'সহজ', 2: 'মাঝারি', 3: 'কঠিন' };
  function $v() { return C.view(); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function params(h) {
    var o = {}, q = (h.split('?')[1] || '');
    q.split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); o[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); });
    return o;
  }
  function pct(a, b) { return b ? a * 100 / b : 0; }
  function fmtSec(s) {
    s = Math.max(0, Math.round(s));
    var m = Math.floor(s / 60), r = s % 60;
    return num((m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r);
  }
  function subjName(id) { return SMAP[id] ? SMAP[id].icon + ' ' + SMAP[id].t : id; }
  function back(h) { return { back: true, actions: '' }; }

  /* ================= প্রশ্ন কার্ড ও ব্যাখ্যা (সব জায়গায় একই) ================= */
  function tagsHTML(q) {
    var t = '<span class="chip">' + DLABEL[q.d || 2] + '</span>';
    var lab = QB.srcLabel(q);
    t += '<span class="chip' + (lab === 'PYQ' ? ' ok' : '') + '">' + esc(lab) + '</span>';
    if (q.exam) t += '<span class="chip">' + esc([q.exam, q.unit, q.session || q.year].filter(Boolean).join(' · ')) + '</span>';
    if (q.ca) t += '<span class="chip verify">সাম্প্রতিক · ' + esc(q.ca) + '</span>';
    if (q.v === false && q.exam) t += '<span class="chip verify">Verify</span>';
    return t;
  }
  /* st: {order:[মূল সূচক], chosen, reveal, n, total, locked} */
  function qCardHTML(q, st) {
    st = st || {};
    var order = st.order || q.o.map(function (_, i) { return i; });
    var ws = (q.e && q.e.w) || [];
    var html = '<div class="card qcard"><div class="qmeta">' + (st.n ? '<span class="chip">প্রশ্ন ' + num(st.n) + (st.total ? '/' + num(st.total) : '') + '</span>' : '') + tagsHTML(q) + '<span class="spacer"></span>' + C.saveBtnHTML('q', q.id, 'sm') + '</div>' +
      '<div class="qtext">' + esc(q.q) + '</div><div class="opts" role="radiogroup">';
    order.forEach(function (oi, k) {
      var cls = 'opt';
      if (st.reveal) { if (oi === q.a) cls += ' right'; else if (oi === st.chosen) cls += ' wrong'; }
      else if (oi === st.chosen) cls += ' sel';
      html += '<button class="' + cls + '" data-oi="' + oi + '" role="radio" aria-checked="' + (oi === st.chosen) + '"' + (st.reveal || st.locked ? ' disabled' : '') + '>' +
        '<span class="ol">' + LET[k] + '</span><span>' + esc(q.o[oi]) +
        (st.reveal && ws[oi] ? '<span class="why">' + esc(ws[oi]) + '</span>' : '') + '</span></button>';
    });
    html += '</div>';
    if (st.reveal) {
      var ok = st.chosen === q.a;
      if (st.view) html += '<div class="verdict ok">সঠিক উত্তর: ' + LET[order.indexOf(q.a)] + ') ' + esc(q.o[q.a]) + '</div>' + explainHTML(q);
      else html += '<div class="verdict ' + (ok ? 'ok' : 'bad') + '">' + (ok ? '✓ সঠিক' : (st.chosen === undefined || st.chosen < 0 ? '— উত্তর দেওয়া হয়নি' : '✗ ভুল')) +
        ' · সঠিক উত্তর: ' + LET[order.indexOf(q.a)] + ') ' + esc(q.o[q.a]) + '</div>' + explainHTML(q);
    }
    return html + '</div>';
  }
  function explainHTML(q) {
    var e = q.e || {};
    var out = '<dl class="explain">';
    if (e.r) out += '<dt>📌 মূল নিয়ম/ধারণা</dt><dd>' + esc(e.r) + '</dd>';
    if (e.f) out += '<dt>🔗 সম্পর্কিত তথ্য</dt><dd>' + esc(e.f) + '</dd>';
    if (e.t) out += '<dt>💡 একই ধরনের প্রশ্নের কৌশল</dt><dd>' + esc(e.t) + '</dd>';
    if (q.sn) out += '<dt>📚 সূত্র</dt><dd>' + esc(q.sn) + '</dd>';
    var links = [];
    if (q.lid && LMAP[q.lid]) {
      links.push('<a href="#/l/' + q.lid + '">📖 পাঠ: ' + esc(LMAP[q.lid].t) + '</a>');
      if (QB.cards().some(function (c) { return c.lid === q.lid; })) links.push('<a href="#/flash/review?lid=' + q.lid + '">🃏 Flashcard</a>');
    }
    if (links.length) out += '<dt>সংশ্লিষ্ট</dt><dd>' + links.join(' · ') + '</dd>';
    return out + '</dl>';
  }

  /* ================= অনুশীলন হাব ================= */
  function viewHub() {
    C.setTop(C.T('practice'));
    var all = QB.all();
    var cards = QB.cards();
    var due = cards.filter(function (c) { return QB.isDue(c); }).length;
    var mist = QB.mistakes().length;
    var act = Store.get('test:active', null);
    var hist = Store.get('tests', []) || [];
    var pyqN = all.filter(function (q) { return q.exam; }).length;
    var ms = QB.mastery(all);
    var bySub = {};
    all.forEach(function (q) { bySub[q.sub] = (bySub[q.sub] || 0) + 1; });

    var html = C.storageBanner();
    if (act) html += activeBanner(act);
    html += '<div class="hub">' +
      hubLink('#/quiz/daily', '⚡', 'আজকের ১০টি প্রশ্ন', 'দুর্বল ও নতুন প্রশ্ন মিলিয়ে') +
      hubLink('#/test/build', '⏱', 'টেস্ট বানান', 'বিষয়, সময়, কঠিনতা নিজে ঠিক করুন') +
      hubLink('#/test/build?preset=speed', '🚀', 'Speed Drill', '১০ প্রশ্ন × ৩০ সেকেন্ড') +
      hubLink('#/flash', '🃏', 'Flashcard', num(due) + 'টি আজ রিভিউ বাকি') +
      hubLink('#/mistakes', '📕', 'ভুলের খাতা', num(mist) + 'টি প্রশ্ন') +
      hubLink('#/ca', '📰', 'সাম্প্রতিক হাব', 'মাসভিত্তিক প্যাক, Quiz ও Flashcard') +
      hubLink('#/written', '✍️', 'DU লিখিত ল্যাব', 'টাইমারসহ লেখা, মডেল উত্তর') +
      hubLink('#/pyq', '🗂', 'PYQ Hub', pyqN ? num(pyqN) + 'টি প্রশ্ন' : 'Import করুন') +
      hubLink('#/test/history', '📊', 'টেস্ট ইতিহাস', num(hist.length) + 'টি টেস্ট') +
      hubLink('#/mega', '🎓', 'Mega Mock', 'প্রতিটি ইউনিটের অফিসিয়াল কাঠামোয় পূর্ণ পরীক্ষা') +
      hubLink('#/final', '🏁', 'Subject Final Exam', 'বিষয়ভিত্তিক ১০০ প্রশ্ন + রিভিশন প্ল্যান') +
      hubLink('#/games', '🎮', 'অনুশীলন গেম', 'মিলাও, সাজাও, Speed Quiz…') +
      hubLink('#/achieve', '🏆', 'অর্জন', 'XP, লেভেল, ব্যাজ, আজকের চ্যালেঞ্জ') +
      '</div>';
    html += '<section class="card"><h2>প্রশ্নব্যাংক</h2>' +
      '<p class="small">মোট ' + num(all.length) + 'টি প্রশ্ন' + (ms && ms.tried ? ' · চেষ্টা করেছেন ' + num(ms.tried) + 'টি · ' + C.T('mastery') + ' ' + C.pct(ms.mastery) + ' · ' + C.T('qscore') + ' ' + C.pct(ms.score) : '') + '</p>' +
      '<table class="data"><tr><th>বিষয়</th><th class="n">প্রশ্ন</th><th class="n">' + C.T('mastery') + '</th><th></th></tr>' +
      C.SUBJ.map(function (s) {
        var n = bySub[s.id] || 0;
        var m = n ? QB.mastery(QB.forSubject(s.id)) : null;
        return '<tr><td>' + s.icon + ' ' + esc(s.t) + '</td><td class="n">' + num(n) + '</td><td class="n">' + (n ? C.pct(m && m.tried ? m.mastery : 0) : '—') + '</td>' +
          '<td class="n">' + (n ? '<a href="#/quiz/s/' + s.id + '">Quiz</a>' : '<span class="small muted">Phase ' + num(C.PHASE_OF[s.id]) + '</span>') + '</td></tr>';
      }).join('') + '</table>' +
      '<p class="small muted" style="margin-top:.6rem">প্রতিটি প্রশ্নে সঠিক উত্তরের সাথে প্রতিটি ভুল অপশনের কারণও দেওয়া আছে। নিজের প্রশ্ন বা আসল PYQ যোগ করতে <a href="#/pyq/import">Import</a> ব্যবহার করুন।</p></section>';
    $v().innerHTML = html;
  }
  function hubLink(href, icon, t, sub) {
    return '<a href="' + href + '"><span class="hi" aria-hidden="true">' + icon + '</span><b>' + t + '</b><span class="small">' + sub + '</span></a>';
  }
  function activeBanner(act) {
    var answered = Object.keys(act.ans || {}).length;
    return '<a class="banner warn row" href="#/test/run" style="text-decoration:none"><span class="spacer">⏸ চলমান টেস্ট: <b>' + esc(act.cfg.title) + '</b> — ' +
      num(answered) + '/' + num(act.qids.length) + ' উত্তর, বাকি সময় ' + fmtSec(act.left) + '</span><span class="btn primary">চালিয়ে যান</span></a>';
  }

  /* ================= একক প্রশ্ন (সার্চ থেকে) ================= */
  function viewSingle(id) {
    var q = QB.get(id);
    if (!q) { location.replace('#/practice'); return; }
    C.setTop('প্রশ্ন', back());
    var st = { chosen: undefined, reveal: false };
    var t0 = Date.now();
    function draw() {
      $v().innerHTML = qCardHTML(q, st);
      qsa('.opt', $v()).forEach(function (b) {
        b.addEventListener('click', function () {
          st.chosen = +b.getAttribute('data-oi'); st.reveal = true;
          QB.record(q.id, st.chosen, (Date.now() - t0) / 1000);
          draw();
        });
      });
    }
    draw();
  }

  /* ================= Quiz (Adaptive ও তালিকাভিত্তিক) ================= */
  /* src: {title, pool:[q], adaptive, len, backHref, lid} */
  function runQuiz(src) {
    var pool = src.pool.slice();
    var len = Math.min(src.len || 10, pool.length);
    if (!len) {
      C.setTop(src.title, back());
      $v().innerHTML = '<div class="card"><p>এখানে এখনো কোনো প্রশ্ন নেই।</p><a class="btn" href="' + (src.backHref || '#/practice') + '">ফিরে যান</a></div>';
      return;
    }
    var used = {}, level = src.adaptive ? 1 : 0, log = [];
    var order = src.adaptive ? null : QB.shuffle(pool).slice(0, len);
    var items = [], pos = -1;   // দেখা প্রশ্নগুলো — আগের/পরের দিয়ে ঘোরা যায়

    function pick() {
      if (!src.adaptive) return order[items.length];
      var tries = [level, level + 1, level - 1, level + 2, level - 2];
      for (var i = 0; i < tries.length; i++) {
        var cand = pool.filter(function (q) { return !used[q.id] && (q.d || 2) === tries[i]; });
        if (cand.length) return cand[Math.floor(Math.random() * cand.length)];
      }
      var rest = pool.filter(function (q) { return !used[q.id]; });
      return rest[0];
    }
    function next() {
      if (pos < items.length - 1) { pos++; items[pos].t0 = Date.now(); return draw(); }
      if (items.length >= len) return finish();
      var q = pick(); used[q.id] = 1;
      items.push({ q: q, st: { chosen: undefined, reveal: false, n: items.length + 1, total: len, order: QB.shuffle(q.o.map(function (_, i) { return i; })) }, t0: Date.now() });
      pos = items.length - 1;
      draw();
    }
    function prev() { if (pos > 0) { pos--; items[pos].t0 = Date.now(); draw(); } }
    function draw() {
      C.setTop(src.title, back());
      var it = items[pos], st = it.st;
      var lvl = src.adaptive ? '<span class="chip">স্তর: ' + DLABEL[level] + '</span>' : '';
      var bar = '<div class="row" style="margin-bottom:.6rem">' + lvl + '<div class="pbar sm spacer"><span style="width:' + pct(log.length, len) + '%"></span></div>' +
        '<span class="small muted">' + num(log.filter(function (x) { return x.ok; }).length) + ' সঠিক · ' + num(log.length) + '/' + num(len) + ' উত্তর</span></div>';
      var last = pos === items.length - 1 && items.length >= len;
      var allDone = log.length >= len;
      $v().innerHTML = bar + qCardHTML(it.q, st) +
        (st.reveal ? '' : '<button class="btn block" id="qskip">জানি না / উত্তর দেখুন</button>') +
        '<div class="lesson-nav q-nav"><button class="btn" id="qprev"' + (pos > 0 ? '' : ' disabled') + '>' + C.T('qprev') + '</button>' +
        '<button class="btn primary" id="qnext">' + (last ? (allDone ? C.T('qresult') : C.T('qfinish')) : C.T('qnext')) + '</button></div>';
      qsa('.opt', $v()).forEach(function (b) { b.addEventListener('click', function () { answer(+b.getAttribute('data-oi')); }); });
      qs('#qnext').addEventListener('click', next);
      qs('#qprev').addEventListener('click', prev);
      var sk = qs('#qskip'); if (sk) sk.addEventListener('click', function () { answer(-1); });
      if (st.reveal) qs('#qnext').focus({ preventScroll: true });
    }
    function answer(oi) {
      var it = items[pos], st = it.st;
      if (st.reveal) return;
      st.chosen = oi; st.reveal = true;
      var sec = (Date.now() - it.t0) / 1000;
      var ok = QB.record(it.q.id, oi, sec);
      log.push({ id: it.q.id, ok: ok, d: it.q.d || 2, chosen: oi, sec: sec, at: pos });
      if (src.adaptive) level = ok ? Math.min(3, level + 1) : Math.max(1, level - 1);
      draw();
      window.scrollTo(0, document.documentElement.scrollHeight);
    }
    function finish() {
      items.forEach(function (it, i) {
        if (!it.st.reveal) { QB.record(it.q.id, -1, 0); log.push({ id: it.q.id, ok: false, d: it.q.d || 2, chosen: -1, sec: 0, at: i }); }
      });
      log.sort(function (x, y) { return x.at - y.at; });
      C.setTop(src.title + ' — ফলাফল', back());
      var c = log.filter(function (x) { return x.ok; }).length;
      var p = pct(c, log.length);
      var byD = { 1: [0, 0], 2: [0, 0], 3: [0, 0] };
      log.forEach(function (x) { byD[x.d][1]++; if (x.ok) byD[x.d][0]++; });
      var weakL = {};
      log.forEach(function (x) { if (!x.ok) { var q = QB.get(x.id); if (q.lid) weakL[q.lid] = (weakL[q.lid] || 0) + 1; } });
      var html = '<section class="card"><div class="score-ring"><b>' + C.pct(p) + '</b><div>' + num(c) + '/' + num(log.length) + ' সঠিক<br><span class="small muted">গড় সময় ' + num(Math.round(log.reduce(function (s, x) { return s + x.sec; }, 0) / log.length)) + ' সেকেন্ড/প্রশ্ন</span></div></div></section>' +
        '<section class="card"><h2>কঠিনতা অনুযায়ী</h2><table class="data"><tr><th>স্তর</th><th class="n">সঠিক</th><th class="n">মোট</th></tr>' +
        [1, 2, 3].filter(function (d) { return byD[d][1]; }).map(function (d) { return '<tr><td>' + DLABEL[d] + '</td><td class="n">' + num(byD[d][0]) + '</td><td class="n">' + num(byD[d][1]) + '</td></tr>'; }).join('') + '</table></section>';
      var wk = Object.keys(weakL);
      html += '<section class="card"><h2>রিভিশন পরামর্শ</h2>' + (p >= 80 ? '<p>চমৎকার! পরের পাঠে যেতে পারেন, কয়েক দিন পর Flashcard দিয়ে ঝালিয়ে নিন।</p>' :
        p >= 60 ? '<p>ভালো, তবে নিচের টপিকগুলো আরেকবার দেখুন।</p>' : '<p>ভিত্তি আরও মজবুত করা দরকার — পাঠটি আবার পড়ে ভুল প্রশ্নগুলো Retry করুন।</p>') +
        (wk.length ? '<ul>' + wk.map(function (lid) { return '<li><a href="#/l/' + lid + '">' + esc(LMAP[lid].t) + '</a> — ' + num(weakL[lid]) + 'টি ভুল</li>'; }).join('') + '</ul>' : '') +
        '<div class="grid2"><a class="btn" href="#/mistakes">ভুলের খাতা</a><button class="btn primary" id="again">আবার দিন</button></div></section>';
      html += '<h2>উত্তরপত্র</h2>' + log.map(function (x, i) {
        var q = QB.get(x.id);
        return '<details class="card tight"><summary style="min-height:44px;cursor:pointer">' + (x.ok ? '✅' : '❌') + ' ' + num(i + 1) + '. ' + esc(q.q) + '</summary>' +
          qCardHTML(q, { chosen: x.chosen, reveal: true }) + '</details>';
      }).join('');
      $v().innerHTML = html;
      qs('#again').addEventListener('click', function () { runQuiz(src); });
    }
    next();
  }

  function dailyPool() {
    var unitSubs = C.unitSubjects().map(function (s) { return s.id; });
    var all = QB.all().filter(function (q) { return !QB.isExpired(q); });
    var mine = all.filter(function (q) { return unitSubs.indexOf(q.sub) >= 0; });
    var base = mine.length >= 10 ? mine : all;   // ইউনিটের বিষয়ে প্রশ্ন কম থাকলে সব থেকে
    var mist = QB.mistakes().map(function (m) { return m.q; }).filter(function (q) { return base.indexOf(q) >= 0; });
    var fresh = base.filter(function (q) { return !QB.stat(q.id); });
    var picked = [], seen = {};
    function take(list, n) { QB.shuffle(list).forEach(function (q) { if (picked.length < n && !seen[q.id]) { seen[q.id] = 1; picked.push(q); } }); }
    take(mist, 4); take(fresh, 8); take(base, 10);
    return { pool: picked, fromAll: base !== mine };
  }

  /* ================= Test Builder (PART G) ================= */
  var PRESETS = {
    practice: { t: 'Practice', mode: 'practice', fb: 'instant' },
    exam: { t: 'Exam Simulation', mode: 'exam', fb: 'end' },
    subject: { t: 'Subject-wise', mode: 'exam', fb: 'end', one: true },
    chapter: { t: 'Chapter-wise', mode: 'exam', fb: 'end', one: true, chapters: true },
    mixed: { t: 'Mixed', mode: 'exam', fb: 'end' },
    weak: { t: 'Weak-topic', mode: 'practice', fb: 'instant', src: 'weak' },
    speed: { t: 'Speed Drill', mode: 'exam', fb: 'end', n: 10, secPerQ: 30 },
    mock: { t: 'Mock Admission', mode: 'exam', fb: 'end', mock: true }
  };
  function unitDefaults(u) {
    var neg = u && u.mcq && typeof u.mcq.negative === 'number' ? u.mcq.negative : 0.25;
    var q = u && u.mcq && (u.mcq.questions || u.mcq.marks);
    var spq = (u && u.mcq && u.mcq.minutes && q) ? u.mcq.minutes * 60 / q : 45;
    return { neg: neg, secPerQ: spq };
  }
  function viewBuild(h) {
    var p = params(h);
    var s = C.settings();
    var preset = PRESETS[p.preset] ? p.preset : 'practice';
    var P = PRESETS[preset];
    var unit = UNITS[s.unit];
    var def = unitDefaults(unit);
    C.setTop('টেস্ট বানান', back());
    var all = QB.all();
    var counts = {}; all.forEach(function (q) { counts[q.sub] = (counts[q.sub] || 0) + 1; });
    var subs = C.SUBJ.filter(function (x) { return counts[x.id]; });
    var unitSubs = C.unitSubjects().map(function (x) { return x.id; });
    var pre = subs.filter(function (x) { return unitSubs.indexOf(x.id) >= 0; }).map(function (x) { return x.id; });
    if (!pre.length) pre = subs.map(function (x) { return x.id; });
    if (P.one) pre = pre.slice(0, 1);
    var n0 = P.n || 20;
    var secq = P.secPerQ || def.secPerQ;

    var html = '<section class="card"><div class="field"><label for="preset">টেস্টের ধরন</label><select id="preset">' +
      Object.keys(PRESETS).map(function (k) { return '<option value="' + k + '"' + (k === preset ? ' selected' : '') + '>' + PRESETS[k].t + '</option>'; }).join('') +
      '</select></div>' +
      '<div class="field"><label for="tunit">পরীক্ষা/ইউনিট (নেগেটিভ ও সময়ের ডিফল্ট এখান থেকে)</label><select id="tunit">' +
      C.EXAM.tracks.map(function (t) {
        return '<optgroup label="' + esc(t.name) + '">' + t.units.map(function (u) { return '<option value="' + u.id + '"' + (u.id === s.unit ? ' selected' : '') + '>' + esc(u.code + ' — ' + u.name) + '</option>'; }).join('') + '</optgroup>';
      }).join('') + '</select></div>';
    if (P.mock) {
      html += mockPlanHTML(unit);
    } else {
      html += '<h3>বিষয়</h3><div class="check-list" id="subs">' + (subs.length ? subs.map(function (x) {
        return '<label><input type="' + (P.one ? 'radio' : 'checkbox') + '" name="sub" value="' + x.id + '"' + (pre.indexOf(x.id) >= 0 ? ' checked' : '') + '> ' + x.icon + ' ' + esc(x.t) + ' <span class="small muted">(' + num(counts[x.id]) + ')</span></label>';
      }).join('') : '<p class="muted">কোনো প্রশ্ন নেই।</p>') + '</div>' +
        '<div id="chaps"></div>' +
        '<div class="grid2"><div class="field"><label for="tn">প্রশ্ন সংখ্যা</label><input id="tn" type="number" min="1" max="200" value="' + n0 + '" inputmode="numeric"></div>' +
        '<div class="field"><label for="tmin">সময় (মিনিট)</label><input id="tmin" type="number" min="1" max="300" step="0.5" value="' + (Math.round(n0 * secq / 30) / 2) + '" inputmode="decimal"></div></div>' +
        '<h3>কঠিনতা (%)</h3><div class="num3"><div class="field"><label for="de">সহজ</label><input id="de" type="number" min="0" max="100" value="30"></div>' +
        '<div class="field"><label for="dm">মাঝারি</label><input id="dm" type="number" min="0" max="100" value="50"></div>' +
        '<div class="field"><label for="dh">কঠিন</label><input id="dh" type="number" min="0" max="100" value="20"></div></div>' +
        '<div class="field"><label for="tsrc">প্রশ্নের উৎস</label><select id="tsrc">' +
        [['all', 'সব'], ['pyq', 'শুধু PYQ/PYQ-Style'], ['mistakes', 'শুধু ভুল প্রশ্ন'], ['new', 'শুধু নতুন (আগে দেননি)'], ['ca', 'শুধু সাম্প্রতিক'], ['weak', 'দুর্বল টপিক']].map(function (o) {
          return '<option value="' + o[0] + '"' + ((P.src || 'all') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
        }).join('') + '</select></div>';
    }
    html += '<div class="grid2"><div class="field"><label for="tneg">নেগেটিভ (প্রতি ভুলে)</label><input id="tneg" type="number" min="0" max="1" step="0.05" value="' + def.neg + '"></div>' +
      '<div class="field"><label for="tfb">ফিডব্যাক</label><select id="tfb"><option value="instant"' + (P.fb === 'instant' ? ' selected' : '') + '>সাথে সাথে</option><option value="end"' + (P.fb === 'end' ? ' selected' : '') + '>শেষে</option></select></div></div>' +
      '<div class="check-list"><label><input type="checkbox" id="tshuf" checked> অপশনের ক্রম এলোমেলো করুন</label>' +
      '<label><input type="checkbox" id="tnoexp" checked> মেয়াদোত্তীর্ণ সাম্প্রতিক প্রশ্ন বাদ</label>' +
      '<label><input type="checkbox" id="tpause"' + (P.mode === 'practice' ? ' checked' : '') + '> বিরতি (Pause) দেওয়া যাবে</label></div>' +
      '<p class="small muted" id="avail"></p>' +
      '<button class="btn primary block" id="tstart">টেস্ট শুরু করুন</button></section>';
    if (Store.get('test:active', null)) html = activeBanner(Store.get('test:active')) + html;
    $v().innerHTML = html;

    qs('#preset').addEventListener('change', function () { location.hash = '#/test/build?preset=' + this.value; });
    qs('#tunit').addEventListener('change', function () {
      var u = UNITS[this.value], d = unitDefaults(u);
      qs('#tneg').value = d.neg;
      if (P.mock) { qs('#mockplan').outerHTML = mockPlanHTML(u); }
      else if (!P.secPerQ) qs('#tmin').value = Math.round(+qs('#tn').value * d.secPerQ / 30) / 2;
    });
    function chapUI() {
      var box = qs('#chaps'); if (!box) return;
      var sel = qsa('input[name="sub"]:checked').map(function (i) { return i.value; });
      if (!P.chapters || sel.length !== 1) { box.innerHTML = ''; return; }
      var s0 = SMAP[sel[0]];
      var cc = {}; QB.forSubject(s0.id).forEach(function (q) { if (q.cid) cc[q.cid] = (cc[q.cid] || 0) + 1; });
      box.innerHTML = '<h3>অধ্যায়</h3><div class="check-list">' + s0.ch.filter(function (c) { return cc[c.id]; }).map(function (c) {
        return '<label><input type="checkbox" name="chap" value="' + c.id + '" checked> ' + esc(c.t) + ' <span class="small muted">(' + num(cc[c.id]) + ')</span></label>';
      }).join('') + '</div>';
      qsa('input[name="chap"]').forEach(function (i) { i.addEventListener('change', avail); });
    }
    function cfgFromForm() {
      var cfg = {
        preset: preset, title: P.t, unit: qs('#tunit').value, neg: Math.max(0, +qs('#tneg').value || 0),
        fb: qs('#tfb').value, shuffle: qs('#tshuf').checked, noExp: qs('#tnoexp').checked, pause: qs('#tpause').checked
      };
      if (!P.mock) {
        cfg.subs = qsa('input[name="sub"]:checked').map(function (i) { return i.value; });
        cfg.cids = qsa('input[name="chap"]:checked').map(function (i) { return i.value; });
        cfg.n = Math.max(1, Math.min(200, parseInt(C.fromBnDigits(qs('#tn').value), 10) || 10));
        cfg.minutes = Math.max(0.5, +C.fromBnDigits(qs('#tmin').value) || cfg.n);
        cfg.mix = [+qs('#de').value || 0, +qs('#dm').value || 0, +qs('#dh').value || 0];
        cfg.src = qs('#tsrc').value;
      }
      return cfg;
    }
    function avail() {
      if (P.mock) return;
      var cfg = cfgFromForm();
      var pool = poolFor(cfg);
      qs('#avail').textContent = 'এই শর্তে পাওয়া যাচ্ছে ' + num(pool.length) + 'টি প্রশ্ন' + (pool.length < cfg.n ? ' — টেস্টে ' + num(pool.length) + 'টিই থাকবে।' : '।');
      qs('#tstart').disabled = !pool.length;
    }
    qsa('input[name="sub"]').forEach(function (i) { i.addEventListener('change', function () { chapUI(); avail(); }); });
    ['#tn', '#tsrc', '#tnoexp'].forEach(function (s) { var el = qs(s); if (el) el.addEventListener('change', avail); });
    var tn = qs('#tn');
    if (tn) tn.addEventListener('input', function () { if (!P.secPerQ) qs('#tmin').value = Math.round((+C.fromBnDigits(this.value) || 1) * unitDefaults(UNITS[qs('#tunit').value]).secPerQ / 30) / 2; else qs('#tmin').value = Math.round((+this.value || 1) * P.secPerQ / 30) / 2; avail(); });
    chapUI(); avail();
    qs('#tstart').addEventListener('click', function () {
      var cfg = cfgFromForm();
      if (Store.get('test:active', null)) {
        modal('<h2>আগের টেস্ট এখনো চলছে</h2><p>নতুন টেস্ট শুরু করলে আগেরটি জমা হয়ে যাবে।</p><div class="grid2"><a class="btn" href="#/test/run">আগেরটি চালান</a><button class="btn primary" id="force">জমা দিয়ে নতুন</button></div>', function (m) {
          qs('#force', m).onclick = function () { closeModal(); submitTest(true); startTest(cfg); };
        });
        return;
      }
      startTest(cfg);
    });
  }
  function mockPlanHTML(u) {
    var secs = u && u.mcq && u.mcq.sections || [];
    var inner;
    if (!secs.length) inner = '<p class="banner warn">এই ইউনিটের বিষয়ভিত্তিক মানবণ্টন এখনো যাচাই/যোগ হয়নি, তাই Mock বানানো যাচ্ছে না। অন্য ধরন বেছে নিন।</p>';
    else {
      inner = '<table class="data"><tr><th>অংশ</th><th class="n">প্রশ্ন</th><th class="n">ব্যাংকে আছে</th></tr>' + secs.map(function (x) {
        var have = QB.filter({ subs: x.subjects }).length;
        return '<tr><td>' + esc(x.label) + '</td><td class="n">' + num(x.marks) + '</td><td class="n"' + (have < x.marks ? ' style="color:var(--bad)"' : '') + '>' + num(have) + '</td></tr>';
      }).join('') + '</table><p class="small">সময় ' + num(u.mcq.minutes || '—') + ' মিনিট' + (u.mcq.sectionsVerified ? '' : ' · <span class="chip verify">মানবণ্টন Verify</span>') +
        '. কোনো অংশে প্রশ্ন কম থাকলে যতগুলো আছে ততগুলো দিয়েই টেস্ট হবে।</p>';
    }
    return '<div id="mockplan"><h3>অফিসিয়াল কাঠামো</h3>' + inner + '</div>';
  }
  function weakSet() {
    var st = Store.get('qstat', {});
    var lessonAcc = {};
    QB.all().forEach(function (q) { var r = st[q.id]; if (r && q.lid) { var a = lessonAcc[q.lid] || (lessonAcc[q.lid] = [0, 0]); a[0] += r.c; a[1] += r.n; } });
    var weakL = Object.keys(lessonAcc).filter(function (l) { return lessonAcc[l][1] && lessonAcc[l][0] / lessonAcc[l][1] < 0.6; });
    var mist = Store.get('mist', {});
    return function (q) { return (mist[q.id] && !mist[q.id].mastered) || (st[q.id] && !st[q.id].last) || weakL.indexOf(q.lid) >= 0; };
  }
  function poolFor(cfg) {
    var src = cfg.src === 'weak' ? 'all' : cfg.src;
    var pool = QB.filter({ subs: cfg.subs, cids: cfg.cids && cfg.cids.length ? cfg.cids : null, src: src, noExpired: cfg.noExp });
    if (cfg.src === 'weak') { var w = weakSet(); pool = pool.filter(w); }
    return pool;
  }
  function pickByMix(pool, n, mix) {
    var tot = (mix[0] + mix[1] + mix[2]) || 1;
    var want = [Math.round(n * mix[0] / tot), Math.round(n * mix[1] / tot)];
    want.push(n - want[0] - want[1]);
    var buckets = [1, 2, 3].map(function (d) { return QB.shuffle(pool.filter(function (q) { return (q.d || 2) === d; })); });
    var out = [];
    for (var i = 0; i < 3; i++) out = out.concat(buckets[i].splice(0, Math.max(0, want[i])));
    var rest = QB.shuffle(buckets[0].concat(buckets[1], buckets[2]));
    while (out.length < n && rest.length) out.push(rest.shift());
    return QB.shuffle(out);
  }
  function startTest(cfg) {
    var picked;
    if (cfg.preset === 'mock') {
      var u = UNITS[cfg.unit];
      picked = [];
      (cfg.sections || u.mcq.sections || []).forEach(function (x) {
        var pool = QB.filter({ subs: x.subjects, noExpired: true }), used = {};
        picked.forEach(function (q) { used[q.id] = 1; });
        pool = pool.filter(function (q) { return !used[q.id]; });
        var fresh = QB.shuffle(pool.filter(function (q) { return !QB.stat(q.id); })), seen = QB.shuffle(pool.filter(function (q) { return QB.stat(q.id); }));
        var want = x.n || x.marks;
        picked = picked.concat(pickByMix(fresh.concat(seen).slice(0, want * 3), want, [30, 50, 20]));
      });
      cfg.minutes = cfg.minutes || u.mcq.minutes || picked.length;
      cfg.title = cfg.title || ('Mock — ' + u.track.name.split(' (')[0] + ' ' + u.code);
      if (!picked.length) { toast('এই ইউনিটের বিষয়ে এখনো প্রশ্ন নেই'); return; }
    } else if (cfg.qids) {
      picked = cfg.qids.map(QB.get).filter(Boolean);
    } else {
      picked = pickByMix(poolFor(cfg), cfg.n, cfg.mix);
    }
    if (!picked.length) { toast('কোনো প্রশ্ন পাওয়া যায়নি'); return; }
    var perm = {};
    picked.forEach(function (q) { var o = q.o.map(function (_, i) { return i; }); perm[q.id] = cfg.shuffle ? QB.shuffle(o) : o; });
    var act = {
      id: 't' + Date.now().toString(36), cfg: cfg, qids: picked.map(function (q) { return q.id; }), perm: perm,
      ans: {}, mark: {}, cur: 0, left: Math.round(cfg.minutes * 60), total: Math.round(cfg.minutes * 60), spent: {}, started: Date.now(), paused: false
    };
    Store.set('test:active', act, 0);
    location.hash = '#/test/run';
  }

  /* ================= টেস্ট চালানো (৫ সেকেন্ডে Auto-Save, Resume) ================= */
  var RUN = null;
  function viewRun() {
    var act = Store.get('test:active', null);
    if (!act) { location.replace('#/practice'); return; }
    RUN = JSON.parse(JSON.stringify(act));
    var last = Date.now(), qStart = Date.now();
    C.setTop(RUN.cfg.title, { back: true, actions: '' });
    if (RUN.paused) RUN.paused = false; // ফিরে এলে আবার চালু (বিরতি অ্যাপ বন্ধের সময়ও কার্যকর ছিল)

    function save() { RUN.saved = Date.now(); Store.set('test:active', RUN, 0); }
    function q() { return QB.get(RUN.qids[RUN.cur]); }
    function locked(id) { return RUN.cfg.fb === 'instant' && RUN.ans[id] !== undefined; }
    function draw() {
      var qq = q();
      if (!qq) { toast('প্রশ্ন পাওয়া যায়নি — হয়তো Import মুছে ফেলা হয়েছে'); submitTest(false); return; }
      var id = qq.id, ans = RUN.ans[id];
      var reveal = locked(id);
      var answered = Object.keys(RUN.ans).length;
      var html = '<div class="testbar"><span class="timer" id="timer" aria-live="off">' + fmtSec(RUN.left) + '</span>' +
        '<span class="small muted spacer">' + num(answered) + '/' + num(RUN.qids.length) + ' উত্তর</span>' +
        (RUN.cfg.pause ? '<button class="icon-btn" id="tpausebtn" aria-label="বিরতি">⏸</button>' : '') +
        '<button class="icon-btn" id="tpal" aria-label="প্রশ্ন তালিকা">▦</button>' +
        '<button class="btn primary" id="tsubmit">জমা</button></div>';
      html += qCardHTML(qq, { order: RUN.perm[id], chosen: ans, reveal: reveal, n: RUN.cur + 1, total: RUN.qids.length });
      html += '<div class="grid2" style="margin-bottom:.6rem"><button class="btn" id="tmark" aria-pressed="' + !!RUN.mark[id] + '">' + (RUN.mark[id] ? '★ রিভিউ চিহ্নিত' : '☆ পরে দেখব') + '</button>' +
        '<button class="btn" id="tclear"' + (ans === undefined || reveal ? ' disabled' : '') + '>উত্তর মুছুন</button></div>' +
        '<div class="lesson-nav"><button class="btn" id="tprev"' + (RUN.cur ? '' : ' disabled') + '>← আগের</button>' +
        '<button class="btn primary" id="tnext">' + (RUN.cur < RUN.qids.length - 1 ? 'পরের →' : 'শেষ — জমা দিন') + '</button></div>' +
        '<section class="card" style="margin-top:.9rem"><h3>প্রশ্ন তালিকা</h3>' + paletteHTML() + '</section>';
      $v().innerHTML = html;
      qsa('.opt', $v()).forEach(function (b) {
        b.addEventListener('click', function () {
          RUN.ans[id] = +b.getAttribute('data-oi'); save(); draw();
          if (RUN.cfg.fb === 'instant') window.scrollTo(0, qs('.verdict') ? qs('.verdict').offsetTop - 120 : 0);
        });
      });
      qs('#tmark').onclick = function () { if (RUN.mark[id]) delete RUN.mark[id]; else RUN.mark[id] = 1; save(); draw(); };
      qs('#tclear').onclick = function () { delete RUN.ans[id]; save(); draw(); };
      qs('#tprev').onclick = function () { go(RUN.cur - 1); };
      qs('#tnext').onclick = function () { if (RUN.cur < RUN.qids.length - 1) go(RUN.cur + 1); else confirmSubmit(); };
      qs('#tsubmit').onclick = confirmSubmit;
      qs('#tpal').onclick = function () { qs('.palette').scrollIntoView({ behavior: 'smooth' }); };
      var pb = qs('#tpausebtn'); if (pb) pb.onclick = pause;
      bindPalette($v());
    }
    function paletteHTML() {
      return '<div class="palette">' + RUN.qids.map(function (id, i) {
        var cls = [];
        if (RUN.ans[id] !== undefined) {
          if (RUN.cfg.fb === 'instant') cls.push(RUN.ans[id] === QB.get(id).a ? 'right' : 'wrong'); else cls.push('ans');
        }
        if (RUN.mark[id]) cls.push('mk');
        if (i === RUN.cur) cls.push('cur');
        return '<button data-go="' + i + '" class="' + cls.join(' ') + '" aria-label="প্রশ্ন ' + (i + 1) + '">' + num(i + 1) + '</button>';
      }).join('') + '</div><div class="legend"><span><i style="background:var(--primary);border-color:var(--primary)"></i>উত্তর দেওয়া</span><span><i style="border-color:var(--warn)"></i>রিভিউ চিহ্নিত</span><span><i></i>বাকি</span></div>';
    }
    function bindPalette(root) { qsa('[data-go]', root).forEach(function (b) { b.onclick = function () { closeModal(); go(+b.getAttribute('data-go')); }; }); }
    function go(i) {
      track();
      RUN.cur = Math.max(0, Math.min(RUN.qids.length - 1, i)); save(); draw(); window.scrollTo(0, 0);
    }
    function track() { var id = RUN.qids[RUN.cur]; RUN.spent[id] = (RUN.spent[id] || 0) + (Date.now() - qStart) / 1000; qStart = Date.now(); }
    function confirmSubmit() {
      var a = Object.keys(RUN.ans).length, n = RUN.qids.length, mk = Object.keys(RUN.mark).length;
      modal('<h2>টেস্ট জমা দেবেন?</h2><p>উত্তর দিয়েছেন ' + num(a) + '/' + num(n) + 'টি' + (n - a ? ', বাকি ' + num(n - a) + 'টি' : '') + (mk ? ', রিভিউ চিহ্নিত ' + num(mk) + 'টি' : '') + '।<br>সময় বাকি ' + fmtSec(RUN.left) + '।</p>' +
        '<div class="grid2"><button class="btn" id="cn">ফিরে যান</button><button class="btn primary" id="cy">জমা দিন</button></div>', function (m) {
        qs('#cn', m).onclick = closeModal;
        qs('#cy', m).onclick = function () { closeModal(); track(); save(); stop(); submitTest(false); };
      });
    }
    function pause() {
      RUN.paused = true; save();
      modal('<h2>⏸ বিরতি</h2><p>টাইমার থেমে আছে। সময় বাকি ' + fmtSec(RUN.left) + '।</p><button class="btn primary block" id="resume">আবার শুরু</button>', function (m) {
        qs('#resume', m).onclick = function () { RUN.paused = false; last = Date.now(); qStart = Date.now(); save(); closeModal(); };
      });
    }
    var tick = setInterval(function () {
      var t = Date.now(), dt = (t - last) / 1000; last = t;
      if (RUN.paused) return;
      if (document.visibilityState === 'hidden' && RUN.cfg.pause) return;
      RUN.left -= dt;
      var el = qs('#timer');
      if (el) { el.textContent = fmtSec(RUN.left); el.classList.toggle('low', RUN.left <= 60); }
      if (RUN.left <= 0) { RUN.left = 0; track(); save(); stop(); toast('⏰ সময় শেষ — স্বয়ংক্রিয়ভাবে জমা হয়েছে'); submitTest(false); }
    }, 1000);
    var saver = setInterval(function () { if (!RUN.paused) save(); }, 5000);   // F4: প্রতি ৫ সেকেন্ডে
    function onHide() { if (document.visibilityState === 'hidden') { track(); save(); } }
    document.addEventListener('visibilitychange', onHide);
    function stop() { clearInterval(tick); clearInterval(saver); document.removeEventListener('visibilitychange', onHide); }
    C.setCleanup(function () { track(); if (Store.get('test:active', null)) save(); stop(); });
    draw();
  }

  function submitTest(silent) {
    var act = Store.get('test:active', null);
    if (!act) return;
    var res = { id: act.id, cfg: act.cfg, qids: act.qids, perm: act.perm, ans: act.ans, mark: act.mark, spent: act.spent,
      used: Math.round(act.total - act.left), total: act.total, at: Date.now() };
    var c = 0, w = 0, sk = 0;
    act.qids.forEach(function (id) {
      var q = QB.get(id); if (!q) return;
      var a = act.ans[id];
      if (a === undefined) sk++; else if (a === q.a) c++; else w++;
      QB.record(id, a === undefined ? -1 : a, act.spent[id]);
    });
    res.c = c; res.w = w; res.s = sk;
    var mp = act.cfg.mp || 1;
    res.score = Math.round((c * mp - w * act.cfg.neg) * 100) / 100;
    res.max = Math.round(act.qids.length * mp * 100) / 100;
    var hist = (Store.get('tests', []) || []).slice();
    hist.unshift(res); if (hist.length > 50) hist.length = 50;
    Store.set('tests', hist, 0);
    Store.del('test:active');
    SUBMIT_HOOKS.forEach(function (fn) { try { fn(res); } catch (e) { console.error(e); } });
    if (!silent) location.hash = '#/test/result/' + res.id;
  }

  /* ================= ফলাফল ও OMR রিভিউ ================= */
  function viewResult(id, h) {
    var res = (Store.get('tests', []) || []).filter(function (r) { return r.id === id; })[0];
    if (!res) { location.replace('#/test/history'); return; }
    var f = params(h).f || 'all';
    C.setTop('ফলাফল', back());
    var n = res.qids.length, att = res.c + res.w;
    var u = UNITS[res.cfg.unit];
    var max = res.max || n;
    var html = '<section class="card"><div class="small muted">' + esc(res.cfg.title) + ' · ' + new Date(res.at).toLocaleString('bn-BD') + '</div>' +
      '<div class="score-ring" style="margin:.5rem 0"><b>' + num(res.score) + '</b><div>/ ' + num(max) + ' নম্বর<br><span class="small muted">নেগেটিভ ' + num(res.cfg.neg) + ' প্রতি ভুলে</span></div></div>' +
      '<div class="grid2"><div class="stat"><span class="small muted">সঠিক / ভুল / বাদ</span><b>' + num(res.c) + ' / ' + num(res.w) + ' / ' + num(res.s) + '</b></div>' +
      '<div class="stat"><span class="small muted">Accuracy</span><b>' + C.pct(pct(res.c, att)) + '</b><span class="small muted">উত্তর দেওয়া প্রশ্নে</span></div>' +
      '<div class="stat"><span class="small muted">সময় লেগেছে</span><b>' + fmtSec(res.used) + '</b><span class="small muted">মোট ' + fmtSec(res.total) + '</span></div>' +
      '<div class="stat"><span class="small muted">গতি</span><b>' + num(att ? Math.round(res.used / att) : 0) + ' সে.</b><span class="small muted">প্রতি উত্তরে</span></div></div>';
    if (u && u.pass && u.pass.mcq && u.mcq && u.mcq.marks === max) {
      html += '<p class="small" style="margin-top:.6rem">' + esc(u.code) + ' ইউনিটের MCQ পাস নম্বর ' + num(u.pass.mcq) + ': ' + (res.score >= u.pass.mcq ? '✅ পাস' : '❌ পাস হয়নি') + (u.pass.verified ? '' : ' <span class="chip verify">Verify</span>') + '</p>';
    }
    html += '<p class="small muted" style="margin-top:.4rem">আনুমানিক Merit Position: যাচাইকৃত কাট-অফ/মেধাতালিকার ডেটা না থাকায় এখন দেখানো হচ্ছে না।</p>' +
      '<div class="grid2 noprint"><button class="btn" id="print">🖨 প্রিন্ট</button><a class="btn primary" href="#/test/build">নতুন টেস্ট</a></div></section>';
    RESULT_HOOKS.forEach(function (fn) { try { html += fn(res) || ''; } catch (e) { console.error(e); } });

    // বিষয়ভিত্তিক
    var bys = {};
    res.qids.forEach(function (id) {
      var q = QB.get(id); if (!q) return;
      var b = bys[q.sub] || (bys[q.sub] = { c: 0, w: 0, s: 0 });
      var a = res.ans[id]; if (a === undefined) b.s++; else if (a === q.a) b.c++; else b.w++;
    });
    html += '<section class="card"><h2>বিষয়ভিত্তিক</h2><table class="data"><tr><th>বিষয়</th><th class="n">সঠিক</th><th class="n">ভুল</th><th class="n">বাদ</th></tr>' +
      Object.keys(bys).map(function (s) { return '<tr><td>' + esc(subjName(s)) + '</td><td class="n">' + num(bys[s].c) + '</td><td class="n">' + num(bys[s].w) + '</td><td class="n">' + num(bys[s].s) + '</td></tr>'; }).join('') + '</table></section>';
    // সময় বিশ্লেষণ
    var slow = res.qids.filter(function (id) { return res.spent[id]; }).sort(function (a, b) { return res.spent[b] - res.spent[a]; }).slice(0, 5);
    if (slow.length) html += '<section class="card"><h2>সবচেয়ে বেশি সময় নেওয়া প্রশ্ন</h2><table class="data">' + slow.map(function (id) {
      var i = res.qids.indexOf(id), q = QB.get(id), a = res.ans[id];
      return '<tr><td>' + num(i + 1) + '. ' + esc((q ? q.q : id).slice(0, 60)) + '</td><td class="n">' + num(Math.round(res.spent[id])) + ' সে. ' + (a === undefined ? '—' : a === (q && q.a) ? '✅' : '❌') + '</td></tr>';
    }).join('') + '</table></section>';
    // OMR
    html += '<h2>OMR রিভিউ</h2><div class="seg noprint" style="margin-bottom:.6rem">' + [['all', 'সব'], ['wrong', 'ভুল'], ['skip', 'বাদ'], ['mark', 'রিভিউ চিহ্নিত']].map(function (o) {
      return '<button data-f="' + o[0] + '" aria-pressed="' + (f === o[0]) + '">' + o[1] + '</button>';
    }).join('') + '</div>';
    html += res.qids.map(function (id, i) {
      var q = QB.get(id); if (!q) return '';
      var a = res.ans[id], ord = res.perm[id] || q.o.map(function (_, k) { return k; });
      if (f === 'wrong' && (a === undefined || a === q.a)) return '';
      if (f === 'skip' && a !== undefined) return '';
      if (f === 'mark' && !res.mark[id]) return '';
      var bub = '<span class="omr">' + ord.map(function (oi, k) {
        var cls = oi === q.a ? (a === oi ? 'c' : 'p') : (a === oi ? 'x' : '');
        return '<span class="' + cls + '">' + LET[k] + '</span>';
      }).join('') + '</span>';
      return '<details class="card tight"><summary class="row" style="min-height:44px;cursor:pointer"><span class="spacer">' + num(i + 1) + '. ' + esc(q.q.slice(0, 70)) + (res.mark[id] ? ' ★' : '') + '</span>' + bub + '</summary>' +
        qCardHTML(q, { order: ord, chosen: a, reveal: true }) + '</details>';
    }).join('');
    $v().innerHTML = html;
    qs('#print').onclick = function () { qsa('details', $v()).forEach(function (d) { d.open = true; }); window.print(); };
    qsa('.seg [data-f]', $v()).forEach(function (b) { b.onclick = function () { history.replaceState(null, '', '#/test/result/' + id + '?f=' + b.getAttribute('data-f')); viewResult(id, location.hash); }; });
  }

  function viewHistory() {
    C.setTop('টেস্ট ইতিহাস', back());
    var hist = Store.get('tests', []) || [];
    var act = Store.get('test:active', null);
    var html = act ? activeBanner(act) : '';
    if (!hist.length) html += '<div class="card"><p class="muted">এখনো কোনো টেস্ট দেননি।</p><a class="btn primary" href="#/test/build">প্রথম টেস্ট দিন</a></div>';
    else {
      var last = hist.slice(0, 10).reverse();
      html += '<section class="card"><h2>অগ্রগতি (শেষ ১০টি, Accuracy %)</h2><div style="display:grid;grid-template-columns:repeat(' + last.length + ',1fr);gap:.3rem;align-items:end;height:110px">' +
        last.map(function (r) { var p = pct(r.c, r.c + r.w); return '<div style="text-align:center"><div style="height:' + Math.max(3, p * .8) + 'px;background:var(--fill);border-radius:6px 6px 2px 2px"></div><div class="small muted">' + C.pct(p) + '</div></div>'; }).join('') + '</div></section>';
      html += '<div class="card">' + hist.map(function (r) {
        return '<a class="result" href="#/test/result/' + r.id + '"><div class="row"><b class="spacer">' + esc(r.cfg.title) + '</b><span>' + num(r.score) + '/' + num(r.max || r.qids.length) + '</span></div>' +
          '<div class="where">' + new Date(r.at).toLocaleString('bn-BD') + ' · সঠিক ' + num(r.c) + ', ভুল ' + num(r.w) + ', বাদ ' + num(r.s) + '</div></a>';
      }).join('') + '</div>';
    }
    $v().innerHTML = html;
  }

  /* ================= Flashcard (F2) ================= */
  function deckFilter(p) {
    return QB.cards().filter(function (c) {
      if (p.lid && c.lid !== p.lid) return false;
      if (p.cid && c.cid !== p.cid) return false;
      if (p.sub && c.sub !== p.sub) return false;
      if (p.saved && !C.isSaved('fc', c.id)) return false;
      if (p.cam && !(c.ca && (p.cam === 'all' || c.ca.slice(0, 7) === p.cam))) return false;
      if (p.mode === 'weak') return QB.isWeak(c);
      if (p.mode === 'all') return true;
      return QB.isDue(c);
    });
  }
  function viewFlash() {
    C.setTop('Flashcard', back());
    var cards = QB.cards();
    var due = cards.filter(function (c) { return QB.isDue(c); });
    var weak = cards.filter(QB.isWeak);
    var subs = {}; cards.forEach(function (c) { subs[c.sub] = (subs[c.sub] || 0) + 1; });
    var html = '<section class="card"><div class="grid2"><div class="stat"><span class="small muted">আজ Due</span><b>' + num(due.length) + '</b></div>' +
      '<div class="stat"><span class="small muted">মোট কার্ড</span><b>' + num(cards.length) + '</b><span class="small muted">দুর্বল ' + num(weak.length) + '</span></div></div></section>' +
      '<section class="card"><h2>ডেক বেছে নিন</h2><div class="field"><label for="fsub">বিষয়</label><select id="fsub"><option value="">সব বিষয়</option>' +
      C.SUBJ.filter(function (s) { return subs[s.id]; }).map(function (s) { return '<option value="' + s.id + '">' + esc(s.t) + ' (' + num(subs[s.id]) + ')</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="fcid">অধ্যায়</label><select id="fcid"><option value="">সব অধ্যায়</option></select></div>' +
      '<div class="field"><label for="fmode">কার্ড</label><select id="fmode"><option value="due">আজকের Due</option><option value="weak">শুধু দুর্বল</option><option value="all">সব কার্ড</option></select></div>' +
      '<p class="small muted" id="fcount"></p><button class="btn primary block" id="fgo">রিভিউ শুরু</button></section>' +
      '<section class="card"><div class="row"><h2 class="spacer" style="margin:0">নিজের কার্ড</h2><a class="btn" href="#/flash/add">+ যোগ করুন</a></div>' +
      (function () {
        var mine = cards.filter(function (c) { return c.user; });
        return mine.length ? mine.map(function (c) { return '<div class="row" style="border-top:1px solid var(--border);padding:.4rem 0"><div class="spacer"><b>' + esc(c.f) + '</b><div class="small muted">' + esc(c.b) + '</div></div><button class="icon-btn" data-rm="' + c.id + '" aria-label="মুছুন">✕</button></div>'; }).join('') : '<p class="small muted">এখনো কোনো নিজের কার্ড নেই।</p>';
      })() + '</section>' +
      '<p class="small muted">Spaced Repetition: "আবার দেখব" চাপলে কার্ডটি কয়েকটি কার্ড পরেই আবার আসবে; "জানি" (বা কঠিন/খুব সহজ) অনুযায়ী পরের রিভিউ ১ দিন থেকে কয়েক সপ্তাহ পরে নিজে থেকে ঠিক হয়। রিভিউয়ের সময় আগের/পরের ও এলোমেলো করো বোতাম আছে।</p>';
    $v().innerHTML = html;
    var fsub = qs('#fsub'), fcid = qs('#fcid'), fmode = qs('#fmode');
    function upd() {
      var s0 = SMAP[fsub.value];
      var cur = fcid.value;
      fcid.innerHTML = '<option value="">সব অধ্যায়</option>' + (s0 ? s0.ch.filter(function (c) { return cards.some(function (k) { return k.cid === c.id; }); }).map(function (c) { return '<option value="' + c.id + '"' + (c.id === cur ? ' selected' : '') + '>' + esc(c.t) + '</option>'; }).join('') : '');
      var n = deckFilter({ sub: fsub.value, cid: fcid.value, mode: fmode.value }).length;
      qs('#fcount').textContent = num(n) + 'টি কার্ড';
      qs('#fgo').disabled = !n;
    }
    [fsub, fcid, fmode].forEach(function (el) { el.addEventListener('change', upd); });
    upd();
    qs('#fgo').onclick = function () { location.hash = '#/flash/review?sub=' + fsub.value + '&cid=' + fcid.value + '&mode=' + fmode.value; };
    qsa('[data-rm]').forEach(function (b) { b.onclick = function () { QB.removeCard(b.getAttribute('data-rm')); viewFlash(); }; });
  }
  function lessonNo(lid) {
    var l = LMAP[lid]; if (!l || !SMAP[l.sid]) return '';
    var ch = SMAP[l.sid].ch, ci = -1, li = -1;
    ch.forEach(function (c, i) { if (c.id === l.cid) { ci = i; c.l.forEach(function (x, j) { if (x.id === lid) li = j; }); } });
    return ci < 0 ? '' : num(ci + 1) + '.' + num(li + 1);
  }
  var ICO = {
    again: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M20 11a8 8 0 0 0-14.5-4.6L4 8M4 4v4h4M4 13a8 8 0 0 0 14.5 4.6L20 16m0 4v-4h-4"/></svg>',
    ok: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    l: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M15 5l-7 7 7 7"/></svg>',
    r: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M9 5l7 7-7 7"/></svg>'
  };
  function viewFlashReview(h) {
    var p = params(h);
    if ((p.lid || p.cam || p.saved) && !p.mode) p.mode = 'all';
    var full = deckFilter(p);
    var title = p.saved ? 'সংরক্ষিত Flashcard' : p.lid && LMAP[p.lid] ? LMAP[p.lid].t : (p.cam ? (window.CA ? CA.monthName(p.cam) : 'সাম্প্রতিক') + ' — Flashcard' : 'Flashcard');
    C.setTop(title, back());
    if (!full.length) {
      $v().innerHTML = '<div class="card"><p>এই ডেকে এখন রিভিউ করার মতো কার্ড নেই। 🎉</p><a class="btn" href="#/flash">ডেক বদলান</a> <a class="btn" href="#/flash/review?' + (p.lid ? 'lid=' + p.lid + '&' : '') + 'mode=all">সব কার্ড দেখুন</a></div>';
      return;
    }
    // অংশ (পাঠ) তালিকা — পাঠ্যসূচির ক্রমে
    var parts = [], pc = {};
    full.forEach(function (c) { var k = c.lid || ('_' + c.sub); if (!pc[k]) { pc[k] = 0; parts.push(k); } pc[k]++; });
    var part = '', deck = [], idx = 0, flipped = false, seen = {}, againSet = {}, stats = [0, 0, 0, 0];
    function known(c) { var st = QB.cardState(c.id); return !!(st && st.reps > 0 && st.ivl >= 1); }
    function build(keep) {
      deck = full.filter(function (c) { return !part || (c.lid || ('_' + c.sub)) === part; });
      if (!keep) idx = 0;
    }
    function partLabel(k) { return k.charAt(0) === '_' ? subjName(k.slice(1)) : ((lessonNo(k) ? lessonNo(k) + ' ' : '') + (LMAP[k] ? LMAP[k].t : k)); }
    function draw() {
      if (idx >= deck.length) return finish();
      var c = deck[idx], mastered = deck.filter(known).length;
      var meta = (c.lid ? lessonNo(c.lid) : '') ;
      $v().innerHTML = '<div class="fc-wrap">' +
        '<div class="fc-eyebrow">সক্রিয় স্মরণ</div><h1 class="fc-h1">ফ্ল্যাশকার্ড</h1>' +
        '<div class="fc-top"><select id="fpart" class="fc-sel" aria-label="অংশ বাছুন"><option value="">সব অংশ (' + num(full.length) + ')</option>' +
        (parts.length > 1 ? parts.map(function (k) { return '<option value="' + esc(k) + '"' + (k === part ? ' selected' : '') + '>' + esc(partLabel(k)) + ' (' + num(pc[k]) + ')</option>'; }).join('') : '') +
        '</select><span class="fc-mast">আয়ত্ত ' + num(mastered) + '/' + num(deck.length) + '</span>' + C.saveBtnHTML('fc', c.id, 'sm') + '</div>' +
        '<div class="fc-bar"><span style="width:' + pct(idx, deck.length) + '%"></span></div>' +
        '<div class="flash fc-card' + (flipped ? ' flipped' : '') + '" id="card" role="button" tabindex="0" aria-label="কার্ড উল্টাতে ট্যাপ করুন"><div class="flash-in">' +
        '<div class="flash-face front"><small>' + (meta ? meta + ' · ' : '') + 'কার্ড ' + num(idx + 1) + '/' + num(deck.length) + '</small><div class="fc-txt">' + esc(c.f) + '</div><span class="fc-hint">উত্তর দেখতে ট্যাপ করো</span></div>' +
        '<div class="flash-face back"><small>' + (meta ? meta + ' · ' : '') + 'কার্ড ' + num(idx + 1) + '/' + num(deck.length) + '</small><div class="fc-txt fc-back">' + esc(c.b) + '</div>' +
        (c.lid ? '<a class="fc-link" href="#/l/' + c.lid + '">📖 সংশ্লিষ্ট পাঠ</a>' : '') + '</div></div></div>' +
        '<div class="fc-grade" id="grades"><button class="btn fc-again" data-g="0">' + ICO.again + ' আবার দেখব</button><button class="btn primary fc-ok" data-g="2">' + ICO.ok + ' জানি</button></div>' +
        '<div class="fc-nav"><button class="fc-ghost" id="fprev"' + (idx ? '' : ' disabled') + '>' + ICO.l + ' আগের</button><span class="spacer"></span>' +
        '<button class="fc-ghost" id="fshuf">' + ICO.again + ' এলোমেলো করো</button><button class="fc-ghost" id="fnext"' + (idx < deck.length - 1 ? '' : ' disabled') + '>পরের ' + ICO.r + '</button></div>' +
        '</div>';
      var el = qs('#card');
      function flip() { flipped = !flipped; el.classList.toggle('flipped', flipped); }
      el.onclick = function (e) { if (e.target.closest('a')) return; flip(); };
      el.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } };
      qsa('[data-g]').forEach(function (b) { b.onclick = function () { grade(+b.getAttribute('data-g')); }; });
      qs('#fprev').onclick = prev; qs('#fnext').onclick = next;
      qs('#fshuf').onclick = function () { deck = deck.slice(0, idx + 1).concat(QB.shuffle(deck.slice(idx + 1))); toast('বাকি কার্ড এলোমেলো করা হলো'); };
      qs('#fpart').onchange = function () { part = this.value; flipped = false; build(); draw(); };
    }
    function grade(g) {
      var c = deck[idx];
      QB.review(c.id, g); stats[g]++;
      if (g === 0) againSet[c.id] = c; else delete againSet[c.id];
      idx++; flipped = false; draw();
    }
    function next() { if (idx < deck.length - 1) { idx++; flipped = false; draw(); } }
    function prev() { if (idx > 0) { idx--; flipped = false; draw(); } }
    function finish() {
      var ag = Object.keys(againSet).map(function (k) { return againSet[k]; });
      $v().innerHTML = '<div class="fc-wrap"><div class="fc-eyebrow">সক্রিয় স্মরণ</div><h1 class="fc-h1">রিভিউ শেষ ✓</h1>' +
        '<section class="card"><p>জানি ' + num(stats[2]) + ' · আবার দেখব ' + num(stats[0]) + '</p><p class="small muted">আয়ত্ত ' + num(deck.filter(known).length) + '/' + num(deck.length) + '</p>' +
        (ag.length ? '<button class="btn primary block" id="fagain">🔁 "আবার দেখব"-এর ' + num(ag.length) + 'টি কার্ড আবার</button>' : '') +
        '<div class="grid2" style="margin-top:.6rem"><button class="btn" id="fprev2">← আগের কার্ড</button><a class="btn" href="#/flash">ডেক</a></div></section></div>';
      var fa = qs('#fagain'); if (fa) fa.onclick = function () { deck = ag; againSet = {}; idx = 0; flipped = false; draw(); };
      qs('#fprev2').onclick = function () { idx = Math.max(0, deck.length - 1); draw(); };
    }
    function onKey(e) {
      if (!qs('#card') || /INPUT|SELECT|TEXTAREA/.test((e.target || {}).tagName || '')) return;
      if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'ArrowRight') next();
      else if (e.key === '1') grade(0);
      else if (e.key === '2') grade(2);
    }
    document.addEventListener('keydown', onKey);
    window.addEventListener('hashchange', function off() { document.removeEventListener('keydown', onKey); window.removeEventListener('hashchange', off); });
    build(); draw();
  }
  function viewFlashAdd() {
    C.setTop('নতুন Flashcard', back());
    $v().innerHTML = '<section class="card"><div class="field"><label for="ns">বিষয়</label><select id="ns">' + C.SUBJ.map(function (s) { return '<option value="' + s.id + '">' + esc(s.t) + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="nl">পাঠ (ঐচ্ছিক)</label><select id="nl"></select></div>' +
      '<div class="field"><label for="nf">সামনে (প্রশ্ন)</label><textarea class="note" id="nf" style="min-height:70px"></textarea></div>' +
      '<div class="field"><label for="nb">পেছনে (উত্তর)</label><textarea class="note" id="nb" style="min-height:70px"></textarea></div>' +
      '<button class="btn primary block" id="nsave">সংরক্ষণ</button></section>';
    function fill() {
      var s = SMAP[qs('#ns').value];
      qs('#nl').innerHTML = '<option value="">—</option>' + s.ch.map(function (c) { return '<optgroup label="' + esc(c.t) + '">' + c.l.filter(function (l) { return l.st !== 'pending'; }).map(function (l) { return '<option value="' + l.id + '">' + esc(l.t) + '</option>'; }).join('') + '</optgroup>'; }).join('');
    }
    qs('#ns').onchange = fill; fill();
    qs('#nsave').onclick = function () {
      var f = qs('#nf').value.trim(), b = qs('#nb').value.trim();
      if (!f || !b) { toast('দুই পাশই লিখুন'); return; }
      QB.addCard({ sub: qs('#ns').value, lid: qs('#nl').value || '', f: f, b: b });
      toast('কার্ড যোগ হয়েছে'); location.hash = '#/flash';
    };
  }

  /* ================= ভুলের খাতা (F3) ================= */
  var REASONS = [['', 'কারণ বাছুন'], ['concept', 'ধারণাগত ভুল'], ['careless', 'অসাবধানতা'], ['time', 'সময়ের চাপ'], ['guess', 'অনুমান']];
  function viewMistakes(h) {
    var p = params(h);
    var showM = p.m === '1';
    C.setTop('ভুলের খাতা', back());
    var all = QB.mistakes(true);
    var list = all.filter(function (m) {
      if (!showM && m.mastered) return false;
      if (p.lid && m.q.lid !== p.lid) return false;
      if (p.sub && m.q.sub !== p.sub) return false;
      if (p.exam && (m.q.exam || '') !== p.exam) return false;
      if (p.r && m.reason !== p.r) return false;
      return true;
    });
    var subs = {}, exams = {};
    all.forEach(function (m) { subs[m.q.sub] = 1; if (m.q.exam) exams[m.q.exam] = 1; });
    var masteredN = all.filter(function (m) { return m.mastered; }).length;
    var html = '<section class="card noprint"><div class="grid2"><div class="field"><label for="ms">বিষয়</label><select id="ms"><option value="">সব</option>' +
      Object.keys(subs).map(function (s) { return '<option value="' + s + '"' + (p.sub === s ? ' selected' : '') + '>' + esc(subjName(s)) + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="mr">ভুলের কারণ</label><select id="mr">' + REASONS.map(function (r) { return '<option value="' + r[0] + '"' + (p.r === r[0] ? ' selected' : '') + '>' + (r[0] ? r[1] : 'সব') + '</option>'; }).join('') + '</select></div></div>' +
      (Object.keys(exams).length ? '<div class="field"><label for="me">বিশ্ববিদ্যালয়/পরীক্ষা</label><select id="me"><option value="">সব</option>' + Object.keys(exams).map(function (e) { return '<option' + (p.exam === e ? ' selected' : '') + '>' + esc(e) + '</option>'; }).join('') + '</select></div>' : '') +
      '<div class="check-list"><label><input type="checkbox" id="mm"' + (showM ? ' checked' : '') + '> আয়ত্ত হওয়াগুলোও দেখান (' + num(masteredN) + ')</label></div>' +
      (p.lid ? '<p class="small">পাঠ: <b>' + esc(LMAP[p.lid].t) + '</b> · <a href="#/mistakes">সব দেখুন</a></p>' : '') +
      '<div class="grid2"><button class="btn primary" id="retry"' + (list.filter(function (m) { return !m.mastered; }).length ? '' : ' disabled') + '>🔁 Retry (' + num(list.filter(function (m) { return !m.mastered; }).length) + ')</button><button class="btn" id="mprint">🖨 প্রিন্ট/PDF</button></div>' +
      '<p class="small muted" style="margin:.5rem 0 0">যেকোনো Quiz/Test-এ ভুল বা বাদ দেওয়া প্রশ্ন এখানে নিজে জমা হয়। পরপর ৩ বার সঠিক হলে "আয়ত্ত" হয়ে তালিকা থেকে সরে যায়।</p></section>';
    if (!list.length) html += '<div class="card"><p class="muted">' + (all.length ? 'এই ফিল্টারে কিছু নেই।' : 'ভুলের খাতা খালি — দারুণ! Quiz বা Test দিলে ভুলগুলো এখানে জমা হবে।') + '</p></div>';
    html += list.map(function (m) {
      var q = m.q;
      return '<div class="card"><div class="qmeta" style="display:flex;flex-wrap:wrap;gap:.35rem;margin-bottom:.4rem">' + tagsHTML(q) +
        '<span class="chip' + (m.mastered ? ' ok' : '') + '">' + (m.mastered ? 'আয়ত্ত ✓' : 'Retry ' + num(m.ok || 0) + '/৩') + '</span><span class="chip">' + (m.skip ? 'বাদ দিয়েছিলেন' : 'ভুল ' + num(m.n) + 'বার') + '</span></div>' +
        '<div style="font-weight:600;margin-bottom:.4rem">' + esc(q.q) + '</div>' +
        '<div class="small">সঠিক উত্তর: <b>' + esc(q.o[q.a]) + '</b></div>' +
        '<details><summary class="small" style="min-height:40px;cursor:pointer">ব্যাখ্যা</summary>' + explainHTML(q) + '</details>' +
        '<div class="row noprint" style="margin-top:.4rem"><select data-reason="' + q.id + '" aria-label="ভুলের কারণ" style="min-height:44px;border-radius:10px;border:1px solid var(--border);background:var(--surface-solid);padding:0 .5rem">' +
        REASONS.map(function (r) { return '<option value="' + r[0] + '"' + (m.reason === r[0] ? ' selected' : '') + '>' + r[1] + '</option>'; }).join('') + '</select><span class="spacer"></span>' +
        '<button class="icon-btn" data-del="' + q.id + '" aria-label="খাতা থেকে সরান">🗑</button></div></div>';
    }).join('');
    if (window.Gami && !p.lid && !p.sub && !p.exam && !p.r) html += Gami.mistakesHTML();
    $v().innerHTML = html;
    if (window.Gami) Gami.bindMistakes($v());
    function nav(k, v) { p[k] = v; var qsx = Object.keys(p).filter(function (x) { return p[x]; }).map(function (x) { return x + '=' + encodeURIComponent(p[x]); }).join('&'); location.hash = '#/mistakes' + (qsx ? '?' + qsx : ''); }
    qs('#ms').onchange = function () { nav('sub', this.value); };
    qs('#mr').onchange = function () { nav('r', this.value); };
    var me = qs('#me'); if (me) me.onchange = function () { nav('exam', this.value); };
    qs('#mm').onchange = function () { nav('m', this.checked ? '1' : ''); };
    qs('#mprint').onclick = function () { qsa('details', $v()).forEach(function (d) { d.open = true; }); window.print(); };
    qs('#retry').onclick = function () {
      var pool = list.filter(function (m) { return !m.mastered; }).map(function (m) { return m.q; });
      runQuiz({ title: 'Retry Mistakes', pool: pool, adaptive: false, len: pool.length, backHref: '#/mistakes' });
    };
    qsa('[data-reason]').forEach(function (s) { s.onchange = function () { QB.setReason(s.getAttribute('data-reason'), s.value); toast('কারণ সংরক্ষিত'); }; });
    qsa('[data-del]').forEach(function (b) { b.onclick = function () { QB.removeMistake(b.getAttribute('data-del')); viewMistakes(location.hash); }; });
  }

  /* ================= PYQ Hub (PART E) ================= */
  function viewPYQ(h) {
    var p = params(h);
    C.setTop('PYQ Hub', back());
    var all = QB.all().filter(function (q) { return q.exam; });
    var html = '';
    if (!all.length) {
      html = '<section class="card"><h2>এখনো কোনো PYQ নেই</h2>' +
        '<p>সততার নিয়ম: শুধু নির্ভরযোগ্য সূত্রে যাচাই করা আসল প্রশ্নকেই "PYQ" বলা হবে। তাই উত্তর-কী-সহ নির্ভরযোগ্য সূত্র না পাওয়া পর্যন্ত বানানো প্রশ্ন দিয়ে এই অংশ ভরানো হয়নি। (DU লিখিত অংশের যাচাইকৃত প্রশ্ন আছে <a href="#/written/pyq">লিখিত ল্যাবে</a>।)</p>' +
        '<p>আপনার কাছে আসল প্রশ্ন থাকলে JSON/CSV ফাইল দিয়ে এখনই যোগ করতে পারেন। "verified" ও সূত্র (sourceNote) দিলে "PYQ", না দিলে "PYQ-Style" ট্যাগ পাবে।</p>' +
        '<a class="btn primary block" href="#/pyq/import">⬆ PYQ Import করুন</a></section>';
      $v().innerHTML = html; return;
    }
    var exams = {}, units = {}, years = {}, subs = {};
    all.forEach(function (q) { exams[q.exam] = 1; if (q.unit) units[q.unit] = 1; var y = q.session || q.year; if (y) years[y] = 1; subs[q.sub] = 1; });
    var list = all.filter(function (q) {
      if (p.lid && q.lid !== p.lid) return false;
      if (p.exam && q.exam !== p.exam) return false;
      if (p.unit && q.unit !== p.unit) return false;
      if (p.y && (q.session || q.year) !== p.y) return false;
      if (p.sub && q.sub !== p.sub) return false;
      if (p.s && (q.q + q.o.join(' ')).toLowerCase().indexOf(p.s.toLowerCase()) < 0) return false;
      return true;
    });
    function sel(id, label, obj, cur, fmt) {
      return '<div class="field"><label for="' + id + '">' + label + '</label><select id="' + id + '"><option value="">সব</option>' +
        Object.keys(obj).sort().map(function (k) { return '<option value="' + esc(k) + '"' + (cur === k ? ' selected' : '') + '>' + esc(fmt ? fmt(k) : k) + '</option>'; }).join('') + '</select></div>';
    }
    html += '<section class="card noprint"><div class="grid2">' + sel('pe', 'প্রতিষ্ঠান', exams, p.exam) + sel('pu', 'ইউনিট', units, p.unit) + sel('py', 'সাল/সেশন', years, p.y) + sel('ps', 'বিষয়', subs, p.sub, subjName) + '</div>' +
      '<div class="search-box"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><input id="pq" type="search" placeholder="প্রশ্নে খুঁজুন…" value="' + esc(p.s || '') + '"></div>' +
      (p.lid ? '<p class="small" style="margin-top:.5rem">পাঠ: <b>' + esc(LMAP[p.lid].t) + '</b> · <a href="#/pyq">সব দেখুন</a></p>' : '') +
      '<div class="grid2" style="margin-top:.6rem"><button class="btn primary" id="ptest"' + (list.length ? '' : ' disabled') + '>এগুলো দিয়ে টেস্ট (' + num(list.length) + ')</button><a class="btn" href="#/pyq/import">⬆ Import</a></div></section>';

    // বছরভিত্তিক পূর্ণ পেপার
    var papers = {};
    all.forEach(function (q) { var k = [q.exam, q.unit || '', q.session || q.year || ''].join('|'); (papers[k] = papers[k] || []).push(q.id); });
    html += '<section class="card"><h2>Year-wise Full Paper</h2>' + Object.keys(papers).sort().reverse().map(function (k) {
      var pp = k.split('|');
      return '<div class="row" style="border-top:1px solid var(--border);padding:.4rem 0"><span class="spacer"><b>' + esc(pp[0] + (pp[1] ? ' ' + pp[1] : '')) + '</b> ' + esc(pp[2]) + '<br><span class="small muted">' + num(papers[k].length) + 'টি প্রশ্ন</span></span>' +
        '<button class="btn" data-paper="' + esc(k) + '">শুরু</button></div>';
    }).join('') + '</section>';

    // Frequency heatmap: টপিক × সাল
    var yrs = Object.keys(years).sort();
    var topics = {};
    all.forEach(function (q) { if (!q.lid) return; var y = q.session || q.year || '?'; var t = topics[q.lid] || (topics[q.lid] = {}); t[y] = (t[y] || 0) + 1; });
    var tk = Object.keys(topics);
    if (tk.length && yrs.length) {
      var mx = 1; tk.forEach(function (l) { yrs.forEach(function (y) { mx = Math.max(mx, topics[l][y] || 0); }); });
      html += '<section class="card"><h2>টপিকভিত্তিক PYQ Frequency</h2><div class="heat"><table><tr><th>টপিক</th>' + yrs.map(function (y) { return '<th>' + esc(y) + '</th>'; }).join('') + '<th>মোট</th></tr>' +
        tk.sort(function (a, b) { return sum(topics[b]) - sum(topics[a]); }).map(function (l) {
          return '<tr><td title="' + esc(LMAP[l].t) + '"><a href="#/pyq?lid=' + l + '">' + esc(LMAP[l].t) + '</a></td>' + yrs.map(function (y) {
            var v = topics[l][y] || 0;
            return '<td style="background:' + (v ? 'color-mix(in srgb, var(--fill) ' + Math.round(15 + 70 * v / mx) + '%, transparent)' : 'transparent') + '">' + (v ? num(v) : '') + '</td>';
          }).join('') + '<td><b>' + num(sum(topics[l])) + '</b></td></tr>';
        }).join('') + '</table></div></section>';
    }
    html += '<h2>প্রশ্ন (' + num(list.length) + ')</h2>' + list.slice(0, 100).map(function (q, i) {
      return '<details class="card tight"><summary style="min-height:44px;cursor:pointer">' + num(i + 1) + '. ' + esc(q.q) + '</summary>' + qCardHTML(q, { reveal: true, chosen: undefined }) + '</details>';
    }).join('') + (list.length > 100 ? '<p class="muted small">প্রথম ১০০টি দেখানো হচ্ছে — ফিল্টার ব্যবহার করুন।</p>' : '');
    $v().innerHTML = html;
    function nav(k, v) { p[k] = v; var s = Object.keys(p).filter(function (x) { return p[x]; }).map(function (x) { return x + '=' + encodeURIComponent(p[x]); }).join('&'); location.hash = '#/pyq' + (s ? '?' + s : ''); }
    qs('#pe').onchange = function () { nav('exam', this.value); };
    qs('#pu').onchange = function () { nav('unit', this.value); };
    qs('#py').onchange = function () { nav('y', this.value); };
    qs('#ps').onchange = function () { nav('sub', this.value); };
    var t; qs('#pq').oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { nav('s', v); }, 400); };
    qs('#ptest').onclick = function () {
      var u = UNITS[C.settings().unit], d = unitDefaults(u);
      startTest({ preset: 'pyq', title: 'PYQ টেস্ট', unit: C.settings().unit, neg: d.neg, fb: 'end', shuffle: true, pause: false,
        qids: QB.shuffle(list).map(function (q) { return q.id; }), minutes: Math.max(1, Math.round(list.length * d.secPerQ / 60)) });
    };
    qsa('[data-paper]').forEach(function (b) {
      b.onclick = function () {
        var k = b.getAttribute('data-paper'), pp = k.split('|');
        var uid = null;
        Object.keys(UNITS).forEach(function (id) { var u = UNITS[id]; if (u.track.id === String(pp[0]).toLowerCase() && u.code === pp[1]) uid = id; });
        var u = UNITS[uid], d = unitDefaults(u);
        var mins = u && u.mcq && u.mcq.minutes && u.mcq.marks === papers[k].length ? u.mcq.minutes : Math.max(1, Math.round(papers[k].length * d.secPerQ / 60));
        startTest({ preset: 'paper', title: pp.join(' ') + ' পূর্ণ পেপার', unit: uid || C.settings().unit, neg: d.neg, fb: 'end', shuffle: false, pause: false, qids: papers[k], minutes: mins });
      };
    });
  }
  function sum(o) { var s = 0; for (var k in o) s += o[k]; return s; }

  function viewImport() {
    C.setTop('প্রশ্ন / PYQ Import', back());
    var userN = (Store.get('userq', []) || []).length;
    $v().innerHTML = '<section class="card"><h2>ফাইল বা লেখা দিন</h2>' +
      '<p class="small">JSON (অ্যারে) বা CSV (প্রথম সারিতে কলামের নাম)। কলাম: <code>id, exam, unit, session, year, subject, topicId, type, question, options (| দিয়ে আলাদা) অথবা option1…option4, answer (অপশনের লেখা বা ১–৪ বা A–D), explanation, sourceNote, verified, difficulty (১–৩)</code></p>' +
      '<p class="small">"verified" = true এবং sourceNote ও exam থাকলে তবেই "PYQ" ট্যাগ পাবে; না হলে "PYQ-Style"।</p>' +
      '<div class="grid2"><button class="btn" id="ifile">📄 ফাইল বাছুন</button><button class="btn" id="itpl">⬇ CSV টেমপ্লেট</button></div>' +
      '<input type="file" id="iinput" accept=".json,.csv,application/json,text/csv,text/plain" hidden>' +
      '<div class="field" style="margin-top:.7rem"><label for="itext">অথবা এখানে পেস্ট করুন</label><textarea class="note" id="itext" style="min-height:140px;font-family:ui-monospace,monospace;font-size:.8rem"></textarea></div>' +
      '<button class="btn primary block" id="icheck">যাচাই করুন</button><div id="iout" style="margin-top:.8rem"></div></section>' +
      '<section class="card small"><p>আপনার যোগ করা প্রশ্ন: <b>' + num(userN) + '</b>টি (ব্যাকআপে অন্তর্ভুক্ত)।</p>' + (userN ? '<button class="btn" id="iclear" style="color:var(--bad)">সব Import করা প্রশ্ন মুছুন</button>' : '') + '</section>';
    var fname = '';
    qs('#ifile').onclick = function () { qs('#iinput').click(); };
    qs('#iinput').onchange = function () {
      var f = this.files && this.files[0]; if (!f) return;
      fname = f.name;
      var r = new FileReader(); r.onload = function () { qs('#itext').value = String(r.result); check(); }; r.readAsText(f); this.value = '';
    };
    qs('#itpl').onclick = function () {
      var csv = '﻿id,exam,unit,session,year,subject,topicId,type,question,option1,option2,option3,option4,answer,explanation,sourceNote,verified,difficulty\n';
      if (!Store.download('question-template.csv', csv)) { qs('#itext').value = csv; toast('ডাউনলোড হয়নি — টেমপ্লেট বক্সে বসানো হলো'); }
    };
    var ic = qs('#iclear'); if (ic) ic.onclick = function () {
      modal('<h2>সব Import করা প্রশ্ন মুছবেন?</h2><div class="grid2"><button class="btn" id="n">না</button><button class="btn primary" id="y" style="background:var(--bad);border-color:var(--bad)">মুছুন</button></div>', function (m) {
        qs('#n', m).onclick = closeModal;
        qs('#y', m).onclick = function () { Store.set('userq', [], 0); QB.invalidate(); closeModal(); toast('মুছে ফেলা হয়েছে'); viewImport(); };
      });
    };
    qs('#icheck').onclick = check;
    function check() {
      var out = qs('#iout'), res;
      try { res = QB.parseImport(qs('#itext').value, fname); }
      catch (e) { out.innerHTML = '<div class="banner bad">পড়া যায়নি: ' + esc(e.message) + '</div>'; return; }
      var pyq = res.ok.filter(function (r) { return r.q.src === 'PYQ'; }).length;
      var warns = res.ok.filter(function (r) { return r.errs.length; });
      out.innerHTML = '<div class="banner ' + (res.ok.length ? 'ok' : 'bad') + '">বৈধ ' + num(res.ok.length) + 'টি (PYQ ' + num(pyq) + ', অন্যান্য ' + num(res.ok.length - pyq) + ') · বাতিল ' + num(res.bad.length) + 'টি</div>' +
        (res.bad.length ? '<details open><summary>বাতিল সারি</summary><ul class="small">' + res.bad.slice(0, 30).map(function (b) { return '<li>সারি ' + num(b.row) + (b.id ? ' (' + esc(b.id) + ')' : '') + ': ' + esc(b.errs.join(', ')) + '</li>'; }).join('') + '</ul></details>' : '') +
        (warns.length ? '<details><summary>সতর্কতা (' + num(warns.length) + ')</summary><ul class="small">' + warns.slice(0, 30).map(function (r) { return '<li>' + esc(r.q.id) + ': ' + esc(r.errs.join(', ')) + '</li>'; }).join('') + '</ul></details>' : '') +
        (res.ok.length ? '<button class="btn primary block" id="iadd" style="margin-top:.5rem">' + num(res.ok.length) + 'টি যোগ করুন</button>' : '');
      var add = qs('#iadd');
      if (add) add.onclick = function () {
        QB.addUser(res.ok.map(function (r) { return r.q; }));
        toast(num(res.ok.length) + 'টি প্রশ্ন যোগ হয়েছে'); location.hash = '#/pyq';
      };
    }
  }

  /* ================= রুট ও হোম ================= */
  C.addRoute(/^#\/practice/, viewHub);
  C.addRoute(/^#\/q\/([\w-]+)/, function (m) { viewSingle(m[1]); });
  C.addRoute(/^#\/quiz\/l\/([\w-]+)/, function (m) {
    var l = LMAP[m[1]];
    runQuiz({ title: l ? l.t : 'Quiz', pool: QB.forLesson(m[1]), adaptive: true, len: 10, backHref: '#/l/' + m[1] });
  }, 'syllabus');
  C.addRoute(/^#\/quiz\/s\/([\w-]+)/, function (m) {
    var s = SMAP[m[1]];
    runQuiz({ title: (s ? s.t : '') + ' — Adaptive Quiz', pool: QB.forSubject(m[1]), adaptive: true, len: 15 });
  });
  C.addRoute(/^#\/quiz\/ca(?:\/([\w-]+))?/, function (m) {
    var mo = m[1] || 'all';
    var pool = QB.all().filter(function (q) { return q.ca && !QB.isExpired(q) && (mo === 'all' || q.ca.slice(0, 7) === mo); });
    var name = mo === 'all' ? 'সব সাম্প্রতিক' : (window.CA ? CA.monthName(mo) : mo);
    runQuiz({ title: name + ' — Quiz', pool: pool, adaptive: mo === 'all', len: mo === 'all' ? 15 : 20, backHref: mo === 'all' ? '#/ca' : '#/ca/m/' + mo });
  });
  C.addRoute(/^#\/quiz\/saved/, function () {
    var sm = C.savedMap('q');
    var pool = QB.all().filter(function (q) { return sm[q.id]; });
    runQuiz({ title: 'সংরক্ষিত MCQ — Quiz', pool: pool, adaptive: false, len: Math.min(pool.length, 50), backHref: '#/saved/q' });
  }, 'saved');
  C.addRoute(/^#\/quiz\/daily/, function () {
    var d = dailyPool();
    runQuiz({ title: 'আজকের ১০টি প্রশ্ন', pool: d.pool, adaptive: false, len: 10 });
    if (d.fromAll) toast('আপনার ইউনিটের বিষয়ে এখনো যথেষ্ট প্রশ্ন নেই — সব বিষয় থেকে নেওয়া হলো');
  });
  C.addRoute(/^#\/test\/build/, function (m, h) { viewBuild(h); });
  C.addRoute(/^#\/test\/run/, viewRun);
  C.addRoute(/^#\/test\/result\/([\w-]+)/, function (m, h) { viewResult(m[1], h); });
  C.addRoute(/^#\/test\/history/, viewHistory);
  C.addRoute(/^#\/flash\/review/, function (m, h) { viewFlashReview(h); });
  C.addRoute(/^#\/flash\/add/, viewFlashAdd);
  C.addRoute(/^#\/flash/, viewFlash);
  C.addRoute(/^#\/mistakes/, function (m, h) { viewMistakes(h); });
  C.addRoute(/^#\/pyq\/import/, viewImport);
  C.addRoute(/^#\/pyq/, function (m, h) { viewPYQ(h); });

  C.addHome(function () {
    var act = Store.get('test:active', null);
    var due = QB.cards().filter(function (c) { return QB.isDue(c); }).length;
    var mist = QB.mistakes().length;
    var out = act ? activeBanner(act) : '';
    out += '<div class="row wrap home-quick">' +
      '<a class="btn sm" href="#/quiz/daily">⚡ আজকের ১০টি</a>' +
      (due ? '<a class="btn sm" href="#/flash/review?mode=due">🃏 ' + num(due) + 'টি কার্ড বাকি</a>' : '') +
      (mist ? '<a class="btn sm" href="#/mistakes">📕 ' + num(mist) + 'টি ভুল</a>' : '') +
      '<a class="btn sm" href="#/mega">🎓 Mega Mock</a></div>';
    return out;
  }, false, 'quick', 'চলমান টেস্ট ও দ্রুত অনুশীলন');

  var RESULT_HOOKS = [], SUBMIT_HOOKS = [];
  window.Practice = { qCardHTML: qCardHTML, submitTest: submitTest, runQuiz: runQuiz, startTest: startTest, pickByMix: pickByMix,
    unitDefaults: unitDefaults, onResult: function (fn) { RESULT_HOOKS.push(fn); }, onSubmit: function (fn) { SUBMIT_HOOKS.push(fn); } };
})();
