/* ইন্টারঅ্যাকশন ইফেক্ট (শুধু মাউস/ট্র্যাকপ্যাডে; টাচ-ফোনে বা Reduce Motion-এ বন্ধ):
   1) Spotlight: .card/.fx-এর ওপর কার্সরের জায়গায় নরম আলো (CSS --mx/--my)
   2) Proximity: কার্সর কাছে এলে (≈৭০px) .fx উপাদান হালকা উঁচু হয় (.near)
   3) Pop-up: data-pop থাকা উপাদানে কার্সর রাখলে ছোট তথ্য-বাবল; কিবোর্ড ফোকাসেও দেখায় */
(function () {
  'use strict';
  var fine = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;
  function reduced() {
    return document.documentElement.getAttribute('data-motion') === 'reduce' ||
      (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  /* ---------- Pop-up ---------- */
  var pop = document.createElement('div');
  pop.className = 'popover'; pop.setAttribute('role', 'tooltip'); pop.id = 'fxpop'; pop.hidden = true;
  document.body.appendChild(pop);
  var popT = null, popFor = null;
  function place(el) {
    var r = el.getBoundingClientRect(), pw = pop.offsetWidth, ph = pop.offsetHeight, vw = innerWidth;
    var x = Math.min(Math.max(8, r.left + r.width / 2 - pw / 2), vw - pw - 8);
    var y = r.top - ph - 8, below = false;
    if (y < 60) { y = r.bottom + 8; below = true; }
    pop.style.left = x + 'px'; pop.style.top = y + 'px';
    pop.classList.toggle('below', below);
    pop.style.setProperty('--ax', Math.min(Math.max(12, r.left + r.width / 2 - x), pw - 12) + 'px');
  }
  function show(el) {
    var t = el.getAttribute('data-pop'); if (!t) return;
    popFor = el; pop.textContent = t; pop.hidden = false; pop.classList.remove('on');
    el.setAttribute('aria-describedby', 'fxpop');
    place(el);
    requestAnimationFrame(function () { pop.classList.add('on'); });
  }
  function hide() {
    clearTimeout(popT); popT = null; pending = null;
    if (popFor) popFor.removeAttribute('aria-describedby');
    popFor = null; pop.classList.remove('on'); pop.hidden = true;
  }
  var pending = null;
  function onMove(e) {
    if (!fine) return;
    var el = e.target.closest && e.target.closest('[data-pop]');
    if (el && (el === popFor || el === pending)) return;
    hide(); pending = el || null;
    if (el) popT = setTimeout(function () { pending = null; show(el); }, 220);
  }
  // mousemove: স্ক্রলের পর কার্সর একই জায়গায় থাকলেও নড়লেই আবার দেখায়
  document.addEventListener('mouseover', onMove);
  document.addEventListener('mousemove', onMove, { passive: true });
  document.addEventListener('focusin', function (e) {
    var el = e.target.closest && e.target.closest('[data-pop]');
    hide(); if (el && e.target.matches(':focus-visible')) show(el);
  });
  document.addEventListener('focusout', hide);
  ['scroll', 'hashchange', 'resize'].forEach(function (ev) { window.addEventListener(ev, hide, true); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); });

  if (!fine) return;

  /* ---------- Spotlight + Proximity ---------- */
  var mx = -1e4, my = -1e4, raf = 0, lastCard = null, nearSet = [];
  var R = 70; // কাছের দূরত্ব (px)
  var NEAR_SEL = 'main .fx, main a.btn, main button.btn, main .opt, main a.chip, main .hub a, main summary, #bottomnav a';
  function frame() {
    raf = 0;
    if (reduced()) { clearNear(); return; }
    // spotlight: কার্সরের নিচের কার্ড
    var under = document.elementFromPoint(mx, my);
    var card = under && under.closest ? under.closest('.card, .fx') : null;
    if (lastCard && lastCard !== card) lastCard.classList.remove('lit');
    if (card) {
      var r = card.getBoundingClientRect();
      card.style.setProperty('--mx', (mx - r.left) + 'px');
      card.style.setProperty('--my', (my - r.top) + 'px');
      card.classList.add('lit');
    }
    lastCard = card;
    // proximity: দৃশ্যমান .fx উপাদানের মধ্যে কাছেরগুলো
    var els = document.querySelectorAll(NEAR_SEL), next = [];
    for (var i = 0; i < els.length; i++) {
      var b = els[i].getBoundingClientRect();
      if (b.bottom < 0 || b.top > innerHeight) continue;
      var dx = Math.max(b.left - mx, 0, mx - b.right), dy = Math.max(b.top - my, 0, my - b.bottom);
      var d = Math.sqrt(dx * dx + dy * dy);
      if (d < R) { els[i].style.setProperty('--near', (1 - d / R).toFixed(2)); next.push(els[i]); }
    }
    nearSet.forEach(function (el) { if (next.indexOf(el) < 0) { el.classList.remove('near'); el.style.removeProperty('--near'); } });
    next.forEach(function (el) { el.classList.add('near'); });
    nearSet = next;
  }
  function clearNear() {
    nearSet.forEach(function (el) { el.classList.remove('near'); el.style.removeProperty('--near'); }); nearSet = [];
    if (lastCard) lastCard.classList.remove('lit'); lastCard = null;
  }
  document.addEventListener('pointermove', function (e) {
    if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    mx = e.clientX; my = e.clientY;
    if (!raf) raf = requestAnimationFrame(frame);
  }, { passive: true });
  document.addEventListener('mouseout', function (e) { if (!e.relatedTarget) { mx = my = -1e4; clearNear(); } });
  window.addEventListener('hashchange', function () { nearSet = []; lastCard = null; });
  document.documentElement.classList.add('fx-on');
})();
