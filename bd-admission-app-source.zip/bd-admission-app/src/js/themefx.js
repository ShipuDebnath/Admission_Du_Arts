/* =========================================================
   themefx.js — ইন্টারঅ্যাক্টিভ গ্লাস থিম (Glass Rainbow, Glass Forest)
   - কার্সর/আঙুলের অবস্থান → --gx/--gy (নরম আলো) ও --px/--py (parallax)
   - স্ক্রল → --sp (Rainbow-এ রঙ ঘোরে)
   - ট্যাপ/ক্লিক → ছোট ঢেউ (ripple)
   Reduce Motion চালু থাকলে কিছুই চলে না।
   ========================================================= */
(function () {
  'use strict';
  var root = document.documentElement;
  var LIVE = { rainbow: 1, forestglass: 1 };
  var mqReduce = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  function on() {
    return LIVE[root.getAttribute('data-theme')] && root.getAttribute('data-motion') !== 'reduce' && !(mqReduce && mqReduce.matches);
  }
  var tx = 0, ty = 0, pending = false, hideT;
  function flush() {
    pending = false;
    var w = window.innerWidth || 1, h = window.innerHeight || 1;
    root.style.setProperty('--gx', tx + 'px');
    root.style.setProperty('--gy', ty + 'px');
    root.style.setProperty('--px', ((tx / w) * 2 - 1).toFixed(3));
    root.style.setProperty('--py', ((ty / h) * 2 - 1).toFixed(3));
    root.style.setProperty('--go', '1');
    clearTimeout(hideT);
    hideT = setTimeout(function () { root.style.setProperty('--go', '0'); }, 1800);
  }
  function move(e) {
    if (!on()) return;
    tx = e.clientX; ty = e.clientY;
    if (!pending) { pending = true; requestAnimationFrame(flush); }
  }
  window.addEventListener('pointermove', move, { passive: true });

  var sp = false;
  window.addEventListener('scroll', function () {
    if (!on() || sp) return;
    sp = true;
    requestAnimationFrame(function () {
      sp = false;
      var max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      root.style.setProperty('--sp', (window.scrollY / max).toFixed(3));
    });
  }, { passive: true });

  var hue = 0;
  window.addEventListener('pointerdown', function (e) {
    if (!on()) return;
    move(e);
    var r = document.createElement('span');
    r.className = 'tfx-ripple';
    r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
    hue = (hue + 47) % 360; r.style.setProperty('--rh', hue);
    document.body.appendChild(r);
    setTimeout(function () { if (r.parentNode) r.parentNode.removeChild(r); }, 750);
  }, { passive: true });
})();
