/* =========================================================
   ca.js — Phase 6: সাম্প্রতিক হাব
   মাসভিত্তিক প্যাক (ঘটনা + MCQ + Flashcard) · "সর্বশেষ হালনাগাদ" ব্যানার ও পুরোনো-সতর্কতা
   Import: সাম্প্রতিক ঘটনা ({date,t,d,src,lid?,exp?}) ও প্রশ্ন (ca/exp ফিল্ডসহ) — অফলাইনে, এই ডিভাইসে
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast;
  var MON = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  function $v() { return C.view(); }
  function today() { return C.todayKey(); }
  function monthName(m) { var p = String(m).split('-'); return p.length < 2 ? m : MON[+p[1] - 1] + ' ' + num(p[0]); }
  function fmtDate(d) { var p = String(d).split('-'); return p.length === 3 ? num(+p[2]) + ' ' + monthName(p[0] + '-' + p[1]) : monthName(d); }
  function pack() { return (Data.has('ca/packs') && Data.get('ca/packs')) || { updated: '', staleDays: 45, items: [] }; }
  function userItems() { return Store.get('caitems', []) || []; }
  function allItems() {
    return pack().items.concat(userItems().map(function (x) { var y = {}; for (var k in x) y[k] = x[k]; y.user = true; return y; }))
      .sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; });
  }
  function expired(x) { return !!(x.exp && x.exp < today()); }
  function daysSince(d) { return d ? Math.floor((new Date(today() + 'T00:00:00') - new Date(d + 'T00:00:00')) / 86400000) : 0; }

  /* মাসভিত্তিক সারাংশ: ঘটনা, MCQ, কার্ড */
  function months() {
    var M = {};
    function m(k) { return M[k] || (M[k] = { m: k, items: 0, q: 0, c: 0, exp: 0 }); }
    allItems().forEach(function (x) { m(x.date.slice(0, 7)).items++; });
    QB.all().forEach(function (q) { if (q.ca) { var o = m(q.ca.slice(0, 7)); if (QB.isExpired(q)) o.exp++; else o.q++; } });
    QB.cards().forEach(function (c) { if (c.ca) m(c.ca.slice(0, 7)).c++; });
    return Object.keys(M).sort().reverse().map(function (k) { return M[k]; });
  }

  function banner() {
    var P = pack(), up = P.updated, extra = userItems().length;
    if (!up) return '<div class="banner warn">সাম্প্রতিক প্যাক পাওয়া যায়নি।</div>';
    var age = daysSince(up), stale = age > (P.staleDays || 45);
    return '<div class="banner ' + (stale ? 'warn' : 'ok') + '" id="caupd">🗓 <b>সর্বশেষ হালনাগাদ: ' + fmtDate(up) + '</b>' +
      (stale ? ' — ⚠️ প্যাকটি ' + num(age) + ' দিন পুরোনো। এর পরের ঘটনা এখানে নেই; পত্রিকা/অফিসিয়াল সূত্রে মিলিয়ে নিন বা নতুন প্যাক Import করুন।'
        : ' (' + num(age) + ' দিন আগে)। পরীক্ষার আগে নতুন ঘটনা নিজে মিলিয়ে নিন।') +
      (extra ? '<br><span class="small">+ আপনার Import করা ' + num(extra) + 'টি ঘটনা</span>' : '') + '</div>';
  }

  function viewHub() {
    C.setTop('সাম্প্রতিক হাব', { back: true });
    var ms = months();
    var tq = 0, tc = 0, ti = 0;
    ms.forEach(function (x) { tq += x.q; tc += x.c; ti += x.items; });
    var html = banner() +
      '<section class="card"><div class="grid2">' +
      '<div class="stat"><span class="small muted">ঘটনা</span><b>' + num(ti) + '</b></div>' +
      '<div class="stat"><span class="small muted">MCQ · Flashcard</span><b>' + num(tq) + ' · ' + num(tc) + '</b></div></div>' +
      '<div class="row wrap" style="margin-top:.75rem"><a class="btn primary" href="#/quiz/ca/all">⚡ সব সাম্প্রতিক — Quiz</a>' +
      '<a class="btn" href="#/flash/review?cam=all">🃏 সব Flashcard</a><a class="btn" href="#/s/ca">📚 বিষয়ভিত্তিক পাঠ</a></div></section>' +
      '<h2 class="sec-h">মাসভিত্তিক প্যাক</h2><div id="calist">' +
      ms.map(function (x) {
        return '<div class="card tight ca-month"><div class="row"><a class="spacer" href="#/ca/m/' + x.m + '" style="text-decoration:none;color:inherit"><b>' + monthName(x.m) + '</b>' +
          '<div class="small muted">' + num(x.items) + 'টি ঘটনা · ' + num(x.q) + 'টি MCQ · ' + num(x.c) + 'টি কার্ড' + (x.exp ? ' · ' + num(x.exp) + 'টি মেয়াদোত্তীর্ণ' : '') + '</div></a>' +
          (x.q ? '<a class="btn sm" href="#/quiz/ca/' + x.m + '" aria-label="' + monthName(x.m) + ' Quiz">Quiz</a>' : '') +
          (x.c ? '<a class="btn sm" href="#/flash/review?cam=' + x.m + '" aria-label="' + monthName(x.m) + ' Flashcard">🃏</a>' : '') + '</div></div>';
      }).join('') + '</div>' +
      '<section class="card"><h3 style="margin-top:0">নতুন প্যাক যোগ করুন</h3><p class="small muted">নতুন মাসের ঘটনা বা প্রশ্ন JSON ফাইল থেকে Import করা যায় — ইন্টারনেট লাগে না, তথ্য এই ডিভাইসেই থাকে।</p>' +
      '<a class="btn" href="#/ca/import">⬆️ সাম্প্রতিক Import</a></section>';
    $v().innerHTML = html;
  }

  function viewMonth(mo) {
    var name = monthName(mo);
    C.setTop(name + ' — সাম্প্রতিক', { back: true });
    var items = allItems().filter(function (x) { return x.date.slice(0, 7) === mo; });
    var qn = QB.all().filter(function (q) { return q.ca && q.ca.slice(0, 7) === mo && !QB.isExpired(q); }).length;
    var cn = QB.cards().filter(function (c) { return c.ca && c.ca.slice(0, 7) === mo; }).length;
    var html = banner() + '<section class="card tight"><div class="row wrap">' +
      (qn ? '<a class="btn primary" href="#/quiz/ca/' + mo + '">⚡ ' + name + ' Quiz (' + num(Math.min(qn, 20)) + ')</a>' : '<span class="small muted">এ মাসের কোনো সক্রিয় MCQ নেই</span>') +
      (cn ? '<a class="btn" href="#/flash/review?cam=' + mo + '">🃏 Flashcard (' + num(cn) + ')</a>' : '') + '</div></section>' +
      '<div class="ca-items">' + (items.length ? items.map(function (x) {
        var L = x.lid && C.LMAP[x.lid];
        return '<article class="card tight ca-item"><div class="small muted">' + fmtDate(x.date) +
          (x.user ? ' · <span class="chip">Import</span>' : '') + (expired(x) ? ' · <span class="chip verify">মেয়াদোত্তীর্ণ</span>' : '') + '</div>' +
          '<h3>' + esc(x.t) + '</h3>' + (x.d ? '<p>' + esc(x.d) + '</p>' : '') +
          '<div class="small muted">সূত্র: ' + esc(x.src || '—') + '</div>' +
          (L ? '<a class="small" href="#/l/' + L.id + '">📖 পাঠ: ' + esc(L.t) + '</a>' : '') + '</article>';
      }).join('') : '<p class="muted">এ মাসের কোনো ঘটনা নেই।</p>') + '</div>';
    $v().innerHTML = html;
  }

  /* ---------- Import ---------- */
  function validItem(x) {
    return x && typeof x === 'object' && /^\d{4}-\d{2}(-\d{2})?$/.test(String(x.date || '')) && String(x.t || '').trim();
  }
  function viewImport() {
    C.setTop('সাম্প্রতিক Import', { back: true });
    var sample = '{\n  "items": [\n    {"date": "2026-11-05", "t": "ঘটনার শিরোনাম", "d": "বিস্তারিত", "src": "সূত্র ও তারিখ", "lid": "ca-1-1", "exp": "2028-11-30"}\n  ],\n  "q": [\n    {"q": "প্রশ্ন?", "o": ["ক", "খ", "গ", "ঘ"], "a": 0, "explanation": "ব্যাখ্যা", "lid": "ca-1-1", "ca": "2026-11-05", "exp": "2028-11-30"}\n  ]\n}';
    $v().innerHTML = '<section class="card"><p class="small">ঘটনা (<code>items</code>) ও প্রশ্ন (<code>q</code>) — যেকোনোটি বা দুটিই দিতে পারেন। <code>date</code>/<code>ca</code> = ঘটনার তারিখ (YYYY-MM-DD বা YYYY-MM), <code>exp</code> = মেয়াদ। তারিখ অনুযায়ী মাসিক প্যাকে বসে যাবে।</p>' +
      '<div class="field"><label for="cafile">JSON ফাইল</label><input type="file" id="cafile" accept=".json,application/json"></div>' +
      '<div class="field"><label for="catext">অথবা এখানে পেস্ট করুন</label><textarea id="catext" rows="9" placeholder="' + esc(sample) + '"></textarea></div>' +
      '<div class="row wrap"><button class="btn primary" id="cago">যাচাই করে যোগ করুন</button>' +
      (userItems().length ? '<button class="btn" id="caclr">আমার Import করা ঘটনা মুছুন (' + num(userItems().length) + ')</button>' : '') + '</div>' +
      '<div id="cares" aria-live="polite"></div></section>' +
      '<details class="card"><summary>নমুনা ফরম্যাট</summary><pre class="small" style="white-space:pre-wrap">' + esc(sample) + '</pre></details>';
    var f = document.getElementById('cafile');
    f.onchange = function () { var r = new FileReader(); r.onload = function () { document.getElementById('catext').value = r.result; }; if (f.files[0]) r.readAsText(f.files[0]); };
    document.getElementById('cago').onclick = function () { doImport(document.getElementById('catext').value); };
    var clr = document.getElementById('caclr');
    if (clr) clr.onclick = function () { Store.set('caitems', [], 0); toast('Import করা ঘটনা মুছে ফেলা হয়েছে'); viewImport(); };
  }
  function doImport(text) {
    var out = document.getElementById('cares'), j;
    try { j = JSON.parse(String(text || '').trim()); } catch (e) { out.innerHTML = '<div class="banner bad">JSON পড়া যায়নি: ' + esc(e.message) + '</div>'; return; }
    var arr = Array.isArray(j) ? j : [];
    var its = (j.items || []).concat(arr.filter(function (x) { return x && x.date && x.t && !x.q; }));
    var qsA = (j.q || j.questions || []).concat(arr.filter(function (x) { return x && x.q && x.o; }));
    var okI = [], badI = 0;
    its.forEach(function (x) {
      if (!validItem(x)) { badI++; return; }
      okI.push({ date: String(x.date), t: String(x.t).trim(), d: String(x.d || '').trim(), src: String(x.src || x.source || '').trim(), lid: x.lid && C.LMAP[x.lid] ? x.lid : '', exp: x.exp ? String(x.exp) : '' });
    });
    var qres = qsA.length ? QB.parseImport(JSON.stringify(qsA), 'ca.json') : { ok: [], bad: [] };
    var okQ = qres.ok.map(function (r) { if (!r.q.sub || r.q.sub === 'misc') r.q.sub = 'ca'; return r.q; });
    var noDate = okQ.filter(function (q) { return !q.ca; }).length;
    if (okI.length) {
      var cur = userItems().slice(), key = {};
      cur.forEach(function (x) { key[x.date + '|' + x.t] = 1; });
      okI.forEach(function (x) { if (!key[x.date + '|' + x.t]) cur.push(x); });
      Store.set('caitems', cur, 0);
    }
    if (okQ.length) QB.addUser(okQ);
    out.innerHTML = '<div class="banner ' + (okI.length || okQ.length ? 'ok' : 'warn') + '">যোগ হয়েছে: ' + num(okI.length) + 'টি ঘটনা, ' + num(okQ.length) + 'টি প্রশ্ন।' +
      (badI ? ' বাদ: ' + num(badI) + 'টি ঘটনা (date/t নেই)।' : '') + (qres.bad.length ? ' বাদ: ' + num(qres.bad.length) + 'টি প্রশ্ন (ত্রুটিপূর্ণ)।' : '') +
      (noDate ? ' ⚠️ ' + num(noDate) + 'টি প্রশ্নে "ca" তারিখ নেই — মাসিক প্যাকে দেখাবে না।' : '') + '</div>' +
      (okI.length || okQ.length ? '<a class="btn" href="#/ca">হাবে ফিরুন</a>' : '');
  }

  window.CA = { monthName: monthName, months: months };
  C.addRoute(/^#\/ca\/import/, viewImport);
  C.addRoute(/^#\/ca\/m\/(\d{4}-\d{2})/, function (m) { viewMonth(m[1]); });
  C.addRoute(/^#\/ca\/?$/, viewHub);
})();
