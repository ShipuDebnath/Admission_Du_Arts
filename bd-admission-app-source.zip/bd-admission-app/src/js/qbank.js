/* =========================================================
   qbank.js — প্রশ্নব্যাংক, পরিসংখ্যান, ভুলের খাতা (F3),
   Flashcard Spaced Repetition (F2), PYQ/প্রশ্ন Import (PART E)
   ---------------------------------------------------------
   অভ্যন্তরীণ প্রশ্ন স্কিমা (সংক্ষিপ্ত কী):
   { id, sub, lid, d (1 সহজ/2 মাঝারি/3 কঠিন), src ('PYQ'|'PYQ-Style'|'মৌলিক'),
     q, o:[], a (সঠিক অপশনের সূচক), e:{ r: নিয়ম, t: টিপ, f: সম্পর্কিত তথ্য, w:[অপশনভিত্তিক কারণ] },
     exam, unit, session, year, sn (sourceNote), v (verified), ca (সাম্প্রতিক: তারিখ), exp (মেয়াদ) }
   ========================================================= */
(function (global) {
  'use strict';

  var cache = null, byId = {}, cardCache = null;
  var TOC = null, LMAP = {}, SMAP = {};
  function toc() {
    if (TOC) return;
    TOC = Data.get('toc');
    TOC.subjects.forEach(function (s) {
      SMAP[s.id] = s;
      s.ch.forEach(function (c) { c.l.forEach(function (l) { l.sid = s.id; l.cid = c.id; LMAP[l.id] = l; }); });
    });
  }

  function now() { return Date.now(); }
  function clone(o) { var c = {}; for (var k in o) c[k] = o[k]; return c; }

  var QB = {
    /* ---------------- প্রশ্ন ---------------- */
    all: function () {
      if (cache) return cache;
      toc();
      cache = []; byId = {};
      var push = function (q, origin) {
        if (!q || !q.id || byId[q.id]) return;
        q._o = origin;
        if (!q.sub && q.lid && LMAP[q.lid]) q.sub = LMAP[q.lid].sid;
        q.cid = q.lid && LMAP[q.lid] ? LMAP[q.lid].cid : null;
        byId[q.id] = q; cache.push(q);
      };
      Data.list('questions/').concat(Data.list('pyq/'), Data.list('current-affairs/')).forEach(function (n) {
        var d = Data.get(n);
        var arr = Array.isArray(d) ? d : (d && (d.q || d.items)) || [];
        arr.forEach(function (q) { push(q, n); });
      });
      (Store.get('userq', []) || []).forEach(function (q) { push(q, 'user'); });
      return cache;
    },
    invalidate: function () { cache = null; cardCache = null; },
    get: function (id) { QB.all(); return byId[id] || null; },
    forLesson: function (lid) { return QB.all().filter(function (q) { return q.lid === lid; }); },
    forSubject: function (sid) { return QB.all().filter(function (q) { return q.sub === sid; }); },
    isExpired: function (q) { return !!(q.exp && q.exp < new Date().toISOString().slice(0, 10)); },
    isPYQ: function (q) { return q.src === 'PYQ' && q.v === true; },
    srcLabel: function (q) { return QB.isPYQ(q) ? 'PYQ' : (q.src === 'PYQ' ? 'PYQ-Style' : (q.src || 'মৌলিক')); },

    /* opts: {subs, cids, lids, src: all|pyq|mistakes|new|ca, noExpired} */
    filter: function (opts) {
      opts = opts || {};
      var st = Store.get('qstat', {}), mist = Store.get('mist', {});
      return QB.all().filter(function (q) {
        if (opts.subs && opts.subs.length && opts.subs.indexOf(q.sub) < 0) return false;
        if (opts.cids && opts.cids.length && opts.cids.indexOf(q.cid) < 0) return false;
        if (opts.lids && opts.lids.length && opts.lids.indexOf(q.lid) < 0) return false;
        if (opts.noExpired && QB.isExpired(q)) return false;
        switch (opts.src) {
          case 'pyq': return !!q.exam;
          case 'mistakes': return mist[q.id] && !mist[q.id].mastered;
          case 'new': return !st[q.id];
          case 'ca': return !!q.ca;
        }
        return true;
      });
    },

    /* উত্তর রেকর্ড: chosen = অপশন সূচক বা -1 (বাদ) ; ফেরত: সঠিক কি না */
    record: function (qid, chosen, sec) {
      var q = QB.get(qid); if (!q) return false;
      var ok = chosen === q.a;
      var st = clone(Store.get('qstat', {}));
      var r = st[qid] ? clone(st[qid]) : { n: 0, c: 0 };
      if (chosen >= 0) { r.n++; if (ok) r.c++; }
      r.last = ok ? 1 : 0; r.t = now(); if (sec) r.sec = Math.round(sec);
      st[qid] = r;
      Store.set('qstat', st, 300);

      // ভুলের খাতা (F3): ভুল বা বাদ → জমা; সঠিক → ধারাবাহিকতা বাড়ে, ৩ বার পরপর = আয়ত্ত
      var mist = clone(Store.get('mist', {}));
      var m = mist[qid] ? clone(mist[qid]) : null;
      if (!ok) {
        m = m || { n: 0, reason: '' };
        m.n++; m.ok = 0; m.t = now(); m.mastered = false; m.skip = chosen < 0;
        mist[qid] = m;
      } else if (m && !m.mastered) {
        m.ok = (m.ok || 0) + 1; m.t = now();
        if (m.ok >= 3) m.mastered = true;
        mist[qid] = m;
      }
      Store.set('mist', mist, 300);
      return ok;
    },
    stat: function (qid) { return Store.get('qstat', {})[qid] || null; },

    /* Mastery % = যেসব প্রশ্নের শেষ উত্তর সঠিক / মোট প্রশ্ন ; Quiz Score % = মোট সঠিক / মোট চেষ্টা */
    mastery: function (qs) {
      if (!qs.length) return null;
      var st = Store.get('qstat', {}), m = 0, n = 0, c = 0, tried = 0;
      qs.forEach(function (q) { var r = st[q.id]; if (r) { tried++; n += r.n; c += r.c; if (r.last) m++; } });
      return { mastery: m * 100 / qs.length, score: n ? c * 100 / n : null, tried: tried, total: qs.length };
    },

    mistakes: function (includeMastered) {
      var mist = Store.get('mist', {});
      return Object.keys(mist).filter(function (id) { return QB.get(id) && (includeMastered || !mist[id].mastered); })
        .map(function (id) { var o = clone(mist[id]); o.id = id; o.q = QB.get(id); return o; })
        .sort(function (a, b) { return b.t - a.t; });
    },
    setReason: function (qid, reason) {
      var mist = clone(Store.get('mist', {}));
      if (!mist[qid]) return;
      mist[qid] = clone(mist[qid]); mist[qid].reason = reason;
      Store.set('mist', mist, 0);
    },
    removeMistake: function (qid) {
      var mist = clone(Store.get('mist', {})); delete mist[qid]; Store.set('mist', mist, 0);
    },

    /* ---------------- Flashcard (F2) ---------------- */
    cards: function () {
      if (cardCache) return cardCache;
      toc();
      cardCache = [];
      var seen = {};
      Data.list('flashcards/').forEach(function (n) {
        var d = Data.get(n); (d && d.cards || []).forEach(function (c) { if (!seen[c.id]) { seen[c.id] = 1; cardCache.push(c); } });
      });
      (Store.get('ufc', []) || []).forEach(function (c) { if (!seen[c.id]) { seen[c.id] = 1; c.user = true; cardCache.push(c); } });
      cardCache.forEach(function (c) { if (!c.sub && c.lid && LMAP[c.lid]) c.sub = LMAP[c.lid].sid; c.cid = c.lid && LMAP[c.lid] ? LMAP[c.lid].cid : null; });
      return cardCache;
    },
    cardState: function (id) { return Store.get('fc', {})[id] || null; },
    isDue: function (c, at) { var s = QB.cardState(c.id); return !s || s.due <= (at || now()); },
    isWeak: function (c) { var s = QB.cardState(c.id); return !!(s && (s.lapses >= 2 || s.ef < 2.0)); },
    /* SM-2 ধাঁচ: grade 0=Again 1=Hard 2=Good 3=Easy ; ফেরত পরবর্তী বিরতি (দিন) */
    review: function (id, grade) {
      var all = clone(Store.get('fc', {}));
      var s = all[id] ? clone(all[id]) : { ivl: 0, ef: 2.5, reps: 0, lapses: 0 };
      var day = 86400000;
      if (grade === 0) { s.lapses++; s.reps = 0; s.ivl = 0; s.ef = Math.max(1.3, s.ef - 0.2); s.due = now() + 60 * 1000; }
      else {
        if (grade === 1) { s.ivl = Math.max(1, Math.round((s.ivl || 1) * 1.2)); s.ef = Math.max(1.3, s.ef - 0.15); }
        else if (grade === 2) { s.ivl = s.reps === 0 ? 1 : s.reps === 1 ? 3 : Math.round(s.ivl * s.ef); }
        else { s.ivl = s.reps === 0 ? 3 : Math.round(Math.max(s.ivl, 1) * s.ef * 1.3); s.ef += 0.15; }
        s.reps++;
        s.due = now() + s.ivl * day;
      }
      s.t = now();
      all[id] = s;
      Store.set('fc', all, 0);
      return s.ivl;
    },
    addCard: function (card) {
      var arr = (Store.get('ufc', []) || []).slice();
      card.id = 'ufc-' + now().toString(36);
      arr.push(card); Store.set('ufc', arr, 0); cardCache = null;
      return card;
    },
    removeCard: function (id) {
      Store.set('ufc', (Store.get('ufc', []) || []).filter(function (c) { return c.id !== id; }), 0); cardCache = null;
    },

    /* ---------------- Import (JSON/CSV) ---------------- */
    parseCSV: function (text) {
      var rows = [], row = [], f = '', i = 0, q = false;
      text = text.replace(/^﻿/, '');
      for (; i < text.length; i++) {
        var ch = text[i];
        if (q) {
          if (ch === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; }
          else f += ch;
        } else if (ch === '"') q = true;
        else if (ch === ',') { row.push(f); f = ''; }
        else if (ch === '\n' || ch === '\r') {
          if (ch === '\r' && text[i + 1] === '\n') i++;
          row.push(f); f = ''; if (row.join('').trim()) rows.push(row); row = [];
        } else f += ch;
      }
      row.push(f); if (row.join('').trim()) rows.push(row);
      if (!rows.length) return [];
      var head = rows[0].map(function (h) { return h.trim(); });
      return rows.slice(1).map(function (r) { var o = {}; head.forEach(function (h, k) { o[h] = (r[k] || '').trim(); }); return o; });
    },

    /* PART E স্কিমা {id, exam, unit, session, year, subject, topicId, type, question, options[], answer,
       explanation, sourceNote, verified} বা অভ্যন্তরীণ সংক্ষিপ্ত স্কিমা — দুটোই নেয় */
    normalize: function (x, i) {
      toc();
      var errs = [];
      var opts = x.o || x.options;
      if (typeof opts === 'string') opts = opts.split('|');
      if (!opts) { opts = []; for (var k = 1; k <= 6; k++) { var v = x['option' + k] || x['o' + k]; if (v) opts.push(v); } }
      opts = (opts || []).map(function (s) { return String(s).trim(); }).filter(Boolean);
      var qt = String(x.q || x.question || '').trim();
      var ans = x.a !== undefined ? x.a : x.answer;
      var ai = -1;
      if (typeof ans === 'number') ai = ans;
      else if (ans !== undefined && ans !== null) {
        var as = String(ans).trim();
        if (/^[A-Fa-f]$/.test(as) && opts.indexOf(as) < 0) ai = as.toUpperCase().charCodeAt(0) - 65;
        else if (/^[1-6১-৬]$/.test(as) && opts.indexOf(as) < 0) ai = parseInt(as.replace(/[১-৬]/, function (d) { return '০১২৩৪৫৬'.indexOf(d); }), 10) - 1;
        else ai = opts.indexOf(as);
      }
      if (!qt) errs.push('প্রশ্ন নেই');
      if (opts.length < 2) errs.push('অপশন ২টির কম');
      if (ai < 0 || ai >= opts.length) errs.push('উত্তর অপশনের সাথে মেলে না');
      var uniq = {}; opts.forEach(function (o) { uniq[o] = 1; });
      if (Object.keys(uniq).length !== opts.length) errs.push('একই অপশন দুবার');
      // বিষয় ও টপিক
      var sub = x.sub || x.subject || '';
      if (sub && !SMAP[sub]) {
        var low = String(sub).toLowerCase();
        Object.keys(SMAP).forEach(function (id) { var s = SMAP[id]; if (s.t === sub || s.en.toLowerCase() === low || s.t.indexOf(sub) >= 0) sub = id; });
      }
      var lid = x.lid || x.topicId || '';
      if (lid && !LMAP[lid]) { errs.push('topicId অজানা: ' + lid); lid = ''; }
      if (!sub && lid) sub = LMAP[lid].sid;
      var verified = x.v === true || x.verified === true || /^(true|yes|1|হ্যাঁ)$/i.test(String(x.verified || ''));
      var sn = String(x.sn || x.sourceNote || '').trim();
      var isPyq = verified && !!sn && !!(x.exam);
      var e = x.e;
      if (!e) e = { r: String(x.explanation || '').trim() };
      if (!e.r) errs.push('ব্যাখ্যা নেই (সতর্কতা)');
      var d = parseInt(x.d || x.difficulty, 10); if (!(d >= 1 && d <= 3)) d = 2;
      var out = {
        id: String(x.id || ('imp-' + now().toString(36) + '-' + i)), sub: sub || 'misc', lid: lid, d: d,
        src: isPyq ? 'PYQ' : (x.exam ? 'PYQ-Style' : (x.src && x.src !== 'PYQ' ? x.src : 'মৌলিক')),
        q: qt, o: opts, a: ai, e: e
      };
      ['exam', 'unit', 'session', 'year', 'ca', 'exp'].forEach(function (k) { if (x[k]) out[k] = String(x[k]); });
      if (sn) out.sn = sn;
      out.v = verified;
      var fatal = errs.filter(function (m) { return m.indexOf('সতর্কতা') < 0 && m.indexOf('topicId') < 0; });
      return { q: out, errs: errs, fatal: fatal.length > 0 };
    },
    parseImport: function (text, filename) {
      var raw;
      text = String(text || '').trim();
      if (/\.csv$/i.test(filename || '') || (!/^[\[{]/.test(text) && text.indexOf(',') > 0)) raw = QB.parseCSV(text);
      else { var j = JSON.parse(text); raw = Array.isArray(j) ? j : (j.q || j.items || j.questions || []); }
      var ok = [], bad = [];
      raw.forEach(function (x, i) {
        var r = QB.normalize(x, i);
        if (r.fatal) bad.push({ row: i + 1, id: x.id, errs: r.errs }); else ok.push(r);
      });
      return { ok: ok, bad: bad };
    },
    addUser: function (qs) {
      var cur = (Store.get('userq', []) || []).slice();
      var idx = {}; cur.forEach(function (q, i) { idx[q.id] = i; });
      qs.forEach(function (q) { if (idx[q.id] !== undefined) cur[idx[q.id]] = q; else cur.push(q); });
      Store.set('userq', cur, 0);
      QB.invalidate();
      return cur.length;
    },

    shuffle: function (arr) {
      var a = arr.slice();
      for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
      return a;
    }
  };

  global.QB = QB;
})(window);
