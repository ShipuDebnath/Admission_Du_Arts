/* =========================================================
   lesson.js — PART D: ব্লকভিত্তিক পাঠ রেন্ডারার ও ইন্টারেক্টিভ ফিগার
   পাঠের স্কিমা: { b: [ব্লক], src: [সূত্র], v?: যাচাই-বাকি নোট }
   ব্লক (k = ধরন):
     h        {x}                         উপশিরোনাম
     p        {x}                         অনুচ্ছেদ (**গাঢ়**, ==হাইলাইট== চলে)
     list     {x:[..], o?:1}              তালিকা (o = ক্রমিক)
     facts    {h?, x:[..]}                Important Facts Box
     summary  {x:[..]}                    এক নজরে রিভিশন কার্ড
     table    {h, c:[কলাম], r:[[..]]}     সারণি — সর্ট, ফিল্টার, Label Hide
     timeline {h, x:[{y, t, d?, g?}]}     টাইমলাইন — ট্যাপে বিবরণ, "সাল লুকাও", "ক্রম মেলাও"
     match    {h, x:[[বাম, ডান]]}         মিলকরণ ফিগার (ট্যাপ করে মেলাও)
     mnemonic {x:[{m, f, how}]}           মনে রাখার কৌশল
     mistakes {x:[..]}                    Common Mistakes
     tricks   {x:[..]}                    Exam Tricks
     quote    {q, s?, ctx?, e}            উদ্ধৃতি ও ব্যাখ্যা (শুধু কপিরাইটমুক্ত রচনা)
     words    {h?, x:[[শব্দ, অর্থ]]}      শব্দার্থ/টীকা
     entries  {h, x:[{w,bn,en?,syn?,ant?,ctx?,ex?}]}  শব্দ/Idiom/প্রবাদ কার্ড — ট্যাপে বিস্তারিত, খোঁজা যায়
     uni      {x}                         University-wise Analysis
     verify   {x}                         যাচাই-বাকি নোট
   ========================================================= */
(function (global) {
  'use strict';
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };
  function inline(s) {
    return esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/==(.+?)==/g, '<mark class="kw">$1</mark>');
  }
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(n) { return String(n).replace(/[0-9]/g, function (d) { return BN[+d]; }); }

  /* শব্দসংখ্যা (পড়ার সময় হিসাবের জন্য) */
  function words(lesson) {
    var n = 0;
    function cnt(v) {
      if (v == null) return;
      if (typeof v === 'string') { n += v.split(/\s+/).filter(Boolean).length; return; }
      if (Array.isArray(v)) { v.forEach(cnt); return; }
      if (typeof v === 'object') { Object.keys(v).forEach(function (k) { if (k !== 'k' && k !== 'g') cnt(v[k]); }); }
    }
    (lesson.b || []).forEach(cnt);
    return n;
  }

  function render(lesson) {
    var fig = 0, tab = 0;
    var out = (lesson.b || []).map(function (bl, i) {
      var id = 'blk' + i;
      switch (bl.k) {
        case 'h': return '<h2 class="lh">' + inline(bl.x) + '</h2>';
        case 'p': return '<p>' + inline(bl.x) + '</p>';
        case 'list': return (bl.o ? '<ol>' : '<ul>') + bl.x.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + (bl.o ? '</ol>' : '</ul>');
        case 'facts': return '<aside class="box facts"><div class="box-h">📌 ' + inline(bl.h || 'গুরুত্বপূর্ণ তথ্য') + '</div><ul>' + bl.x.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ul></aside>';
        case 'summary': return '<aside class="box summary"><div class="box-h">🗂 এক নজরে (রিভিশন কার্ড)</div><ul>' + bl.x.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ul></aside>';
        case 'mistakes': return '<aside class="box warnbox"><div class="box-h">⚠️ সাধারণ ভুল</div><ul>' + bl.x.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ul></aside>';
        case 'tricks': return '<aside class="box tricks"><div class="box-h">🎯 পরীক্ষার কৌশল</div><ul>' + bl.x.map(function (x) { return '<li>' + inline(x) + '</li>'; }).join('') + '</ul></aside>';
        case 'uni': return '<aside class="box"><div class="box-h">🏛 বিশ্ববিদ্যালয়ভিত্তিক বিশ্লেষণ</div><p>' + inline(bl.x) + '</p></aside>';
        case 'verify': return '<div class="banner warn"><span class="chip verify">Verify</span> ' + inline(bl.x) + '</div>';
        case 'mnemonic':
          return '<aside class="box mnem"><div class="box-h">🧠 মনে রাখার কৌশল</div>' + bl.x.map(function (m) {
            return '<div class="mn"><div class="mn-m">' + inline(m.m) + '</div><div class="small"><b>কীসের জন্য:</b> ' + inline(m.f) + '</div><div class="small"><b>কীভাবে মেলাবেন:</b> ' + inline(m.how) + '</div></div>';
          }).join('') + '</aside>';
        case 'quote':
          return '<figure class="quote"><blockquote>' + inline(bl.q) + '</blockquote>' + (bl.s ? '<figcaption>— ' + inline(bl.s) + '</figcaption>' : '') +
            (bl.ctx ? '<p class="small"><b>প্রসঙ্গ:</b> ' + inline(bl.ctx) + '</p>' : '') + '<p class="small"><b>ব্যাখ্যা:</b> ' + inline(bl.e) + '</p></figure>';
        case 'words':
          return '<div class="figure"><div class="fig-h">' + inline(bl.h || 'শব্দার্থ ও টীকা') + '</div><dl class="gloss">' +
            bl.x.map(function (w) { return '<dt>' + inline(w[0]) + '</dt><dd>' + inline(w[1]) + '</dd>'; }).join('') + '</dl></div>';
        case 'entries':
          var EL = [['en', 'English meaning'], ['syn', 'Synonyms'], ['ant', 'Antonyms'], ['ctx', 'উৎস ও প্রসঙ্গ'], ['ex', 'উদাহরণ']];
          return '<div class="figure" data-fig="entries" id="' + id + '"><div class="fig-h">' + inline(bl.h) + ' <span class="small muted">(' + bn(bl.x.length) + 'টি · ট্যাপে বিস্তারিত)</span></div>' +
            '<div class="fig-tools noprint"><input type="search" class="efilter" placeholder="খুঁজুন…" aria-label="কার্ডে খুঁজুন"><button class="btn sm e-all" aria-pressed="false">সব খোলো</button></div>' +
            '<div class="ent-list">' + bl.x.map(function (e) {
              return '<details class="ent"><summary><b class="ent-w">' + inline(e.w) + '</b><span class="ent-bn">' + inline(e.bn) + '</span></summary><dl>' +
                EL.filter(function (f) { return e[f[0]]; }).map(function (f) { return '<dt>' + f[1] + '</dt><dd>' + inline(e[f[0]]) + '</dd>'; }).join('') + '</dl></details>';
            }).join('') + '</div></div>';
        case 'table':
          tab++;
          return '<div class="figure" data-fig="table" id="' + id + '"><div class="fig-h">সারণি ' + bn(tab) + ': ' + inline(bl.h) + '</div>' +
            '<div class="fig-tools noprint"><input type="search" class="tfilter" placeholder="সারণিতে খুঁজুন…" aria-label="সারণিতে খুঁজুন">' +
            (bl.c.length > 1 ? '<button class="btn sm thide" aria-pressed="false">' + window.Core.T('labelhide') + '</button>' : '') + '</div>' +
            '<div class="tscroll"><table class="data ltable"><thead><tr>' + bl.c.map(function (c, ci) { return '<th><button class="tsort" data-ci="' + ci + '">' + inline(c) + ' ⇅</button></th>'; }).join('') + '</tr></thead><tbody>' +
            bl.r.map(function (r) { return '<tr>' + r.map(function (c, ci) { return '<td' + (ci === r.length - 1 && bl.c.length > 1 ? ' class="hidecell"' : '') + '>' + inline(c) + '</td>'; }).join('') + '</tr>'; }).join('') +
            '</tbody></table></div><div class="small muted noprint">শিরোনামে ট্যাপ = সাজান · "শেষ কলাম লুকাও" = শেষ কলাম লুকিয়ে নিজে মনে করুন, ঘরে ট্যাপ করলে দেখাবে</div></div>';
        case 'timeline':
          fig++;
          var groups = [];
          bl.x.forEach(function (e) { if (e.g && groups.indexOf(e.g) < 0) groups.push(e.g); });
          return '<div class="figure" data-fig="timeline" id="' + id + '"><div class="fig-h">চিত্র ' + bn(fig) + ': ' + inline(bl.h) + '</div>' +
            '<div class="fig-tools noprint"><button class="btn sm tl-hide" aria-pressed="false">সাল লুকাও</button><button class="btn sm tl-order">ক্রম মেলাও</button></div>' +
            '<ol class="tl">' + bl.x.map(function (e, j) {
              return '<li class="tl-i g' + (groups.indexOf(e.g) % 4) + '" data-j="' + j + '"><button class="tl-btn" aria-expanded="false"><span class="tl-y">' + inline(e.y) + '</span><span class="tl-t">' + inline(e.t) + '</span></button>' +
                (e.d ? '<div class="tl-d" hidden>' + inline(e.d) + '</div>' : '') + '</li>';
            }).join('') + '</ol>' +
            (groups.length ? '<div class="legend">' + groups.map(function (g, gi) { return '<span><i class="lg g' + (gi % 4) + '"></i>' + esc(g) + '</span>'; }).join('') + '</div>' : '') + '</div>';
        case 'match':
          fig++;
          return '<div class="figure" data-fig="match" id="' + id + '"><div class="fig-h">চিত্র ' + bn(fig) + ': ' + inline(bl.h) + ' <span class="small muted">(বাম থেকে একটি, তারপর ডান থেকে মিল বাছুন)</span></div>' +
            '<div class="match"><div class="m-col m-l">' + bl.x.map(function (p, j) { return '<button class="m-it" data-j="' + j + '">' + inline(p[0]) + '</button>'; }).join('') + '</div>' +
            '<div class="m-col m-r"></div></div><div class="row noprint"><span class="small muted spacer m-score"></span><button class="btn sm m-reset">আবার</button></div></div>';
      }
      return '';
    }).join('');
    if (lesson.src && lesson.src.length) {
      out += '<details class="srcs"><summary>📚 তথ্যসূত্র (' + bn(lesson.src.length) + ')</summary><ul>' + lesson.src.map(function (s) { return '<li>' + inline(s) + '</li>'; }).join('') + '</ul></details>';
    }
    return out;
  }

  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ইন্টারেক্টিভিটি বাঁধা */
  function bind(root, lesson) {
    root.querySelectorAll('[data-fig="entries"]').forEach(function (fg) {
      var items = Array.prototype.slice.call(fg.querySelectorAll('.ent'));
      fg.querySelector('.efilter').addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        items.forEach(function (d) { d.hidden = q && d.textContent.toLowerCase().indexOf(q) < 0; });
      });
      var b = fg.querySelector('.e-all');
      b.addEventListener('click', function () {
        var on = b.getAttribute('aria-pressed') !== 'true'; b.setAttribute('aria-pressed', on);
        b.textContent = on ? 'সব বন্ধ' : 'সব খোলো';
        items.forEach(function (d) { d.open = on; });
      });
    });
    // সারণি
    root.querySelectorAll('[data-fig="table"]').forEach(function (fg) {
      var tb = fg.querySelector('tbody');
      var rows = Array.prototype.slice.call(tb.rows);
      fg.querySelector('.tfilter').addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        rows.forEach(function (r) { r.hidden = q && r.textContent.toLowerCase().indexOf(q) < 0; });
      });
      var dir = {};
      fg.querySelectorAll('.tsort').forEach(function (b) {
        b.addEventListener('click', function () {
          var ci = +b.getAttribute('data-ci'); dir[ci] = !dir[ci];
          rows.sort(function (a, c) {
            var x = a.cells[ci].textContent, y = c.cells[ci].textContent;
            return (dir[ci] ? 1 : -1) * x.localeCompare(y, 'bn', { numeric: true });
          });
          rows.forEach(function (r) { tb.appendChild(r); });
        });
      });
      var hb = fg.querySelector('.thide');
      if (hb) hb.addEventListener('click', function () {
        var on = hb.getAttribute('aria-pressed') !== 'true';
        hb.setAttribute('aria-pressed', on); fg.classList.toggle('lblhide', on);
        fg.querySelectorAll('.hidecell').forEach(function (c) { c.classList.remove('shown'); });
      });
      fg.addEventListener('click', function (e) { var c = e.target.closest('.hidecell'); if (c && fg.classList.contains('lblhide')) c.classList.add('shown'); });
    });
    // টাইমলাইন
    root.querySelectorAll('[data-fig="timeline"]').forEach(function (fg) {
      var ol = fg.querySelector('.tl');
      var items = Array.prototype.slice.call(ol.children);
      ol.addEventListener('click', function (e) {
        var b = e.target.closest('.tl-btn'); if (!b || fg.classList.contains('ordering')) return;
        var d = b.parentNode.querySelector('.tl-d');
        if (d) { d.hidden = !d.hidden; b.setAttribute('aria-expanded', !d.hidden); }
        if (fg.classList.contains('nodates')) b.parentNode.classList.toggle('reveal');
      });
      var hb = fg.querySelector('.tl-hide');
      hb.addEventListener('click', function () {
        var on = hb.getAttribute('aria-pressed') !== 'true';
        hb.setAttribute('aria-pressed', on); fg.classList.toggle('nodates', on);
        items.forEach(function (it) { it.classList.remove('reveal'); });
      });
      var ob = fg.querySelector('.tl-order');
      ob.addEventListener('click', function () {
        if (fg.classList.contains('ordering')) { // যাচাই
          var cur = Array.prototype.slice.call(ol.children).map(function (li) { return +li.getAttribute('data-j'); });
          var ok = 0;
          Array.prototype.slice.call(ol.children).forEach(function (li, k) {
            var good = +li.getAttribute('data-j') === k;
            li.classList.toggle('ok', good); li.classList.toggle('bad', !good); if (good) ok++;
          });
          fg.classList.remove('ordering'); fg.classList.add('nodates', 'checked');
          ob.textContent = 'ঠিক ' + bn(ok) + '/' + bn(cur.length) + ' · সঠিক ক্রম দেখাও';
          return;
        }
        if (fg.classList.contains('checked')) {
          fg.classList.remove('checked', 'nodates');
          items.forEach(function (it) { it.classList.remove('ok', 'bad'); ol.appendChild(it); });
          ob.textContent = 'ক্রম মেলাও';
          return;
        }
        fg.classList.add('ordering', 'nodates');
        shuffle(items).forEach(function (it) { ol.appendChild(it); it.classList.remove('ok', 'bad'); });
        ob.textContent = 'যাচাই করুন';
        selected = null;
      });
      var selected = null;
      ol.addEventListener('click', function (e) {
        if (!fg.classList.contains('ordering')) return;
        var li = e.target.closest('.tl-i'); if (!li) return;
        if (!selected) { selected = li; li.classList.add('picked'); return; }
        if (selected !== li) { // অদলবদল
          var tmp = document.createElement('li');
          ol.replaceChild(tmp, selected); ol.replaceChild(selected, li); ol.replaceChild(li, tmp);
        }
        selected.classList.remove('picked'); selected = null;
      });
    });
    // মিলকরণ
    root.querySelectorAll('[data-fig="match"]').forEach(function (fg, fi) {
      var bi = +fg.id.replace('blk', '');
      var pairs = lesson.b[bi].x;
      var R = fg.querySelector('.m-r'), L = fg.querySelector('.m-l'), sc = fg.querySelector('.m-score');
      var pick = null, done = 0, tries = 0;
      function setup() {
        R.innerHTML = shuffle(pairs.map(function (p, j) { return j; })).map(function (j) { return '<button class="m-it" data-j="' + j + '">' + inline(pairs[j][1]) + '</button>'; }).join('');
        L.querySelectorAll('.m-it').forEach(function (b) { b.className = 'm-it'; b.disabled = false; });
        pick = null; done = 0; tries = 0; sc.textContent = '';
      }
      L.addEventListener('click', function (e) {
        var b = e.target.closest('.m-it'); if (!b || b.disabled) return;
        if (pick) pick.classList.remove('picked');
        pick = b; b.classList.add('picked');
      });
      R.addEventListener('click', function (e) {
        var b = e.target.closest('.m-it'); if (!b || b.disabled || !pick) return;
        tries++;
        if (b.getAttribute('data-j') === pick.getAttribute('data-j')) {
          b.classList.add('ok'); pick.classList.remove('picked'); pick.classList.add('ok'); b.disabled = pick.disabled = true; pick = null; done++;
        } else { b.classList.add('bad'); setTimeout(function () { b.classList.remove('bad'); }, 600); }
        sc.textContent = 'মিলেছে ' + bn(done) + '/' + bn(pairs.length) + ' · চেষ্টা ' + bn(tries);
      });
      fg.querySelector('.m-reset').addEventListener('click', setup);
      setup();
    });
  }

  global.LessonRender = { render: render, bind: bind, words: words };
})(window);
