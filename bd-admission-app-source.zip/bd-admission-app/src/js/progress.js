/* =========================================================
   progress.js — প্রতিটি পাতার একদম উপরে পাতলা স্ক্রল-অগ্রগতি রেখা
   পাতা যতটুকু স্ক্রল হয়েছে, রেখা ততটুকু ভরে — পাতার কোন অংশে আছেন বোঝা যায়।
   ========================================================= */
(function () {
  'use strict';
  var bar = document.createElement('div');
  bar.id = 'scrollprog';
  bar.setAttribute('role', 'progressbar');
  bar.setAttribute('aria-label', 'পাতার কতটুকু পড়া হয়েছে');
  bar.setAttribute('aria-valuemin', '0');
  bar.setAttribute('aria-valuemax', '100');
  bar.innerHTML = '<span></span>';
  var fill = bar.firstChild, ticking = false;
  function update() {
    ticking = false;
    var de = document.documentElement;
    var max = Math.max(0, (de.scrollHeight || document.body.scrollHeight) - window.innerHeight);
    var p = max > 4 ? Math.min(1, Math.max(0, (window.scrollY || de.scrollTop) / max)) : 0;
    fill.style.transform = 'scaleX(' + p.toFixed(4) + ')';
    bar.classList.toggle('none', max <= 4);
    bar.setAttribute('aria-valuenow', String(Math.round(p * 100)));
  }
  function req() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
  function mount() {
    var host = document.querySelector('.topbar') || document.body;   // হেডারের নিচের কিনারায় বসে
    if (!host.contains(bar)) host.appendChild(bar);
    if (host !== document.body) bar.classList.add('in-top');
    update();
    window.addEventListener('scroll', req, { passive: true });
    window.addEventListener('resize', req);
    window.addEventListener('hashchange', function () { setTimeout(update, 60); });
    // পাতার কনটেন্ট বদলালে (রাউট, details খোলা, কার্ড খোলা) দৈর্ঘ্য বদলায়
    if (window.MutationObserver) new MutationObserver(req).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['open', 'hidden'] });
    if (window.ResizeObserver) new ResizeObserver(req).observe(document.body);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();
})();
