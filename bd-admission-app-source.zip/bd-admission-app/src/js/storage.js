/* =========================================================
   storage.js — F4: Auto Save ও Backup স্তর
   - IndexedDB প্রধান, localStorage ব্যাকআপ (write-through)
   - কোনোটি না চললে memory মোড + ব্যবহারকারীকে সতর্কবার্তা
   - প্রতিটি রেকর্ড {v: মান, t: সময়} আকারে; বুটে দুই জায়গার মধ্যে নতুনটি নেওয়া হয়
   - Export/Import: JSON ফাইল + Copy/Paste ব্যাকআপ কোড (WebView-এ ডাউনলোড না চললে)
   ========================================================= */
(function (global) {
  'use strict';

  var DB_NAME = 'bdadm';
  var STORE = 'kv';
  var LS_PREFIX = 'bdadm:';
  var APP_ID = 'bd-admission-superapp';

  var cache = {};         // key -> {v, t}
  var db = null;
  var hasIDB = false;
  var hasLS = false;
  var listeners = [];
  var pending = {};       // key -> timer (debounce)

  function now() { return Date.now(); }

  /* ---------- localStorage ---------- */
  function lsTest() {
    try {
      var k = LS_PREFIX + '__t';
      localStorage.setItem(k, '1');
      localStorage.removeItem(k);
      return true;
    } catch (e) { return false; }
  }
  function lsGetAll() {
    var out = {};
    if (!hasLS) return out;
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf(LS_PREFIX) === 0 && k !== LS_PREFIX + '__t') {
          try { out[k.slice(LS_PREFIX.length)] = JSON.parse(localStorage.getItem(k)); } catch (e) { /* নষ্ট রেকর্ড বাদ */ }
        }
      }
    } catch (e) { /* ignore */ }
    return out;
  }
  function lsPut(key, rec) {
    if (!hasLS) return false;
    try { localStorage.setItem(LS_PREFIX + key, JSON.stringify(rec)); return true; }
    catch (e) { return false; } // কোটা পূর্ণ ইত্যাদি
  }
  function lsDel(key) { if (hasLS) { try { localStorage.removeItem(LS_PREFIX + key); } catch (e) { } } }

  /* ---------- IndexedDB ---------- */
  function idbOpen() {
    return new Promise(function (resolve) {
      var idb;
      try { idb = global.indexedDB; } catch (e) { idb = null; }
      if (!idb) return resolve(null);
      var done = false;
      var timer = setTimeout(function () { if (!done) { done = true; resolve(null); } }, 2500); // কিছু WebView-এ open ঝুলে থাকে
      try {
        var req = idb.open(DB_NAME, 1);
        req.onupgradeneeded = function () { req.result.createObjectStore(STORE); };
        req.onsuccess = function () { if (!done) { done = true; clearTimeout(timer); resolve(req.result); } };
        req.onerror = req.onblocked = function () { if (!done) { done = true; clearTimeout(timer); resolve(null); } };
      } catch (e) { done = true; clearTimeout(timer); resolve(null); }
    });
  }
  function idbGetAll() {
    return new Promise(function (resolve) {
      if (!db) return resolve({});
      var out = {};
      try {
        var tx = db.transaction(STORE, 'readonly');
        var st = tx.objectStore(STORE);
        var cur = st.openCursor();
        cur.onsuccess = function () {
          var c = cur.result;
          if (c) { out[c.key] = c.value; c.continue(); } else resolve(out);
        };
        cur.onerror = function () { resolve(out); };
      } catch (e) { resolve(out); }
    });
  }
  function idbPut(key, rec) {
    return new Promise(function (resolve) {
      if (!db) return resolve(false);
      try {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).put(rec, key);
        tx.oncomplete = function () { resolve(true); };
        tx.onerror = tx.onabort = function () { resolve(false); };
      } catch (e) { resolve(false); }
    });
  }
  function idbDel(key) {
    return new Promise(function (resolve) {
      if (!db) return resolve(false);
      try {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).delete(key);
        tx.oncomplete = function () { resolve(true); };
        tx.onerror = function () { resolve(false); };
      } catch (e) { resolve(false); }
    });
  }

  /* ---------- Public API ---------- */
  var Store = {
    mode: 'memory',
    ready: null,
    lastSaveOk: true,

    init: function () {
      hasLS = lsTest();
      Store.ready = idbOpen().then(function (d) {
        db = d; hasIDB = !!d;
        return idbGetAll();
      }).then(function (fromIDB) {
        var fromLS = lsGetAll();
        var keys = {};
        Object.keys(fromIDB).forEach(function (k) { keys[k] = 1; });
        Object.keys(fromLS).forEach(function (k) { keys[k] = 1; });
        Object.keys(keys).forEach(function (k) {
          var a = fromIDB[k], b = fromLS[k];
          var pick = (!a) ? b : (!b) ? a : ((b.t || 0) > (a.t || 0) ? b : a);
          if (pick && typeof pick === 'object' && 't' in pick) cache[k] = pick;
          // দুই জায়গা মিলিয়ে নেওয়া (একটিতে না থাকলে বা পুরোনো হলে)
          if (pick && hasIDB && pick !== a) idbPut(k, pick);
          if (pick && hasLS && pick !== b) lsPut(k, pick);
        });
        Store.mode = hasIDB && hasLS ? 'idb+ls' : hasIDB ? 'idb' : hasLS ? 'ls' : 'memory';
        // ব্রাউজারকে ডেটা স্থায়ী রাখতে অনুরোধ (সমর্থিত হলে)
        try { if (navigator.storage && navigator.storage.persist) { var pp = navigator.storage.persist(); if (pp && pp.catch) pp.catch(function () { }); } } catch (e) { }
        return Store.mode;
      });
      return Store.ready;
    },

    get: function (key, def) {
      var r = cache[key];
      return r ? r.v : def;
    },

    /* তাৎক্ষণিক মেমরিতে, ডিস্কে লেখা debounce (ms) করে; 0 দিলে সাথে সাথে */
    set: function (key, val, debounceMs) {
      cache[key] = { v: val, t: now() };
      var ms = debounceMs == null ? 250 : debounceMs;
      if (pending[key]) clearTimeout(pending[key]);
      if (ms === 0) return Store._flush(key);
      pending[key] = setTimeout(function () { Store._flush(key); }, ms);
      return Promise.resolve(true);
    },

    _flush: function (key) {
      delete pending[key];
      var rec = cache[key];
      if (!rec) return Promise.resolve(true);
      var okLS = lsPut(key, rec);
      return idbPut(key, rec).then(function (okIDB) {
        var ok = okIDB || okLS;
        if (ok !== Store.lastSaveOk) {
          Store.lastSaveOk = ok;
          listeners.forEach(function (fn) { try { fn(ok); } catch (e) { } });
        }
        return ok;
      });
    },

    flushAll: function () {
      return Promise.all(Object.keys(pending).map(function (k) { clearTimeout(pending[k]); return Store._flush(k); }));
    },

    del: function (key) {
      delete cache[key];
      lsDel(key);
      return idbDel(key);
    },

    keys: function () { return Object.keys(cache); },

    onSaveStatus: function (fn) { listeners.push(fn); },

    /* ---------- Backup ---------- */
    exportObject: function () {
      var data = {};
      Object.keys(cache).forEach(function (k) { data[k] = cache[k]; });
      return { app: APP_ID, schema: 1, exportedAt: new Date().toISOString(), data: data };
    },

    exportJSON: function () { return JSON.stringify(Store.exportObject()); },

    /* ইউনিকোড-নিরাপদ Base64 ব্যাকআপ কোড */
    exportCode: function () {
      var s = Store.exportJSON();
      return 'BDADM1:' + btoa(unescape(encodeURIComponent(s)));
    },

    parseBackup: function (text) {
      text = (text || '').trim();
      if (text.indexOf('BDADM1:') === 0) text = decodeURIComponent(escape(atob(text.slice(7).replace(/\s+/g, ''))));
      var obj = JSON.parse(text);
      if (!obj || obj.app !== APP_ID || !obj.data) throw new Error('এটি এই অ্যাপের ব্যাকআপ নয়');
      return obj;
    },

    /* mode: 'replace' (সব মুছে বসানো) বা 'merge' (প্রতি কী-তে নতুনটি) */
    importBackup: function (text, mode) {
      var obj = Store.parseBackup(text);
      var tasks = [];
      if (mode === 'replace') Object.keys(cache).forEach(function (k) { tasks.push(Store.del(k)); });
      return Promise.all(tasks).then(function () {
        var n = 0;
        Object.keys(obj.data).forEach(function (k) {
          var rec = obj.data[k];
          if (!rec || typeof rec !== 'object' || !('v' in rec)) return;
          var cur = cache[k];
          if (mode === 'replace' || !cur || (rec.t || 0) >= (cur.t || 0)) {
            cache[k] = { v: rec.v, t: rec.t || now() };
            n++;
          }
        });
        return Promise.all(Object.keys(cache).map(function (k) { return Store._flush(k); })).then(function () { return n; });
      });
    },

    /* ফাইল ডাউনলোড; ব্যর্থ হলে false (তখন Copy কোড দেখাতে হবে) */
    download: function (filename, text) {
      try {
        var blob = new Blob([text], { type: 'application/json' });
        if (global.navigator && global.navigator.msSaveBlob) { global.navigator.msSaveBlob(blob, filename); return true; }
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = filename; a.rel = 'noopener';
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
        return true;
      } catch (e) { return false; }
    }
  };

  // অ্যাপ ব্যাকগ্রাউন্ডে গেলে/বন্ধ হলে সাথে সাথে সব লিখে ফেলা
  try {
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') Store.flushAll(); });
    global.addEventListener('pagehide', function () { Store.flushAll(); });
  } catch (e) { }

  global.Store = Store;
})(window);
