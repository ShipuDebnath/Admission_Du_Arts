/* =========================================================
   data.js — ডেটা লোডার (file:// ও WebView-বান্ধব; fetch ব্যবহার নেই)
   দুই উৎস:
   1) ডেভ মোড: build.py-এর তৈরি src/data/js/<name>.js ফাইল
      যা window.__D["<name>"] = {...} সেট করে (<script src> দিয়ে লোড)।
   2) Single-file build: <script type="application/json" id="d-<name>">
      — শুধু প্রথমবার দরকার হলে JSON.parse হয় (Lazy Parse)।
   ========================================================= */
(function (global) {
  'use strict';
  var parsed = {};
  global.Data = {
    has: function (name) {
      return !!((global.__D && global.__D[name]) || document.getElementById('d-' + name));
    },
    /* উপসর্গ দিয়ে ডেটাসেটের নাম তালিকা, যেমন list('questions/') */
    list: function (prefix) {
      var names = {};
      if (global.__D) Object.keys(global.__D).forEach(function (k) { names[k] = 1; });
      var els = document.querySelectorAll('script[type="application/json"][id^="d-"]');
      for (var i = 0; i < els.length; i++) names[els[i].id.slice(2)] = 1;
      return Object.keys(names).filter(function (n) { return !prefix || n.indexOf(prefix) === 0; }).sort();
    },
    get: function (name) {
      if (parsed[name]) return parsed[name];
      var v = global.__D && global.__D[name];
      if (!v) {
        var el = document.getElementById('d-' + name);
        if (el) {
          try { v = JSON.parse(el.textContent); } catch (e) { console.error('ডেটা পার্স ব্যর্থ:', name, e); v = null; }
        }
      }
      if (v) parsed[name] = v;
      return v || null;
    }
  };
})(window);
