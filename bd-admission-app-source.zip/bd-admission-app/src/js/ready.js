/* তৈরি কনটেন্ট হাব (#/ready) — যেসব অধ্যায়ে কনটেন্ট/প্রশ্ন প্রস্তুত, সরাসরি সেখানে ঢোকার পথ।
   হোমে একটি বড় "তৈরি কনটেন্ট" কার্ড, আর অধ্যায়ভিত্তিক কুইজ রুট (#/quiz/c/:cid)। */
(function () {
  'use strict';
  var C = window.Core, esc = C.esc, num = C.num;

  // অধ্যায়ভিত্তিক গণনা (প্রতি রেন্ডারে একবার)
  function counts() {
    var q = {}, f = {};
    QB.all().forEach(function (x) { if (x.lid) q[x.lid] = (q[x.lid] || 0) + 1; });
    QB.cards().forEach(function (x) { if (x.lid) f[x.lid] = (f[x.lid] || 0) + 1; });
    return { q: q, f: f };
  }
  function readyChapters() {
    var out = [];
    C.SUBJ.forEach(function (s) {
      s.ch.forEach(function (c) {
        var ls = c.l.filter(function (l) { return l.has; });
        if (ls.length) out.push({ s: s, c: c, ls: ls });
      });
    });
    return out;
  }
  function qOnlySubjects(rc) {
    // কনটেন্ট-পাঠ নেই কিন্তু প্রশ্নব্যাংক আছে এমন বিষয়
    var withLesson = {}; rc.forEach(function (x) { withLesson[x.s.id] = 1; });
    return C.SUBJ.filter(function (s) { return !withLesson[s.id] && QB.forSubject(s.id).length; });
  }
  C.readyInfo = function () {
    var rc = readyChapters(), cn = counts(), nl = 0, nq = 0;
    rc.forEach(function (x) { x.ls.forEach(function (l) { nl++; nq += cn.q[l.id] || 0; }); });
    return { rc: rc, cn: cn, lessons: nl, mcq: nq };
  };
  C.lessonPop = function (l, cn, done) {
    var parts = ['⏱ ' + C.fmtMin(l.m)];
    if (l.has) {
      if (cn.q[l.id]) parts.push('MCQ ' + num(cn.q[l.id]));
      if (cn.f[l.id]) parts.push('Flashcard ' + num(cn.f[l.id]));
      parts.push(done ? '✓ সম্পন্ন' : '✅ কনটেন্ট প্রস্তুত');
    } else parts.push('⏳ কনটেন্ট পরের Phase-এ');
    return parts.join(' · ');
  };

  function chapCard(x, cn, dm) {
    var nq = 0, nf = 0, nd = 0;
    x.ls.forEach(function (l) { nq += cn.q[l.id] || 0; nf += cn.f[l.id] || 0; if (dm[l.id]) nd++; });
    var next = x.ls.filter(function (l) { return !dm[l.id]; })[0] || x.ls[0];
    var pct = Math.round(nd * 100 / x.ls.length);
    return '<section class="card ready-card fx" id="rc-' + x.c.id + '">' +
      '<div class="small muted">' + x.s.icon + ' ' + esc(x.s.t) + '</div>' +
      '<h2 style="margin:.15rem 0 .35rem">' + esc(x.c.t.replace(/^ব্লক\s*[^·]*·\s*/, '')) + '</h2>' +
      '<div class="row wrap" style="gap:.35rem;margin-bottom:.55rem">' +
      '<span class="chip ok">📖 ' + num(x.ls.length) + ' পাঠ</span>' +
      (nq ? '<span class="chip">❓ ' + num(nq) + ' MCQ</span>' : '') +
      (nf ? '<span class="chip">🃏 ' + num(nf) + ' কার্ড</span>' : '') +
      '<span class="chip">' + num(nd) + '/' + num(x.ls.length) + ' সম্পন্ন</span></div>' +
      '<div class="pbar sm" style="margin-bottom:.6rem"><span style="width:' + pct + '%"></span></div>' +
      '<ul class="rl">' + x.ls.map(function (l) {
        var d = !!dm[l.id];
        return '<li><a class="rl-a fx' + (d ? ' done' : '') + '" href="#/l/' + l.id + '" data-pop="' + esc(C.lessonPop(l, cn, d)) + '">' +
          '<span class="rl-dot" aria-hidden="true">' + (d ? '✓' : '›') + '</span>' +
          '<span class="spacer">' + esc(l.t.replace(/^[^:]+:\s*/, '')) + '</span>' +
          (cn.q[l.id] ? '<span class="rl-n">' + num(cn.q[l.id]) + '</span>' : '') + '</a></li>';
      }).join('') + '</ul>' +
      '<div class="row wrap" style="margin-top:.7rem">' +
      '<a class="btn primary" href="#/l/' + next.id + '">' + (nd ? 'চালিয়ে যান →' : 'পড়া শুরু →') + '</a>' +
      (nq ? '<a class="btn" href="#/quiz/c/' + x.c.id + '">⚡ অধ্যায় কুইজ</a>' : '') +
      (nf ? '<a class="btn" href="#/flash/review?sub=' + x.s.id + '&cid=' + x.c.id + '&mode=all">🃏 কার্ড</a>' : '') +
      '</div></section>';
  }

  function viewReady() {
    C.setTop('তৈরি কনটেন্ট', { back: true });
    var info = C.readyInfo(), dm = Store.get('done', {});
    var html = '<div class="card tight"><b>' + num(info.rc.length) + 'টি অধ্যায় · ' + num(info.lessons) + 'টি পাঠ · ' + num(info.mcq) + 'টি MCQ</b> প্রস্তুত।' +
      '<div class="small muted">নিচের যেকোনো পাঠে সরাসরি ঢুকুন; বাকি পাঠ্যসূচি ধাপে ধাপে যোগ হচ্ছে।</div></div>';
    // দ্রুত লাফ
    html += '<nav class="row wrap jump" aria-label="অধ্যায়ে যান" style="margin-bottom:.8rem">' + info.rc.map(function (x) {
      return '<a class="chip fx" href="#/ready" data-jump="rc-' + x.c.id + '">' + esc(x.c.t.replace(/^ব্লক\s*[^·]*·\s*\S+\s*—\s*/, '')) + '</a>';
    }).join('') + '</nav>';
    html += info.rc.map(function (x) { return chapCard(x, info.cn, dm); }).join('');
    var qo = qOnlySubjects(info.rc);
    if (qo.length) html += '<h2 style="margin:1.1rem 0 .5rem">শুধু প্রশ্নব্যাংক প্রস্তুত</h2>' + qo.map(function (s) {
      var n = QB.forSubject(s.id).length;
      return '<a class="card tight row fx" style="text-decoration:none;color:inherit" href="#/quiz/s/' + s.id + '" data-pop="' + esc(num(n) + 'টি MCQ — পাঠ-কনটেন্ট Phase ' + num(C.PHASE_OF[s.id] || 0) + '-এ') + '">' +
        '<span style="font-size:1.4rem">' + s.icon + '</span><div class="spacer"><b>' + esc(s.t) + '</b><div class="small muted">' + num(n) + 'টি MCQ</div></div><span class="btn">কুইজ →</span></a>';
    }).join('');
    var V = C.view(); V.innerHTML = html;
    V.querySelectorAll('[data-jump]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        var t = document.getElementById(a.getAttribute('data-jump'));
        if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); t.classList.add('flash-hl'); setTimeout(function () { t.classList.remove('flash-hl'); }, 1200); }
      });
    });
  }

  C.addRoute(/^#\/ready/, viewReady, 'syllabus');
  C.addRoute(/^#\/quiz\/c\/([\w-]+)/, function (m) {
    var c = C.CMAP[m[1]];
    if (!c) { location.replace('#/ready'); return; }
    var pool = QB.all().filter(function (q) { var l = C.LMAP[q.lid]; return l && l.cid === m[1]; });
    window.Practice.runQuiz({ title: c.t.replace(/^ব্লক\s*[^·]*·\s*/, '') + ' — অধ্যায় কুইজ', pool: pool, adaptive: true, len: 15, backHref: '#/ready' });
  }, 'practice');

  // হোম: তৈরি কনটেন্টের সারসংক্ষেপ + শুধু সাম্প্রতিক ৩টি অধ্যায় (চালিয়ে যাওয়ার জন্য)
  C.addHome(function () {
    var info = C.readyInfo();
    if (!info.rc.length) return '';
    var dm = Store.get('done', {}), en = C.settings().lang === 'en';
    var byC = {}; info.rc.forEach(function (x) { byC[x.c.id] = x; });
    var pick = [], seen = {};
    function add(cid) { if (byC[cid] && !seen[cid] && pick.length < 3) { seen[cid] = 1; pick.push(byC[cid]); } }
    var lastL = {};
    (Store.get('recent', []) || []).forEach(function (r) { if (r) { if (!lastL[r.cid] && r.lid) lastL[r.cid] = r.lid; add(r.cid); } });
    // পুরোনো ব্যবহারকারী: সম্পন্ন পাঠের সময় থেকে সাম্প্রতিক অধ্যায়
    if (pick.length < 3) {
      Object.keys(dm).filter(function (lid) { return C.LMAP[lid]; })
        .sort(function (a, b) { return (+dm[b] || 0) - (+dm[a] || 0); })
        .forEach(function (lid) { add(C.LMAP[lid].cid); });
    }
    var resumed = pick.length;
    var mine = C.unitSubjects();
    if (pick.length < 3) info.rc.forEach(function (x) { if (mine.indexOf(x.s) >= 0 && x.ls.some(function (l) { return !dm[l.id]; })) add(x.c.id); });
    if (pick.length < 3) info.rc.forEach(function (x) { if (x.ls.some(function (l) { return !dm[l.id]; })) add(x.c.id); });
    var items = pick.map(function (x) {
      var nd = x.ls.filter(function (l) { return dm[l.id]; }).length;
      var rl = lastL[x.c.id];
      var next = (rl && !dm[rl] && C.LMAP[rl]) ? C.LMAP[rl] : (x.ls.filter(function (l) { return !dm[l.id]; })[0] || x.ls[0]);
      var pc = Math.round(nd * 100 / x.ls.length);
      return '<a class="rs-item fx" href="#/l/' + next.id + '" title="' + esc((en ? 'Next: ' : 'পরের পাঠ: ') + next.t) + '" data-pop="' + esc((en ? 'Next: ' : 'পরের পাঠ: ') + next.t) + '">' +
        '<b>' + esc(x.c.t.replace(/^ব্লক\s*[^·]*·\s*\S+\s*—\s*/, '').replace(/^অধ্যায়\s*[০-৯0-9]+:\s*/, '')) + '</b>' +
        '<span class="rs-sub">' + esc(x.s.t) + '</span>' +
        '<span class="rs-bar" aria-hidden="true"><i style="width:' + pc + '%"></i></span>' +
        '<span class="rs-n">' + num(nd) + '/' + num(x.ls.length) + '</span></a>';
    }).join('');
    return '<section class="card ready-home fx"><div class="row"><div class="spacer"><div class="small muted">' + (en ? '✅ Ready content' : '✅ তৈরি কনটেন্ট') + '</div>' +
      '<h2 style="margin:0">' + num(info.lessons) + (en ? ' lessons · ' : ' পাঠ · ') + num(info.mcq) + ' MCQ</h2></div><a class="btn primary" href="#/ready">' + (en ? 'See all →' : 'সব দেখুন →') + '</a></div>' +
      (items ? '<div class="small muted" style="margin:.6rem 0 .35rem">' + (resumed ? (en ? 'Your last ' + resumed + ' — tap to continue' : 'সর্বশেষ শুরু করা ' + num(resumed) + 'টি — ট্যাপ করে চালিয়ে যান') : (en ? 'Start here' : 'এখান থেকে শুরু করুন')) + '</div><div class="rs-list">' + items + '</div>' : '') +
      '</section>';
  }, true, 'ready', 'তৈরি কনটেন্ট ও চলমান পাঠ');
})();
