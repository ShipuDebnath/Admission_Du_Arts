/* =========================================================
   written.js — Phase 8: DU লিখিত ল্যাব (PART I) — শুধু DU-র জন্য
   টপিক তালিকা ও কৌশল · মডেল উত্তর · নম্বর বণ্টন · পরীক্ষকের নোট · Self-Evaluation Checklist
   আগের বছরের যাচাইকৃত প্রশ্ন · Timed Writing (৪৫ মিনিট) · শব্দ গণনা · Auto-Save · নিজের লেখা সংরক্ষণ
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast;
  function $v() { return C.view(); }
  function D() { return (Data.has('written/du') && Data.get('written/du')) || { sections: [], pyq: [], analysis: [] }; }
  function topics() { var a = []; D().sections.forEach(function (s) { s.topics.forEach(function (t) { t.sec = s.id; a.push(t); }); }); return a; }
  function topic(id) { return topics().filter(function (t) { return t.id === id; })[0]; }
  function duUnit() {
    var s = C.settings(), u = C.UNITS[s.unit];
    if (u && u.writtenLab) return u;
    return C.UNITS['du-b'];
  }
  function chip(v) { return v ? '' : ' <span class="chip verify">Verify</span>'; }
  function words(t) { t = String(t || '').trim(); return t ? t.split(/\s+/).length : 0; }
  function fmt(sec) {
    sec = Math.max(0, Math.round(sec));
    var m = Math.floor(sec / 60), s = sec % 60;
    return num((m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s);
  }
  function md(x) { return esc(x).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>'); }

  /* ---------------- হাব ---------------- */
  function structureBanner() {
    var s = C.settings(), cur = C.UNITS[s.unit], u = duUnit();
    var w = u && u.written;
    var h = '';
    if (!cur || !cur.writtenLab) h += '<div class="banner warn" id="wl-note">ℹ️ লিখিত অংশ শুধু ঢাকা বিশ্ববিদ্যালয়ের ভর্তি পরীক্ষায় আছে। আপনার নির্বাচিত ইউনিটে (' + esc(cur ? cur.code + ' — ' + cur.name : '—') + ') লিখিত নেই — অনুশীলন চাইলে নিচে DU B ইউনিটের কাঠামো দেখানো হলো।</div>';
    if (w) {
      h += '<section class="card" id="wl-struct"><div class="small muted">' + esc(u.track ? u.track.name.split(' (')[0] : 'ঢাকা বিশ্ববিদ্যালয়') + ' · ' + esc(u.code + ' — ' + u.name) + '</div>' +
        '<h2 style="margin:.2rem 0 .5rem">লিখিত ' + num(w.marks) + ' নম্বর · ' + num(w.minutes) + ' মিনিট' + chip(w.verified || w.totalsVerified) + '</h2>' + (w.sectionsNote ? '<p class="small muted" style="margin:0 0 .5rem">' + esc(w.sectionsNote) + '</p>' : '') +
        (w.sections && w.sections.length ? '<div class="grid2">' + w.sections.map(function (x) { return '<div class="stat"><span class="small muted">' + esc(x.label) + '</span><b>' + num(x.marks) + '</b></div>'; }).join('') + '</div>' : '<p class="small muted">বিষয়ভিত্তিক নম্বর বণ্টন যাচাই বাকি। <span class="chip verify">Verify</span></p>') +
        (u.pass && u.pass.written ? '<p class="small" style="margin:.5rem 0 0">লিখিত অংশে পাস: ' + num(u.pass.written) + chip(u.pass.verified) + (u.pass.mcq ? ' · লিখিত খাতা দেখা হয় MCQ-তে ন্যূনতম ' + num(u.pass.mcq) + ' পেলে' : '') + '</p>' : '') + '</section>';
    }
    return h;
  }
  function viewHub() {
    C.setTop('DU লিখিত ল্যাব', { back: true });
    var saved = Store.get('wsaved', []) || [];
    var d = D();
    var html = structureBanner() +
      '<div class="hub">' +
      '<a href="#/written/full"><span class="hi" aria-hidden="true">⏱</span><b>পূর্ণ লিখিত অনুশীলন</b><span class="small">' + num((duUnit().written || {}).minutes || 45) + ' মিনিটের টাইমার</span></a>' +
      '<a href="#/written/mine"><span class="hi" aria-hidden="true">📂</span><b>আমার লেখা</b><span class="small">' + num(saved.length) + 'টি সংরক্ষিত</span></a>' +
      '<a href="#/written/pyq"><span class="hi" aria-hidden="true">🗂</span><b>আগের বছরের প্রশ্ন</b><span class="small">' + num(d.pyq.length) + 'টি যাচাইকৃত</span></a>' +
      '<a href="#/written/analysis"><span class="hi" aria-hidden="true">📊</span><b>প্রশ্নধারা বিশ্লেষণ</b><span class="small">কোন ধরন কত নম্বরে</span></a></div>';
    d.sections.forEach(function (s) {
      html += '<h2 class="sec-h">' + esc(s.t) + '</h2><div class="wl-topics">' + s.topics.map(function (t) {
        var n = saved.filter(function (x) { return x.tid === t.id; }).length;
        return '<a class="card tight row wl-topic" href="#/written/t/' + t.id + '" style="text-decoration:none;color:inherit"><span class="wl-ic" aria-hidden="true">' + (t.icon || '✍️') + '</span>' +
          '<div class="spacer"><b>' + esc(t.t) + '</b><div class="small muted">' + esc(t.sub || '') + (n ? ' · লিখেছেন ' + num(n) + ' বার' : '') + '</div></div>' +
          (t.seen ? '<span class="chip ok">PYQ-তে এসেছে</span>' : '') + '</a>';
      }).join('') + '</div>';
    });
    $v().innerHTML = html;
  }

  /* ---------------- টপিক ---------------- */
  function viewTopic(id) {
    var t = topic(id);
    if (!t) { location.replace('#/written'); return; }
    C.setTop(t.t, { back: true });
    var cl = (Store.get('wcheck', {}) || {})[t.id] || {};
    var html = '<section class="card"><div class="small muted">' + (t.sec === 'bn' ? 'বাংলা' : 'English') + ' · লিখিত</div><h1 style="margin:.2rem 0">' + esc(t.t) + '</h1>' +
      (t.what ? '<p>' + md(t.what) + '</p>' : '') +
      '<div class="row wrap"><a class="btn primary" href="#/written/p/' + t.id + '">✍️ এখনই লিখুন (' + num(t.minutes) + ' মি.)</a>' + C.saveBtnHTML('wt', t.id) + '</div></section>';
    if (t.seenNote) html += '<div class="banner ' + (t.seen ? 'ok' : 'warn') + '">' + md(t.seenNote) + '</div>';
    html += '<section class="card"><h3 style="margin-top:0">লেখার কৌশল</h3><ol class="wl-steps">' + t.strategy.map(function (x) { return '<li>' + md(x) + '</li>'; }).join('') + '</ol></section>';
    if (t.marks && t.marks.length) html += '<section class="card"><h3 style="margin-top:0">নম্বর কীভাবে আসে (মূল্যায়নের মানদণ্ড)</h3><div class="tbl-wrap"><table class="wl-tbl"><thead><tr><th>অংশ</th><th>ভাগ</th></tr></thead><tbody>' +
      t.marks.map(function (m) { return '<tr><td>' + md(m[0]) + '</td><td>' + md(m[1]) + '</td></tr>'; }).join('') + '</tbody></table></div><p class="small muted">' + esc(t.marksNote || 'মানদণ্ডটি অনুশীলনের জন্য — পরীক্ষকের অফিসিয়াল রুব্রিক প্রকাশিত নয়।') + '</p></section>';
    if (t.examiner && t.examiner.length) html += '<section class="card"><h3 style="margin-top:0">🧑‍🏫 পরীক্ষকের চোখে</h3><ul>' + t.examiner.map(function (x) { return '<li>' + md(x) + '</li>'; }).join('') + '</ul></section>';
    html += '<h2 class="sec-h">মডেল উত্তর</h2>' + t.model.map(function (m, i) {
      return '<details class="card wl-model"' + (i === 0 ? ' open' : '') + '><summary><b>' + md(m.prompt) + '</b>' + (m.src ? '<div class="small muted">' + esc(m.src) + '</div>' : '') + '</summary>' +
        '<div class="wl-ans">' + md(m.answer) + '</div>' + (m.note ? '<p class="small muted" style="margin-top:.5rem">💡 ' + md(m.note) + '</p>' : '') +
        '<p class="small muted">শব্দ: ' + num(words(m.answer)) + '</p></details>';
    }).join('');
    html += '<section class="card" id="wl-check"><h3 style="margin-top:0">✅ নিজের লেখা মিলিয়ে দেখুন</h3>' + t.checklist.map(function (x, i) {
      return '<label class="wl-ck"><input type="checkbox" data-i="' + i + '"' + (cl[i] ? ' checked' : '') + '> ' + md(x) + '</label>';
    }).join('') + '</section>';
    $v().innerHTML = html;
    Array.prototype.forEach.call($v().querySelectorAll('#wl-check input'), function (b) {
      b.onchange = function () {
        var all = JSON.parse(JSON.stringify(Store.get('wcheck', {}) || {}));
        all[t.id] = all[t.id] || {}; all[t.id][b.getAttribute('data-i')] = b.checked;
        Store.set('wcheck', all, 0);
      };
    });
  }

  /* ---------------- লেখার ঘর (Timed) ---------------- */
  function buildTask(key) {
    if (key === 'full') {
      var plan = D().full || [];
      var u = duUnit(), mins = (u.written && u.written.minutes) || 45;
      var parts = plan.map(function (p) {
        var t = topic(p.tid); if (!t) return null;
        var pr = t.practice[Math.floor(Math.random() * t.practice.length)];
        return { tid: t.id, sec: t.sec, title: t.t, prompt: pr, marks: p.marks, words: t.words };
      }).filter(Boolean);
      return { key: 'full', title: 'পূর্ণ লিখিত অনুশীলন', minutes: mins, parts: parts };
    }
    var t = topic(key); if (!t) return null;
    var pr = t.practice[Math.floor(Math.random() * t.practice.length)];
    return { key: t.id, title: t.t, minutes: t.minutes, parts: [{ tid: t.id, sec: t.sec, title: t.t, prompt: pr, words: t.words }] };
  }
  function viewPad(key) {
    var dk = 'wdraft:' + key;
    var dr = Store.get(dk, null);
    if (!dr || !dr.parts) { dr = buildTask(key); if (!dr) { location.replace('#/written'); return; } dr.texts = dr.parts.map(function () { return ''; }); dr.used = 0; dr.running = false; Store.set(dk, dr, 0); }
    C.setTop(dr.title, { back: true });
    var total = dr.minutes * 60;
    var html = '<div class="wl-timer card tight row" id="wl-timer"><span class="spacer"><span class="small muted">সময় বাকি</span><b id="wl-left">' + fmt(total - dr.used) + '</b></span>' +
      '<span class="small muted" id="wl-wc"></span><button class="btn sm" id="wl-tg">' + (dr.running ? '⏸ বিরতি' : '▶ শুরু') + '</button></div>' +
      '<p class="small muted">লেখা প্রতি কয়েক সেকেন্ডে নিজে থেকে সংরক্ষিত হয় — পাতা বন্ধ করলেও হারাবে না। প্রথম অক্ষর লিখলেই টাইমার চালু হয়।</p>';
    dr.parts.forEach(function (p, i) {
      html += '<section class="card wl-part"><div class="small muted">' + (p.sec === 'bn' ? 'বাংলা' : 'English') + ' · ' + esc(p.title) + (p.marks ? ' · ' + num(p.marks) + ' নম্বর' + (D().fullVerified ? '' : ' (অনুশীলনের জন্য আনুমানিক)') : '') + '</div>' +
        '<p class="wl-prompt"><b>' + md(p.prompt.q) + '</b></p>' + (p.prompt.hint ? '<p class="small muted">' + md(p.prompt.hint) + '</p>' : '') +
        '<textarea class="wl-text" data-i="' + i + '" rows="10" lang="' + (p.sec === 'bn' ? 'bn' : 'en') + '" placeholder="এখানে লিখুন…">' + esc(dr.texts[i] || '') + '</textarea>' +
        '<div class="small muted wl-cnt" id="wl-c' + i + '"></div></section>';
    });
    html += '<div class="row wrap"><button class="btn primary" id="wl-sub">জমা দিন ও মিলিয়ে দেখুন</button><button class="btn" id="wl-new">নতুন প্রশ্ন</button></div>';
    $v().innerHTML = html;
    var areas = Array.prototype.slice.call($v().querySelectorAll('.wl-text'));
    function counts() {
      var tw = 0;
      areas.forEach(function (a, i) {
        var w = words(a.value), p = dr.parts[i]; tw += w;
        var rng = p.words ? ' (লক্ষ্য ' + num(p.words[0]) + '–' + num(p.words[1]) + ')' : '';
        var el = document.getElementById('wl-c' + i);
        if (el) { el.textContent = 'শব্দ: ' + num(w) + rng; el.className = 'small wl-cnt ' + (p.words && w > p.words[1] ? 'over' : (p.words && w >= p.words[0] ? 'ok' : 'muted')); }
      });
      document.getElementById('wl-wc').textContent = 'মোট ' + num(tw) + ' শব্দ';
    }
    function save() { Store.set(dk, dr, 2000); }
    areas.forEach(function (a) {
      a.addEventListener('input', function () {
        dr.texts[+a.getAttribute('data-i')] = a.value;
        if (!dr.running && dr.used < total) { dr.running = true; tg.textContent = '⏸ বিরতি'; }
        counts(); save();
      });
    });
    var tg = document.getElementById('wl-tg');
    tg.onclick = function () { dr.running = !dr.running; tg.textContent = dr.running ? '⏸ বিরতি' : '▶ চালু'; Store.set(dk, dr, 0); };
    var warned = dr.used >= total;
    var iv = setInterval(function () {
      if (!document.getElementById('wl-left')) { clearInterval(iv); return; }
      if (dr.running) {
        dr.used++;
        if (dr.used % 5 === 0) save();
        if (dr.used >= total && !warned) { warned = true; toast('⏰ সময় শেষ! এখন জমা দিন — বাড়তি সময় আলাদা দেখানো হবে।'); }
      }
      var left = total - dr.used;
      var el = document.getElementById('wl-left');
      el.textContent = left >= 0 ? fmt(left) : '+' + fmt(-left);
      document.getElementById('wl-timer').classList.toggle('late', left < 0);
      document.getElementById('wl-timer').classList.toggle('low', left >= 0 && left <= 300);
    }, 1000);
    C.setCleanup(function () { clearInterval(iv); Store.set(dk, dr, 0); });
    counts();
    document.getElementById('wl-new').onclick = function () { Store.del(dk); viewPad(key); };
    document.getElementById('wl-sub').onclick = function () {
      var tw = dr.texts.reduce(function (s, x) { return s + words(x); }, 0);
      if (!tw) { toast('আগে কিছু লিখুন'); return; }
      var rec = { id: 'w' + Date.now().toString(36), key: key, tid: key === 'full' ? 'full' : key, title: dr.title, parts: dr.parts, texts: dr.texts, used: dr.used, minutes: dr.minutes, at: Date.now(), self: {} };
      var all = (Store.get('wsaved', []) || []).slice(); all.unshift(rec);
      Store.set('wsaved', all, 0); Store.del(dk);
      if (window.Mega) Mega.onWritten(rec);
      clearInterval(iv);
      location.hash = '#/written/r/' + rec.id;
    };
  }

  /* ---------------- জমার পর: মডেল উত্তর + Checklist + নিজের নম্বর ---------------- */
  function viewReview(id) {
    var all = Store.get('wsaved', []) || [];
    var r = all.filter(function (x) { return x.id === id; })[0];
    if (!r) { location.replace('#/written/mine'); return; }
    C.setTop('মিলিয়ে দেখুন', { back: true });
    var over = r.used - r.minutes * 60;
    var html = '<section class="card tight"><b>' + esc(r.title) + '</b><div class="small muted">' + new Date(r.at).toLocaleString('bn-BD') + ' · সময় লেগেছে ' + fmt(r.used) +
      (over > 0 ? ' <span class="chip verify">নির্ধারিত সময়ের ' + fmt(over) + ' বেশি</span>' : ' <span class="chip ok">সময়ের মধ্যে</span>') + '</div></section>';
    if (window.Mega) html += Mega.writtenNote(r);
    r.parts.forEach(function (p, i) {
      var t = topic(p.tid) || { checklist: [], model: [] };
      var self = (r.self || {})[i] || {};
      var mx = p.marks || (p.prompt && p.prompt.marks) || 10;
      var model = p.prompt && p.prompt.model;
      html += '<section class="card wl-rev" data-i="' + i + '"><div class="small muted">' + esc(p.title) + '</div><p class="wl-prompt"><b>' + md(p.prompt.q) + '</b></p>' +
        '<h3>আপনার লেখা <span class="small muted">(' + num(words(r.texts[i])) + ' শব্দ)</span></h3><div class="wl-mine">' + md(r.texts[i] || '—') + '</div>' +
        (model ? '<details class="wl-model" open><summary><b>মডেল উত্তর</b></summary><div class="wl-ans">' + md(model) + '</div></details>' :
          (t.model[0] ? '<details class="wl-model"><summary><b>এ ধরনের একটি মডেল উত্তর দেখুন</b></summary><div class="small muted">' + md(t.model[0].prompt) + '</div><div class="wl-ans">' + md(t.model[0].answer) + '</div></details>' : '')) +
        '<h3>চেকলিস্ট</h3>' + t.checklist.map(function (x, k) { return '<label class="wl-ck"><input type="checkbox" data-k="' + k + '"' + (self['c' + k] ? ' checked' : '') + '> ' + md(x) + '</label>'; }).join('') +
        '<div class="field" style="margin-top:.6rem"><label>নিজেকে নম্বর দিন (০–' + num(mx) + ')</label><input type="text" class="wl-score" data-max="' + mx + '" value="' + (self.score != null ? num(self.score) : '') + '" inputmode="decimal" autocomplete="off"></div></section>';
    });
    html += '<div class="row wrap"><a class="btn primary" href="#/written/p/' + r.key + '">আবার লিখুন</a><a class="btn" href="#/written/mine">আমার লেখা</a></div>';
    $v().innerHTML = html;
    function persist() {
      var list = (Store.get('wsaved', []) || []).map(function (x) { return x.id === r.id ? r : x; });
      Store.set('wsaved', list, 300);
    }
    Array.prototype.forEach.call($v().querySelectorAll('.wl-rev'), function (sec) {
      var i = sec.getAttribute('data-i');
      r.self = r.self || {}; r.self[i] = r.self[i] || {};
      Array.prototype.forEach.call(sec.querySelectorAll('input[type=checkbox]'), function (b) { b.onchange = function () { r.self[i]['c' + b.getAttribute('data-k')] = b.checked; persist(); }; });
      var sc = sec.querySelector('.wl-score');
      sc.oninput = function () { var v = parseFloat(C.fromBnDigits(sc.value)); r.self[i].score = isNaN(v) ? null : Math.max(0, Math.min(+sc.getAttribute('data-max'), v)); persist(); };
    });
  }

  function viewMine() {
    C.setTop('আমার লেখা', { back: true });
    var all = Store.get('wsaved', []) || [];
    var html = all.length ? all.map(function (r) {
      var sc = 0, mx = 0, has = false;
      r.parts.forEach(function (p, i) { var s = (r.self || {})[i]; mx += p.marks || 10; if (s && s.score != null) { sc += s.score; has = true; } });
      var w = r.texts.reduce(function (s, x) { return s + words(x); }, 0);
      return '<div class="card tight row wl-saved"><a class="spacer" href="#/written/r/' + r.id + '" style="text-decoration:none;color:inherit"><b>' + esc(r.title) + '</b><div class="small muted">' +
        new Date(r.at).toLocaleDateString('bn-BD') + ' · ' + num(w) + ' শব্দ · ' + fmt(r.used) + (has ? ' · নিজের নম্বর ' + num(sc) + '/' + num(mx) : '') + '</div></a>' +
        '<button class="btn sm" data-del="' + r.id + '" aria-label="মুছুন">🗑</button></div>';
    }).join('') : '<div class="card"><p>এখনো কিছু লেখেননি।</p><a class="btn primary" href="#/written">টপিক বেছে নিন</a></div>';
    $v().innerHTML = html;
    Array.prototype.forEach.call($v().querySelectorAll('[data-del]'), function (b) {
      b.onclick = function () {
        var id = b.getAttribute('data-del');
        Store.set('wsaved', (Store.get('wsaved', []) || []).filter(function (x) { return x.id !== id; }), 0);
        toast('মুছে ফেলা হয়েছে'); viewMine();
      };
    });
  }

  function viewPYQ() {
    C.setTop('আগের বছরের লিখিত প্রশ্ন', { back: true });
    var d = D(), by = {};
    var mine = Store.get('wpyq', []) || [];
    d.pyq.concat(mine.map(function (q) { var y = {}; for (var k in q) y[k] = q[k]; y.user = true; y.src = 'আপনার যোগ করা'; return y; }))
      .forEach(function (q) { var k = q.session + '|' + q.unit; (by[k] = by[k] || []).push(q); });
    var keys = Object.keys(by).sort().reverse();
    var html = '<div class="banner warn">শুধু নির্ভরযোগ্য সূত্রে মেলানো প্রশ্ন রাখা হয়েছে; প্রতিটির সূত্র দেওয়া আছে। হুবহু শব্দচয়ন আসল প্রশ্নপত্রের সঙ্গে সামান্য ভিন্ন হতে পারে।</div>';
    html += keys.length ? keys.map(function (k) {
      var p = k.split('|');
      return '<section class="card"><h3 style="margin-top:0">' + esc(num(p[0])) + ' · ' + esc(by[k][0].unitName || p[1]) + '</h3>' + by[k].map(function (q) {
        var t = q.tid && topic(q.tid);
        return '<div class="wl-pq"><div class="small muted">' + (q.sec === 'bn' ? 'বাংলা' : 'English') + (q.marks ? ' · ' + num(q.marks) + ' নম্বর' : '') + (t ? ' · <a href="#/written/t/' + t.id + '">' + esc(t.t) + '</a>' : '') +
          (q.user ? ' · <span class="chip">নিজে যোগ করা</span> <button class="btn sm" data-wdel="' + esc(q.id) + '" aria-label="মুছুন">🗑</button>' : '') + '</div><p>' + md(q.q) + '</p></div>';
      }).join('') + '<p class="small muted">সূত্র: ' + esc(by[k].filter(function (x) { return !x.user; }).map(function (x) { return x.src; })[0] || 'আপনার যোগ করা') + '</p></section>';
    }).join('') : '<div class="card"><p>যাচাইকৃত প্রশ্ন এখনো যোগ হয়নি। <span class="chip verify">Verify</span></p></div>';
    html += '<details class="card" id="wpq-add"><summary><b>➕ আগের বছরের প্রশ্ন নিজে যোগ করুন</b></summary><p class="small muted">গাইড বা প্রশ্নব্যাংক থেকে পাওয়া প্রশ্ন এখানে রাখুন — শুধু এই ডিভাইসে থাকবে, ব্যাকআপে যাবে।</p>' +
      '<div class="grid2"><div class="field"><label for="wq-ses">শিক্ষাবর্ষ</label><input id="wq-ses" placeholder="2022-23"></div><div class="field"><label for="wq-sec">অংশ</label><select id="wq-sec"><option value="bn">বাংলা</option><option value="en">English</option></select></div></div>' +
      '<div class="grid2"><div class="field"><label for="wq-tid">ধরন</label><select id="wq-tid"><option value="">—</option>' + topics().map(function (t) { return '<option value="' + t.id + '">' + esc(t.t) + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="wq-mk">নম্বর</label><input id="wq-mk" type="text" inputmode="numeric" autocomplete="off"></div></div>' +
      '<div class="field"><label for="wq-q">প্রশ্ন</label><textarea id="wq-q" rows="4"></textarea></div><button class="btn primary" id="wq-go">যোগ করুন</button></details>';
    $v().innerHTML = html;
    document.getElementById('wq-go').onclick = function () {
      var ses = document.getElementById('wq-ses').value.trim(), q = document.getElementById('wq-q').value.trim();
      if (!/^\d{4}-\d{2}$/.test(ses) || !q) { toast('শিক্ষাবর্ষ (যেমন 2022-23) ও প্রশ্ন দিন'); return; }
      var mk = parseInt(C.fromBnDigits(document.getElementById('wq-mk').value), 10);
      var list = (Store.get('wpyq', []) || []).slice();
      list.push({ id: 'u' + Date.now().toString(36), session: ses, unit: 'du-b', unitName: 'কলা, আইন ও সামাজিক বিজ্ঞান ইউনিট (B)', sec: document.getElementById('wq-sec').value, tid: document.getElementById('wq-tid').value, marks: isNaN(mk) ? null : mk, q: q });
      Store.set('wpyq', list, 0); toast('প্রশ্ন যোগ হয়েছে'); viewPYQ();
    };
    Array.prototype.forEach.call($v().querySelectorAll('[data-wdel]'), function (b) {
      b.onclick = function () { var id = b.getAttribute('data-wdel'); Store.set('wpyq', (Store.get('wpyq', []) || []).filter(function (x) { return x.id !== id; }), 0); viewPYQ(); };
    });
  }
  function viewAnalysis() {
    C.setTop('প্রশ্নধারা বিশ্লেষণ', { back: true });
    var d = D();
    var html = (d.analysisNote ? '<div class="banner ' + (d.analysisVerified ? 'ok' : 'warn') + '">' + md(d.analysisNote) + '</div>' : '') +
      (d.analysis.length ? '<section class="card"><div class="tbl-wrap"><table class="wl-tbl"><thead><tr><th>শিক্ষাবর্ষ</th><th>বাংলা</th><th>English</th></tr></thead><tbody>' +
        d.analysis.map(function (a) { return '<tr><td>' + esc(num(a.session)) + '</td><td>' + md(a.bn) + '</td><td>' + md(a.en) + '</td></tr>'; }).join('') + '</tbody></table></div></section>' : '') +
      (d.trend ? '<section class="card"><h3 style="margin-top:0">যা দেখা যাচ্ছে</h3><ul>' + d.trend.map(function (x) { return '<li>' + md(x) + '</li>'; }).join('') + '</ul></section>' : '');
    $v().innerHTML = html || '<div class="card"><p>বিশ্লেষণ যাচাই বাকি। <span class="chip verify">Verify</span></p></div>';
  }

  window.Written = { words: words };
  C.addRoute(/^#\/written\/t\/([\w-]+)/, function (m) { viewTopic(m[1]); });
  C.addRoute(/^#\/written\/p\/([\w-]+)/, function (m) { viewPad(m[1]); });
  C.addRoute(/^#\/written\/full/, function () { viewPad('full'); });
  C.addRoute(/^#\/written\/r\/([\w-]+)/, function (m) { viewReview(m[1]); });
  C.addRoute(/^#\/written\/mine/, viewMine);
  C.addRoute(/^#\/written\/pyq/, viewPYQ);
  C.addRoute(/^#\/written\/analysis/, viewAnalysis);
  C.addRoute(/^#\/written\/?$/, viewHub);
  /* হোমে: DU ইউনিট হলে লিখিত ল্যাবের কার্ড */
  C.addHome(function () {
    var u = C.UNITS[C.settings().unit];
    if (!u || !u.writtenLab) return '';
    var n = (Store.get('wsaved', []) || []).length;
    return '<a class="card tight row" id="wl-home" href="#/written" style="text-decoration:none;color:inherit"><span style="font-size:1.5rem" aria-hidden="true">✍️</span><div class="spacer"><b>DU লিখিত ল্যাব</b><div class="small muted">লিখিত ' + num(u.written ? u.written.marks : 40) + ' নম্বর · ' + (n ? num(n) + 'টি লেখা সংরক্ষিত' : 'টাইমারসহ লেখার অনুশীলন') + '</div></div><span class="btn sm">খুলুন →</span></a>';
  }, false, 'written', 'DU লিখিত ল্যাব');
})();
