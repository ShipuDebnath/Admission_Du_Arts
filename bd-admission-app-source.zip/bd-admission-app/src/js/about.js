/* =========================================================
   about.js — Phase 10
   PWA (শুধু http/https-এ হোস্ট করলে; file://-এ কিছুই করে না — ফিচার-ডিটেকশন)
   ইনস্টল/অফলাইন তথ্য · sw.js তৈরি · APK Packaging গাইড
   Coverage Checklist (লাইভ গণনা) · QC রিপোর্ট · আকার ও সামঞ্জস্য রিপোর্ট
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast;
  function $v() { return C.view(); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  var BUILD = window.__BUILD__ || {};
  var hosted = /^https?:$/.test(location.protocol);
  var deferred = null;

  /* ---------------- PWA ---------------- */
  function iconPNG(sz) {
    try {
      var c = document.createElement('canvas'); c.width = c.height = sz;
      var x = c.getContext('2d'), r = sz * 0.22;
      var g = x.createLinearGradient(0, 0, sz, sz); g.addColorStop(0, '#4b3fbf'); g.addColorStop(1, '#0f8a7e');
      x.fillStyle = g; x.beginPath();
      x.moveTo(r, 0); x.lineTo(sz - r, 0); x.quadraticCurveTo(sz, 0, sz, r); x.lineTo(sz, sz - r); x.quadraticCurveTo(sz, sz, sz - r, sz);
      x.lineTo(r, sz); x.quadraticCurveTo(0, sz, 0, sz - r); x.lineTo(0, r); x.quadraticCurveTo(0, 0, r, 0); x.fill();
      // খোলা বই
      var u = sz / 100;
      x.fillStyle = '#ffffff';
      x.beginPath(); x.moveTo(50 * u, 36 * u); x.quadraticCurveTo(36 * u, 28 * u, 20 * u, 31 * u); x.lineTo(20 * u, 72 * u); x.quadraticCurveTo(36 * u, 69 * u, 50 * u, 77 * u); x.closePath(); x.fill();
      x.beginPath(); x.moveTo(50 * u, 36 * u); x.quadraticCurveTo(64 * u, 28 * u, 80 * u, 31 * u); x.lineTo(80 * u, 72 * u); x.quadraticCurveTo(64 * u, 69 * u, 50 * u, 77 * u); x.closePath(); x.globalAlpha = 0.85; x.fill(); x.globalAlpha = 1;
      // টুপি (গ্র্যাজুয়েশন)
      x.fillStyle = '#ffd166';
      x.beginPath(); x.moveTo(50 * u, 12 * u); x.lineTo(70 * u, 20 * u); x.lineTo(50 * u, 28 * u); x.lineTo(30 * u, 20 * u); x.closePath(); x.fill();
      return c.toDataURL('image/png');
    } catch (e) { return ''; }
  }
  function setupPWA() {
    if (!hosted) return;
    try {
      var base = location.href.split('#')[0], dir = base.replace(/[^/]*$/, '');
      var i192 = iconPNG(192), i512 = iconPNG(512);
      var man = { name: 'ভর্তি প্রস্তুতি — বিশ্ববিদ্যালয় ভর্তি পরীক্ষা', short_name: 'ভর্তি প্রস্তুতি', lang: 'bn', dir: 'ltr',
        start_url: base, scope: dir, display: 'standalone', orientation: 'portrait', background_color: '#f6f4ef', theme_color: '#4b3fbf',
        icons: i192 ? [{ src: i192, sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: i512, sizes: '512x512', type: 'image/png', purpose: 'any' }, { src: i512, sizes: '512x512', type: 'image/png', purpose: 'maskable' }] : [] };
      var l = document.createElement('link'); l.rel = 'manifest';
      l.href = URL.createObjectURL(new Blob([JSON.stringify(man)], { type: 'application/manifest+json' }));
      document.head.appendChild(l);
      if (i192) { var a = document.createElement('link'); a.rel = 'apple-touch-icon'; a.href = i192; document.head.appendChild(a); }
      [['apple-mobile-web-app-capable', 'yes'], ['mobile-web-app-capable', 'yes'], ['apple-mobile-web-app-title', 'ভর্তি প্রস্তুতি']].forEach(function (m) {
        var e = document.createElement('meta'); e.name = m[0]; e.content = m[1]; document.head.appendChild(e);
      });
    } catch (e) { }
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; var b = qs('#pwainstall'); if (b) b.hidden = false; });
    window.addEventListener('appinstalled', function () { deferred = null; toast('✓ অ্যাপ ইনস্টল হয়েছে'); });
    // sw.js পাশে থাকলেই রেজিস্টার (না থাকলে নীরবে কিছু করে না)
    if ('serviceWorker' in navigator && window.fetch) {
      window.addEventListener('load', function () {
        fetch('sw.js', { method: 'HEAD', cache: 'no-store' }).then(function (r) {
          if (r.ok) navigator.serviceWorker.register('sw.js').catch(function () { });
        }).catch(function () { });
      });
    }
  }
  function swSource() {
    var v = (window.App && App.version) || '1';
    return "/* ভর্তি প্রস্তুতি — Service Worker (index.html-এর পাশে রাখুন) */\n" +
      "var CACHE = 'bdadm-" + v + "-" + (BUILD.date || '') + "';\n" +
      "self.addEventListener('install', function (e) {\n  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(['./', './index.html']); }).then(function () { return self.skipWaiting(); }));\n});\n" +
      "self.addEventListener('activate', function (e) {\n  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));\n});\n" +
      "self.addEventListener('fetch', function (e) {\n  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;\n" +
      "  e.respondWith(caches.open(CACHE).then(function (c) {\n    return c.match(e.request, { ignoreSearch: true }).then(function (hit) {\n" +
      "      var net = fetch(e.request).then(function (res) { if (res && res.ok) c.put(e.request, res.clone()); return res; }).catch(function () { return hit || c.match('./index.html'); });\n" +
      "      return hit || net;\n    });\n  }));\n});\n";
  }

  /* ---------------- রিপোর্ট পাতা ---------------- */
  function mb(b) { return b ? num((b / 1e6).toFixed(2)) + ' MB' : '—'; }
  function coverageHTML() {
    var cardsBy = {}; QB.cards().forEach(function (c) { cardsBy[c.sub] = (cardsBy[c.sub] || 0) + 1; });
    var qBy = {}; QB.all().forEach(function (q) { qBy[q.sub] = (qBy[q.sub] || 0) + 1; });
    var tot = { ch: 0, l: 0, has: 0, q: 0, c: 0 };
    var rows = C.SUBJ.map(function (s) {
      var l = 0, has = 0; s.ch.forEach(function (c) { c.l.forEach(function (x) { l++; if (x.has) has++; }); });
      tot.ch += s.ch.length; tot.l += l; tot.has += has; tot.q += qBy[s.id] || 0; tot.c += cardsBy[s.id] || 0;
      return '<tr><td>' + (has === l ? '✅' : '⏳') + ' ' + s.icon + ' ' + esc(s.t) + '</td><td class="n">' + num(s.ch.length) + '</td><td class="n">' + num(has) + '/' + num(l) + '</td><td class="n">' + num(qBy[s.id] || 0) + '</td><td class="n">' + num(cardsBy[s.id] || 0) + '</td></tr>';
    }).join('');
    return '<table class="data"><tr><th>বিষয় (PART C)</th><th class="n">অধ্যায়</th><th class="n">পাঠ</th><th class="n">MCQ</th><th class="n">কার্ড</th></tr>' + rows +
      '<tr><th>মোট</th><th class="n">' + num(tot.ch) + '</th><th class="n">' + num(tot.has) + '/' + num(tot.l) + '</th><th class="n">' + num(tot.q) + '</th><th class="n">' + num(tot.c) + '</th></tr></table>';
  }
  var FEATURES = [
    ['✅', 'পরীক্ষার Track ও ইউনিট (PART B)', 'ঢাবি B ও D, জাবি B ও C, রাবি A, চবি B ও D, গুচ্ছ B — Unit Mode ও নিজের মতো বিষয় বাছাই', '#/settings'],
    ['✅', 'পাঠ্যসূচি ও পাঠ (PART C–D)', 'অধ্যায় → পাঠ, টেবিল/টাইমলাইন/মিলকরণ ফিগার, Memory Hack, Common Mistakes, Exam Tricks, University-wise Analysis', '#/syllabus'],
    ['✅', 'PYQ Hub ও Import (PART E)', 'JSON/CSV Import; শুধু যাচাইকৃত প্রশ্ন "PYQ" ট্যাগ পায়। DU B লিখিত PYQ যাচাইকৃত', '#/pyq'],
    ['✅', 'Tracker, Flashcard (SRS), ভুলের খাতা, Backup (PART F)', 'IndexedDB + localStorage, ফাইল/কোড ব্যাকআপ, Resume', '#/flash'],
    ['✅', 'Timed Test Engine (PART G)', 'Builder, Palette, Mark for Review, Auto-submit, OMR রিভিউ, ৫ সেকেন্ডে Auto-save, প্রিন্ট', '#/test/build'],
    ['✅', 'Mega Mock (PART G)', 'প্রতিটি ইউনিটের কাঠামোয়; DU B = MCQ ৬০ + লিখিত ৪০ সম্মিলিত ফল', '#/mega'],
    ['✅', 'Adaptive Quiz ও Subject Final (PART H)', 'সহজ→কঠিন Quiz; বিষয়ভিত্তিক ১০০ প্রশ্ন, LQS, দুর্বল টপিক, রিভিশন প্ল্যান', '#/final'],
    ['✅', 'DU লিখিত ল্যাব (PART I)', '১২টি টপিক, মডেল উত্তর, টাইমার, নিজে মূল্যায়ন', '#/written'],
    ['✅', 'Mobile-First (PART K)', '৩২০px+, ৪৪px টাচ, Search, সংরক্ষণ, Notes, Highlights, Streak, দৈনিক লক্ষ্য; হোমের অংশ টেনে সাজানো ও লুকানো যায়', '#/search'],
    ['✅', 'থিম (PART L)', '৮+ থিম, Auto, WCAG AA কনট্রাস্ট (QC-তে যাচাই)', '#/settings'],
    ['✅', 'Gamification ও Mini-Games (PART M)', 'XP, লেভেল, ব্যাজ, Daily Challenge, লোকাল লিডারবোর্ড, ৬টি গেম', '#/achieve'],
    ['✅', 'শাবিপ্রবি B ও জাবি E; অন্যান্য বিষয়', 'শাবিপ্রবি B (মানবিক শাখা) ও জাবি E (বিজ্ঞান/মানবিক শাখা) ইউনিট; নতুন বিষয়: পৌরনীতি ও সুশাসন, সমাজবিজ্ঞান ও সমাজকর্ম, ইতিহাস, মাধ্যমিক সাধারণ গণিত, বিশ্ববিদ্যালয় পরিচিতি (ক্যাম্পাস-প্রশ্ন)', '#/s/uni'],
    ['✅', 'চার্ট ও ডায়াগ্রাম', '৫১টি পাঠ্যবইভিত্তিক চার্ট (ইংরেজি, বাংলা, সাধারণ জ্ঞান, ICT, গণিত, অর্থনীতি) — প্রতিটিতে ব্যতিক্রম ও মনে রাখার কৌশল; প্রতি অধ্যায়ের স্বয়ংক্রিয় কনসেপ্ট ম্যাপ; হোমে পিন', '#/charts'],
    ['✅', 'সাম্প্রতিক হাব (Phase 6)', 'মাসভিত্তিক প্যাক, হালনাগাদ ব্যানার, Import', '#/ca'],
    ['✅', 'Single-file, file://, অফলাইন (A7)', 'সব CSS/JS/ডেটা/ফন্ট একটি index.html-এ; ইন্টারনেট লাগে না', ''],
    ['⬜', 'DU B — Elective English (বাংলার বিকল্প)', 'তৈরি হয়নি — আপনার সিদ্ধান্তের অপেক্ষায়। বাংলা অংশ সম্পূর্ণ আছে।', '']
  ];
  function qcHTML() {
    var r = Data.has('qc-report') ? Data.get('qc-report') : null;
    if (!r) return '<p class="muted">QC রিপোর্ট এই বিল্ডে নেই।</p>';
    return '<p class="small muted">চালানো হয়েছে: ' + esc(r.date) + '</p><ul class="small">' + (r.info || []).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' +
      '<table class="data small"><tr><th>A6 চেকলিস্ট</th><th>ফল</th></tr>' + (r.checks || []).map(function (c) { return '<tr><td>' + esc(c[0]) + '</td><td>' + esc(c[1]) + '</td></tr>'; }).join('') + '</table>' +
      (r.warnSummary && r.warnSummary.length ? '<details class="small"><summary>সতর্কতা (' + num(r.warns) + ') — ধরন অনুযায়ী</summary><ul>' + r.warnSummary.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('') + '</ul></details>' : '') +
      (r.tests ? '<h3>স্বয়ংক্রিয় ব্রাউজার টেস্ট</h3><table class="data small"><tr><th>টেস্ট</th><th class="n">পাস</th></tr>' + r.tests.map(function (t) { return '<tr><td>' + esc(t[0]) + '</td><td class="n">' + esc(t[1]) + '</td></tr>'; }).join('') + '</table>' : '') +
      (r.compat ? '<h3>সামঞ্জস্য (A7)</h3><ul class="small">' + r.compat.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : '');
  }
  function viewAbout() {
    C.setTop('ইনস্টল ও রিপোর্ট', { back: true });
    var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone;
    var ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
    var html = '<section class="card"><h2>📲 ইনস্টল ও অফলাইন</h2>';
    if (!hosted) html += '<div class="banner ok">এখন ফাইল থেকে চলছে (' + esc(location.protocol) + ') — সব পাঠ, প্রশ্ন ও ফন্ট এই একটি ফাইলেই আছে, তাই <b>ইন্টারনেট ছাড়াই পুরোপুরি চলে</b>। ফোনে স্থায়ী অ্যাপ চাইলে নিচের APK গাইড দেখুন।</div>';
    else if (standalone) html += '<div class="banner ok">✓ অ্যাপ হিসেবে ইনস্টল করা অবস্থায় চলছে।</div>';
    else {
      html += '<p class="small">ওয়েবসাইট হিসেবে খোলা হয়েছে — হোম স্ক্রিনে যোগ করলে আলাদা অ্যাপের মতো খুলবে।</p>' +
        '<button class="btn primary block" id="pwainstall"' + (deferred ? '' : ' hidden') + '>⬇ অ্যাপ ইনস্টল করুন</button>' +
        (ios ? '<p class="small">iPhone/iPad: Safari-তে <b>Share</b> বাটন → <b>Add to Home Screen</b>।</p>' : '<p class="small">ইনস্টল বাটন না দেখালে ব্রাউজারের মেনু (⋮) → <b>Install app / Add to Home screen</b>।</p>');
    }
    html += '<p class="small">Service Worker: ' + (!('serviceWorker' in navigator) ? 'এই ব্রাউজারে নেই — সমস্যা নেই, অ্যাপ এমনিতেই অফলাইনে চলে।' : !hosted ? 'ফাইল থেকে খুললে দরকার নেই (ব্রাউজার file://-এ চালায় না)।' : (navigator.serviceWorker.controller ? '✓ চালু — পরেরবার নেটওয়ার্ক ছাড়াও খুলবে।' : 'চালু নেই — ওয়েবসাইটে index.html-এর পাশে sw.js রাখলে চালু হবে।')) + '</p>' +
      '<details class="small"><summary style="min-height:44px;cursor:pointer">ওয়েবসাইটে হোস্ট করতে চাইলে (ঐচ্ছিক)</summary><ol><li>index.html যেকোনো HTTPS হোস্টে (যেমন GitHub Pages/Netlify) আপলোড করুন।</li><li>নিচের বাটনে sw.js ডাউনলোড করে index.html-এর একই ফোল্ডারে রাখুন।</li><li>সাইট একবার খুললেই সব ক্যাশ হবে; এরপর ইন্টারনেট ছাড়াও খুলবে ও "Install" করা যাবে।</li></ol>' +
      '<button class="btn" id="swdl">⬇ sw.js ডাউনলোড</button></details></section>';

    var zip = BUILD.zip || 0, LIM = 2 * 1000 * 1000;
    html += '<section class="card"><h2>🤖 Android APK বানানোর গাইড (WebIntoApp)</h2>' +
      '<ol class="small"><li>এই <b>index.html</b> ফাইলটি একটি ZIP-এ রাখুন (ZIP-এর ভেতরে সরাসরি index.html থাকবে, কোনো ফোল্ডারের ভেতরে নয়)।</li>' +
      '<li>webintoapp.com-এ অ্যাকাউন্ট খুলে App Maker থেকে HTML/ZIP দিয়ে অ্যাপ বানানোর অপশন বাছুন এবং ZIP আপলোড করুন।</li>' +
      '<li>অ্যাপের নাম (যেমন "ভর্তি প্রস্তুতি") ও আইকন দিন, তারপর Build করে APK ডাউনলোড করুন।</li>' +
      '<li>ফোনে APK ইনস্টল করে খুলুন: একটি পাঠ খুলে বন্ধ করুন, আবার খুলে দেখুন "যেখানে ছিলেন" কার্ড আসে কি না (সংরক্ষণ কাজ করছে কি না)।</li>' +
      '<li>ব্যাকআপ: APK-এ ফাইল ডাউনলোড কাজ না করলে সেটিংস → ব্যাকআপ → <b>কোড কপি</b> ব্যবহার করুন।</li></ol>' +
      '<table class="data small"><tr><th>WebIntoApp প্ল্যান</th><th>HTML/ZIP সীমা</th><th>অন্যান্য</th></tr>' +
      '<tr><td>Free</td><td>২ MB</td><td>প্ল্যাটফর্মের বিজ্ঞাপন থাকে; ডাউনলোড ৭ দিন রাখে</td></tr>' +
      '<tr><td>Dedicated (এককালীন $৮৯ থেকে)</td><td>১০০ MB</td><td>নিজের আইকন/ব্র্যান্ডিং, ৩৬৫ দিন</td></tr></table>' +
      '<p class="small">এই বিল্ড: index.html ' + mb(BUILD.bytes) + (zip ? ' · ZIP করলে প্রায় ' + mb(zip) + ' — ' + (zip < LIM ? '✅ Free প্ল্যানের ২ MB সীমার মধ্যে' : '⚠️ Free প্ল্যানের ২ MB সীমার বেশি') : '') + '.</p>' +
      '<p class="small muted">সূত্র: webintoapp.com/plans (অক্টোবর ২০২৬-এ দেখা)। প্ল্যান ও সীমা বদলাতে পারে — আপলোডের আগে সাইটে মিলিয়ে নিন। আসল Android ডিভাইসে পরীক্ষা করা হয়নি; ব্রাউজারে মোবাইল-মাপে পরীক্ষা করা হয়েছে।</p></section>';

    html += '<section class="card"><h2>📋 Coverage Checklist (A1)</h2>' + coverageHTML() +
      '<h3>ফিচার</h3><ul class="feat-list">' + FEATURES.map(function (f) { return '<li><span aria-hidden="true">' + f[0] + '</span><div><b>' + (f[3] ? '<a href="' + f[3] + '">' + esc(f[1]) + '</a>' : esc(f[1])) + '</b><div class="small muted">' + esc(f[2]) + '</div></div></li>'; }).join('') + '</ul></section>';
    html += '<section class="card"><h2>🔍 QC রিপোর্ট (A6)</h2>' + qcHTML() + '</section>';
    html += '<section class="card small"><h2>📦 আকার (A7)</h2><p>index.html: <b>' + mb(BUILD.bytes) + '</b>' + (BUILD.parts ? ' — ফন্ট ' + mb(BUILD.parts.fonts) + ' · ডেটা ' + mb(BUILD.parts.data) + ' · কোড ' + mb(BUILD.parts.code) : '') + '</p>' +
      '<p>ডেটা ব্লক প্রয়োজন হলে তবেই পার্স হয় (Lazy Parse)। এই ডিভাইসে এবার খুলতে লেগেছে ≈ <b>' + num(((window.__BOOT_MS__ || 0) / 1000).toFixed(1)) + ' সেকেন্ড</b>।</p>' +
      '<p class="muted">বিল্ড: ' + esc(BUILD.date || '—') + ' · সংস্করণ ' + esc((window.App && App.version) || '') + '</p>' +
      '<details><summary style="min-height:44px;cursor:pointer">ফন্ট লাইসেন্স</summary><p>Hind Siliguri, Noto Sans Bengali, Noto Serif Bengali, Tiro Bangla, Baloo Da 2 — SIL Open Font License 1.1 (অ্যাপে এম্বেড করা, ইন্টারনেট লাগে না)।</p></details></section>';
    $v().innerHTML = html;
    var ib = qs('#pwainstall');
    if (ib) ib.onclick = function () { if (!deferred) return; deferred.prompt(); deferred.userChoice.then(function () { deferred = null; ib.hidden = true; }); };
    qs('#swdl').onclick = function () { if (Store.download('sw.js', swSource())) toast('sw.js ডাউনলোড শুরু হয়েছে'); else toast('ডাউনলোড হয়নি'); };
  }

  C.addRoute(/^#\/about/, viewAbout, 'settings');
  setupPWA();
  window.AboutApp = { swSource: swSource, iconPNG: iconPNG };
})();
