/* =========================================================
   app.js — Core: রাউটার, পাঠ্যসূচি নেভিগেশন, পাঠ, Search,
   Bookmark, Notes, Highlights, Progress Tracker, Resume,
   থিম/ভাষা/সেটিংস, Backup UI, Study Streak ও Daily Goal
   ========================================================= */
(function () {
  'use strict';

  var APP_VERSION = '3.2.0';

  /* ---------------- ডেটা ও সূচক ---------------- */
  var TOC = Data.get('toc');
  var EXAM = Data.get('exam-config');
  var SUBJ = TOC.subjects;
  var SMAP = {}, CMAP = {}, LMAP = {};
  var ORDER = [];            // সব সক্রিয় পাঠ ক্রমানুসারে
  SUBJ.forEach(function (s) {
    SMAP[s.id] = s;
    s.ch.forEach(function (c) {
      c.sid = s.id; CMAP[c.id] = c;
      c.l.forEach(function (l) {
        l.sid = s.id; l.cid = c.id; LMAP[l.id] = l;
        if (l.st !== 'pending') { l.idx = ORDER.length; ORDER.push(l); }
      });
    });
  });
  // শব্দসংখ্যা থেকে পুনর্গণিত পড়ার সময় (build.py-এর lesson-meta); আনুমানিক মান l.m0-তে থাকে
  var META = Data.get('lesson-meta') || {};
  // প্রস্তুতির সময় = পড়া (শব্দসংখ্যা/১৫০) + অনুশীলন (প্রতি MCQ ≈ ১ মিনিট, ব্যাখ্যা পড়াসহ) + ১০% ঝালাই;
  // পাঠ্যসূচির আনুমানিক মানের (l.m0) চেয়ে কম হলে আনুমানিক মানই থাকে — যাতে সময় অবাস্তবভাবে কমে না যায়।
  Object.keys(META).forEach(function (lid) {
    var l = LMAP[lid], v = META[lid]; if (!l) return;
    var rd = Array.isArray(v) ? v[0] : v, qn = Array.isArray(v) ? v[1] : 0;
    if (!(rd > 0)) return;
    l.m0 = l.m; l.rd = rd; l.qn = qn; l.has = 1;
    l.m = Math.max(l.m0 || 0, Math.ceil((rd + qn) * 1.1));
  });
  var LCACHE = {};
  function lessonData(sid) {
    if (LCACHE[sid]) return LCACHE[sid];
    var out = {};
    Data.list('lessons/' + sid + '/').forEach(function (n) { var d = Data.get(n) || {}; for (var k in d) out[k] = d[k]; });
    return (LCACHE[sid] = out);
  }
  function lessonText(lid) {
    var L = LMAP[lid]; if (!L || !L.has) return '';
    var d = lessonData(L.sid)[lid]; if (!d) return '';
    var parts = [];
    (function walk(v) { if (typeof v === 'string') parts.push(v); else if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === 'object') for (var k in v) if (k !== 'k') walk(v[k]); })(d.b);
    return parts.join(' ').replace(/\*\*|==/g, '');
  }
  var UNITS = {};
  EXAM.tracks.forEach(function (t) { t.units.forEach(function (u) { u.track = t; UNITS[u.id] = u; }); });

  var PHASE_OF = { bn1: 3, bn2: 3, en: 4, gkbd: 5, gkint: 5, ca: 6, ict: 7, eco: 9, math: 9, civ: 11, soc: 11, hist: 11, uni: 11 };

  /* ---------------- ভাষা (A4) ---------------- */
  var STR = {
    home: ['হোম', 'Home'], syllabus: ['পাঠ্যসূচি', 'Syllabus'], search: ['সার্চ', 'Search'],
    saved: ['সংরক্ষিত', 'Saved'], settings: ['সেটিংস', 'Settings'], practice: ['অনুশীলন', 'Practice'],
    progress: ['অগ্রগতি', 'Progress'], resume: ['যেখানে ছিলেন', 'Resume'],
    lessons: ['পাঠ', 'lessons'], min: ['মি.', 'min'], remaining: ['বাকি', 'left'],
    done: ['পাঠ সম্পন্ন', 'Lesson complete'], prev: ['পূর্ববর্তী পাঠ', 'Previous'], next: ['পরবর্তী পাঠ', 'Next'],
    notes: ['নোট', 'Notes'], bookmarks: ['বুকমার্ক', 'Bookmarks'], highlights: ['হাইলাইট', 'Highlights'],
    theme: ['থিম', 'Theme'], language: ['ভাষা', 'Language'], backup: ['ব্যাকআপ', 'Backup'],
    myunit: ['আমার ইউনিট', 'My unit'], all: ['সব', 'All'], today: ['আজ', 'Today'], streak: ['ধারাবাহিকতা', 'Streak'],
    days: ['দিন', 'days'], appname: ['ভর্তি প্রস্তুতি', 'Admission Prep'],
    mastery: ['আয়ত্ত', 'Mastery'], qscore: ['কুইজ স্কোর', 'Quiz Score'],
    qprev: ['← পূর্ববর্তী', '← Previous'], qnext: ['পরবর্তী →', 'Next →'], qfinish: ['শেষ করুন →', 'Finish →'], qresult: ['ফলাফল দেখুন →', 'See result →'],
    labelhide: ['শেষ কলাম লুকাও', 'Hide last column'], bnfont: ['বাংলা ফন্ট', 'Bangla font'], fontsize: ['লেখার আকার', 'Text size'], motion: ['অ্যানিমেশন', 'Animation'],
    langnote: ['পাঠের মূল বিষয়বস্তু বাংলায়; এখানে শুধু মেনু, বোতাম ও লেবেলের ভাষা বদলায়।', 'Lesson content stays in Bangla; this changes menus, buttons and labels.']
  };
  function T(k) {
    var s = STR[k]; if (!s) return k;
    var lang = settings().lang;
    if (lang === 'en') return s[1];
    return s[0];
  }
  var BN_DIG = '০১২৩৪৫৬৭৮৯';
  /* শতাংশ: সবসময় দশমিকের পর দুই অঙ্ক — ৫৬.২৫% */
  function pct(x) { return num((+x || 0).toFixed(2)) + '%'; }
  function num(n) {
    var s = String(n);
    if (settings().lang === 'en') return s;
    return s.replace(/[0-9]/g, function (d) { return BN_DIG[+d]; });
  }
  function fromBnDigits(s) { return String(s).replace(/[০-৯]/g, function (d) { return BN_DIG.indexOf(d); }); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtMin(m) {
    m = Math.round(m);
    if (m < 60) return num(m) + ' ' + T('min');
    var h = Math.floor(m / 60), r = m % 60;
    return settings().lang === 'en' ? (h + 'h ' + (r ? r + 'm' : '')) : (num(h) + ' ঘ. ' + (r ? num(r) + ' মি.' : ''));
  }
  function todayKey(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }

  /* ---------------- স্টেট (Store-এ) ---------------- */
  var DEFAULT_SETTINGS = { unitCustom: {}, homeOrder: [], homeHidden: {}, theme: 'aurora', lang: 'bn', font: 'hind', fs: 1, motion: 'auto', unit: 'du-b', examDate: '', goal: 60, sfilter: 'all' };
  function settings() {
    var s = Store.get('settings', {});
    var out = {}; for (var k in DEFAULT_SETTINGS) out[k] = (s[k] === undefined ? DEFAULT_SETTINGS[k] : s[k]);
    if (out.lang !== 'en') out.lang = 'bn'; // পুরোনো "মিশ্র" সেটিং → বাংলা
    return out;
  }
  function setSetting(k, v) { var s = settings(); s[k] = v; Store.set('settings', s, 0); }
  function doneMap() { return Store.get('done', {}); }
  function isDone(lid) { return !!doneMap()[lid]; }
  function setDone(lid, on) {
    var d = doneMap(); var c = {}; for (var k in d) c[k] = d[k];
    if (on) c[lid] = Date.now(); else delete c[lid];
    Store.set('done', c, 0);
  }
  function bmMap() { return Store.get('bm', {}); }
  function toggleBm(lid) {
    var b = bmMap(); var c = {}; for (var k in b) c[k] = b[k];
    if (c[lid]) delete c[lid]; else c[lid] = Date.now();
    Store.set('bm', c, 0); return !!c[lid];
  }
  /* ---- সংরক্ষণ (পাঠ = 'bm', MCQ, Flashcard, লিখিত টপিক) ---- */
  var SAVE_KEYS = { l: 'bm', q: 'saveq', fc: 'savefc', wt: 'savewt' };
  function savedMap(kind) { return Store.get(SAVE_KEYS[kind], {}) || {}; }
  function isSaved(kind, id) { return !!savedMap(kind)[id]; }
  function toggleSaved(kind, id) {
    var b = savedMap(kind); var c = {}; for (var k in b) c[k] = b[k];
    if (c[id]) delete c[id]; else c[id] = Date.now();
    Store.set(SAVE_KEYS[kind], c, 0); return !!c[id];
  }
  function saveBtnHTML(kind, id, extra) {
    var on = isSaved(kind, id);
    return '<button type="button" class="save-btn' + (extra ? ' ' + extra : '') + '" data-save="' + kind + '|' + esc(id) + '" aria-pressed="' + on + '" title="সংরক্ষিত তালিকায় রাখুন">' + (on ? '★ সংরক্ষিত' : '☆ সংরক্ষণ') + '</button>';
  }
  function savedCounts() { var o = {}; for (var k in SAVE_KEYS) o[k] = Object.keys(savedMap(k)).length; return o; }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-save]');
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    var v = b.getAttribute('data-save'), i = v.indexOf('|');
    var kind = v.slice(0, i), id = v.slice(i + 1);
    var on = toggleSaved(kind, id);
    document.querySelectorAll('[data-save]').forEach(function (x) {
      if (x.getAttribute('data-save') !== v) return;
      x.setAttribute('aria-pressed', on);
      x.innerHTML = x.classList.contains('save-btn') ? (on ? '★ সংরক্ষিত' : '☆ সংরক্ষণ') : (on ? ICON.bmOn : ICON.bm);
    });
    toast(on ? '★ সংরক্ষিত তালিকায় যোগ হলো' : 'সংরক্ষিত তালিকা থেকে সরানো হলো');
  }, true);
  function notesMap() { return Store.get('notes', {}); }
  function hlMap() { return Store.get('hl', {}); }

  /* ---------------- Progress হিসাব (F1) ---------------- */
  function statsFor(lessons) {
    var d = doneMap(), total = 0, done = 0, minT = 0, minD = 0;
    lessons.forEach(function (l) {
      if (l.st === 'pending') return;
      total++; minT += l.m;
      if (d[l.id]) { done++; minD += l.m; }
    });
    return { total: total, done: done, pct: total ? done * 100 / total : 0, minTotal: minT, minLeft: minT - minD };
  }
  function lessonsOfSubject(s) { var a = []; s.ch.forEach(function (c) { a = a.concat(c.l); }); return a; }
  function unitSubjects() {
    var u = UNITS[settings().unit];
    return u ? u.subjects.map(function (id) { return SMAP[id]; }).filter(Boolean) : SUBJ;
  }
  function lessonsOfSubjects(list) { var a = []; list.forEach(function (s) { a = a.concat(lessonsOfSubject(s)); }); return a; }

  function pbar(st, small) {
    return '<div class="pbar' + (small ? ' sm' : '') + '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(st.pct) + '"><span style="width:' + st.pct + '%"></span></div>' +
      '<div class="pmeta"><span>' + num(st.done) + '/' + num(st.total) + ' ' + T('lessons') + ' · ' + pct(st.pct) + '</span><span>' + T('remaining') + ' ' + fmtMin(st.minLeft) + '</span></div>';
  }

  /* ---------------- স্টাডি টাইম, Streak ---------------- */
  function daysMap() { return Store.get('days', {}); }
  function addStudySeconds(sec) {
    var d = daysMap(); var c = {}; for (var k in d) c[k] = d[k];
    var k2 = todayKey(); c[k2] = (c[k2] || 0) + sec;
    Store.set('days', c, 2000);
  }
  function streak() {
    var d = daysMap(), n = 0, day = new Date();
    if (!d[todayKey(day)]) day.setDate(day.getDate() - 1); // আজ এখনো না পড়লে গতকাল থেকে গোনা
    while (d[todayKey(day)] && d[todayKey(day)] >= 60) { n++; day.setDate(day.getDate() - 1); }
    return n;
  }
  setInterval(function () {
    if (document.visibilityState === 'visible' && /^#\/(l\/|quiz|test\/run|flash\/review|mistakes|q\/|games\/|written\/p)/.test(location.hash)) addStudySeconds(15);
  }, 15000);

  /* ---------------- থিম ও সেটিংস প্রয়োগ ---------------- */
  var THEMES = [
    ['vanilla', 'Vanilla Off White', ['#faf7f0', '#8a4b10', '#22201b']],
    ['ocean', 'Light Ocean', ['#f2f7fb', '#0b5c8f', '#0e7c86']],
    ['forest', 'Fresh Forest', ['#f3f8f2', '#2c6a33', '#5a7d1c']],
    ['sky', 'Clear Sky', ['#f1f8fe', '#1f5fae', '#2b78c5']],
    ['volcano', 'Soft Volcano', ['#fdf5f0', '#a8371b', '#b8541a']],
    ['glass', 'iOS Glass Light', ['#eef1f6', '#0a5fd1', '#6d3fd1']],
    ['aurora', 'Glass Aurora (ডিফল্ট)', ['#c9f1e6', '#4b3bc4', '#ffd9e6']],
    ['rainbow', 'Glass Rainbow ✨', ['#ffe1ec', '#6328b3', '#dff3ff']],
    ['forestglass', 'Glass Forest ✨', ['#d4f0dc', '#1d6a3a', '#e6f6d6']],
    ['dark', 'Modern Dark', ['#121418', '#7cb4ff', '#f2b25c']],
    ['auto', 'Auto (সিস্টেম)', ['#e9eef7', '#121418', '#7cb4ff']]
  ];
  // বাংলা ফন্ট — সব OFL লাইসেন্সের, অ্যাপের ভেতরেই এম্বেড করা (অফলাইনে চলে)
  var FONTS = [
    ['hind', "'AppBangla'", 'হিন্দ শিলিগুড়ি (ডিফল্ট)'],
    ['notosans', "'BnNotoSans'", 'নোটো সান্স বাংলা']
  ];  // সেরিফ, তিরো ও বালু বাদ — WebIntoApp-এর ২ MB সীমায় নতুন বিষয়ের জায়গা করতে (ব্যবহারকারীর সিদ্ধান্ত, ২৩ অক্টোবর ২০২৬)
  var mqDark = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  /* Unit Mode: ইউনিটের নাম ও বিষয় ব্যবহারকারী নিজে বদলাতে পারেন (exam-config অপরিবর্তিত থাকে) */
  function applyUnitCustom() {
    var c = settings().unitCustom || {};
    Object.keys(UNITS).forEach(function (id) {
      var u = UNITS[id];
      if (!u._o) u._o = { name: u.name, subjects: (u.subjects || []).slice() };
      var o = c[id];
      u.name = o && o.name ? o.name : u._o.name;
      u.subjects = o && o.subjects && o.subjects.length ? o.subjects.slice() : u._o.subjects.slice();
      u.custom = !!(o && (o.name || (o.subjects && o.subjects.length)));
    });
  }
  function applySettings() {
    applyUnitCustom();
    var s = settings();
    var th = s.theme === 'auto' ? (mqDark && mqDark.matches ? 'dark' : 'aurora') : s.theme;
    document.documentElement.setAttribute('data-theme', th);
    document.documentElement.style.setProperty('--fs', s.fs);
    var ff = FONTS.filter(function (f) { return f[0] === s.font; })[0] || FONTS[0];
    document.documentElement.style.setProperty('--app-font', ff[1]);
    if (s.motion === 'reduce') document.documentElement.setAttribute('data-motion', 'reduce');
    else document.documentElement.removeAttribute('data-motion');
    document.documentElement.lang = s.lang === 'en' ? 'en' : 'bn';
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', getComputedStyle(document.documentElement).getPropertyValue('--surface-solid').trim() || '#ffffff');
    renderNav();
  }
  if (mqDark && mqDark.addEventListener) mqDark.addEventListener('change', function () { if (settings().theme === 'auto') applySettings(); });

  /* ---------------- UI সহায়ক ---------------- */
  var $view = document.getElementById('view');
  var $title = document.getElementById('title');
  var $actions = document.getElementById('actions');
  var toastTimer;
  function toast(msg) {
    var t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }
  function modal(html, onMount) {
    closeModal();
    var back = document.createElement('div');
    back.className = 'modal-back'; back.id = 'modal';
    back.innerHTML = '<div class="modal" role="dialog" aria-modal="true">' + html + '</div>';
    back.addEventListener('click', function (e) { if (e.target === back) closeModal(); });
    document.body.appendChild(back);
    if (onMount) onMount(back.firstChild);
    var f = back.querySelector('button, textarea, input'); if (f) f.focus();
  }
  function closeModal() { var m = document.getElementById('modal'); if (m) m.remove(); }

  var ICON = {
    home: '<svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg>',
    book: '<svg viewBox="0 0 24 24"><path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    bm: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z"/></svg>',
    bmOn: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z" fill="currentColor"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>',
    target: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg>',
    palette: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 0 18c1 0 1.5-.8 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.8.7-1.5 1.5-1.5H16a5 5 0 0 0 5-5c0-4.4-4-7.8-9-7.8z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10.5" cy="7.5" r="1"/><circle cx="15" cy="7.5" r="1"/></svg>'
  };

  function renderNav() {
    var nav = document.getElementById('bottomnav');
    var r = currentTab();
    var items = [['home', '#/home', ICON.home], ['syllabus', '#/syllabus', ICON.book], ['practice', '#/practice', ICON.target], ['saved', '#/saved', ICON.bm], ['settings', '#/settings', ICON.gear]];
    nav.innerHTML = items.map(function (it) {
      return '<a href="' + it[1] + '"' + (r === it[0] ? ' aria-current="page"' : '') + '>' + it[2] + '<span>' + T(it[0]) + '</span></a>';
    }).join('');
  }
  function currentTab() {
    var h = location.hash;
    for (var i = 0; i < EXT.length; i++) if (EXT[i].re.test(h)) return EXT[i].tab || 'practice';
    if (/^#\/(syllabus|s\/|l\/)/.test(h)) return 'syllabus';
    if (/^#\/search/.test(h)) return 'search';
    if (/^#\/saved/.test(h)) return 'saved';
    if (/^#\/settings/.test(h)) return 'settings';
    return 'home';
  }
  function setTop(title, opts) {
    opts = opts || {};
    $title.textContent = title;
    document.title = title + ' · ' + T('appname');
    document.getElementById('backbtn').hidden = !opts.back;
    $actions.innerHTML = opts.actions || '';
  }

  /* ---------------- রাউটার ---------------- */
  var cleanup = null;
  var EXT = [];   // বাইরের মডিউলের রুট: {re, fn, tab}
  function route() {
    closeModal();
    if (cleanup) { try { cleanup(); } catch (e) { } cleanup = null; }
    var h = location.hash || '#/home';
    var m;
    for (var i = 0; i < EXT.length; i++) {
      if ((m = h.match(EXT[i].re))) { EXT[i].fn(m, h); renderNav(); window.scrollTo(0, 0); return; }
    }
    if ((m = h.match(/^#\/l\/([\w-]+)/))) viewLesson(m[1]);
    else if ((m = h.match(/^#\/s\/([\w-]+)/))) viewSubject(m[1]);
    else if (/^#\/syllabus/.test(h)) viewSyllabus();
    else if (/^#\/search/.test(h)) viewSearch(decodeURIComponent((h.split('?q=')[1] || '')));
    else if ((m = h.match(/^#\/saved(?:\/(\w+))?/))) viewSaved(m[1] || 'bm');
    else if (/^#\/settings/.test(h)) viewSettings();
    else if (/^#\/study/.test(h)) viewStudy();
    else viewHome();
    renderNav();
    if (!/^#\/l\//.test(h)) window.scrollTo(0, 0);
  }

  /* ================= HOME ================= */
  /* ================= HOME (সাজানো যায় এমন অংশ) ================= */
  var HOME_SECS = {}, HOME_SEQ = [];
  function addHomeSec(id, label, fn) { if (!HOME_SECS[id]) HOME_SEQ.push(id); HOME_SECS[id] = { label: label, fn: fn }; }
  var HOME_DEFAULT = ['unit', 'ready', 'progress', 'quick', 'charts', 'level', 'stats', 'saved', 'written', 'week'];
  var homeEdit = false;
  function homeOrder() {
    var s = settings(), o = (s.homeOrder || []).filter(function (id) { return HOME_SECS[id]; });
    HOME_DEFAULT.concat(HOME_SEQ).forEach(function (id) { if (HOME_SECS[id] && o.indexOf(id) < 0) o.push(id); });
    return o;
  }
  function homeHidden() { return settings().homeHidden || {}; }

  addHomeSec('unit', 'আমার ইউনিট', function () {
    var u = UNITS[settings().unit], my = statsFor(lessonsOfSubjects(unitSubjects()));
    return '<section class="card tight home-unit"><div class="row"><div class="spacer"><div class="small muted">' + T('myunit') + '</div><b class="hu-name">' +
      (u ? esc(u.track.name.split(' (')[0]) + ' · ' + esc(u.code) + ' — ' + esc(u.name) : 'নির্বাচন করুন') + '</b></div>' +
      '<a class="btn sm" href="#/settings">বদলান</a></div>' + pbar(my, true) + '</section>';
  });
  addHomeSec('progress', T('progress') + ' — বিষয়ভিত্তিক', function () {
    var mySubj = unitSubjects();
    return '<section class="card home-prog"><h2>' + T('progress') + ' — বিষয়ভিত্তিক</h2>' +
      mySubj.map(function (sj) {
        var st = statsFor(lessonsOfSubject(sj));
        var ms = QB.mastery(QB.forSubject(sj.id));
        var full = st.total && st.done === st.total;
        return '<a class="subj-link fx" href="#/s/' + sj.id + '" data-pop="' + esc(num(st.done) + '/' + num(st.total) + ' পাঠ সম্পন্ন · বিষয় খুলতে চাপুন') + '">' +
          '<div class="row"><span>' + sj.icon + '</span><b class="spacer">' + esc(sj.t) + (full ? ' <span class="done-mark" title="সম্পন্ন">✓</span>' : '') + '</b>' +
          (ms && ms.tried ? '<span class="chip">' + T('mastery') + ' ' + pct(ms.mastery) + '</span>' : '') + '<span class="caret" aria-hidden="true">›</span></div>' + pbar(st, true) + '</a>';
      }).join('') +
      (SUBJ.length > mySubj.length ? '<div class="other-subj"><div class="small muted" style="margin-bottom:.35rem">অন্যান্য বিষয়</div><div class="row wrap">' +
        SUBJ.filter(function (x) { return mySubj.indexOf(x) < 0; }).map(function (x) { return '<a class="chip" href="#/s/' + x.id + '">' + x.icon + ' ' + esc(x.t) + '</a>'; }).join('') + '</div></div>' : '') +
      '</section>';
  });
  addHomeSec('stats', 'আজ, Streak ও কাউন্টডাউন', function () {
    var s = settings(), u = UNITS[s.unit], dm = daysMap(), todaySec = dm[todayKey()] || 0;
    var goalPct = Math.min(100, Math.round(todaySec / 60 * 100 / (s.goal || 60)));
    var gl = statsFor(ORDER), my = statsFor(lessonsOfSubjects(unitSubjects()));
    var examDate = s.examDate || (u && u.date) || '', cd = '';
    if (examDate) {
      var dleft = Math.ceil((new Date(examDate + 'T00:00:00') - new Date(todayKey() + 'T00:00:00')) / 86400000);
      if (dleft >= 0) {
        var perDay = dleft > 0 ? Math.ceil(my.minLeft / dleft) : my.minLeft;
        cd = '<div class="ms" title="দৈনিক দরকার ≈ ' + esc(fmtMin(perDay)) + '"><span>পরীক্ষা বাকি' + (!s.examDate && u && !u.dateVerified ? '*' : '') + '</span><b>' + num(dleft) + ' ' + T('days') + '</b><small>দিনে ≈ ' + fmtMin(perDay) + '</small></div>';
      }
    }
    return '<section class="mini-stats">' +
      '<div class="ms"><span>' + T('today') + '</span><b>' + fmtMin(todaySec / 60) + '</b><i class="mbar"><i style="width:' + goalPct + '%"></i></i></div>' +
      '<div class="ms"><span>' + T('streak') + '</span><b>🔥 ' + num(streak()) + '</b><small>' + T('days') + '</small></div>' + cd +
      '<div class="ms"><span>মোট অগ্রগতি</span><b>' + pct(gl.pct) + '</b><small>' + num(gl.done) + '/' + num(gl.total) + '</small></div></section>';
  });
  addHomeSec('saved', T('saved'), function () {
    var sc = savedCounts(), stot = sc.l + sc.q + sc.fc + sc.wt;
    return '<a class="card tight row" id="home-saved" href="#/saved/' + (sc.l ? 'bm' : sc.q ? 'q' : sc.fc ? 'fc' : sc.wt ? 'wt' : 'bm') + '" style="text-decoration:none;color:inherit"><span style="font-size:1.3rem" aria-hidden="true">★</span><div class="spacer"><b>' + T('saved') + '</b><div class="small muted">' +
      (stot ? 'পাঠ ' + num(sc.l) + ' · MCQ ' + num(sc.q) + ' · Flashcard ' + num(sc.fc) + ' · লিখিত ' + num(sc.wt) : 'পাঠ, MCQ, Flashcard-এ ☆ সংরক্ষণ চাপলে এখানে জমা হবে') + '</div></div><span class="caret" aria-hidden="true">›</span></a>';
  });
  addHomeSec('week', 'সাপ্তাহিক পড়া', function () {
    return '<section class="card tight home-week"><a class="hw-head" href="#/study" aria-label="গত ৩০ দিনের পড়ার রেকর্ড দেখুন"><h3>সাপ্তাহিক পড়া</h3><span class="hw-more">৩০ দিন <b aria-hidden="true">›</b></span></a>' +
      '<a href="#/study" class="hw-chart" tabindex="-1" aria-hidden="true">' + weekChart(daysMap()) + '</a></section>';
  });

  function viewHome() {
    setTop(T('appname'), { actions: '<button class="icon-btn" id="homeedit" aria-label="হোম সাজান" title="হোম সাজান" aria-pressed="' + homeEdit + '"><svg viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg></button>' });
    document.getElementById('homeedit').onclick = function () { homeEdit = !homeEdit; viewHome(); };
    var order = homeOrder(), hid = homeHidden();
    var html = storageBanner();
    if (homeEdit) {
      html += '<section class="card"><h2 style="margin-top:0">হোম সাজান</h2><p class="small muted">⠿ ধরে টেনে ওপর-নিচ করুন (বা ▲▼ চাপুন)। 👁 চেপে কোনো অংশ লুকাতে/দেখাতে পারবেন। সাথে সাথে সংরক্ষিত হয়।</p>' +
        '<ul class="home-arrange" id="harr">' + order.map(function (id) {
          return '<li data-id="' + id + '" class="' + (hid[id] ? 'off' : '') + '"><span class="h-handle" aria-hidden="true">⠿</span><span class="spacer">' + esc(HOME_SECS[id].label) + '</span>' +
            '<button class="icon-btn" data-mv="-1" aria-label="ওপরে">▲</button><button class="icon-btn" data-mv="1" aria-label="নিচে">▼</button>' +
            '<button class="icon-btn" data-eye aria-pressed="' + !hid[id] + '" aria-label="' + (hid[id] ? 'দেখান' : 'লুকান') + '">' + (hid[id] ? '🚫' : '👁') + '</button></li>';
        }).join('') + '</ul><div class="grid2" style="margin-top:.7rem"><button class="btn" id="hreset">ডিফল্টে ফেরান</button><button class="btn primary" id="hdone">সম্পন্ন</button></div></section>';
      $view.innerHTML = html;
      bindArrange();
      return;
    }
    order.forEach(function (id) {
      if (hid[id]) return;
      var out = ''; try { out = HOME_SECS[id].fn() || ''; } catch (e) { console.error(e); }
      if (out) html += '<div class="hsec" data-sec="' + id + '">' + out + '</div>';
    });
    html += '<p class="small muted home-foot">আয়ত্ত % = যেসব প্রশ্নের শেষ উত্তর সঠিক। হোমের অংশগুলোর ক্রম বদলাতে ওপরের <b>সাজান</b> বোতাম (⚙︎ রেখা) চাপুন।</p>';
    $view.innerHTML = html;
  }
  function saveHomeOrder() {
    var ids = Array.prototype.map.call(document.querySelectorAll('#harr li'), function (li) { return li.getAttribute('data-id'); });
    setSetting('homeOrder', ids);
  }
  function bindArrange() {
    var ul = document.getElementById('harr');
    ul.querySelectorAll('[data-mv]').forEach(function (b) {
      b.onclick = function () {
        var li = b.closest('li'), d = +b.getAttribute('data-mv');
        if (d < 0 && li.previousElementSibling) ul.insertBefore(li, li.previousElementSibling);
        else if (d > 0 && li.nextElementSibling) ul.insertBefore(li.nextElementSibling, li);
        saveHomeOrder(); b.focus();
      };
    });
    ul.querySelectorAll('[data-eye]').forEach(function (b) {
      b.onclick = function () {
        var li = b.closest('li'), id = li.getAttribute('data-id');
        var h = JSON.parse(JSON.stringify(homeHidden()));
        if (h[id]) delete h[id]; else h[id] = 1;
        setSetting('homeHidden', h);
        li.classList.toggle('off', !!h[id]); b.textContent = h[id] ? '🚫' : '👁'; b.setAttribute('aria-pressed', !h[id]);
      };
    });
    // টেনে সাজানো (Pointer Events — মাউস, টাচ, পেন)
    ul.querySelectorAll('.h-handle').forEach(function (h) {
      h.addEventListener('pointerdown', function (e) {
        var li = h.closest('li'); li.classList.add('dragging');
        e.preventDefault();
        function move(ev) {
          var y = ev.clientY;
          var sibs = Array.prototype.filter.call(ul.children, function (x) { return x !== li; });
          var before = null;
          for (var i = 0; i < sibs.length; i++) { var r = sibs[i].getBoundingClientRect(); if (y < r.top + r.height / 2) { before = sibs[i]; break; } }
          if (before) { if (li.nextElementSibling !== before) ul.insertBefore(li, before); } else if (ul.lastElementChild !== li) ul.appendChild(li);
        }
        // DOM-এ জায়গা বদলালে pointer capture হারায়, তাই ডকুমেন্ট-স্তরে শোনা হয়
        function up() {
          li.classList.remove('dragging');
          document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up);
          saveHomeOrder();
        }
        document.addEventListener('pointermove', move); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
      });
    });
    document.getElementById('hdone').onclick = function () { homeEdit = false; viewHome(); window.scrollTo(0, 0); };
    document.getElementById('hreset').onclick = function () { setSetting('homeOrder', []); setSetting('homeHidden', {}); viewHome(); toast('ডিফল্ট ক্রমে ফেরানো হলো'); };
  }

  function weekChart(dm) {
    var cells = [], max = 1, d = new Date(); d.setDate(d.getDate() - 6);
    var names = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
    for (var i = 0; i < 7; i++) { var k = todayKey(d); var m = (dm[k] || 0) / 60; cells.push([names[d.getDay()], m]); if (m > max) max = m; d.setDate(d.getDate() + 1); }
    return '<div class="wk-chart">' +
      cells.map(function (c) {
        var h = Math.max(3, Math.round(c[1] * 48 / max));
        return '<div><div class="wk-bar" title="' + Math.round(c[1]) + ' মি." style="height:' + h + 'px;opacity:' + (c[1] ? 1 : .25) + '"></div><div class="small muted">' + c[0] + '</div></div>';
      }).join('') + '</div>';
  }

  /* ================= গত ৩০ দিনের পড়া (রঙের গাঢ়ত্বে সময়) ================= */
  var MONTHS_BN = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  function studyLevel(min, goal) {
    if (min <= 0) return 0;
    if (min < goal / 4) return 1;
    if (min < goal / 2) return 2;
    if (min < goal) return 3;
    return 4;
  }
  function viewStudy() {
    setTop('গত ৩০ দিনের পড়া', { back: true });
    var dm = daysMap(), goal = Math.max(5, +settings().goal || 60), dn = doneMap();
    var perDay = {};   // দিনে কয়টি পাঠ সম্পন্ন
    Object.keys(dn).forEach(function (lid) { var k = todayKey(new Date(dn[lid])); perDay[k] = (perDay[k] || 0) + 1; });
    var days = [], d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - 29);
    for (var i = 0; i < 30; i++) { var k = todayKey(d); days.push({ k: k, d: new Date(d), min: (dm[k] || 0) / 60, les: perDay[k] || 0 }); d.setDate(d.getDate() + 1); }
    var tot = 0, act = 0, met = 0, best = null;
    days.forEach(function (x) { tot += x.min; if (x.min > 0) act++; if (x.min >= goal) met++; if (!best || x.min > best.min) best = x; });
    var wk = function (a, b) { return days.slice(a, b).reduce(function (s, x) { return s + x.min; }, 0); };
    var thisW = wk(23, 30), lastW = wk(16, 23);
    var names = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
    var fullDay = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
    function dstr(x) { return num(x.d.getDate()) + ' ' + MONTHS_BN[x.d.getMonth()] + ', ' + fullDay[x.d.getDay()]; }
    function detail(x) {
      return '<b>' + dstr(x) + '</b> — ' + (x.min > 0 ? fmtMin(x.min) : 'পড়া হয়নি') + (x.les ? ' · ' + num(x.les) + 'টি পাঠ সম্পন্ন' : '') +
        (x.min >= goal ? ' · ✅ লক্ষ্য পূরণ' : (x.min > 0 ? ' · লক্ষ্যের ' + pct(Math.min(100, x.min * 100 / goal)) : ''));
    }
    var lead = days[0].d.getDay(), cells = '';
    for (var j = 0; j < lead; j++) cells += '<span class="hm-c hm-pad" aria-hidden="true"></span>';
    days.forEach(function (x, i) {
      var lv = studyLevel(x.min, goal), today = i === 29;
      cells += '<button class="hm-c lv' + lv + (today ? ' today' : '') + '" data-i="' + i + '" aria-label="' + esc(dstr(x) + ': ' + (x.min > 0 ? Math.round(x.min) + ' মিনিট' : 'পড়া হয়নি')) + '">' +
        '<i aria-hidden="true"></i><span>' + num(x.d.getDate()) + '</span>' + (x.min >= goal ? '<em aria-hidden="true">✓</em>' : '') + '</button>';
    });
    var first = days[0].d, last = days[29].d;
    var range = num(first.getDate()) + ' ' + MONTHS_BN[first.getMonth()] + ' – ' + num(last.getDate()) + ' ' + MONTHS_BN[last.getMonth()];
    var diff = thisW - lastW;
    var html = '<section class="card"><div class="row"><h2 class="spacer" style="margin:0">৩০ দিনের ক্যালেন্ডার</h2><span class="small muted">' + range + '</span></div>' +
      '<p class="small muted" style="margin:.25rem 0 .6rem">রং যত গাঢ়, সেদিন তত বেশি পড়েছেন। দৈনিক লক্ষ্য ' + fmtMin(goal) + ' (সেটিংস থেকে বদলানো যায়); ✓ = লক্ষ্য পূরণ। কোনো দিনে চাপ দিলে বিস্তারিত দেখাবে।</p>' +
      '<div class="hm-grid">' + names.map(function (n) { return '<span class="hm-wd">' + n + '</span>'; }).join('') + cells + '</div>' +
      '<div class="hm-legend small muted"><span>কম</span>' + [0, 1, 2, 3, 4].map(function (l) { return '<span class="hm-c lv' + l + ' hm-key"><i></i></span>'; }).join('') + '<span>বেশি</span></div>' +
      '<div class="hm-legend-txt small muted">০ মি. · ' + fmtMin(goal / 4) + '-এর কম · ' + fmtMin(goal / 2) + '-এর কম · লক্ষ্যের কম · লক্ষ্য পূরণ</div>' +
      '<div class="hm-detail" id="hmd" aria-live="polite">' + detail(days[29]) + '</div></section>' +
      '<section class="card"><h2>সারসংক্ষেপ</h2><div class="hm-stats">' +
      '<div><b>' + fmtMin(tot) + '</b><span>মোট পড়া</span></div>' +
      '<div><b>' + num(act) + '/৩০</b><span>পড়ার দিন</span></div>' +
      '<div><b>' + fmtMin(tot / 30) + '</b><span>দৈনিক গড়</span></div>' +
      '<div><b>' + num(met) + '</b><span>লক্ষ্য পূরণের দিন</span></div>' +
      '<div><b>' + (best && best.min > 0 ? fmtMin(best.min) : '—') + '</b><span>সেরা দিন' + (best && best.min > 0 ? ' (' + num(best.d.getDate()) + ' ' + MONTHS_BN[best.d.getMonth()] + ')' : '') + '</span></div>' +
      '<div><b>' + num(streak()) + ' দিন</b><span>টানা পড়া</span></div></div>' +
      '<p class="small" style="margin:.7rem 0 0">শেষ ৭ দিনে ' + fmtMin(thisW) + ', তার আগের ৭ দিনে ' + fmtMin(lastW) + (thisW || lastW ? ' — ' + (diff >= 0 ? '📈 ' + fmtMin(diff) + ' বেশি' : '📉 ' + fmtMin(-diff) + ' কম') : '') + '।</p></section>' +
      '<p class="small muted">সময় গোনা হয় পাঠ, Quiz, টেস্ট, Flashcard, ভুলের খাতা, গেম ও লিখিত অনুশীলনের পাতায় থাকার সময় থেকে (অ্যাপ সামনে খোলা থাকলে)। রেকর্ড এই ডিভাইসেই থাকে — ব্যাকআপ নিলে সঙ্গে যায়।</p>';
    $view.innerHTML = html;
    var btns = $view.querySelectorAll('.hm-grid button');
    Array.prototype.forEach.call(btns, function (b) {
      b.onclick = function () {
        Array.prototype.forEach.call(btns, function (o) { o.classList.remove('sel'); });
        b.classList.add('sel');
        document.getElementById('hmd').innerHTML = detail(days[+b.getAttribute('data-i')]);
      };
    });
  }

  function storageBanner() {
    if (Store.mode === 'memory') return '<div class="banner bad" role="alert">⚠️ এই ব্রাউজার/অ্যাপে সংরক্ষণ কাজ করছে না (হয়তো Private Mode)। অ্যাপ বন্ধ করলে অগ্রগতি হারাবে। সেটিংস → ব্যাকআপ থেকে কোড কপি করে রাখুন।</div>';
    if (!Store.lastSaveOk) return '<div class="banner bad" role="alert">⚠️ শেষ সংরক্ষণ ব্যর্থ হয়েছে (জায়গা পূর্ণ?)। ব্যাকআপ নিয়ে রাখুন।</div>';
    return '';
  }

  /* ================= SYLLABUS ================= */
  function subjCard(sj, openSid, mine, cn) {
    var st = statsFor(lessonsOfSubject(sj));
    var open = openSid === sj.id;
    var nReady = sj.ch.filter(function (c) { return c.l.some(function (l) { return l.has; }); }).length;
    return '<details class="card subj" data-sid="' + sj.id + '"' + (open ? ' open' : '') + '><summary>' +
      '<span class="ico" aria-hidden="true">' + sj.icon + '</span><span class="txt"><b>' + esc(sj.t) + '</b>' +
      (st.total && st.done === st.total ? ' <span class="done-mark" title="বিষয় সম্পন্ন">✓</span>' : '') +
      '<div class="small muted">' + esc(sj.en) + ' · ' + num(st.total) + ' ' + T('lessons') + ' · ' + fmtMin(st.minTotal) + '</div>' +
      (st.total ? '<div class="pbar sm" style="margin-top:.3rem"><span style="width:' + st.pct + '%"></span></div>' : '') +
      '</span><span class="caret">›</span></summary>' +
      (sj.note ? '<div class="banner warn" style="margin:0 1rem .5rem">' + esc(sj.note) + '</div>' : '') +
      sj.ch.map(function (c) { return chapterHTML(c, open && sj.ch.length === 1, cn); }).join('') + '</details>';
  }
  function viewSyllabus(openSid) {
    var s = settings();
    var mine = unitSubjects();
    var others = SUBJ.filter(function (x) { return mine.indexOf(x) < 0; });
    var onlyReady = false;
    var onlyMine = s.sfilter === 'unit' && !(openSid && mine.indexOf(SMAP[openSid]) < 0);
    var list = onlyMine ? mine : mine.concat(others);
    var cn = Core.readyInfo ? Core.readyInfo().cn : { q: {}, f: {} };
    setTop(openSid && SMAP[openSid] ? SMAP[openSid].t : T('syllabus'), { back: !!openSid });
    var gl = statsFor(lessonsOfSubjects(list));
    var html = '<div class="row wrap" style="margin-bottom:.8rem"><div class="seg" role="group" aria-label="ফিল্টার">' +
      '<button data-f="all" aria-pressed="' + !onlyMine + '">' + T('all') + ' (' + num(SUBJ.length) + ')</button>' +
      '<button data-f="unit" aria-pressed="' + onlyMine + '">' + T('myunit') + ' (' + num(mine.length) + ')</button></div>' +
      '<span class="small muted spacer" style="text-align:right">মোট ' + fmtMin(gl.minTotal) + '</span></div>';
    html += '<div class="card tight">' + pbar(gl) + '</div>';
    if (onlyReady) {
      var any = false;
      SUBJ.forEach(function (sj) {
        var chs = sj.ch.filter(function (c) { return c.l.some(function (l) { return l.has; }); });
        if (!chs.length) return; any = true;
        html += '<details class="card subj" data-sid="' + sj.id + '" open><summary><span class="ico" aria-hidden="true">' + sj.icon + '</span><span class="txt"><b>' + esc(sj.t) + '</b>' +
          '<div class="small muted">' + num(chs.length) + 'টি অধ্যায় প্রস্তুত</div></span><span class="caret">›</span></summary>' +
          chs.map(function (c) { return chapterHTML(c, true, cn); }).join('') + '</details>';
      });
      if (!any) html += '<p class="muted">এখনো কোনো অধ্যায় প্রস্তুত নয়।</p>';
      html += '<p class="small muted">সব অধ্যায় দেখতে "' + T('all') + '" চাপুন। অধ্যায়ভিত্তিক কার্ড ও কুইজ: <a href="#/ready">তৈরি কনটেন্ট</a></p>';
    } else
    html += mine.map(function (sj) { return subjCard(sj, openSid, true, cn); }).join('');
    if (onlyReady) { } else if (onlyMine) {
      if (others.length) html += '<p class="small muted">আরও ' + num(others.length) + 'টি বিষয় (' + others.map(function (x) { return esc(x.t); }).join(', ') + ') দেখতে "' + T('all') + '" চাপুন।</p>';
    } else if (others.length) {
      html += '<h2 style="margin:1.2rem 0 .6rem">অন্যান্য বিষয়</h2><p class="small muted" style="margin-top:-.3rem">আপনার নির্বাচিত ইউনিটের সিলেবাসে নেই, তবে পড়া ও অনুশীলন করা যাবে।</p>' +
        others.map(function (sj) { return subjCard(sj, openSid, false, cn); }).join('');
    }
    $view.innerHTML = html;

    $view.querySelectorAll('.seg button').forEach(function (b) {
      b.addEventListener('click', function () { setSetting('sfilter', b.getAttribute('data-f')); viewSyllabus(openSid); });
    });
    bindTicks($view, function () { viewSyllabusKeepOpen(); });
    if (openSid) { var el = $view.querySelector('[data-sid="' + openSid + '"]'); if (el) el.scrollIntoView(); }
  }

  /* ================= SUBJECT PAGE (#/s/:sid) ================= */
  function viewSubject(sid) {
    var sj = SMAP[sid];
    if (!sj) { location.replace('#/syllabus'); return; }
    setTop(sj.t, { back: true });
    var cn = Core.readyInfo ? Core.readyInfo().cn : { q: {}, f: {} };
    var st = statsFor(lessonsOfSubject(sj));
    var qs = QB.forSubject(sid), ms = QB.mastery(qs);
    var nCards = QB.cards().filter(function (c) { return c.sub === sid; }).length;
    var d = doneMap();
    var readyCh = sj.ch.filter(function (c) { return c.l.some(function (l) { return l.has; }); });
    var nextL = null;
    readyCh.some(function (c) { return c.l.some(function (l) { if (l.has && !d[l.id]) { nextL = l; return true; } return false; }); });
    var mine = unitSubjects().indexOf(sj) >= 0;
    var html = storageBanner() + '<section class="card subj-head"><div class="row"><span style="font-size:2rem" aria-hidden="true">' + sj.icon + '</span>' +
      '<div class="spacer"><h1 style="margin:0">' + esc(sj.t) + '</h1><div class="small muted">' + esc(sj.en) + ' · ' + num(st.total) + ' ' + T('lessons') + ' · ' + fmtMin(st.minTotal) + '</div></div></div>' +
      (st.total && st.done === st.total ? '<div class="row wrap" style="gap:.35rem;margin:.5rem 0 0"><span class="chip ok">✓ বিষয় সম্পন্ন</span></div>' : '') +
      (st.total ? '<div style="margin-top:.6rem">' + pbar(st) + '</div>' : '') +
      '<div class="row wrap subj-actions">' +
      (nextL ? '<a class="btn primary" href="#/l/' + nextL.id + '">' + (st.done ? 'চালিয়ে যান →' : 'পড়া শুরু →') + '</a>' : '') +
      (qs.length ? '<a class="act-chip" href="#/quiz/s/' + sid + '" title="বিষয়ের Adaptive Quiz">❓ ' + num(qs.length) + ' MCQ</a>' : '') +
      (nCards ? '<a class="act-chip" href="#/flash/review?sub=' + sid + '&cid=&mode=all" title="Flashcard রিভিউ">🃏 ' + num(nCards) + ' কার্ড</a>' : '') +
      (qs.length >= 20 ? '<a class="act-chip" href="#/final/' + sid + '" title="১০০ প্রশ্নের Subject Final">🏁 Final</a>' : '') +
      (window.Charts && Charts.forSubject(sid).length ? '<a class="act-chip" href="#/charts?s=' + sid + '" title="এই বিষয়ের চার্ট ও ডায়াগ্রাম">📊 ' + num(Charts.forSubject(sid).length) + ' চার্ট</a>' : '') +
      (ms && ms.tried ? '<a class="act-chip" href="#/mistakes?sub=' + sid + '" title="এই বিষয়ের ভুলগুলো">' + T('mastery') + ' ' + pct(ms.mastery) + '</a>' : '') +
      '</div></section>';
    if (sid === 'ca') html += '<a class="card tight row" id="cahublink" href="#/ca" style="text-decoration:none;color:inherit"><span style="font-size:1.6rem" aria-hidden="true">📰</span><div class="spacer"><b>সাম্প্রতিক হাব</b><div class="small muted">মাসভিত্তিক প্যাক · মাসের Quiz ও Flashcard · নতুন প্যাক Import</div></div><span class="btn sm primary">খুলুন →</span></a>';
    if (sj.note) html += '<div class="banner warn">' + esc(sj.note) + '</div>';
    if (!st.total) html += '<p class="muted">এই বিষয়ের পাঠ্যসূচি যাচাই বাকি (Phase ' + num(PHASE_OF[sid] || 0) + ')।</p>';
    html += '<section class="card subj" style="padding:0">' + sj.ch.map(function (c) {
      var open = nextL ? nextL.cid === c.id : sj.ch.length === 1;
      return chapterHTML(c, open, cn);
    }).join('') + '</section>';
    html += '<p class="small"><a href="#/syllabus">← সম্পূর্ণ পাঠ্যসূচি</a></p>';
    $view.innerHTML = html;
    bindTicks($view, function () { viewSyllabusKeepOpen(); });
  }
  function viewSyllabusKeepOpen() {
    // টিক দেওয়ার পর খোলা অবস্থা ও স্ক্রল ধরে রেখে আবার আঁকা
    var openS = [], openC = [];
    $view.querySelectorAll('details.subj[open]').forEach(function (d) { openS.push(d.getAttribute('data-sid')); });
    $view.querySelectorAll('details.chap[open]').forEach(function (d) { openC.push(d.getAttribute('data-cid')); });
    var y = window.scrollY;
    var m = location.hash.match(/^#\/s\/([\w-]+)/);
    if (m) viewSubject(m[1]); else viewSyllabus(null);
    openS.forEach(function (id) { var d = $view.querySelector('details.subj[data-sid="' + id + '"]'); if (d) d.open = true; });
    openC.forEach(function (id) { var d = $view.querySelector('details.chap[data-cid="' + id + '"]'); if (d) d.open = true; });
    window.scrollTo(0, y);
  }
  function chapterHTML(c, open, cn) {
    var st = statsFor(c.l);
    var d = doneMap();
    cn = cn || { q: {}, f: {} };
    var ready = c.l.some(function (l) { return l.has; });
    return '<details class="chap' + (ready ? ' is-ready' : '') + '" data-cid="' + c.id + '"' + (open ? ' open' : '') + '><summary><span class="txt">' + esc(c.t) +
      (st.total && st.done === st.total ? ' <span class="done-mark" title="অধ্যায় সম্পন্ন">✓</span>' : '') +
      '<div class="small muted">' + (st.total ? num(st.done) + '/' + num(st.total) + ' · ' + fmtMin(st.minTotal) + ' · ' + T('remaining') + ' ' + fmtMin(st.minLeft) : 'সিলেবাস যাচাই বাকি') + '</div></span>' +
      '<span class="caret">›</span></summary><ul class="lessons">' +
      (c.l.some(function (l) { return l.has; }) ? '<li class="map-li"><a href="#/charts/map/' + c.id + '">🗺 এই অধ্যায়ের কনসেপ্ট ম্যাপ</a></li>' : '') +
      c.l.map(function (l) {
        if (l.st === 'pending') return '<li><span class="small muted" style="padding:.6rem .5rem">⏳ ' + esc(l.t) + '</span></li>';
        var on = !!d[l.id];
        return '<li class="' + (on ? 'done' : '') + '"><button class="tick" data-lid="' + l.id + '" aria-pressed="' + on + '" aria-label="' + esc(l.t) + ' — ' + T('done') + '"><span>✓</span></button>' +
          '<a class="fx' + (l.has ? ' has' : ' soon') + '" href="#/l/' + l.id + '" data-pop="' + esc(Core.lessonPop ? Core.lessonPop(l, cn, on) : fmtMin(l.m)) + '"><span class="lt spacer">' + (l.has ? '<span class="dot" aria-hidden="true"></span>' : '') + esc(l.t) + (l.v ? ' <span class="chip verify">Verify</span>' : '') + '</span><span class="min">' + fmtMin(l.m) + '</span></a></li>';
      }).join('') + '</ul></details>';
  }
  function bindTicks(root, after) {
    root.querySelectorAll('.tick').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.preventDefault();
        var lid = b.getAttribute('data-lid');
        var on = !isDone(lid);
        setDone(lid, on);
        toast(on ? '✓ সম্পন্ন হিসেবে চিহ্নিত' : 'চিহ্ন তুলে নেওয়া হলো');
        if (after) after();
      });
    });
  }

  /* ================= LESSON ================= */
  function viewLesson(lid) {
    var L = LMAP[lid];
    if (!L || L.st === 'pending') { location.replace('#/syllabus'); return; }
    var S = SMAP[L.sid], C = CMAP[L.cid];
    var bmOn = !!bmMap()[lid];
    setTop(S.t, { back: true, actions: '<button class="icon-btn" id="bmbtn" data-save="l|' + lid + '" aria-pressed="' + bmOn + '" aria-label="সংরক্ষণ">' + (bmOn ? ICON.bmOn : ICON.bm) + '</button>' });

    var content = lessonData(S.id)[lid] || null;
    var prev = ORDER[L.idx - 1], next = ORDER[L.idx + 1];
    var note = (notesMap()[lid] || {}).text || '';

    var html = '<div class="crumbs"><a href="#/s/' + S.id + '">' + esc(S.t) + '</a> › ' + esc(C.t) + '</div>' +
      '<h1>' + esc(L.t) + '</h1>' +
      '<div class="row wrap" style="margin-bottom:.8rem"><span class="chip">⏱ ' + (L.rd ? (settings().lang === 'en' ? 'Study ~' + fmtMin(L.m) + ' (reading ' + fmtMin(L.rd) + (L.qn ? ' + ' + L.qn + ' MCQ' : '') + ')' : 'প্রস্তুতি ~' + fmtMin(L.m) + ' (পড়া ' + fmtMin(L.rd) + (L.qn ? ' + ' + num(L.qn) + 'টি MCQ' : '') + ')') : fmtMin(L.m)) + '</span>' +
      (L.v ? '<span class="chip verify">Verify: শিরোনাম যাচাই বাকি</span>' : '') +
      (content && content.v ? '<span class="chip verify">' + esc(content.v) + '</span>' : '') + saveBtnHTML('l', lid) + '</div>' +
      '<article class="card lesson-body" id="lbody">' +
      (content ? LessonRender.render(content) : '<div class="placeholder"><p><b>এই পাঠের কনটেন্ট Phase ' + num(PHASE_OF[S.id]) + '-এ যোগ হবে।</b></p>' +
        '<p class="small">কাঠামো (PART D): Concept Overview · Deep Explanation · Key Facts/Table/Timeline · Memory Hacks · Common Mistakes ও Exam Tricks · Important Facts Box · University-wise Analysis · MCQ Focus · PYQ</p>' +
        '<p class="small">এখন যা পরীক্ষা করতে পারেন: পাঠ সম্পন্ন চিহ্ন, বুকমার্ক, নোট, হাইলাইট (এই লেখার যেকোনো অংশ সিলেক্ট করে), পরের/আগের পাঠ, এবং অ্যাপ বন্ধ করে আবার খুললে এখানেই ফিরে আসা।</p></div>') +
      '</article>' +
      lessonChartsHTML(lid) +
      lessonPracticeHTML(lid) +
      '<div class="card tight"><label class="done-toggle"><input type="checkbox" id="donechk"' + (isDone(lid) ? ' checked' : '') + '> ' + T('done') + '</label></div>' +
      '<div class="lesson-nav">' +
      (prev ? '<a class="btn" href="#/l/' + prev.id + '">← ' + T('prev') + '</a>' : '<span></span>') +
      (next ? '<a class="btn primary" href="#/l/' + next.id + '">' + T('next') + ' →</a>' : '<span></span>') + '</div>' +
      '<section class="card" style="margin-top:.9rem"><h2>📝 ' + T('notes') + '</h2>' +
      '<textarea class="note" id="note" placeholder="এই পাঠের জন্য নিজের নোট লিখুন… (স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়)">' + esc(note) + '</textarea>' +
      '<div class="saved-ind" id="saveind" aria-live="polite"></div></section>';
    $view.innerHTML = html;

    // Highlights প্রয়োগ
    if (content) LessonRender.bind(document.getElementById('lbody'), content);
    applyHighlights(document.getElementById('lbody'), (hlMap()[lid] || []));

    // সংরক্ষণ: data-save দিয়ে ডকুমেন্ট-স্তরে ধরা হয়
    // Done
    document.getElementById('donechk').addEventListener('change', function () {
      setDone(lid, this.checked);
      toast(this.checked ? '✓ পাঠ সম্পন্ন' : 'অসম্পন্ন হিসেবে রাখা হলো');
    });
    // Notes (Auto-save)
    var ta = document.getElementById('note'), ind = document.getElementById('saveind'), nt;
    ta.addEventListener('input', function () {
      ind.textContent = 'লিখছেন…';
      clearTimeout(nt);
      nt = setTimeout(function () {
        var n = notesMap(); var c = {}; for (var k in n) c[k] = n[k];
        if (ta.value.trim()) c[lid] = { text: ta.value, t: Date.now() }; else delete c[lid];
        Store.set('notes', c, 0).then(function () { ind.textContent = '✓ সংরক্ষিত'; });
      }, 500);
    });

    // Highlight বাটন (টেক্সট সিলেক্ট করলে)
    var hlBtn = document.createElement('button');
    hlBtn.className = 'btn primary'; hlBtn.textContent = '🖍 ' + T('highlights');
    hlBtn.style.cssText = 'position:fixed;right:1rem;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:30;display:none';
    document.body.appendChild(hlBtn);
    function onSel() {
      var sel = window.getSelection();
      var txt = sel ? String(sel).trim() : '';
      var inside = sel && sel.rangeCount && document.getElementById('lbody') && document.getElementById('lbody').contains(sel.anchorNode);
      hlBtn.style.display = (txt.length >= 2 && txt.length <= 400 && inside) ? 'inline-flex' : 'none';
    }
    document.addEventListener('selectionchange', onSel);
    hlBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    hlBtn.addEventListener('click', function () {
      var txt = String(window.getSelection()).trim();
      if (!txt) return;
      var h = hlMap(); var c = {}; for (var k in h) c[k] = h[k].slice ? h[k].slice() : h[k];
      c[lid] = (c[lid] || []).concat([txt]);
      Store.set('hl', c, 0);
      window.getSelection().removeAllRanges();
      hlBtn.style.display = 'none';
      applyHighlights(document.getElementById('lbody'), [txt]);
      toast('হাইলাইট সংরক্ষিত');
    });

    // Resume: শেষ পাঠ ও স্ক্রল অবস্থান
    var last = Store.get('last', null);
    var y0 = (last && last.lid === lid) ? (last.y || 0) : 0;
    Store.set('last', { lid: lid, y: y0, t: Date.now() }, 0);
    // সাম্প্রতিক অধ্যায় (হোমের "চালিয়ে যান" অংশের জন্য) — সর্বশেষ আগে, সর্বোচ্চ ১০টি
    (function () {
      var cid = LMAP[lid] && LMAP[lid].cid; if (!cid) return;
      var r = (Store.get('recent', []) || []).filter(function (x) { return x && x.cid !== cid; });
      r.unshift({ cid: cid, lid: lid, t: Date.now() });
      Store.set('recent', r.slice(0, 10), 0);
    })();
    requestAnimationFrame(function () { window.scrollTo(0, y0); });
    var st;
    function onScroll() {
      clearTimeout(st);
      st = setTimeout(function () { Store.set('last', { lid: lid, y: Math.round(window.scrollY), t: Date.now() }, 500); }, 300);
    }
    window.addEventListener('scroll', onScroll, { passive: true });

    cleanup = function () {
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('selectionchange', onSel);
      hlBtn.remove();
      // নোট টাইপ চলা অবস্থায় চলে গেলে সংরক্ষণ নিশ্চিত
      if (nt) {
        clearTimeout(nt);
        var n = notesMap(); var c = {}; for (var k in n) c[k] = n[k];
        if (ta.value.trim()) c[lid] = { text: ta.value, t: Date.now() }; else delete c[lid];
        Store.set('notes', c, 0);
      }
    };
  }

  function lessonChartsHTML(lid) {
    if (!window.Charts) return '';
    var cs = Charts.forLesson(lid);
    if (!cs.length) return '';
    return '<section class="card tight"><h2 style="margin:0 0 .45rem;font-size:1.05rem">📊 এই পাঠের চার্ট ও ডায়াগ্রাম</h2><div class="lesson-charts">' +
      cs.map(function (c) { return '<a class="act-chip" href="#/charts/' + c.id + '">' + num(c.n) + '. ' + esc(c.t) + '</a>'; }).join('') + '</div></section>';
  }
  function lessonPracticeHTML(lid) {
    var qs = QB.forLesson(lid);
    var pyq = qs.filter(function (q) { return q.exam; }).length;
    var cards = QB.cards().filter(function (c) { return c.lid === lid; }).length;
    var mist = QB.mistakes().filter(function (m) { return m.q.lid === lid; }).length;
    var ms = QB.mastery(qs);
    function b(href, label, n, primary) {
      return n ? '<a class="btn' + (primary ? ' primary' : '') + '" href="' + href + '">' + label + ' (' + num(n) + ')</a>'
               : '<button class="btn" disabled>' + label + ' (০)</button>';
    }
    return '<section class="card"><h2>পাঠ-শেষ অনুশীলন</h2>' +
      (ms && ms.tried ? '<p class="small">' + T('mastery') + ' ' + pct(ms.mastery) + ' · ' + T('qscore') + ' ' + (ms.score === null ? pct(0) : pct(ms.score)) + '</p>' : '') +
      '<div class="grid2">' + b('#/quiz/l/' + lid, 'MCQ', qs.length, true) + b('#/pyq?lid=' + lid, 'PYQ', pyq) +
      b('#/flash/review?lid=' + lid, 'Flashcard', cards) + b('#/mistakes?lid=' + lid, 'ভুল অনুশীলন', mist) + '</div>' +
      (!qs.length ? '<p class="small muted" style="margin:.5rem 0 0">এই পাঠের জন্য আলাদা MCQ নেই — <a href="#/quiz/s/' + LMAP[lid].sid + '">বিষয়ের কুইজ</a> দিন।</p>' : '') + '</section>';
  }

  function applyHighlights(root, list) {
    if (!root || !list || !list.length) return;
    list.forEach(function (needle) {
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
      var node;
      while ((node = walker.nextNode())) {
        if (node.parentNode && node.parentNode.nodeName === 'MARK') continue;
        // একটি টেক্সট নোডের ভেতরে থাকা অংশই হাইলাইট হয় (একাধিক ট্যাগ জুড়ে হলে প্রথম নোড পর্যন্ত)
        var j = node.nodeValue.indexOf(needle);
        if (j < 0) continue;
        var after = node.splitText(j);
        after.splitText(needle.length);
        var mk = document.createElement('mark'); mk.className = 'hl';
        after.parentNode.replaceChild(mk, after); mk.appendChild(after);
        break;
      }
    });
  }

  /* ================= SEARCH ================= */
  function norm(s) { return fromBnDigits(String(s || '')).toLowerCase().replace(/[‌‍]/g, '').replace(/\s+/g, ' ').trim(); }
  var INDEX = null;
  function buildIndex() {
    INDEX = ORDER.map(function (l) {
      var S = SMAP[l.sid], C = CMAP[l.cid];
      return { l: l, key: norm(l.t), ctx: norm(C.t + ' ' + S.t + ' ' + S.en), body: norm(lessonText(l.id)) };
    });
  }
  function viewSearch(q) {
    setTop(T('search'));
    $view.innerHTML = '<div class="search-box">' + ICON.search + '<input id="q" type="search" inputmode="search" autocomplete="off" placeholder="পাঠ, টপিক, নোট খুঁজুন… (যেমন: সমাস, Voice, জাতিসংঘ)" value="' + esc(q) + '" aria-label="সার্চ"></div>' +
      '<div id="res" style="margin-top:.6rem"></div>';
    var inp = document.getElementById('q'), t;
    function run() {
      var qq = norm(inp.value);
      history.replaceState(null, '', '#/search' + (inp.value ? '?q=' + encodeURIComponent(inp.value) : ''));
      document.getElementById('res').innerHTML = searchHTML(qq);
    }
    inp.addEventListener('input', function () { clearTimeout(t); t = setTimeout(run, 150); });
    run();
    setTimeout(function () { inp.focus(); }, 50);
  }
  function searchHTML(q) {
    if (!q) return '<p class="muted small">সব ' + num(ORDER.length) + 'টি পাঠের শিরোনাম, অধ্যায়, বিষয়, আপনার নোট ও ' + num(QB.all().length) + 'টি প্রশ্নে খোঁজা হবে।</p>';
    if (!INDEX) buildIndex();
    var words = q.split(' ');
    var hits = [];
    INDEX.forEach(function (it) {
      var score = 0, all = true;
      words.forEach(function (w) {
        if (it.key.indexOf(w) >= 0) score += (it.key.indexOf(w) === 0 ? 4 : 3);
        else if (it.ctx.indexOf(w) >= 0) score += 1;
        else if (it.body && it.body.indexOf(w) >= 0) score += 0.5;
        else all = false;
      });
      if (all && score) hits.push([score, it.l]);
    });
    hits.sort(function (a, b) { return b[0] - a[0] || a[1].idx - b[1].idx; });
    var notes = notesMap(), nHits = [];
    Object.keys(notes).forEach(function (lid) {
      var tx = norm(notes[lid].text);
      if (LMAP[lid] && words.every(function (w) { return tx.indexOf(w) >= 0; })) nHits.push(lid);
    });
    var qHits = QB.all().filter(function (qq) {
      var tx = norm(qq.q + ' ' + qq.o.join(' '));
      return words.every(function (w) { return tx.indexOf(w) >= 0; });
    });
    var cHits = window.Charts ? Charts.all().filter(function (c) { var tx = norm(c.t + ' ' + (c.d || '') + ' ' + (c.tags || '')); return words.every(function (w) { return tx.indexOf(w) >= 0; }); }) : [];
    var out = '<p class="small muted">' + num(hits.length) + 'টি পাঠ' + (cHits.length ? ', ' + num(cHits.length) + 'টি চার্ট' : '') + (nHits.length ? ', ' + num(nHits.length) + 'টি নোট' : '') + (qHits.length ? ', ' + num(qHits.length) + 'টি প্রশ্ন' : '') + '</p>';
    if (cHits.length) out += '<h3 style="margin-top:.4rem">📊 চার্টে পাওয়া</h3>' + cHits.slice(0, 12).map(function (c) { return '<a class="result" href="#/charts/' + c.id + '"><div><b>' + num(c.n) + '. ' + esc(c.t) + '</b></div><div class="where">' + esc(c.d || '') + '</div></a>'; }).join('');
    out += hits.slice(0, 80).map(function (h) { return resultHTML(h[1]); }).join('');
    if (nHits.length) out += '<h3 style="margin-top:1rem">📝 নোটে পাওয়া</h3>' + nHits.map(function (lid) { return resultHTML(LMAP[lid], notes[lid].text); }).join('');
    if (qHits.length) out += '<h3 style="margin-top:1rem">❓ প্রশ্নে পাওয়া</h3>' + qHits.slice(0, 40).map(function (qq) {
      return '<a class="result" href="#/q/' + qq.id + '"><div>' + esc(qq.q) + '</div><div class="where">' + (SMAP[qq.sub] ? SMAP[qq.sub].icon + ' ' + esc(SMAP[qq.sub].t) : '') + ' · ' + esc(QB.srcLabel(qq)) + '</div></a>';
    }).join('');
    if (!hits.length && !nHits.length && !qHits.length && !cHits.length) out += '<p class="muted">কিছু পাওয়া যায়নি। বানান বা অন্য শব্দ চেষ্টা করুন।</p>';
    return out;
  }
  function resultHTML(l, snippet) {
    var S = SMAP[l.sid], C = CMAP[l.cid];
    return '<a class="result" href="#/l/' + l.id + '"><div><b>' + (isDone(l.id) ? '✓ ' : '') + esc(l.t) + '</b></div>' +
      '<div class="where">' + S.icon + ' ' + esc(S.t) + ' › ' + esc(C.t) + ' · ' + fmtMin(l.m) + '</div>' +
      (snippet ? '<div class="small muted">' + esc(snippet.slice(0, 120)) + (snippet.length > 120 ? '…' : '') + '</div>' : '') + '</a>';
  }

  /* ================= SAVED ================= */
  function viewSaved(tab) {
    setTop(T('saved'));
    var bm = bmMap(), notes = notesMap(), hl = hlMap();
    var sq = savedMap('q'), sf = savedMap('fc'), sw = savedMap('wt');
    var qList = Object.keys(sq).map(function (id) { return QB.get(id); }).filter(Boolean).sort(function (a, b) { return sq[b.id] - sq[a.id]; });
    var cmap = {}; QB.cards().forEach(function (c) { cmap[c.id] = c; });
    var fList = Object.keys(sf).filter(function (id) { return cmap[id]; }).sort(function (a, b) { return sf[b] - sf[a]; }).map(function (id) { return cmap[id]; });
    var wd = (Data.has('written/du') && Data.get('written/du')) || { sections: [] }, wmap = {};
    (wd.sections || []).forEach(function (sec) { (sec.topics || []).forEach(function (t) { wmap[t.id] = { t: t, sec: sec }; }); });
    var wList = Object.keys(sw).filter(function (id) { return wmap[id]; }).sort(function (a, b) { return sw[b] - sw[a]; });
    var lList = Object.keys(bm).filter(function (k) { return LMAP[k]; });
    var tabs = [['bm', '📖 পাঠ', lList.length], ['q', '❓ MCQ', qList.length], ['fc', '🃏 Flashcard', fList.length], ['wt', '✍️ লিখিত', wList.length],
      ['notes', '📝 ' + T('notes'), Object.keys(notes).length], ['hl', '🖍 ' + T('highlights'), Object.keys(hl).length]];
    var html = '<p class="small muted" style="margin:0 0 .6rem">পাঠ, MCQ, Flashcard বা লিখিত টপিকের <b>☆ সংরক্ষণ</b> বাটনে চাপলে এখানে জমা হয়। আবার চাপলে সরে যায়।</p>' +
      '<div class="seg saved-tabs" role="tablist" style="margin-bottom:.8rem">' +
      tabs.map(function (t) { return '<button role="tab" data-t="' + t[0] + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + ' (' + num(t[2]) + ')</button>'; }).join('') + '</div>';
    var body = '';
    if (tab === 'bm') {
      body = '<div class="card">' + lList.sort(function (a, b) { return bm[b] - bm[a]; }).map(function (lid) { return '<div class="row">' + '<div class="spacer">' + resultHTML(LMAP[lid]) + '</div>' + saveBtnHTML('l', lid, 'sm') + '</div>'; }).join('') + '</div>';
      if (!lList.length) body = '<div class="card"><p class="muted">কোনো পাঠ সংরক্ষিত নেই। পাঠের শিরোনামের নিচে বা উপরের 🔖 বাটনে <b>☆ সংরক্ষণ</b> চাপুন।</p></div>';
    } else if (tab === 'q') {
      if (qList.length) {
        body = '<div class="row wrap" style="margin-bottom:.6rem"><a class="btn primary" href="#/quiz/saved">▶ সংরক্ষিত ' + num(qList.length) + 'টি MCQ দিয়ে Quiz</a></div>' +
          qList.map(function (q, i) {
            return '<details class="card tight"><summary style="min-height:44px;cursor:pointer">' + num(i + 1) + '. ' + esc(q.q) + '</summary>' +
              (window.Practice ? Practice.qCardHTML(q, { reveal: true, view: true }) : '') + '</details>';
          }).join('');
      } else body = '<div class="card"><p class="muted">কোনো MCQ সংরক্ষিত নেই। যেকোনো প্রশ্নের উপরে <b>☆ সংরক্ষণ</b> চাপুন — Quiz, টেস্ট, ফলাফল বা ভুলের খাতা থেকে।</p></div>';
    } else if (tab === 'fc') {
      if (fList.length) {
        body = '<div class="row wrap" style="margin-bottom:.6rem"><a class="btn primary" href="#/flash/review?saved=1">🃏 সংরক্ষিত ' + num(fList.length) + 'টি কার্ড রিভিউ</a></div>' +
          fList.map(function (c) {
            return '<details class="card tight"><summary class="row" style="min-height:44px;cursor:pointer"><span class="spacer">' + esc(c.f) + '</span></summary>' +
              '<p style="margin:.4rem 0"><b>উত্তর:</b> ' + esc(c.b) + '</p><div class="row wrap">' + (c.lid && LMAP[c.lid] ? '<a class="small" href="#/l/' + c.lid + '">📖 ' + esc(LMAP[c.lid].t) + '</a>' : '') + '<span class="spacer"></span>' + saveBtnHTML('fc', c.id, 'sm') + '</div></details>';
          }).join('');
      } else body = '<div class="card"><p class="muted">কোনো Flashcard সংরক্ষিত নেই। কার্ড রিভিউ করার সময় উপরের <b>☆ সংরক্ষণ</b> চাপুন।</p></div>';
    } else if (tab === 'wt') {
      body = '<div class="card">' + wList.map(function (id) {
        var w = wmap[id];
        return '<div class="row" style="padding:.4rem 0;border-top:1px solid var(--border)"><a class="spacer" href="#/written/t/' + id + '"><b>' + esc(w.t.t) + '</b><div class="small muted">' + esc(w.sec.t || '') + ' · লিখিত</div></a>' + saveBtnHTML('wt', id, 'sm') + '</div>';
      }).join('') + '</div>';
      if (!wList.length) body = '<div class="card"><p class="muted">কোনো লিখিত টপিক সংরক্ষিত নেই। DU লিখিত ল্যাবের টপিক পাতায় <b>☆ সংরক্ষণ</b> চাপুন। (নিজের লেখা উত্তরগুলো ল্যাবের "আমার লেখা" অংশে থাকে।)</p></div>';
    } else if (tab === 'notes') {
      body = Object.keys(notes).filter(function (k) { return LMAP[k]; }).sort(function (a, b) { return notes[b].t - notes[a].t; }).map(function (lid) { return resultHTML(LMAP[lid], notes[lid].text); }).join('');
      body = '<div class="card">' + (body || '<p class="muted">কোনো নোট নেই। পাঠের নিচে নোট লিখলে এখানে দেখাবে।</p>') + '</div>';
    } else {
      body = Object.keys(hl).filter(function (k) { return LMAP[k] && hl[k].length; }).map(function (lid) {
        return resultHTML(LMAP[lid]) + '<div style="padding:0 0 .6rem">' + hl[lid].map(function (h, i) {
          return '<div class="row" style="margin:.2rem 0"><mark class="hl spacer">' + esc(h) + '</mark><button class="icon-btn" data-del="' + lid + '|' + i + '" aria-label="হাইলাইট মুছুন">✕</button></div>';
        }).join('') + '</div>';
      }).join('');
      body = '<div class="card">' + (body || '<p class="muted">কোনো হাইলাইট নেই। পাঠে লেখা সিলেক্ট করে 🖍 চাপুন।</p>') + '</div>';
    }
    $view.innerHTML = html + body;
    $view.querySelectorAll('[data-t]').forEach(function (b) { b.addEventListener('click', function () { location.hash = '#/saved/' + b.getAttribute('data-t'); }); });
    $view.querySelectorAll('[data-del]').forEach(function (b) {
      b.addEventListener('click', function () {
        var p = b.getAttribute('data-del').split('|');
        var h = hlMap(); var c = {}; for (var k in h) c[k] = h[k].slice();
        c[p[0]].splice(+p[1], 1); if (!c[p[0]].length) delete c[p[0]];
        Store.set('hl', c, 0); viewSaved('hl');
      });
    });
  }

  function themeGridHTML() {
    var cur = settings().theme;
    return '<div class="theme-grid">' + THEMES.map(function (t) {
      return '<button class="theme-opt" data-theme-opt="' + t[0] + '" aria-pressed="' + (cur === t[0]) + '" style="background:' + t[2][0] + ';color:' + (t[0] === 'dark' ? '#ecedf0' : '#1a1a1a') + '">' +
        '<span class="small"><b>' + esc(t[1]) + '</b></span><span class="sw">' + t[2].map(function (c) { return '<i style="background:' + c + '"></i>'; }).join('') + '</span></button>';
    }).join('') + '</div>';
  }
  function bindThemeGrid(root, after) {
    root.querySelectorAll('[data-theme-opt]').forEach(function (b) {
      b.addEventListener('click', function () {
        setSetting('theme', b.getAttribute('data-theme-opt')); applySettings();
        root.querySelectorAll('[data-theme-opt]').forEach(function (x) { x.setAttribute('aria-pressed', x === b); });
        if (after) after();
      });
    });
  }
  function openThemeSheet() {
    modal('<div class="row"><h2 class="spacer" style="margin:0">🎨 ' + T('theme') + '</h2><button class="icon-btn" id="thx" aria-label="বন্ধ">✕</button></div>' +
      '<p class="small muted">ট্যাপ করলেই সাথে সাথে বদলাবে ও সংরক্ষিত হবে।</p>' + themeGridHTML(), function (m) {
      m.querySelector('#thx').onclick = closeModal;
      bindThemeGrid(m);
    });
  }

  /* ================= SETTINGS ================= */
  function viewSettings() {
    setTop(T('settings'));
    var s = settings();
    var modeTxt = { 'idb+ls': 'IndexedDB (প্রধান) + localStorage (ব্যাকআপ) ✓', idb: 'শুধু IndexedDB ✓', ls: 'শুধু localStorage ✓', memory: '⚠️ সংরক্ষণ কাজ করছে না' }[Store.mode];
    var html = storageBanner();

    html += '<section class="card"><h2>🎨 ' + T('theme') + ' (' + num(THEMES.length - 1) + 'টি + Auto)</h2>' + themeGridHTML() + '</section>';

    html += '<section class="card"><h2>🔤 ' + T('language') + '</h2><div class="seg">' +
      [['bn', 'বাংলা'], ['en', 'English']].map(function (o) { return '<button data-lang="' + o[0] + '" aria-pressed="' + (s.lang === o[0]) + '">' + o[1] + '</button>'; }).join('') +
      '</div><p class="small muted" style="margin-top:.5rem">' + T('langnote') + '</p><h3 style="margin-top:1rem">' + T('bnfont') + '</h3><div class="font-grid">' +
      FONTS.map(function (f) { return '<button class="font-opt" data-font="' + f[0] + '" aria-pressed="' + (s.font === f[0]) + '" style="font-family:' + f[1] + ',sans-serif"><b>' + f[2] + '</b><span class="small">আমার সোনার বাংলা, আমি তোমায় ভালোবাসি।</span></button>'; }).join('') +
      '</div><h3 style="margin-top:1rem">' + T('fontsize') + '</h3><div class="seg">' +
      [[0.9, 'ছোট'], [1, 'স্বাভাবিক'], [1.12, 'বড়'], [1.25, 'অনেক বড়']].map(function (o) { return '<button data-fs="' + o[0] + '" aria-pressed="' + (+s.fs === o[0]) + '">' + o[1] + '</button>'; }).join('') +
      '</div><h3 style="margin-top:1rem">' + T('motion') + '</h3><div class="seg">' +
      [['auto', 'সিস্টেম অনুযায়ী'], ['reduce', 'Reduce Motion']].map(function (o) { return '<button data-motion="' + o[0] + '" aria-pressed="' + (s.motion === o[0]) + '">' + o[1] + '</button>'; }).join('') +
      '</div></section>';

    html += '<section class="card"><h2>🎯 পরীক্ষা ও লক্ষ্য</h2>' +
      '<div class="field"><label for="unitsel">' + T('myunit') + '</label><select id="unitsel">' +
      EXAM.tracks.map(function (t) {
        return '<optgroup label="' + esc(t.name) + ' · ' + esc(t.session) + '">' + t.units.map(function (u) {
          return '<option value="' + u.id + '"' + (s.unit === u.id ? ' selected' : '') + '>' + esc(u.code + ' — ' + u.name) + '</option>';
        }).join('') + '</optgroup>';
      }).join('') + '</select></div>' + unitInfo(UNITS[s.unit]) + unitCustomHTML(UNITS[s.unit]) +
      '<div class="field"><label for="exdate">পরীক্ষার তারিখ (খালি রাখলে ইউনিটের ডিফল্ট)</label><input id="exdate" type="date" value="' + esc(s.examDate) + '"></div>' +
      '<div class="field"><label for="goal">দৈনিক লক্ষ্য (মিনিট)</label><input id="goal" type="number" min="10" max="600" step="5" value="' + esc(s.goal) + '" inputmode="numeric"></div></section>';

    html += '<section class="card"><h2>💾 ' + T('backup') + '</h2>' +
      '<p class="small">সংরক্ষণ: <b>' + modeTxt + '</b>. প্রতিটি পরিবর্তন সাথে সাথে স্বয়ংক্রিয়ভাবে সেভ হয়। অ্যাপ বদলালে বা ডেটা মুছে গেলে নিচের ব্যাকআপ দিয়ে ফেরাতে পারবেন।</p>' +
      '<div class="grid2"><button class="btn" id="bk-dl">⬇ ফাইল ডাউনলোড</button><button class="btn" id="bk-copy">📋 কোড কপি</button>' +
      '<button class="btn" id="bk-file">⬆ ফাইল থেকে ফেরান</button><button class="btn" id="bk-paste">📥 কোড পেস্ট</button></div>' +
      '<input type="file" id="bk-input" accept=".json,application/json,text/plain" hidden>' +
      '<p class="small muted" style="margin-top:.6rem">কিছু Android অ্যাপে ফাইল ডাউনলোড/আপলোড কাজ না করলে "কোড কপি" ও "কোড পেস্ট" ব্যবহার করুন।</p>' +
      '<button class="btn block" id="reset" style="margin-top:.4rem;color:var(--bad)">সব অগ্রগতি মুছুন…</button></section>';

    html += '<a class="card tight row" href="#/about" id="aboutlink" style="text-decoration:none;color:inherit"><span style="font-size:1.5rem" aria-hidden="true">📲</span><div class="spacer"><b>ইনস্টল, অফলাইন ও APK</b><div class="small muted">হোম স্ক্রিনে যোগ · APK বানানোর গাইড · Coverage ও QC রিপোর্ট</div></div><span class="caret" aria-hidden="true">›</span></a>';
    html += '<section class="card small"><h2>ℹ️ অ্যাপ সম্পর্কে</h2><p>সংস্করণ ' + APP_VERSION + ' · পাঠ্যসূচি ' + num(ORDER.length) + ' পাঠ · পরীক্ষা-কনফিগ হালনাগাদ ' + esc(EXAM.updated) + '</p>' +
      '<p class="muted">পরীক্ষার কাঠামোর তথ্য সংবাদসূত্র থেকে; "Verify" চিহ্নিত অংশ সর্বশেষ অফিসিয়াল বিজ্ঞপ্তি দেখে যাচাই করুন।</p>' +
      '<details><summary style="min-height:44px;cursor:pointer">তথ্যসূত্র</summary><ul>' + EXAM.sources.map(function (x) { return '<li>' + esc(x.t) + ' — <span class="muted">' + esc(x.url) + '</span></li>'; }).join('') + '</ul></details></section>';
    $view.innerHTML = html;

    bindThemeGrid($view, viewSettings);
    $view.querySelectorAll('[data-lang]').forEach(function (b) { b.addEventListener('click', function () { setSetting('lang', b.getAttribute('data-lang')); applySettings(); viewSettings(); }); });
    $view.querySelectorAll('[data-font]').forEach(function (b) { b.addEventListener('click', function () { setSetting('font', b.getAttribute('data-font')); applySettings(); viewSettings(); }); });
    $view.querySelectorAll('[data-fs]').forEach(function (b) { b.addEventListener('click', function () { setSetting('fs', +b.getAttribute('data-fs')); applySettings(); viewSettings(); }); });
    $view.querySelectorAll('[data-motion]').forEach(function (b) { b.addEventListener('click', function () { setSetting('motion', b.getAttribute('data-motion')); applySettings(); viewSettings(); }); });
    (function () {
      var sv = document.getElementById('ucsave'); if (!sv) return;
      function put(v) { var c = JSON.parse(JSON.stringify(settings().unitCustom || {})); if (v) c[s.unit] = v; else delete c[s.unit]; setSetting('unitCustom', c); applyUnitCustom(); viewSettings(); }
      sv.onclick = function () {
        var u = UNITS[s.unit], nm = document.getElementById('ucname').value.trim();
        var subs = Array.prototype.slice.call(document.querySelectorAll('#ucsubs input:checked')).map(function (x) { return x.value; });
        if (!subs.length) { toast('অন্তত একটি বিষয় বেছে নিন'); return; }
        put({ name: nm && nm !== u._o.name ? nm : '', subjects: subs.join() === u._o.subjects.join() ? [] : subs });
        toast('ইউনিট কাস্টমাইজ সংরক্ষিত');
      };
      document.getElementById('ucreset').onclick = function () { put(null); toast('ডিফল্টে ফেরানো হলো'); };
    })();
    document.getElementById('unitsel').addEventListener('change', function () { setSetting('unit', this.value); toast('ইউনিট বদলানো হলো'); viewSettings(); });
    document.getElementById('exdate').addEventListener('change', function () { setSetting('examDate', this.value); toast('তারিখ সংরক্ষিত'); });
    document.getElementById('goal').addEventListener('change', function () { var v = Math.max(10, Math.min(600, parseInt(fromBnDigits(this.value), 10) || 60)); this.value = v; setSetting('goal', v); toast('লক্ষ্য সংরক্ষিত'); });

    var fname = 'bd-admission-backup-' + todayKey() + '.json';
    document.getElementById('bk-dl').addEventListener('click', function () {
      Store.flushAll().then(function () {
        if (Store.download(fname, Store.exportJSON())) toast('ডাউনলোড শুরু হয়েছে (না হলে "কোড কপি" ব্যবহার করুন)');
        else showCode();
      });
    });
    document.getElementById('bk-copy').addEventListener('click', showCode);
    document.getElementById('bk-file').addEventListener('click', function () { document.getElementById('bk-input').click(); });
    document.getElementById('bk-input').addEventListener('change', function () {
      var f = this.files && this.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () { askImport(String(r.result)); };
      r.onerror = function () { toast('ফাইল পড়া যায়নি'); };
      r.readAsText(f);
      this.value = '';
    });
    document.getElementById('bk-paste').addEventListener('click', function () {
      modal('<h2>ব্যাকআপ কোড পেস্ট করুন</h2><textarea id="pastebox" placeholder="BDADM1:… বা JSON"></textarea><div class="grid2" style="margin-top:.6rem"><button class="btn" id="pc">বাতিল</button><button class="btn primary" id="po">পরবর্তী</button></div>', function (m) {
        m.querySelector('#pc').onclick = closeModal;
        m.querySelector('#po').onclick = function () { askImport(m.querySelector('#pastebox').value); };
      });
    });
    document.getElementById('reset').addEventListener('click', function () {
      modal('<h2>সব অগ্রগতি মুছবেন?</h2><p>পাঠ সম্পন্ন, নোট, সংরক্ষিত তালিকা, হাইলাইট, পড়ার সময় সব মুছে যাবে। আগে ব্যাকআপ নিয়ে রাখুন। থিম ও সেটিংস থাকবে।</p><div class="grid2"><button class="btn" id="rc">বাতিল</button><button class="btn primary" id="ro" style="background:var(--bad);border-color:var(--bad)">মুছে ফেলুন</button></div>', function (m) {
        m.querySelector('#rc').onclick = closeModal;
        m.querySelector('#ro').onclick = function () {
          Promise.all(['done', 'bm', 'saveq', 'savefc', 'savewt', 'notes', 'hl', 'last', 'days', 'recent'].map(function (k) { return Store.del(k); })).then(function () { closeModal(); toast('মুছে ফেলা হয়েছে'); location.hash = '#/home'; });
        };
      });
    });
  }
  function unitCustomHTML(u) {
    if (!u) return '';
    return '<details class="unit-custom" id="ucust"' + (u.custom ? ' open' : '') + '><summary>⚙️ Unit Mode: এই ইউনিটের নাম ও বিষয় নিজে ঠিক করুন' + (u.custom ? ' <span class="chip ok">কাস্টম</span>' : '') + '</summary>' +
      '<p class="small muted">অফিসিয়াল বিজ্ঞপ্তিতে ইউনিটের নাম বা বিষয় বদলালে এখানে মিলিয়ে নিন। হোম, অগ্রগতি, দৈনিক লক্ষ্য ও Mock সব এই বিষয়গুলো ধরে চলবে।</p>' +
      '<div class="field"><label for="ucname">ইউনিটের নাম</label><input id="ucname" type="text" value="' + esc(u.name) + '" placeholder="' + esc(u._o ? u._o.name : u.name) + '"></div>' +
      '<div class="check-list" id="ucsubs">' + SUBJ.map(function (x) {
        return '<label><input type="checkbox" value="' + x.id + '"' + (u.subjects.indexOf(x.id) >= 0 ? ' checked' : '') + '> ' + x.icon + ' ' + esc(x.t) + '</label>';
      }).join('') + '</div><div class="grid2" style="margin-top:.6rem"><button class="btn" id="ucreset">ডিফল্টে ফেরান</button><button class="btn primary" id="ucsave">সংরক্ষণ</button></div></details>';
  }
  function unitInfo(u) {
    if (!u) return '';
    var parts = [];
    if (u.date) parts.push('তারিখ: ' + num(u.date) + (u.time ? ' (' + num(u.time) + ')' : '') + (u.dateVerified ? '' : ' <span class="chip verify">Verify</span>'));
    if (!u.date && u.dateNote) parts.push('তারিখ: ' + esc(u.dateNote) + ' <span class="chip verify">Verify</span>');
    if (u.mcq && u.mcq.marks) parts.push('MCQ ' + num(u.mcq.marks) + ' নম্বর' + (u.mcq.minutes ? ', ' + num(u.mcq.minutes) + ' মি.' : '') + (u.mcq.negative ? ', নেগেটিভ ' + num(u.mcq.negative) : ''));
    if (u.written) parts.push('লিখিত ' + num(u.written.marks) + ' নম্বর' + (u.written.minutes ? ', ' + num(u.written.minutes) + ' মি.' : '') + (u.writtenLab ? ' · <a href="#/written">✍️ লিখিত ল্যাব</a>' : ''));
    if (u.drawing) parts.push('অঙ্কন ' + num(u.drawing.marks) + ' নম্বর');
    if (u.mcq && u.mcq.sections && u.mcq.sections.length) parts.push('বণ্টন: ' + u.mcq.sections.map(function (x) { return esc(x.label) + ' ' + num(x.marks); }).join(', ') + (u.mcq.sectionsVerified ? '' : ' <span class="chip verify">Verify</span>'));
    if (u.pass && u.pass.total) parts.push('পাস ' + num(u.pass.total) + (u.pass.verified ? '' : ' <span class="chip verify">Verify</span>'));
    if (u.todo) parts.push('<span style="color:var(--warn)">⚠️ ' + esc(u.todo) + '</span>');
    if (!parts.length) parts.push('মানবণ্টন এখনো যাচাই হয়নি <span class="chip verify">Verify</span>');
    return '<div class="banner ok" style="background:var(--surface-2);color:var(--text)">' + parts.join('<br>') + '</div>';
  }
  function showCode() {
    Store.flushAll().then(function () {
      var code = Store.exportCode();
      modal('<h2>ব্যাকআপ কোড</h2><p class="small">পুরো কোডটি কপি করে কোথাও (নোট/মেসেজ) রেখে দিন। পরে "কোড পেস্ট" দিয়ে ফেরানো যাবে।</p><textarea id="codebox" readonly>' + esc(code) + '</textarea>' +
        '<div class="grid2" style="margin-top:.6rem"><button class="btn" id="cc">বন্ধ</button><button class="btn primary" id="cp">কপি করুন</button></div>', function (m) {
        var box = m.querySelector('#codebox');
        m.querySelector('#cc').onclick = closeModal;
        m.querySelector('#cp').onclick = function () {
          box.focus(); box.select();
          var ok = false;
          try { ok = document.execCommand('copy'); } catch (e) { }
          if (!ok && navigator.clipboard) navigator.clipboard.writeText(code).then(function () { toast('কপি হয়েছে'); }, function () { toast('নিজে সিলেক্ট করে কপি করুন'); });
          else toast(ok ? 'কপি হয়েছে' : 'নিজে সিলেক্ট করে কপি করুন');
        };
      });
    });
  }
  function askImport(text) {
    var obj;
    try { obj = Store.parseBackup(text); } catch (e) { toast('ব্যাকআপ পড়া যায়নি: ' + (e.message || 'ভুল ফরম্যাট')); return; }
    var nDone = obj.data.done ? Object.keys(obj.data.done.v || {}).length : 0;
    modal('<h2>ব্যাকআপ ফেরাবেন?</h2><p class="small">তারিখ: ' + esc(obj.exportedAt) + '<br>সম্পন্ন পাঠ: ' + num(nDone) + '</p>' +
      '<p class="small"><b>মিলিয়ে নিন</b>: প্রতিটি অংশে নতুনটি রাখবে। <b>পুরো বদলান</b>: বর্তমান সব ডেটা মুছে ব্যাকআপ বসাবে।</p>' +
      '<div class="grid2"><button class="btn" id="im">মিলিয়ে নিন</button><button class="btn primary" id="ir">পুরো বদলান</button></div><button class="btn block" id="ic" style="margin-top:.5rem">বাতিল</button>', function (m) {
      function go(mode) {
        Store.importBackup(text, mode).then(function (n) { closeModal(); applySettings(); toast(num(n) + 'টি অংশ ফেরানো হয়েছে'); route(); })
          .catch(function (e) { toast('ব্যর্থ: ' + e.message); });
      }
      m.querySelector('#im').onclick = function () { go('merge'); };
      m.querySelector('#ir').onclick = function () { go('replace'); };
      m.querySelector('#ic').onclick = closeModal;
    });
  }

  /* ---------------- বাইরের মডিউলের জন্য Core API ---------------- */
  window.Core = {
    addRoute: function (re, fn, tab) { EXT.push({ re: re, fn: fn, tab: tab }); },
    addHome: function (fn, first, id, label) { addHomeSec(id || ('x' + HOME_SEQ.length), label || 'অন্যান্য', fn); },
    setCleanup: function (fn) { cleanup = fn; },
    setTop: setTop, toast: toast, modal: modal, closeModal: closeModal, esc: esc, num: num, pct: pct, T: T, fmtMin: fmtMin,
    fromBnDigits: fromBnDigits, todayKey: todayKey, settings: settings, setSetting: setSetting, storageBanner: storageBanner,
    view: function () { return $view; }, route: route, addStudySeconds: addStudySeconds,
    SUBJ: SUBJ, SMAP: SMAP, CMAP: CMAP, LMAP: LMAP, UNITS: UNITS, EXAM: EXAM, ORDER: ORDER, PHASE_OF: PHASE_OF,
    unitSubjects: unitSubjects, lessonsOfSubject: lessonsOfSubject,
    isSaved: isSaved, toggleSaved: toggleSaved, saveBtnHTML: saveBtnHTML, savedMap: savedMap, streak: streak, daysMap: daysMap, doneMap: doneMap
  };

  /* ---------------- বুট ---------------- */
  document.getElementById('themebtn').addEventListener('click', openThemeSheet);
  document.getElementById('backbtn').addEventListener('click', function () {
    if (history.length > 1) history.back(); else location.hash = '#/home';
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  Store.onSaveStatus(function (ok) { if (!ok) toast('⚠️ সংরক্ষণ ব্যর্থ — ব্যাকআপ নিন'); });

  Store.init().then(function () {
    applySettings();
    window.addEventListener('hashchange', route);
    // প্রথমবার খুললে বা হোমে এলে, আগের পাঠ থাকলে সেখানেই নয় — হোমে "যেখানে ছিলেন" কার্ড দেখায়
    route();
    document.documentElement.classList.add('ready');
    window.__BOOT_MS__ = window.performance && performance.now ? Math.round(performance.now()) : 0;
    window.__APP_READY = true;
  });

  // Service Worker / PWA: about.js-এ (শুধু http(s)-এ, ফিচার-ডিটেকশনসহ)

  // টেস্ট/ডিবাগের জন্য
  window.App = { version: APP_VERSION, stats: function () { return statsFor(ORDER); }, route: route, Store: Store };
})();
