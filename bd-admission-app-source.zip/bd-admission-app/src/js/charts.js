/* =========================================================
   charts.js — চার্ট, ডায়াগ্রাম ও ইনফোগ্রাফিক
   ডেটা: data/charts/*.json  → { charts: [ {n, id, sub, t, d, lids[], intro, parts[], keys[], ex[], tip, src[]} ] }
   অংশের ধরন (parts[].k):
     grid      {h?, cols[], rows[[..]], stack?, note?}      সারণি (মোবাইলে কার্ডে রূপান্তর হয় stack হলে)
     flow      {h?, root:{q, b:[{l, n}]} | {a, ex}}           সিদ্ধান্ত-বৃক্ষ (হ্যাঁ/না শাখা)
     steps     {h?, x:[{t, d?, ex?}]}                        ধাপে ধাপে প্রবাহ
     ladder    {h?, x:[[from, to, note?]], fl?, tl?}         রূপান্তরের সিঁড়ি
     pyramid   {h?, x:[{t, d?, ex?}]}  (ওপর = সবচেয়ে ছোট)
     tree      {h?, root:{t, d?, c:[..]}}                    শ্রেণিবিভাগ/সংগঠন বৃক্ষ
     cards     {h?, x:[{h, b, ex?, tag?, svg?}]}
     timeline  {h?, x:[{y, t, d?}]}
     tense     {h?, rows:[{asp, cells:[{name, form, ex, g}]}]}  কালের সময়রেখা
     nest      {h?, root:{t, d?, c:[..]}}                    এক বাক্সের ভেতর আরেক বাক্স
     relmap    {h?, nodes:[{id,t,s?,x,y,main?}], edges:[[a,b,label]], w, h}
     zones     {h?, cols, x:[{r,c,t,b}], note?}              অবস্থানভিত্তিক নকশা (সেক্টর)
     bars      {h?, x:[{t, segs:[[label, value, tone?]], note?}]}
     svg       {h?, name, p?}                                আঁকা ছবি (DRAW[name])
     note      {tone: ok|warn|bad|info, x}
     list      {h?, x:[..], o?}
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core;
  var esc = C.esc, num = C.num, toast = C.toast;
  function $v() { return C.view(); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function inl(s) {
    return esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/==(.+?)==/g, '<mark class="kw">$1</mark>')
      .replace(/\[\[(ok|bad|warn|p|a|b|c|d)\|(.+?)\]\]/g, '<span class="tc-$1">$2</span>').replace(/\n/g, '<br>');
  }
  var SUBS = [['en', '🔤', 'English'], ['bn2', '✍️', 'বাংলা ২য় পত্র'], ['bn1', '📖', 'বাংলা ১ম পত্র'], ['gkbd', '🇧🇩', 'সাধারণ জ্ঞান — বাংলাদেশ'],
    ['gkint', '🌍', 'সাধারণ জ্ঞান — আন্তর্জাতিক'], ['ict', '💻', 'ICT'], ['math', '🧮', 'গাণিতিক যুক্তি'], ['eco', '📈', 'অর্থনীতি']];
  var SUBNAME = {}; SUBS.forEach(function (s) { SUBNAME[s[0]] = s; });

  var CH = null, BYID = {};
  function all() {
    if (CH) return CH;
    CH = [];
    Data.list('charts/').forEach(function (n) { var d = Data.get(n); (d && d.charts || []).forEach(function (c) { if (!BYID[c.id]) { BYID[c.id] = c; CH.push(c); } }); });
    CH.sort(function (a, b) { return a.n - b.n; });
    return CH;
  }
  function get(id) { all(); return BYID[id] || null; }
  function pins() { return (Store.get('chpin', []) || []).filter(function (id) { return get(id); }); }
  function setPins(a) { Store.set('chpin', a, 0); }
  function isPinned(id) { return pins().indexOf(id) >= 0; }
  function forLesson(lid) { return all().filter(function (c) { return (c.lids || []).indexOf(lid) >= 0; }); }
  function forSubject(sid) { return all().filter(function (c) { return c.sub === sid; }); }

  /* ================= SVG সহায়ক ================= */
  function svg(w, h, inner, label, cls) {
    return '<svg class="ch-svg' + (cls ? ' ' + cls : '') + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(label || '') + '" preserveAspectRatio="xMidYMid meet">' +
      '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerUnits="userSpaceOnUse" markerWidth="9" markerHeight="9" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" class="s-arrow"/></marker></defs>' + inner + '</svg>';
  }
  function T(x, y, s, o) {
    o = o || {};
    return '<text x="' + x + '" y="' + y + '" class="s-txt' + (o.c ? ' ' + o.c : '') + '"' + (o.a ? ' text-anchor="' + o.a + '"' : ' text-anchor="middle"') + (o.fs ? ' font-size="' + o.fs + '"' : '') + (o.w ? ' font-weight="' + o.w + '"' : '') + '>' + esc(s) + '</text>';
  }
  function Ln(x1, y1, x2, y2, c, arrow) { return '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" class="' + (c || 's-line') + '"' + (arrow ? ' marker-end="url(#ah)"' : '') + '/>'; }
  function Rc(x, y, w, h, c, r) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (r || 6) + '" class="' + (c || 's-box') + '"/>'; }
  function Ci(x, y, r, c) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" class="' + (c || 's-box') + '"/>'; }
  function Pa(d, c, arrow) { return '<path d="' + d + '" class="' + (c || 's-line') + '"' + (arrow ? ' marker-end="url(#ah)"' : '') + '/>'; }
  function bn(x) { return num(x); }

  var DRAW = {};
  /* ---- কালের ছোট গ্লিফ: g = s|c|p|pc, ref = past|present|future ---- */
  function tenseGlyph(g, ref) {
    var R = { past: 42, present: 78, future: 114 }[ref], y = 22, out = '';
    out += Ln(4, y, 136, y, 's-axis', true) + Ln(78, 8, 78, 36, 's-now') + T(78, 46, 'এখন', { fs: 9, c: 's-mute' });
    if (ref !== 'present') out += Ln(R, 12, R, 32, 's-ref');
    if (g === 's') out += Ci(R, y, 5, 's-dot');
    function head(x) { return '<path d="M' + x + ' ' + (y - 5) + ' L' + (x + 8) + ' ' + y + ' L' + x + ' ' + (y + 5) + ' Z" class="s-dot"/>'; }
    if (g === 'c') out += Pa('M' + (R - 16) + ' ' + y + ' q4 -7 8 0 t8 0 t8 0 t8 0', 's-wave') + head(R + 16);
    if (g === 'p') out += Rc(R - 34, y - 4, 30, 8, 's-bar', 3) + Ci(R - 4, y, 4, 's-dot');
    if (g === 'pc') out += Pa('M' + (R - 38) + ' ' + y + ' q4 -7 8 0 t8 0 t8 0 t8 0 t8 0', 's-wave') + head(R + 2);
    return svg(140, 50, out, '', 'tg');
  }
  /* ---- স্থানের preposition ---- */
  DRAW.placePrep = function () {
    var o = '';
    o += Rc(14, 28, 74, 62, 's-box2') + Ci(51, 64, 7, 's-dot') + T(51, 112, 'in — ভেতরে', { w: 700 }) + T(51, 128, 'in the box / in Dhaka', { fs: 10, c: 's-mute' });
    o += Rc(118, 74, 92, 10, 's-box2', 2) + Ln(130, 84, 130, 100, 's-line') + Ln(198, 84, 198, 100, 's-line') + Ci(164, 66, 7, 's-dot') + T(164, 112, 'on — তলের ওপর', { w: 700 }) + T(164, 128, 'on the table / on the wall', { fs: 10, c: 's-mute' });
    o += Ln(240, 70, 320, 70, 's-axis') + Ci(280, 70, 7, 's-dot') + Pa('M280 40 v18', 's-acc', true) + T(280, 112, 'at — নির্দিষ্ট বিন্দু', { w: 700 }) + T(280, 128, 'at the gate / at 12 Elephant Rd', { fs: 10, c: 's-mute' });
    return svg(330, 140, o, 'in: ভেতরে, on: তলের ওপর, at: নির্দিষ্ট বিন্দু');
  };
  /* ---- নেটওয়ার্ক টপোলজি ---- */
  function nodeC(x, y) { return Rc(x - 9, y - 7, 18, 14, 's-node', 3); }
  DRAW.topology = function (p) {
    var t = p.t, o = '', i, pts = [];
    if (t === 'bus') {
      o += Ln(10, 60, 190, 60, 's-thick') + Rc(4, 54, 6, 12, 's-term', 1) + Rc(190, 54, 6, 12, 's-term', 1);
      for (i = 0; i < 5; i++) { var x = 30 + i * 35, up = i % 2 ? 1 : -1; o += Ln(x, 60, x, 60 + up * 26) + nodeC(x, 60 + up * 33); }
      o += T(100, 112, 'দুই প্রান্তে টার্মিনেটর', { fs: 10, c: 's-mute' });
    } else if (t === 'ring') {
      for (i = 0; i < 6; i++) { var a = i * Math.PI / 3 - Math.PI / 2; pts.push([100 + 42 * Math.cos(a), 58 + 42 * Math.sin(a)]); }
      for (i = 0; i < 6; i++) { var q = pts[(i + 1) % 6]; o += Ln(pts[i][0], pts[i][1], q[0], q[1], 's-line', i === 0); }
      pts.forEach(function (q) { o += nodeC(q[0], q[1]); });
      o += T(100, 116, 'ডেটা এক দিকে ঘোরে', { fs: 10, c: 's-mute' });
    } else if (t === 'star') {
      for (i = 0; i < 6; i++) { var b = i * Math.PI / 3; pts.push([100 + 46 * Math.cos(b), 58 + 40 * Math.sin(b)]); }
      pts.forEach(function (q) { o += Ln(100, 58, q[0], q[1]) + nodeC(q[0], q[1]); });
      o += Rc(84, 48, 32, 20, 's-hub', 4) + T(100, 62, 'হাব', { fs: 10, w: 700 });
    } else if (t === 'tree') {
      o += Rc(84, 6, 32, 18, 's-hub', 4) + T(100, 19, 'রুট', { fs: 9, w: 700 });
      [[50, 52], [150, 52]].forEach(function (h) {
        o += Ln(100, 24, h[0], h[1] - 9) + Rc(h[0] - 14, h[1] - 9, 28, 16, 's-hub', 4);
        [-26, 0, 26].forEach(function (dx) { o += Ln(h[0], h[1] + 7, h[0] + dx, 92) + nodeC(h[0] + dx, 99); });
      });
    } else if (t === 'mesh') {
      for (i = 0; i < 5; i++) { var c = i * 2 * Math.PI / 5 - Math.PI / 2; pts.push([100 + 46 * Math.cos(c), 60 + 44 * Math.sin(c)]); }
      for (i = 0; i < 5; i++) for (var j = i + 1; j < 5; j++) o += Ln(pts[i][0], pts[i][1], pts[j][0], pts[j][1], 's-thin');
      pts.forEach(function (q) { o += nodeC(q[0], q[1]); });
      o += T(100, 118, '৫ নোড → ৫×৪÷২ = ১০ সংযোগ', { fs: 10, c: 's-mute' });
    }
    return svg(200, 122, o, t + ' topology');
  };
  /* ---- ফাইবার অপটিক ---- */
  DRAW.fiber = function () {
    var o = '';
    o += Ci(60, 64, 50, 's-jacket') + Ci(60, 64, 34, 's-clad') + Ci(60, 64, 16, 's-core');
    o += T(60, 68, 'কোর', { fs: 10, w: 700 }) + T(60, 42, 'ক্ল্যাডিং', { fs: 9 }) + T(60, 24, 'জ্যাকেট', { fs: 9 });
    o += Rc(130, 34, 200, 60, 's-clad', 4) + Rc(130, 50, 200, 28, 's-core', 2);
    o += Pa('M132 64 L160 51 L190 77 L220 51 L250 77 L280 51 L310 77 L328 68', 's-ray', true);
    o += T(230, 26, 'আলো কোর-ক্ল্যাডিং সীমানায় বারবার পূর্ণ প্রতিফলিত হয়', { fs: 10 });
    o += T(230, 112, 'শর্ত: কোরের প্রতিসরণাঙ্ক > ক্ল্যাডিংয়ের', { fs: 10, c: 's-mute' });
    return svg(340, 120, o, 'ফাইবার অপটিক: কোর, ক্ল্যাডিং, জ্যাকেট; পূর্ণ অভ্যন্তরীণ প্রতিফলন');
  };
  /* ---- লজিক গেট ---- */
  function gateShape(g) {
    var b = g.replace(/^N(?=AND|OR)/, '').replace(/^XN/, 'X'), neg = /^(NAND|NOR|XNOR|NOT)$/.test(g), o = '', ox = 70;
    if (b === 'AND') o += Pa('M20 10 H48 A24 24 0 0 1 48 58 H20 Z', 's-gate');
    else if (b === 'OR' || b === 'XOR') { o += Pa('M18 10 Q32 34 18 58 Q52 58 72 34 Q52 10 18 10 Z', 's-gate'); if (b === 'XOR') o += Pa('M10 10 Q24 34 10 58', 's-line'); ox = 72; }
    else if (g === 'NOT') { o += Pa('M22 12 L60 34 L22 56 Z', 's-gate'); ox = 60; }
    if (neg) { o += Ci(ox + 5, 34, 5, 's-bub'); ox += 10; }
    if (g === 'NOT') o += Ln(0, 34, 22, 34);
    else o += Ln(0, 22, 22, 22) + Ln(0, 46, 22, 46);
    o += Ln(ox, 34, 100, 34);
    return o;
  }
  function gateFn(g) {
    return { AND: function (a, b) { return a & b; }, OR: function (a, b) { return a | b; }, NOT: function (a) { return 1 - a; }, NAND: function (a, b) { return 1 - (a & b); },
      NOR: function (a, b) { return 1 - (a | b); }, XOR: function (a, b) { return a ^ b; }, XNOR: function (a, b) { return 1 - (a ^ b); } }[g];
  }
  DRAW.gate = function (p) { return svg(104, 68, gateShape(p.g), p.g + ' gate'); };
  function truth(g) {
    var f = gateFn(g), rows = g === 'NOT' ? [[0], [1]] : [[0, 0], [0, 1], [1, 0], [1, 1]];
    return '<table class="ch-tt"><tr>' + (g === 'NOT' ? '<th>A</th>' : '<th>A</th><th>B</th>') + '<th>Y</th></tr>' + rows.map(function (r) {
      var y = f(r[0], r[1]);
      return '<tr>' + r.map(function (v) { return '<td>' + v + '</td>'; }).join('') + '<td class="' + (y ? 'on' : '') + '">' + y + '</td></tr>';
    }).join('') + '</table>';
  }
  /* ---- অ্যাডার ---- */
  DRAW.adder = function (p) {
    var o = '';
    function g(x, y, k) { return '<g transform="translate(' + x + ',' + y + ') scale(.6)">' + gateShape(k) + '</g>'; }
    if (p.t === 'half') {
      o += T(14, 30, 'A', { w: 700 }) + T(14, 80, 'B', { w: 700 });
      o += Ln(22, 26, 70, 26) + Ln(22, 76, 70, 76) + Ln(46, 26, 46, 104) + Ln(58, 76, 58, 118) + Ln(46, 104, 120, 104) + Ln(58, 118, 120, 118);
      o += Ln(70, 26, 120, 26) + Ln(70, 76, 90, 76) + Ln(90, 76, 90, 40) + Ln(90, 40, 120, 40);
      o += g(120, 13, 'XOR') + g(120, 91, 'AND');
      o += Ln(180, 33, 214, 33, 's-acc', true) + T(240, 37, 'S (যোগফল)', { fs: 11, w: 700 }) + Ln(180, 111, 214, 111, 's-acc', true) + T(240, 115, 'C (ক্যারি)', { fs: 11, w: 700 });
      o += T(150, 8, 'XOR', { fs: 9, c: 's-mute' }) + T(150, 140, 'AND', { fs: 9, c: 's-mute' });
      return svg(290, 146, o, 'হাফ অ্যাডার: S = A XOR B, C = A AND B');
    }
    o += Rc(40, 20, 80, 56, 's-box2') + T(80, 44, 'হাফ', { w: 700 }) + T(80, 60, 'অ্যাডার ১', { fs: 10 });
    o += Rc(150, 50, 80, 56, 's-box2') + T(190, 74, 'হাফ', { w: 700 }) + T(190, 90, 'অ্যাডার ২', { fs: 10 });
    o += T(14, 34, 'A', { w: 700 }) + T(14, 66, 'B', { w: 700 }) + T(14, 120, 'Cin', { w: 700 });
    o += Ln(24, 30, 40, 30, 's-line', true) + Ln(24, 62, 40, 62, 's-line', true) + Ln(120, 40, 150, 66, 's-line', true) + Ln(30, 116, 140, 116) + Ln(140, 116, 150, 94, 's-line', true);
    o += Ln(230, 66, 290, 66, 's-acc', true) + T(305, 70, 'S', { w: 700, a: 'start' });
    o += Ln(120, 66, 130, 66) + Ln(130, 66, 130, 140) + Ln(130, 140, 250, 140) + Ln(230, 96, 250, 96) + Ln(250, 96, 250, 112) + Ln(250, 140, 250, 128);
    o += '<g transform="translate(250,100) scale(.5)">' + gateShape('OR') + '</g>' + Ln(300, 117, 312, 117, 's-acc', true) + T(318, 121, 'Cout', { w: 700, a: 'start' });
    o += T(128, 152, 'ক্যারি দুটি OR গেটে মেলে', { fs: 9, c: 's-mute' });
    return svg(350, 158, o, 'ফুল অ্যাডার = দুটি হাফ অ্যাডার + একটি OR গেট');
  };
  /* ---- ফ্লোচার্ট প্রতীক ও উদাহরণ ---- */
  DRAW.fcSymbols = function () {
    var o = '', items = [['ellipse', 'শুরু / শেষ'], ['para', 'ইনপুট / আউটপুট'], ['rect', 'প্রসেস'], ['dia', 'সিদ্ধান্ত'], ['arrow', 'প্রবাহ'], ['circ', 'সংযোগ']];
    items.forEach(function (it, i) {
      var x = 55 + (i % 3) * 110, y = 34 + Math.floor(i / 3) * 78, s = it[0];
      if (s === 'ellipse') o += '<ellipse cx="' + x + '" cy="' + y + '" rx="38" ry="16" class="s-box2"/>';
      if (s === 'para') o += Pa('M' + (x - 30) + ' ' + (y + 16) + ' L' + (x - 20) + ' ' + (y - 16) + ' L' + (x + 38) + ' ' + (y - 16) + ' L' + (x + 28) + ' ' + (y + 16) + ' Z', 's-box2');
      if (s === 'rect') o += Rc(x - 36, y - 16, 72, 32, 's-box2', 2);
      if (s === 'dia') o += Pa('M' + x + ' ' + (y - 20) + ' L' + (x + 34) + ' ' + y + ' L' + x + ' ' + (y + 20) + ' L' + (x - 34) + ' ' + y + ' Z', 's-box2');
      if (s === 'arrow') o += Ln(x - 30, y, x + 30, y, 's-thick', true);
      if (s === 'circ') o += Ci(x, y, 12, 's-box2');
      o += T(x, y + 36, it[1], { fs: 11, w: 700 });
    });
    return svg(330, 160, o, 'ফ্লোচার্টের ছয় প্রতীক');
  };
  DRAW.fcExample = function () {
    var o = '', x = 150;
    o += '<ellipse cx="' + x + '" cy="18" rx="34" ry="13" class="s-box2"/>' + T(x, 22, 'শুরু', { fs: 11 }) + Ln(x, 31, x, 44, 's-line', true);
    o += Pa('M95 64 L105 44 L205 44 L195 64 Z', 's-box2') + T(x, 58, 'A, B ইনপুট', { fs: 11 }) + Ln(x, 64, x, 78, 's-line', true);
    o += Pa('M' + x + ' 78 L200 100 L' + x + ' 122 L100 100 Z', 's-box2') + T(x, 104, 'A > B ?', { fs: 11, w: 700 });
    o += Ln(200, 100, 236, 100) + Ln(236, 100, 236, 140, 's-line', true) + T(222, 94, 'হ্যাঁ', { fs: 10, c: 's-ok' });
    o += Ln(100, 100, 64, 100) + Ln(64, 100, 64, 140, 's-line', true) + T(80, 94, 'না', { fs: 10, c: 's-bad' });
    o += Pa('M190 140 L200 160 L282 160 L272 140 Z', 's-box2') + T(236, 154, 'A বড়', { fs: 11 });
    o += Pa('M18 140 L28 160 L110 160 L100 140 Z', 's-box2') + T(64, 154, 'B বড়', { fs: 11 });
    o += Ln(236, 160, 236, 178) + Ln(64, 160, 64, 178) + Ln(64, 178, 236, 178) + Ln(x, 178, x, 190, 's-line', true);
    o += '<ellipse cx="' + x + '" cy="203" rx="34" ry="13" class="s-box2"/>' + T(x, 207, 'শেষ', { fs: 11 });
    return svg(300, 220, o, 'দুটি সংখ্যার বড়টি বের করার ফ্লোচার্ট');
  };
  /* ---- E-R ডায়াগ্রাম ---- */
  DRAW.er = function () {
    var o = '';
    o += Rc(14, 60, 84, 34, 's-box2', 2) + T(56, 82, 'শিক্ষার্থী', { w: 700 });
    o += Pa('M150 50 L196 77 L150 104 L104 77 Z', 's-dia') + T(150, 81, 'ভর্তি হয়', { fs: 11 });
    o += Rc(202, 60, 84, 34, 's-box2', 2) + T(244, 82, 'কোর্স', { w: 700 });
    o += Ln(98, 77, 104, 77) + Ln(196, 77, 202, 77) + T(108, 70, 'M', { fs: 10, c: 's-mute' }) + T(192, 70, 'N', { fs: 10, c: 's-mute' });
    [[30, 20, 'রোল', 1], [86, 18, 'নাম', 0], [228, 20, 'কোর্স কোড', 1], [290, 30, 'নাম', 0]].forEach(function (a) {
      o += '<ellipse cx="' + a[0] + '" cy="' + a[1] + '" rx="28" ry="12" class="s-ell"/>' + T(a[0], a[1] + 4, a[2], { fs: 10, c: a[3] ? 's-key' : '' });
      o += Ln(a[0], a[1] + 12, a[0] < 150 ? 56 : 244, 60, 's-thin');
    });
    o += T(150, 128, 'আয়ত = এনটিটি · উপবৃত্ত = অ্যাট্রিবিউট (দাগ = প্রাইমারি কী) · রম্বস = সম্পর্ক', { fs: 9, c: 's-mute' });
    return svg(320, 136, o, 'E-R ডায়াগ্রাম: শিক্ষার্থী M:N কোর্স');
  };
  /* ---- সিজার সাইফার চাকা (ইন্টারেক্টিভ) ---- */
  DRAW.cipher = function (p) {
    var k = p.k || 3, o = '', i, A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    o += Ci(110, 110, 104, 's-box2') + Ci(110, 110, 76, 's-box') + Ci(110, 110, 50, 's-fill2');
    for (i = 0; i < 26; i++) {
      var a = i / 26 * 2 * Math.PI - Math.PI / 2, a2 = a;
      o += T(110 + 90 * Math.cos(a), 114 + 90 * Math.sin(a), A[i], { fs: 12, w: 700 });
      o += T(110 + 63 * Math.cos(a2), 114 + 63 * Math.sin(a2), A[(i + k) % 26], { fs: 11, c: 's-accT' });
    }
    o += T(110, 106, 'বাইরে: মূল', { fs: 10 }) + T(110, 122, 'ভেতরে: +' + k, { fs: 10, c: 's-accT', w: 700 });
    return svg(220, 220, o, 'সিজার সাইফার চাকা, শিফট ' + k);
  };
  /* ---- ভেনচিত্র ---- */
  DRAW.venn = function (p) {
    var o = '';
    if (p.t === 2) {
      o += Ci(110, 70, 52, 's-vA') + Ci(170, 70, 52, 's-vB') + T(80, 74, 'শুধু A', { fs: 11 }) + T(140, 74, 'A∩B', { fs: 11, w: 700 }) + T(200, 74, 'শুধু B', { fs: 11 });
      o += T(80, 16, 'A', { w: 700 }) + T(200, 16, 'B', { w: 700 }) + Rc(40, 6, 200, 128, 's-uni', 8) + T(232, 128, 'U', { fs: 10, c: 's-mute' });
      return svg(280, 140, o, 'দুই সেটের ভেনচিত্র');
    }
    if (p.t === 3) {
      o += Ci(110, 62, 48, 's-vA') + Ci(160, 62, 48, 's-vB') + Ci(135, 104, 48, 's-vC');
      o += T(90, 52, 'A', { w: 700 }) + T(180, 52, 'B', { w: 700 }) + T(135, 134, 'C', { w: 700 }) + T(135, 86, 'A∩B∩C', { fs: 9, w: 700 });
      return svg(270, 160, o, 'তিন সেটের ভেনচিত্র');
    }
    var s = p.s, o2 = '';
    if (s === 'all') o2 += Ci(110, 60, 52, 's-vB') + Ci(110, 66, 26, 's-vA') + T(110, 70, 'A', { w: 700 }) + T(110, 22, 'B', { w: 700 });
    if (s === 'no') o2 += Ci(70, 60, 34, 's-vA') + Ci(160, 60, 34, 's-vB') + T(70, 64, 'A', { w: 700 }) + T(160, 64, 'B', { w: 700 });
    if (s === 'some') o2 += Ci(90, 60, 40, 's-vA') + Ci(140, 60, 40, 's-vB') + T(76, 64, 'A', { w: 700 }) + T(154, 64, 'B', { w: 700 }) + T(115, 64, '•', { w: 700 });
    if (s === 'somenot') o2 += Ci(90, 60, 40, 's-vA') + Ci(140, 60, 40, 's-vB') + T(70, 64, 'A•', { w: 700 }) + T(154, 64, 'B', { w: 700 });
    return svg(220, 120, o2, 'সিলোজিজম চিত্র: ' + s);
  };
  /* ---- কম্পাস ও দিক ---- */
  DRAW.compass = function (p) {
    var o = '', dirs = [['উ', 0], ['উপূ', 45], ['পূ', 90], ['দপূ', 135], ['দ', 180], ['দপ', 225], ['প', 270], ['উপ', 315]];
    o += Ci(80, 80, 62, 's-box2');
    dirs.forEach(function (d) { var a = (d[1] - 90) * Math.PI / 180; o += Ln(80, 80, 80 + 52 * Math.cos(a), 80 + 52 * Math.sin(a), d[1] % 90 ? 's-thin' : 's-line') + T(80 + 70 * Math.cos(a), 84 + 70 * Math.sin(a), d[0], { fs: 11, w: 700 }); });
    if (p && p.walk) {
      var x = 210, y = 140, s = 22, pts = [[x, y]];
      p.walk.forEach(function (w) { var a = (w[0] - 90) * Math.PI / 180; x += w[1] * s * Math.cos(a); y += w[1] * s * Math.sin(a); pts.push([x, y]); });
      for (var i = 1; i < pts.length; i++) o += Ln(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1], 's-acc', true);
      o += Ln(pts[0][0], pts[0][1], x, y, 's-dash', true) + Ci(pts[0][0], pts[0][1], 4, 's-dot') + T(pts[0][0], pts[0][1] + 16, 'শুরু', { fs: 10 });
    }
    return svg(320, 170, o, 'আট দিকের কম্পাস ও উদাহরণ পথ');
  };
  /* ---- ঘড়ির কোণ ---- */
  DRAW.clock = function (p) {
    var H = p.h, M = p.m, o = '', i;
    o += Ci(90, 90, 78, 's-box2');
    for (i = 1; i <= 12; i++) { var a = (i * 30 - 90) * Math.PI / 180; o += T(90 + 64 * Math.cos(a), 94 + 64 * Math.sin(a), bn(i), { fs: 12, w: 700 }); }
    var ha = ((H % 12) * 30 + M * 0.5 - 90) * Math.PI / 180, ma = (M * 6 - 90) * Math.PI / 180;
    o += Ln(90, 90, 90 + 40 * Math.cos(ha), 90 + 40 * Math.sin(ha), 's-hand') + Ln(90, 90, 90 + 58 * Math.cos(ma), 90 + 58 * Math.sin(ma), 's-hand2') + Ci(90, 90, 4, 's-dot');
    return svg(180, 180, o, H + ':' + M + ' সময়ে ঘড়ির কাঁটা');
  };
  /* ---- চাহিদা-যোগান ---- */
  DRAW.supplyDemand = function () {
    var o = '';
    o += Ln(40, 180, 40, 14, 's-axis', true) + Ln(40, 180, 300, 180, 's-axis', true) + T(20, 20, 'দাম', { fs: 11, a: 'start' }) + T(296, 196, 'পরিমাণ', { fs: 11, a: 'end' });
    o += Pa('M60 40 Q140 120 270 160', 's-dem') + T(272, 154, 'D', { w: 700, c: 's-demT', a: 'start' });
    o += Pa('M60 160 Q160 120 270 34', 's-sup') + T(272, 36, 'S', { w: 700, c: 's-supT', a: 'start' });
    o += Ci(150, 114, 5, 's-dot') + Ln(150, 114, 150, 180, 's-dash') + Ln(40, 114, 150, 114, 's-dash') + T(150, 194, 'Qe', { fs: 11 }) + T(30, 118, 'Pe', { fs: 11 }) + T(176, 108, 'E (ভারসাম্য)', { fs: 11, w: 700, a: 'start' });
    return svg(320, 204, o, 'চাহিদা রেখা নিম্নগামী, যোগান রেখা ঊর্ধ্বগামী; ছেদবিন্দুতে ভারসাম্য দাম ও পরিমাণ');
  };
  DRAW.ppf = function () {
    var o = '';
    o += Ln(40, 180, 40, 14, 's-axis', true) + Ln(40, 180, 300, 180, 's-axis', true) + T(24, 12, 'পণ্য Y', { fs: 11, a: 'start' }) + T(298, 196, 'পণ্য X', { fs: 11, a: 'end' });
    o += Pa('M40 40 Q210 46 230 180', 's-sup') + Pa('M40 22 Q240 26 266 180', 's-dash');
    o += Ci(168, 92, 5, 's-dot') + T(176, 88, 'A — রেখার ওপর: পূর্ণ ও দক্ষ ব্যবহার', { fs: 10, a: 'start' });
    o += Ci(100, 132, 5, 's-dotB') + T(108, 136, 'B — ভেতরে: অব্যবহৃত সম্পদ', { fs: 10, a: 'start' });
    o += Ci(232, 60, 5, 's-dotC') + T(206, 50, 'C — বাইরে: এখন অসম্ভব', { fs: 10, a: 'start' });
    o += T(262, 172, 'নতুন PPF (প্রবৃদ্ধি)', { fs: 9, c: 's-mute', a: 'end' });
    return svg(320, 204, o, 'উৎপাদন সম্ভাবনা রেখা');
  };
  DRAW.circularFlow = function () {
    var o = '';
    o += Rc(14, 70, 96, 50, 's-box2') + T(62, 92, 'পরিবার', { w: 700 }) + T(62, 108, '(Households)', { fs: 9, c: 's-mute' });
    o += Rc(250, 70, 96, 50, 's-box2') + T(298, 92, 'প্রতিষ্ঠান', { w: 700 }) + T(298, 108, '(Firms)', { fs: 9, c: 's-mute' });
    o += Pa('M298 70 C260 10 100 10 62 70', 's-real', true) + T(180, 22, 'পণ্য ও সেবা →', { fs: 10 });
    o += Pa('M80 70 C120 34 240 34 280 70', 's-money', true) + T(180, 44, 'ভোগব্যয় (টাকা) →', { fs: 10, c: 's-moneyT' });
    o += Pa('M62 120 C100 182 260 182 298 120', 's-real', true) + T(180, 176, '← উৎপাদনের উপকরণ (শ্রম, জমি, মূলধন)', { fs: 10 });
    o += Pa('M280 120 C240 156 120 156 80 120', 's-money', true) + T(180, 148, '← আয় (মজুরি, খাজনা, সুদ, মুনাফা)', { fs: 10, c: 's-moneyT' });
    return svg(360, 190, o, 'দুই খাতের অর্থনীতিতে আয়ের বৃত্তাকার প্রবাহ');
  };
  /* ---- নদী-ব্যবস্থা (নকশা, মাপ নয়) ---- */
  DRAW.rivers = function () {
    var o = '';
    o += Rc(6, 6, 308, 300, 's-uni', 12) + T(160, 296, 'বঙ্গোপসাগর', { fs: 11, c: 's-mute' });
    o += Pa('M150 14 C152 60 150 110 146 150', 's-riv', true) + T(158, 30, 'ব্রহ্মপুত্র → যমুনা', { fs: 10, a: 'start', w: 700 });
    o += Pa('M190 14 C180 40 162 58 152 70', 's-rivS', true) + T(196, 24, 'তিস্তা', { fs: 10, a: 'start' });
    o += Pa('M150 64 C190 92 214 122 226 160', 's-rivS', true) + T(196, 104, 'পুরাতন ব্রহ্মপুত্র', { fs: 9, a: 'start' });
    o += Pa('M300 70 C270 96 246 130 230 160', 's-rivS', true) + T(298, 62, 'সুরমা', { fs: 10, a: 'end' });
    o += Pa('M306 108 C282 122 254 142 232 162', 's-rivS', true) + T(300, 124, 'কুশিয়ারা', { fs: 10, a: 'end' });
    o += Ci(230, 162, 5, 's-dot') + T(244, 172, 'ভৈরব — মেঘনা নাম', { fs: 9, a: 'start' });
    o += Pa('M14 120 C70 134 110 146 146 152', 's-riv', true) + T(18, 112, 'গঙ্গা → পদ্মা', { fs: 10, a: 'start', w: 700 });
    o += Ci(146, 152, 5, 's-dot') + T(118, 172, 'গোয়ালন্দ', { fs: 9 });
    o += Pa('M146 152 C176 186 200 210 214 228', 's-riv', true) + T(150, 204, 'পদ্মা', { fs: 10 });
    o += Pa('M230 162 C226 190 222 210 214 228', 's-riv', true) + T(240, 200, 'মেঘনা', { fs: 10, a: 'start' });
    o += Ci(214, 228, 5, 's-dot') + T(226, 236, 'চাঁদপুর', { fs: 9, a: 'start' });
    o += Pa('M214 228 C212 252 208 270 204 286', 's-riv', true) + T(176, 262, 'মেঘনা', { fs: 10 });
    o += Pa('M296 200 C290 230 284 256 280 284', 's-rivS', true) + T(300, 214, 'কর্ণফুলী', { fs: 9, a: 'end' });
    return svg(320, 312, o, 'বাংলাদেশের প্রধান নদী-ব্যবস্থার নকশা — মানচিত্রের মাপে নয়');
  };
  /* ---- সংখ্যা রূপান্তরের কাজ (হিসাব কোডে) ---- */
  function convWork(n) {
    var steps = [], x = n;
    while (x > 0) { steps.push([x, Math.floor(x / 2), x % 2]); x = Math.floor(x / 2); }
    var bin = n.toString(2), oct = n.toString(8), hex = n.toString(16).toUpperCase();
    var pad3 = bin; while (pad3.length % 3) pad3 = '0' + pad3;
    var pad4 = bin; while (pad4.length % 4) pad4 = '0' + pad4;
    var g3 = pad3.match(/.{3}/g), g4 = pad4.match(/.{4}/g);
    return '<div class="cv"><div class="cv-col"><b>দশমিক ' + n + ' → বাইনারি (২ দিয়ে বারবার ভাগ)</b><table class="ch-tt"><tr><th>ভাজ্য</th><th>÷২ ভাগফল</th><th>ভাগশেষ</th></tr>' +
      steps.map(function (s) { return '<tr><td>' + s[0] + '</td><td>' + s[1] + '</td><td class="on">' + s[2] + '</td></tr>'; }).join('') +
      '</table><p class="small">ভাগশেষ <b>নিচ থেকে ওপরে</b> পড়ুন → <b>' + bin + '</b><sub>2</sub></p></div>' +
      '<div class="cv-col"><b>বাইনারি → অক্টাল (ডান থেকে ৩ বিট করে)</b><div class="cv-g">' + g3.map(function (g) { return '<span>' + g + '<i>' + parseInt(g, 2) + '</i></span>'; }).join('') + '</div><p class="small">= <b>' + oct + '</b><sub>8</sub></p>' +
      '<b>বাইনারি → হেক্সা (ডান থেকে ৪ বিট করে)</b><div class="cv-g">' + g4.map(function (g) { return '<span>' + g + '<i>' + parseInt(g, 2).toString(16).toUpperCase() + '</i></span>'; }).join('') + '</div><p class="small">= <b>' + hex + '</b><sub>16</sub></p>' +
      '<b>উল্টো পথে যাচাই</b><p class="small">' + bin.split('').map(function (d, i) { return d + '×2<sup>' + (bin.length - 1 - i) + '</sup>'; }).join(' + ') + ' = <b>' + n + '</b></p></div></div>';
  }
  /* ---- সংখ্যা ধারা: পার্থক্য দেখানো ---- */
  function seriesStrip(s) {
    var t = s.t, d1 = [], i;
    for (i = 1; i < t.length; i++) d1.push(s.ratio ? (t[i] / t[i - 1]) : (t[i] - t[i - 1]));
    var d2 = [];
    if (s.d2) for (i = 1; i < d1.length; i++) d2.push(d1[i] - d1[i - 1]);
    function row(arr, cls, pre) { return '<div class="sr-row ' + cls + '">' + arr.map(function (v) { return '<span>' + (pre || '') + (typeof v === 'number' ? num(Math.round(v * 100) / 100) : v) + '</span>'; }).join('') + '</div>'; }
    return '<div class="sr"><div class="small muted">' + inl(s.h) + '</div>' + row(t.concat(['?']), 'sr-t') + row(d1, 'sr-d', s.ratio ? '×' : (d1[0] >= 0 ? '+' : '')) + (d2.length ? row(d2, 'sr-d2', '+') : '') +
      '<div class="small">পরের পদ: <b>' + s.next + '</b> — ' + inl(s.why) + '</div></div>';
  }

  /* পাঠের চিপ: একই নামের পাঠ (যেমন "লেখক পরিচিতি") থাকলে অধ্যায়ের নাম আগে বসে */
  function lessonChips(lids) {
    var ls = lids.filter(function (l) { return C.LMAP[l]; }), seen = {}, dup = false;
    function lt(l) { return C.LMAP[l].t.replace(/^[^:]+:\s*/, ''); }
    ls.forEach(function (l) { var t = lt(l); if (seen[t]) dup = true; seen[t] = 1; });
    var more = ls.length > 6 ? ls.length - 6 : 0;
    return ls.slice(0, 6).map(function (l) {
      var ch = C.CMAP[C.LMAP[l].cid], t = dup && ch ? ch.t.replace(/^[^:]+:\s*/, '').replace(/^.*—\s*/, '') : lt(l);
      return '<a class="act-chip" href="#/l/' + l + '">📖 ' + esc(t.length > 36 ? t.slice(0, 35) + '…' : t) + '</a>';
    }).join('') + (more ? '<span class="act-chip muted">+' + num(more) + 'টি পাঠ</span>' : '');
  }
  /* ================= অংশ রেন্ডারার ================= */
  /* সিদ্ধান্ত-বৃক্ষ: শেষ "প্রশ্ন-শাখা"টি নিচে পরের ধাপ হিসেবে আসে (মোবাইলে গভীর ইনডেন্ট এড়াতে); অন্য শাখা ভেতরে */
  function flowNode(n, step) {
    if (!n) return '';
    if (n.a) return '<div class="fl-leaf"><b>' + inl(n.a) + '</b>' + (n.ex ? '<div class="fl-ex">' + inl(n.ex) + '</div>' : '') + '</div>';
    step = step || 1;
    var br = n.b || [], cont = -1;
    br.forEach(function (b, i) { if (b.n && b.n.q) cont = i; });
    function lab(l) { return '<span class="fl-lab' + (/^(হ্যাঁ|Yes)/.test(l) ? ' y' : /^(না|No)/.test(l) ? ' n' : '') + '">' + inl(l) + '</span>'; }
    var inner = br.map(function (b, i) {
      if (i === cont) return '<div class="fl-b fl-next">' + lab(b.l) + '<span class="fl-go">↓ ধাপ ' + num(step + 1) + '-এ যান</span></div>';
      return '<div class="fl-b">' + lab(b.l) + flowNode(b.n, step) + '</div>';
    }).join('');
    var out = '<div class="fl-q"><div class="fl-ask"><span class="fl-step">' + num(step) + '</span>' + inl(n.q) + '</div><div class="fl-br">' + inner + '</div></div>';
    if (cont >= 0) out += '<div class="fl-arrow" aria-hidden="true">↓ ' + inl(br[cont].l) + '</div>' + flowNode(br[cont].n, step + 1);
    return out;
  }
  function treeNode(n, depth) {
    var kids = n.c || [];
    var head = '<span class="tr-t">' + inl(n.t) + '</span>' + (n.d ? '<span class="tr-d">' + inl(n.d) + '</span>' : '');
    if (!kids.length) return '<li><div class="tr-n leaf">' + head + '</div></li>';
    return '<li><details class="tr-det"' + (depth < 2 ? ' open' : '') + '><summary class="tr-n">' + head + ' <span class="tr-cnt">' + num(kids.length) + '</span></summary><ul>' +
      kids.map(function (k) { return treeNode(k, depth + 1); }).join('') + '</ul></details></li>';
  }
  function nestNode(n, d) {
    return '<div class="nb nb' + Math.min(d, 4) + '"><div class="nb-t">' + inl(n.t) + (n.d ? ' <span class="nb-d">' + inl(n.d) + '</span>' : '') + '</div>' + (n.c || []).map(function (k) { return nestNode(k, d + 1); }).join('') + '</div>';
  }
  function part(p) {
    var h = p.h ? '<h3 class="ch-h">' + inl(p.h) + '</h3>' : '', k = p.k, o = '';
    if (k === 'grid') {
      o = '<div class="ch-grid-wrap' + (p.stack ? ' stack' : '') + '"><table class="ch-grid"><thead><tr>' + p.cols.map(function (c) { return '<th>' + inl(c) + '</th>'; }).join('') + '</tr></thead><tbody>' +
        p.rows.map(function (r) { return '<tr>' + r.map(function (c, i) { return '<td data-h="' + esc(String(p.cols[i] || '').replace(/\*\*/g, '')) + '">' + inl(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>' +
        (p.note ? '<p class="ch-cap">' + inl(p.note) + '</p>' : '');
    } else if (k === 'flow') o = '<div class="fl">' + flowNode(p.root) + '</div>';
    else if (k === 'steps') o = '<ol class="ch-steps">' + p.x.map(function (s) { return '<li><b>' + inl(s.t) + '</b>' + (s.d ? '<div>' + inl(s.d) + '</div>' : '') + (s.ex ? '<div class="st-ex">' + inl(s.ex) + '</div>' : '') + '</li>'; }).join('') + '</ol>';
    else if (k === 'ladder') o = '<div class="ld">' + (p.fl ? '<div class="ld-row ld-h"><span>' + inl(p.fl) + '</span><i></i><span>' + inl(p.tl) + '</span></div>' : '') + p.x.map(function (r, i) {
      return '<div class="ld-row" style="--i:' + i + '"><span class="ld-a">' + inl(r[0]) + '</span><i aria-hidden="true">→</i><span class="ld-b">' + inl(r[1]) + '</span>' + (r[2] ? '<small>' + inl(r[2]) + '</small>' : '') + '</div>';
    }).join('') + '</div>';
    else if (k === 'pyramid') o = '<div class="py">' + p.x.map(function (l, i) {
      var w = p.x.length > 1 ? 46 + i * 54 / (p.x.length - 1) : 100;
      return '<div class="py-l py' + (i % 4) + '" style="width:' + w + '%"><b>' + inl(l.t) + '</b>' + (l.d ? '<span>' + inl(l.d) + '</span>' : '') + (l.ex ? '<em>' + inl(l.ex) + '</em>' : '') + '</div>';
    }).join('') + '</div>';
    else if (k === 'tree') o = '<ul class="tr">' + treeNode(p.root, 0) + '</ul>';
    else if (k === 'nest') o = '<div class="nest">' + nestNode(p.root, 0) + '</div>';
    else if (k === 'cards') o = '<div class="cc' + (p.wide ? ' wide' : '') + (p.x.every(function (c) { return c.svg; }) ? ' sv' : '') + '">' + p.x.map(function (c) {
      var s = c.svg ? (c.svg.name === 'gate' ? DRAW.gate(c.svg) + truth(c.svg.g) : DRAW[c.svg.name](c.svg)) : '';
      return '<div class="cc-i">' + (c.tag ? '<span class="cc-tag">' + inl(c.tag) + '</span>' : '') + '<b class="cc-h">' + inl(c.h) + '</b>' + s +
        (c.b ? (Array.isArray(c.b) ? '<ul>' + c.b.map(function (x) { return '<li>' + inl(x) + '</li>'; }).join('') + '</ul>' : '<div class="cc-b">' + inl(c.b) + '</div>') : '') +
        (c.ex ? '<div class="cc-ex">' + inl(c.ex) + '</div>' : '') + '</div>';
    }).join('') + '</div>';
    else if (k === 'timeline') o = '<ol class="ch-tl">' + p.x.map(function (e) { return '<li><span class="tl-y2">' + inl(e.y) + '</span><b>' + inl(e.t) + '</b>' + (e.d ? '<div class="small">' + inl(e.d) + '</div>' : '') + '</li>'; }).join('') + '</ol>';
    else if (k === 'tense') o = '<div class="tz-axis" aria-hidden="true"><span>অতীত</span><span>বর্তমান (এখন)</span><span>ভবিষ্যৎ</span></div>' + p.rows.map(function (r) {
      return '<div class="tz-row"><div class="tz-asp">' + inl(r.asp) + '</div><div class="tz-cells">' + r.cells.map(function (c) {
        return '<div class="tz-c"><div class="tz-txt"><b>' + inl(c.name) + '</b><code>' + inl(c.form) + '</code><div class="tz-ex">' + inl(c.ex) + '</div></div>' + tenseGlyph(c.g, c.ref) + '</div>';
      }).join('') + '</div></div>';
    }).join('');
    else if (k === 'relmap') {
      var W = p.w || 340, H = p.hh || 240, ix = {}, s2 = '';
      p.nodes.forEach(function (n) { ix[n.id] = n; });
      var lab = '';
      p.edges.forEach(function (e, i) {
        var a = ix[e[0]], b = ix[e[1]], mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        s2 += Ln(a.x, a.y, b.x, b.y, e[3] === 'x' ? 's-conf' : 's-rel');
        lab += '<circle cx="' + mx + '" cy="' + my + '" r="8" class="' + (e[3] === 'x' ? 's-badgeX' : 's-badge') + '"/>' + T(mx, my + 3.5, num(i + 1), { fs: 10, w: 700, c: 's-badgeT' });
      });
      p.nodes.forEach(function (n) {
        var w = Math.max(56, n.t.length * 7.4 + 14);
        s2 += Rc(n.x - w / 2, n.y - 13, w, 26, n.main ? 's-main' : 's-box2', 13) + T(n.x, n.y + 4, n.t, { fs: 11, w: 700, c: n.main ? 's-mainT' : '' });
      });
      s2 += lab;
      o = svg(W, H, s2, p.h || 'চরিত্র-সম্পর্ক', 'rm') + '<ol class="rel-list">' + p.edges.map(function (e) { return '<li' + (e[3] === 'x' ? ' class="conf"' : '') + '><b>' + esc(ix[e[0]].t) + '</b> → <b>' + esc(ix[e[1]].t) + '</b>: ' + esc(e[2]) + '</li>'; }).join('') + '</ol>';
    } else if (k === 'zones') o = '<div class="zn" style="--cols:' + (p.cols || 3) + '">' + p.x.map(function (z) {
      return '<div class="zn-c" style="grid-row:' + z.r + ';grid-column:' + z.c + '"><span class="zn-n">' + inl(z.n) + '</span><b>' + inl(z.t) + '</b><div class="small">' + inl(z.b) + '</div></div>';
    }).join('') + '</div>';
    else if (k === 'bars') o = p.x.map(function (b) {
      var tot = b.segs.reduce(function (s, x) { return s + x[1]; }, 0);
      return '<div class="bm"><div class="bm-t">' + inl(b.t) + '</div><div class="bm-bar">' + b.segs.map(function (x) {
        return '<span class="bm-s ' + (x[2] || '') + '" style="flex:' + x[1] + '"><b>' + inl(x[0]) + '</b></span>';
      }).join('') + '</div>' + (b.note ? '<div class="bm-n">' + inl(b.note) + '</div>' : '') + '</div>';
    }).join('');
    else if (k === 'svg') {
      if (p.name === 'convWork') o = convWork(p.p.n);
      else if (p.name === 'series') o = p.p.x.map(seriesStrip).join('');
      else if (p.name === 'cipherLive') o = '<div class="cp-live"><div id="cpw">' + DRAW.cipher({ k: 3 }) + '</div><div class="cp-ctl"><label>শিফট <input type="range" min="1" max="25" value="3" id="cpk"> <b id="cpkv">৩</b></label>' +
        '<label>শব্দ লিখুন <input type="text" id="cpin" value="ICT" maxlength="20" autocomplete="off" autocapitalize="characters"></label><div class="cp-out">সাইফারটেক্সট: <b id="cpout">LFW</b></div></div></div>';
      else o = DRAW[p.name](p.p || {});
      if (p.cap) o += '<p class="ch-cap">' + inl(p.cap) + '</p>';
    } else if (k === 'note') o = '<div class="banner ' + (p.tone || 'ok') + '">' + inl(p.x) + '</div>';
    else if (k === 'list') o = (p.o ? '<ol>' : '<ul>') + p.x.map(function (x) { return '<li>' + inl(x) + '</li>'; }).join('') + (p.o ? '</ol>' : '</ul>');
    return '<section class="ch-part">' + h + o + '</section>';
  }

  /* ================= কনসেপ্ট ম্যাপ (স্বয়ংক্রিয়) ================= */
  function conceptMap(cid) {
    var c = C.CMAP[cid]; if (!c) return null;
    var sid = cid.replace(/-\d+$/, '');
    var S = C.SMAP[sid] || {};
    var lessons = c.l.filter(function (l) { return l.has; });
    var data = {};
    Data.list('lessons/' + sid + '/').forEach(function (n) { var d = Data.get(n) || {}; for (var k in d) data[k] = d[k]; });
    function clean(s) { return String(s || '').replace(/\*\*|==/g, '').trim(); }
    var root = { t: c.t, c: lessons.map(function (l) {
      var b = (data[l.id] && data[l.id].b) || [];
      var hs = b.filter(function (x) { return x.k === 'h'; }).map(function (x) { return clean(x.x); }).slice(0, 6);
      var sm = (b.filter(function (x) { return x.k === 'summary'; })[0] || { x: [] }).x.slice(0, 4).map(clean);
      var kids = hs.map(function (h) { return { t: h }; });
      if (sm.length) kids.push({ t: '⚡ এক নজরে', c: sm.map(function (s) { return { t: s }; }) });
      return { t: l.t.replace(/^[^:]+:\s*/, ''), d: '', c: kids, lid: l.id };
    }) };
    return { c: c, S: S, sid: sid, root: root };
  }

  /* ================= পাতা: হাব ================= */
  function tile(c, small) {
    var s = SUBNAME[c.sub] || ['', '📊', c.sub];
    return '<a class="cht' + (small ? ' sm' : '') + '" href="#/charts/' + c.id + '"><span class="cht-n">' + num(c.n) + '</span><span class="cht-i" aria-hidden="true">' + s[1] + '</span>' +
      '<span class="cht-b"><b>' + esc(c.t) + '</b>' + (small ? '' : '<span class="small muted">' + esc(c.d || '') + '</span>') + '</span>' + (isPinned(c.id) ? '<span class="cht-pin" title="হোমে পিন করা">📌</span>' : '') + '</a>';
  }
  function viewHub(h) {
    var p = {}; (h.split('?')[1] || '').split('&').forEach(function (kv) { if (kv) { var a = kv.split('='); p[a[0]] = decodeURIComponent(a[1] || ''); } });
    var f = p.s || '', q = (p.q || '').trim().toLowerCase();
    C.setTop('চার্ট ও ডায়াগ্রাম', { back: true });
    var list = all().filter(function (c) {
      if (f === 'map') return false;
      if (f && c.sub !== f) return false;
      if (q && (c.t + ' ' + (c.d || '') + ' ' + (c.tags || '')).toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
    var pn = pins();
    var html = '<div class="ch-search"><input type="search" id="chq" placeholder="চার্ট খুঁজুন… (যেমন tense, সমাস, UN)" value="' + esc(p.q || '') + '" aria-label="চার্ট খুঁজুন"></div>' +
      '<div class="ch-filter" role="group" aria-label="বিষয়">' + [['', '📊', 'সব']].concat(SUBS).concat([['map', '🗺', 'কনসেপ্ট ম্যাপ']]).map(function (s) {
        var n = s[0] === '' ? all().length : s[0] === 'map' ? null : forSubject(s[0]).length;
        if (n === 0) return '';
        return '<button data-f="' + s[0] + '" aria-pressed="' + (f === s[0]) + '">' + s[1] + ' ' + esc(s[2]) + (n ? ' <small>' + num(n) + '</small>' : '') + '</button>';
      }).join('') + '</div>';
    if (pn.length && !f && !q) {
      html += '<section class="card tight"><div class="row"><h2 class="spacer" style="margin:0;font-size:1.05rem">📌 পিন করা (হোমে দেখায়)</h2></div><ul class="pin-list">' + pn.map(function (id, i) {
        var c = get(id);
        return '<li data-id="' + id + '"><a href="#/charts/' + id + '" class="spacer">' + num(c.n) + '. ' + esc(c.t) + '</a>' +
          '<button class="icon-btn" data-mv="-1" aria-label="ওপরে"' + (i ? '' : ' disabled') + '>▲</button><button class="icon-btn" data-mv="1" aria-label="নিচে"' + (i < pn.length - 1 ? '' : ' disabled') + '>▼</button><button class="icon-btn" data-unpin aria-label="পিন সরান">✕</button></li>';
      }).join('') + '</ul></section>';
    }
    if (f === 'map') {
      html += '<p class="small muted">প্রতিটি অধ্যায়ের পাঠ, উপশিরোনাম ও "এক নজরে" অংশ থেকে স্বয়ংক্রিয়ভাবে তৈরি মাইন্ড-ম্যাপ — রিভিশনের আগে পুরো অধ্যায় এক পাতায় দেখুন।</p>' + C.SUBJ.map(function (s) {
        return '<details class="card tight"><summary class="row" style="min-height:44px;cursor:pointer"><span>' + s.icon + '</span><b class="spacer">' + esc(s.t) + '</b><span class="small muted">' + num(s.ch.length) + 'টি অধ্যায়</span></summary><div class="map-list">' +
          s.ch.map(function (c) { return '<a href="#/charts/map/' + c.id + '">🗺 ' + esc(c.t) + '</a>'; }).join('') + '</div></details>';
      }).join('');
    } else {
      var groups = {};
      list.forEach(function (c) { (groups[c.sub] = groups[c.sub] || []).push(c); });
      SUBS.forEach(function (s) {
        if (!groups[s[0]]) return;
        html += '<h2 class="sec-h">' + s[1] + ' ' + esc(s[2]) + '</h2><div class="cht-grid">' + groups[s[0]].map(function (c) { return tile(c); }).join('') + '</div>';
      });
      if (!list.length) html += '<div class="card"><p class="muted">কিছু পাওয়া যায়নি।</p></div>';
      if (!f && !q) html += '<a class="card tight row" href="#/charts?s=map" style="text-decoration:none;color:inherit"><span style="font-size:1.4rem">🗺</span><div class="spacer"><b>' + num(52) + '. অধ্যায়ের কনসেপ্ট ম্যাপ</b><div class="small muted">প্রতিটি অধ্যায়ের স্বয়ংক্রিয় মাইন্ড-ম্যাপ — ' + num(C.SUBJ.reduce(function (s, x) { return s + x.ch.length; }, 0)) + 'টি অধ্যায়</div></div><span class="caret">›</span></a>';
    }
    $v().innerHTML = html;
    var inp = qs('#chq'), tmo;
    inp.oninput = function () { clearTimeout(tmo); tmo = setTimeout(function () { history.replaceState(null, '', '#/charts?' + (f ? 's=' + f + '&' : '') + 'q=' + encodeURIComponent(inp.value)); viewHub(location.hash); var i2 = qs('#chq'); i2.focus(); i2.setSelectionRange(i2.value.length, i2.value.length); }, 250); };
    qsa('[data-f]').forEach(function (b) { b.onclick = function () { location.hash = '#/charts' + (b.getAttribute('data-f') ? '?s=' + b.getAttribute('data-f') : ''); }; });
    qsa('.pin-list [data-mv]').forEach(function (b) {
      b.onclick = function () { var id = b.closest('li').getAttribute('data-id'), a = pins(), i = a.indexOf(id), j = i + (+b.getAttribute('data-mv')); if (j < 0 || j >= a.length) return; a.splice(i, 1); a.splice(j, 0, id); setPins(a); viewHub(location.hash); };
    });
    qsa('.pin-list [data-unpin]').forEach(function (b) { b.onclick = function () { var id = b.closest('li').getAttribute('data-id'); setPins(pins().filter(function (x) { return x !== id; })); toast('পিন সরানো হলো'); viewHub(location.hash); }; });
  }

  /* ================= পাতা: একটি চার্ট ================= */
  function viewChart(id) {
    var c = get(id);
    if (!c) { location.replace('#/charts'); return; }
    var s = SUBNAME[c.sub] || ['', '📊', ''];
    C.setTop('চার্ট ' + num(c.n), { back: true, actions: '<button class="icon-btn" id="chprint" aria-label="প্রিন্ট" title="প্রিন্ট">🖨</button>' });
    var rec = (Store.get('chrecent', []) || []).filter(function (x) { return x !== id; }); rec.unshift(id); Store.set('chrecent', rec.slice(0, 8), 0);
    var sib = forSubject(c.sub), ix = sib.indexOf(c);
    var html = '<article class="chart-page">' +
      '<header class="card ch-head"><div class="small muted">' + s[1] + ' ' + esc(s[2]) + ' · চার্ট ' + num(c.n) + '</div><h1>' + esc(c.t) + '</h1>' +
      (c.intro ? '<p>' + inl(c.intro) + '</p>' : '') +
      '<div class="row wrap" style="gap:.4rem"><button class="btn sm' + (isPinned(id) ? ' primary' : '') + '" id="chpin" aria-pressed="' + isPinned(id) + '">' + (isPinned(id) ? '📌 হোমে পিন করা' : '📌 হোমে পিন করুন') + '</button>' +
      lessonChips(c.lids || []) + '</div></header>';
    html += (c.parts || []).map(part).join('');
    if (c.keys && c.keys.length) html += '<section class="ch-box keys"><h3>📌 মনে রাখুন</h3><ul>' + c.keys.map(function (x) { return '<li>' + inl(x) + '</li>'; }).join('') + '</ul></section>';
    if (c.ex && c.ex.length) html += '<section class="ch-box exc"><h3>⚠️ ব্যতিক্রম ও সাধারণ ভুল</h3><ul>' + c.ex.map(function (x) { return '<li>' + inl(x) + '</li>'; }).join('') + '</ul></section>';
    if (c.tip) html += '<section class="ch-box tip"><h3>🧠 মনে রাখার কৌশল</h3><p>' + inl(c.tip) + '</p></section>';
    if (c.src && c.src.length) html += '<details class="ch-src"><summary>📚 সূত্র</summary><ul>' + c.src.map(function (x) { return '<li>' + inl(x) + '</li>'; }).join('') + '</ul></details>';
    html += '<div class="lesson-nav">' + (ix > 0 ? '<a class="btn" href="#/charts/' + sib[ix - 1].id + '">← ' + esc(sib[ix - 1].t.slice(0, 22)) + '</a>' : '<a class="btn" href="#/charts">সব চার্ট</a>') +
      (ix < sib.length - 1 ? '<a class="btn primary" href="#/charts/' + sib[ix + 1].id + '">' + esc(sib[ix + 1].t.slice(0, 22)) + ' →</a>' : '<a class="btn primary" href="#/charts">সব চার্ট</a>') + '</div></article>';
    $v().innerHTML = html;
    qs('#chpin').onclick = function () {
      var a = pins(), on = a.indexOf(id) < 0;
      if (on) a.push(id); else a = a.filter(function (x) { return x !== id; });
      setPins(a); this.setAttribute('aria-pressed', on); this.classList.toggle('primary', on); this.textContent = on ? '📌 হোমে পিন করা' : '📌 হোমে পিন করুন';
      toast(on ? 'হোমের "চার্ট ও ডায়াগ্রাম" অংশে যোগ হলো' : 'পিন সরানো হলো');
    };
    qs('#chprint').onclick = function () { qsa('details', $v()).forEach(function (d) { d.open = true; }); window.print(); };
    var k = qs('#cpk');
    if (k) {
      var upd = function () {
        var sh = +k.value, t = (qs('#cpin').value || '').toUpperCase().replace(/[^A-Z]/g, '');
        qs('#cpkv').textContent = num(sh); qs('#cpw').innerHTML = DRAW.cipher({ k: sh });
        qs('#cpout').textContent = t.split('').map(function (ch) { return String.fromCharCode((ch.charCodeAt(0) - 65 + sh) % 26 + 65); }).join('') || '—';
      };
      k.oninput = upd; qs('#cpin').oninput = upd;
    }
  }
  function viewMap(cid) {
    var m = conceptMap(cid);
    if (!m) { location.replace('#/charts?s=map'); return; }
    C.setTop('কনসেপ্ট ম্যাপ', { back: true });
    var root = m.root;
    function mapNode(n, d) {
      var kids = n.c || [];
      return '<li><div class="mm-n d' + d + '">' + (n.lid ? '<a href="#/l/' + n.lid + '">' + esc(n.t) + '</a>' : esc(n.t)) + '</div>' + (kids.length ? '<ul>' + kids.map(function (k) { return mapNode(k, d + 1); }).join('') + '</ul>' : '') + '</li>';
    }
    $v().innerHTML = '<header class="card ch-head"><div class="small muted">' + (m.S.icon || '') + ' ' + esc(m.S.t || '') + ' · চার্ট ' + num(52) + ' — কনসেপ্ট ম্যাপ</div><h1>' + esc(m.c.t) + '</h1>' +
      '<p class="small muted">পাঠ → উপশিরোনাম → এক নজরে মূল তথ্য। পাঠের নামে চাপলে সেই পাঠ খুলবে।</p></header>' +
      '<div class="mm"><ul>' + mapNode(root, 0) + '</ul></div>' +
      '<div class="lesson-nav"><a class="btn" href="#/charts?s=map">সব ম্যাপ</a><a class="btn primary" href="#/s/' + m.sid + '">বিষয়ে যান →</a></div>';
  }

  /* ================= হোমের অংশ ================= */
  C.addHome(function () {
    var pn = pins(), list;
    if (pn.length) list = pn.slice(0, 4).map(get);
    else {
      var mine = C.unitSubjects().map(function (s) { return s.id; });
      var pool = all().filter(function (c) { return mine.indexOf(c.sub) >= 0; });
      if (!pool.length) pool = all();
      var d = new Date(), start = (d.getDate() * 3) % Math.max(1, pool.length);
      list = [0, 1, 2].map(function (i) { return pool[(start + i * 5) % pool.length]; }).filter(function (c, i, a) { return c && a.indexOf(c) === i; });
    }
    if (!list.length) return '';
    return '<section class="card tight home-charts"><div class="row"><div class="spacer"><b>📊 চার্ট ও ডায়াগ্রাম</b><div class="small muted">' + (pn.length ? 'আপনার পিন করা চার্ট' : 'আজকের প্রস্তাব — যেকোনো চার্টে 📌 চাপলে এখানে থাকবে') + '</div></div>' +
      '<a class="btn sm" href="#/charts">সব (' + num(all().length + 1) + ') →</a></div><div class="hc-list">' + list.map(function (c) { return tile(c, true); }).join('') + '</div></section>';
  }, false, 'charts', 'চার্ট ও ডায়াগ্রাম');

  /* ================= রুট ================= */
  C.addRoute(/^#\/charts\/map\/([\w-]+)/, function (m) { viewMap(m[1]); }, 'syllabus');
  C.addRoute(/^#\/charts\/([\w-]+)/, function (m) { viewChart(m[1]); }, 'syllabus');
  C.addRoute(/^#\/charts/, function (m, h) { viewHub(h); }, 'syllabus');

  window.Charts = { all: all, get: get, forLesson: forLesson, forSubject: forSubject, pins: pins, DRAW: DRAW, conceptMap: conceptMap };
})();
