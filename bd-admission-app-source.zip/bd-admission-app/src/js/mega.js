/* =========================================================
   mega.js — Phase 10
   Mega Mock (PART G): প্রতিটি ইউনিটের অফিসিয়াল কাঠামোয় পূর্ণ পরীক্ষা;
     DU B = ৬০ MCQ (টেস্ট ইঞ্জিন) → ৪০ নম্বরের লিখিত (Written Lab) → সম্মিলিত ফল
   Subject Final Exam (PART H): বিষয়ভিত্তিক ১০০ MCQ, Mastery, Learning Quality Score,
     দুর্বল টপিক ও দিনভিত্তিক রিভিশন প্ল্যান
   ========================================================= */
(function () {
  'use strict';
  var C = window.Core, P = window.Practice;
  var esc = C.esc, num = C.num, toast = C.toast;
  var SMAP = C.SMAP, CMAP = C.CMAP, LMAP = C.LMAP, UNITS = C.UNITS;
  function $v() { return C.view(); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function pct(a, b) { return b ? a * 100 / b : 0; }
  function r2(x) { return Math.round(x * 100) / 100; }
  function vchip(ok) { return ok ? '' : ' <span class="chip verify">Verify</span>'; }
  function dstr(t) { return new Date(t).toLocaleDateString('bn-BD'); }

  /* ---------------- ইউনিটের Mega Mock পরিকল্পনা ---------------- */
  var GROUPS = [['বাংলা', ['bn1', 'bn2']], ['ইংরেজি', ['en']], ['সাধারণ জ্ঞান', ['gkbd', 'gkint', 'ca', 'ict']], ['গাণিতিক যুক্তি', ['math']], ['অর্থনীতি', ['eco']], ['পৌরনীতি', ['civ']], ['সমাজবিজ্ঞান ও সমাজকর্ম', ['soc']], ['ইতিহাস', ['hist']], ['বিশ্ববিদ্যালয় পরিচিতি', ['uni']]];
  function plan(u) {
    var m = u.mcq || {};
    var nq = m.questions || m.marks || 0;
    var secs = (m.sections || []).filter(function (x) { return x.subjects && x.subjects.length; });
    // যে অংশের বিষয় অ্যাপে নেই (যেমন জাবি E-র ব্যবসায় সংক্রান্ত সাধারণ জ্ঞান) — Mock থেকে বাদ, কার্ডে স্পষ্ট লেখা থাকে
    var skipped = (m.sections || []).filter(function (x) { return !x.subjects || !x.subjects.length; });
    var official = !!secs.length;
    if (!official) {
      // অফিসিয়াল বিষয়ভিত্তিক বণ্টন প্রকাশিত নয় → ইউনিটের বিষয়গুলো থেকে সমান ভাগ (স্পষ্টভাবে জানানো হয়)
      var subs = u.subjects || [];
      var g = GROUPS.map(function (x) { return [x[0], x[1].filter(function (s) { return subs.indexOf(s) >= 0; })]; }).filter(function (x) { return x[1].length; });
      var base = Math.floor(nq / g.length), extra = nq - base * g.length;
      secs = g.map(function (x, i) { return { label: x[0], n: base + (i < extra ? 1 : 0), subjects: x[1] }; });
    } else {
      // marks ≠ প্রশ্নসংখ্যা হলে (যেমন RU) অংশের প্রশ্নসংখ্যা অনুপাতে
      var mk = m.marks || nq;
      secs = secs.map(function (x) { return { label: x.label, n: Math.round(x.marks * nq / mk), marks: x.marks, subjects: x.subjects }; });
      if (skipped.length) {
        var full = nq;
        nq = secs.reduce(function (s, x) { return s + x.n; }, 0);
        if (m.minutes) var minsScaled = Math.round(m.minutes * nq / full);
      }
    }
    var mins = (typeof minsScaled === 'number' ? minsScaled : m.minutes) || 0, minsGuess = false;
    if (!mins) { mins = Math.round(nq * 36 / 60); minsGuess = true; }
    var mp = (m.marks && (m.questions || m.marks)) ? m.marks / (m.questions || m.marks) : 1;
    return { nq: nq, marks: Math.round(nq * mp * 100) / 100, mp: mp, skipped: skipped, neg: typeof m.negative === 'number' ? m.negative : 0.25,
      negVerified: m.negativeVerified !== false, secs: secs, official: official, secVerified: !!m.sectionsVerified,
      mins: mins, minsGuess: minsGuess, minsVerified: m.minutesVerified !== false && !minsGuess };
  }
  function megaLog() { return Store.get('mega', {}) || {}; }
  function pushMega(unit, rec) {
    var all = megaLog(), c = {}; for (var k in all) c[k] = all[k];
    c[unit] = [rec].concat(c[unit] || []).slice(0, 30);
    Store.set('mega', c, 0);
  }
  function bestOf(list) { return (list || []).reduce(function (b, r) { return !b || r.score > b.score ? r : b; }, null); }

  function unitCard(u, mine) {
    var p = plan(u), log = megaLog()[u.id] || [], best = bestOf(log);
    var have = p.secs.map(function (x) { return QB.filter({ subs: x.subjects, noExpired: true }).length; });
    var short = p.secs.some(function (x, i) { return have[i] < x.n; });
    var w = u.writtenLab && u.written;
    return '<section class="card mega-card' + (mine ? ' mine' : '') + '">' +
      '<div class="row"><div class="spacer"><div class="small muted">' + esc(u.track.name.split(' (')[0]) + (mine ? ' · <b>আমার ইউনিট</b>' : '') + '</div>' +
      '<h3 style="margin:.1rem 0">' + esc(u.code) + ' — ' + esc(u.name) + '</h3></div>' +
      (best ? '<div class="mega-best"><span class="small muted">সেরা</span><b>' + num(best.score) + '</b><span class="small muted">/' + num(best.max) + '</span></div>' : '') + '</div>' +
      '<div class="row wrap" style="gap:.35rem;margin:.4rem 0">' +
      '<span class="chip">' + num(p.nq) + 'টি MCQ' + (p.marks !== p.nq ? ' · ' + num(p.marks) + ' নম্বর' : '') + '</span>' +
      '<span class="chip">' + num(p.mins) + ' মিনিট' + (p.minsVerified ? '' : ' (Verify)') + '</span>' +
      '<span class="chip">নেগেটিভ ' + num(p.neg) + (p.negVerified ? '' : ' (Verify)') + '</span>' +
      (w ? '<span class="chip ok">+ লিখিত ' + num(u.written.marks) + ' নম্বর</span>' : '') + '</div>' +
      '<div class="small">' + p.secs.map(function (x, i) { return esc(x.label) + ' ' + num(x.n) + (have[i] < x.n ? ' <span style="color:var(--bad)">(ব্যাংকে ' + num(have[i]) + ')</span>' : ''); }).join(' · ') +
      (p.skipped && p.skipped.length ? '<div class="small muted" style="margin-top:.2rem">বাদ: ' + p.skipped.map(function (x) { return esc(x.label) + ' ' + num(x.marks); }).join(', ') + ' — তাই Mock ' + num(p.nq) + ' প্রশ্নে, সময় আনুপাতিক</div>' : '') +
      (p.official ? (p.secVerified ? '' : ' <span class="chip verify">বণ্টন Verify</span>') : ' <span class="chip verify">অফিসিয়াল বণ্টন প্রকাশিত নয় — সমান ভাগে অনুশীলন</span>') + '</div>' +
      (short ? '<p class="small muted" style="margin:.3rem 0 0">কোনো অংশে প্রশ্ন কম থাকলে যতগুলো আছে ততগুলো দিয়েই পরীক্ষা হবে।</p>' : '') +
      '<div class="row wrap" style="margin-top:.6rem"><button class="btn primary" data-start="' + u.id + '">▶ শুরু করুন</button>' +
      (log.length ? '<a class="btn" href="#/mega/' + u.id + '">📊 ' + num(log.length) + 'টি চেষ্টা</a>' : '') + '</div></section>';
  }

  function viewHub() {
    C.setTop('Mega Mock', { back: true });
    var my = C.settings().unit, units = [];
    C.EXAM.tracks.forEach(function (t) { t.units.forEach(function (u) { units.push(UNITS[u.id]); }); });
    units.sort(function (a, b) { return (b.id === my) - (a.id === my); });
    var html = '<div class="banner ok">প্রতিটি ইউনিটের অফিসিয়াল কাঠামো (প্রশ্নসংখ্যা, সময়, নেগেটিভ মার্কিং) অনুযায়ী পূর্ণ পরীক্ষা। আগে দেননি এমন প্রশ্নকে অগ্রাধিকার দেওয়া হয়; প্রতিটি অংশে সহজ-মাঝারি-কঠিন ৩০:৫০:২০।</div>' +
      units.map(function (u) { return unitCard(u, u.id === my); }).join('') +
      '<p class="small muted">যে তথ্যের পাশে Verify আছে তা প্রতি বছর বদলাতে পারে — সর্বশেষ ভর্তি বিজ্ঞপ্তি দেখে মিলিয়ে নিন।</p>';
    $v().innerHTML = html;
    Array.prototype.forEach.call($v().querySelectorAll('[data-start]'), function (b) { b.onclick = function () { start(b.getAttribute('data-start')); }; });
  }

  function start(unitId) {
    var u = UNITS[unitId], p = plan(u);
    function go() {
      var cfg = { preset: 'mock', mega: true, unit: unitId, neg: p.neg, mp: p.mp, fb: 'end', shuffle: true, noExp: true, pause: false,
        minutes: p.mins, sections: p.secs, title: 'Mega Mock — ' + u.track.name.split(' (')[0] + ' ' + u.code };
      if (u.writtenLab) Store.set('megaRun', { unit: unitId, at: Date.now() }, 0);
      P.startTest(cfg);
    }
    if (Store.get('test:active', null)) {
      C.modal('<h2>আগের টেস্ট এখনো চলছে</h2><p>Mega Mock শুরু করলে আগেরটি জমা হয়ে যাবে।</p><div class="grid2"><a class="btn" href="#/test/run">আগেরটি চালান</a><button class="btn primary" id="force">জমা দিয়ে শুরু</button></div>', function (m) {
        qs('#force', m).onclick = function () { C.closeModal(); P.submitTest(true); go(); };
      });
      return;
    }
    C.modal('<h2>' + esc(u.code) + ' — Mega Mock</h2><p>' + num(p.nq) + 'টি প্রশ্ন · ' + num(p.mins) + ' মিনিট · প্রতি ভুলে ' + num(p.neg) + ' কাটা যাবে।' +
      (u.writtenLab ? ' MCQ জমা দেওয়ার পর ' + num(u.written.minutes) + ' মিনিটের লিখিত অংশ।' : '') + '</p><p class="small muted">টাইমার চালু হবে; অ্যাপ বন্ধ করলেও অগ্রগতি সংরক্ষিত থাকবে (প্রতি ৫ সেকেন্ডে)।</p>' +
      '<div class="grid2"><button class="btn" id="mc">বাতিল</button><button class="btn primary" id="mo">শুরু</button></div>', function (m) {
      qs('#mc', m).onclick = C.closeModal;
      qs('#mo', m).onclick = function () { C.closeModal(); go(); };
    });
  }

  /* টেস্ট জমার পর */
  P.onSubmit(function (res) {
    if (res.cfg.mega) {
      pushMega(res.cfg.unit, { id: res.id, score: res.score, max: res.max, c: res.c, w: res.w, s: res.s, at: res.at });
      var mr = Store.get('megaRun', null);
      if (mr && mr.unit === res.cfg.unit) { mr = { unit: mr.unit, at: mr.at, tid: res.id }; Store.set('megaRun', mr, 0); }
      bumpBest('mega:' + res.cfg.unit, res.score, res.max);
    }
    if (res.cfg.final) {
      var f = finalStats(res);
      var all = Store.get('finals', {}) || {}, c = {}; for (var k in all) c[k] = all[k];
      c[res.cfg.final] = [{ id: res.id, pct: f.acc, lqs: f.lqs, score: res.score, max: res.max, at: res.at }].concat(c[res.cfg.final] || []).slice(0, 20);
      Store.set('finals', c, 0);
      bumpBest('final:' + res.cfg.final, f.lqs, 100);
    }
  });
  function bumpBest(key, score, max) {
    var b = Store.get('best', {}) || {}, c = {}; for (var k in b) c[k] = b[k];
    if (!c[key] || score > c[key].score) { c[key] = { score: score, max: max, at: Date.now() }; Store.set('best', c, 0); }
  }

  /* ফলাফল পাতায় বাড়তি অংশ */
  P.onResult(function (res) {
    if (res.cfg.mega) return megaResultHTML(res);
    if (res.cfg.final) return finalResultHTML(res);
    return '';
  });
  function megaResultHTML(res) {
    var u = UNITS[res.cfg.unit]; if (!u) return '';
    var log = megaLog()[u.id] || [], best = bestOf(log);
    var h = '<section class="card"><h2>🎓 Mega Mock</h2>';
    h += '<p class="small">ব্যক্তিগত সেরা: <b>' + num(best ? best.score : res.score) + '/' + num(res.max) + '</b>' + (log.length > 1 ? ' · মোট ' + num(log.length) + 'টি চেষ্টা' : '') + '</p>';
    if (log.length > 1) h += trend(log.slice(0, 8).reverse());
    if (u.pass && u.pass.total && !u.writtenLab) h += '<p class="small">' + esc(u.code) + ' ইউনিটে পাস নম্বর ' + num(u.pass.total) + ': ' + (res.score >= u.pass.total ? '✅ পাস' : '❌ পাস হয়নি') + vchip(u.pass.verified) + (u.pass.note ? '<br><span class="muted">' + esc(u.pass.note) + '</span>' : '') + '</p>';
    if (u.writtenLab) {
      var mr = Store.get('megaRun', null);
      if (mr && mr.tid === res.id && !mr.wid) h += '<div class="banner warn"><b>ধাপ ২ বাকি:</b> এখন ' + num(u.written.minutes) + ' মিনিটের লিখিত অংশ (' + num(u.written.marks) + ' নম্বর) দিন। শেষে নিজের লেখা মডেল উত্তরের সাথে মিলিয়ে নম্বর দিলে সম্মিলিত ফল দেখাবে।</div>' +
        '<a class="btn primary block" href="#/written/full">✍️ লিখিত অংশ শুরু করুন</a>';
      h += '<a class="btn block" style="margin-top:.5rem" href="#/mega/' + u.id + '">📊 সম্মিলিত ফল ও সব চেষ্টা</a>';
    } else h += '<a class="btn block" href="#/mega/' + u.id + '">📊 সব চেষ্টা</a>';
    return h + '</section>';
  }
  function trend(list) {
    var mx = Math.max.apply(null, list.map(function (r) { return r.max; }));
    return '<div class="mini-trend" style="grid-template-columns:repeat(' + list.length + ',1fr)">' + list.map(function (r) {
      return '<div><div class="bar" style="height:' + Math.max(3, Math.round(Math.max(0, r.score) * 70 / mx)) + 'px"></div><span class="small muted">' + num(r.score) + '</span></div>';
    }).join('') + '</div>';
  }

  /* ইউনিটের সব চেষ্টা + DU B সম্মিলিত ফল */
  function writtenScore(wid) {
    var r = (Store.get('wsaved', []) || []).filter(function (x) { return x.id === wid; })[0];
    if (!r) return null;
    var sc = 0, mx = 0, n = 0;
    r.parts.forEach(function (p, i) { var s = (r.self || {})[i]; mx += p.marks || 10; if (s && s.score != null) { sc += s.score; n++; } });
    return { rec: r, score: r2(sc), max: mx, done: n === r.parts.length, partial: n > 0 && n < r.parts.length };
  }
  function viewUnit(unitId) {
    var u = UNITS[unitId]; if (!u) { location.replace('#/mega'); return; }
    C.setTop('Mega Mock — ' + u.code, { back: true });
    var log = megaLog()[unitId] || [], combos = Store.get('megaCombo', []) || [];
    var html = '';
    if (u.writtenLab) {
      var mr = Store.get('megaRun', null);
      var rows = combos.filter(function (x) { return x.unit === unitId; });
      if (mr && mr.unit === unitId && mr.tid && !rows.some(function (x) { return x.tid === mr.tid; })) rows = [{ unit: unitId, tid: mr.tid, wid: mr.wid, pending: true }].concat(rows);
      html += '<section class="card"><h2>সম্মিলিত ফল (MCQ ' + num(u.mcq.marks) + ' + লিখিত ' + num(u.written.marks) + ')</h2>';
      if (!rows.length) html += '<p class="muted">এখনো কোনো পূর্ণ Mega Mock নেই। MCQ অংশ দিয়ে শুরু করুন — শেষে লিখিত অংশের বাটন আসবে।</p>';
      rows.slice(0, 10).forEach(function (x) {
        var t = log.filter(function (r) { return r.id === x.tid; })[0];
        var w = x.wid ? writtenScore(x.wid) : null;
        var ps = u.pass || {};
        var tot = t && w && w.done ? r2(t.score + w.score) : null;
        html += '<div class="mega-combo"><div class="small muted">' + (t ? dstr(t.at) : '') + '</div><div class="grid3">' +
          '<div class="stat"><span class="small muted">MCQ</span><b>' + (t ? num(t.score) : '—') + '</b><span class="small muted">/' + num(u.mcq.marks) + (ps.mcq ? ' · পাস ' + num(ps.mcq) : '') + '</span></div>' +
          '<div class="stat"><span class="small muted">লিখিত</span><b>' + (w ? (w.done ? num(w.score) : (w.partial ? num(w.score) + '…' : '—')) : '—') + '</b><span class="small muted">/' + num(u.written.marks) + (ps.written ? ' · পাস ' + num(ps.written) : '') + '</span></div>' +
          '<div class="stat"><span class="small muted">মোট</span><b>' + (tot != null ? num(tot) : '—') + '</b><span class="small muted">/' + num(u.mcq.marks + u.written.marks) + (ps.total ? ' · পাস ' + num(ps.total) : '') + '</span></div></div>';
        if (tot != null && ps.total) {
          var okAll = tot >= ps.total && (!ps.mcq || t.score >= ps.mcq) && (!ps.written || w.score >= ps.written);
          html += '<p class="small">' + (okAll ? '✅ পাস নম্বরের শর্ত পূরণ হয়েছে' : '❌ পাস নম্বরের শর্ত পূরণ হয়নি') + vchip(ps.verified) + '</p>';
        }
        if (!x.wid) html += '<a class="btn primary" href="#/written/full">✍️ লিখিত অংশ দিন</a>';
        else if (w && !w.done) html += '<a class="btn" href="#/written/r/' + x.wid + '">লিখিত অংশে নিজে নম্বর দিন →</a>';
        else if (w) html += '<a class="small" href="#/written/r/' + x.wid + '">লিখিত উত্তর দেখুন</a>';
        if (t) html += ' <a class="small" href="#/test/result/' + t.id + '">MCQ ফলাফল</a>';
        html += '</div>';
      });
      html += '<p class="small muted">লিখিত অংশের নম্বর আপনার নিজের মূল্যায়ন (মডেল উত্তর ও চেকলিস্ট দেখে)। পাস নম্বর' + (u.pass && u.pass.verified ? '' : ' (Verify)') + ' সর্বশেষ বিজ্ঞপ্তিতে মিলিয়ে নিন।</p></section>';
    }
    html += '<section class="card"><h2>MCQ চেষ্টাসমূহ</h2>' + (log.length ? trend(log.slice(0, 10).reverse()) + log.map(function (r) {
      return '<a class="result" href="#/test/result/' + r.id + '"><div class="row"><b class="spacer">' + dstr(r.at) + '</b><span>' + num(r.score) + '/' + num(r.max) + '</span></div><div class="where">সঠিক ' + num(r.c) + ' · ভুল ' + num(r.w) + ' · বাদ ' + num(r.s) + '</div></a>';
    }).join('') : '<p class="muted">এখনো কোনো চেষ্টা নেই।</p>') +
      '<button class="btn primary block" id="again" style="margin-top:.6rem">▶ নতুন Mega Mock</button></section>';
    $v().innerHTML = html;
    qs('#again').onclick = function () { start(unitId); };
  }

  /* লিখিত অংশ জমা হলে Mega-র সাথে যুক্ত করা (written.js থেকে ডাকা হয়) */
  function onWritten(rec) {
    var mr = Store.get('megaRun', null);
    if (!mr || !mr.tid || mr.wid || rec.key !== 'full') return;
    if (Date.now() - mr.at > 6 * 3600 * 1000) return; // একই বসায় না হলে যুক্ত নয়
    var combos = (Store.get('megaCombo', []) || []).slice();
    combos.unshift({ unit: mr.unit, tid: mr.tid, wid: rec.id, at: Date.now() });
    Store.set('megaCombo', combos.slice(0, 30), 0);
    Store.set('megaRun', { unit: mr.unit, at: mr.at, tid: mr.tid, wid: rec.id }, 0);
  }
  function writtenNote(r) {
    var c = (Store.get('megaCombo', []) || []).filter(function (x) { return x.wid === r.id; })[0];
    if (!c) return '';
    return '<div class="banner ok">এটি Mega Mock-এর লিখিত অংশ। প্রতিটি অংশে নিজেকে নম্বর দিন, তারপর <a href="#/mega/' + c.unit + '"><b>সম্মিলিত ফল দেখুন →</b></a></div>';
  }

  /* ================= Subject Final Exam ================= */
  var FINAL_N = 100, SEC_PER_Q = 45;
  function finalsLog() { return Store.get('finals', {}) || {}; }
  function viewFinalHub() {
    C.setTop('Subject Final Exam', { back: true });
    var mine = C.unitSubjects().map(function (s) { return s.id; });
    var subs = C.SUBJ.slice().sort(function (a, b) { return (mine.indexOf(b.id) >= 0) - (mine.indexOf(a.id) >= 0); });
    var log = finalsLog();
    var html = '<div class="banner ok">বিষয় শেষ করে নিজেকে যাচাই: প্রতিটি অধ্যায় থেকে অনুপাতে মোট ' + num(FINAL_N) + 'টি প্রশ্ন (যাচাইকৃত PYQ থাকলে তা-সহ), প্রশ্নপ্রতি ' + num(SEC_PER_Q) + ' সেকেন্ড, প্রতি ভুলে ০.২৫ কাটা। শেষে Mastery, Learning Quality Score, দুর্বল টপিক ও দিনভিত্তিক রিভিশন প্ল্যান।</div>';
    html += '<div class="card">' + subs.map(function (s) {
      var n = QB.forSubject(s.id).length, l = log[s.id] || [], best = l.reduce(function (b, r) { return !b || r.lqs > b.lqs ? r : b; }, null);
      var ms = QB.mastery(QB.forSubject(s.id));
      return '<div class="row final-row"><span class="fi" aria-hidden="true">' + s.icon + '</span><div class="spacer"><b>' + esc(s.t) + '</b>' + (mine.indexOf(s.id) >= 0 ? ' <span class="chip ok">আমার ইউনিট</span>' : '') +
        '<div class="small muted">' + num(n) + 'টি প্রশ্নব্যাংকে' + (ms && ms.tried ? ' · Mastery ' + C.pct(ms.mastery) : '') + (best ? ' · সেরা LQS ' + num(best.lqs) : '') + '</div></div>' +
        (n ? '<a class="btn sm primary" href="#/final/' + s.id + '">শুরু</a>' : '') + '</div>';
    }).join('') + '</div>';
    $v().innerHTML = html;
  }
  function pickFinal(sid) {
    var pool = QB.forSubject(sid).filter(function (q) { return !QB.isExpired(q); });
    var n = Math.min(FINAL_N, pool.length);
    var pyq = QB.shuffle(pool.filter(QB.isPYQ)).slice(0, Math.round(n * 0.2));
    var used = {}; pyq.forEach(function (q) { used[q.id] = 1; });
    var rest = pool.filter(function (q) { return !used[q.id]; });
    var byC = {}, order = [];
    rest.forEach(function (q) { var k = q.cid || '_'; if (!byC[k]) { byC[k] = []; order.push(k); } byC[k].push(q); });
    var need = n - pyq.length, quota = {}, given = 0;
    order.forEach(function (k) { quota[k] = Math.max(1, Math.floor(need * byC[k].length / rest.length)); given += quota[k]; });
    // বাকি/বাড়তি ঠিক করা — বড় অধ্যায় আগে
    var big = order.slice().sort(function (a, b) { return byC[b].length - byC[a].length; }), i = 0;
    while (given < need && i < 1000) { var k = big[i % big.length]; if (quota[k] < byC[k].length) { quota[k]++; given++; } i++; }
    i = 0; while (given > need && i < 1000) { var k2 = big[i % big.length]; if (quota[k2] > 1) { quota[k2]--; given--; } i++; }
    var out = pyq.slice();
    order.forEach(function (k) {
      var fresh = QB.shuffle(byC[k].filter(function (q) { return !QB.stat(q.id); })), seen = QB.shuffle(byC[k].filter(function (q) { return QB.stat(q.id); }));
      out = out.concat(P.pickByMix(fresh.concat(seen), Math.min(quota[k], byC[k].length), [30, 45, 25]));
    });
    return out;
  }
  function viewFinalStart(sid) {
    var s = SMAP[sid]; if (!s) { location.replace('#/final'); return; }
    C.setTop('Final — ' + s.t, { back: true });
    var pool = QB.forSubject(sid), n = Math.min(FINAL_N, pool.length);
    var chs = {}; pool.forEach(function (q) { chs[q.cid] = 1; });
    var mins = Math.round(n * SEC_PER_Q / 60);
    $v().innerHTML = '<section class="card"><div class="small muted">Subject Final Exam</div><h1 style="margin:.2rem 0">' + s.icon + ' ' + esc(s.t) + '</h1>' +
      '<div class="grid2"><div class="stat"><span class="small muted">প্রশ্ন</span><b>' + num(n) + '</b><span class="small muted">' + num(Object.keys(chs).length) + 'টি অধ্যায় থেকে</span></div>' +
      '<div class="stat"><span class="small muted">সময়</span><b>' + num(mins) + ' মি.</b><span class="small muted">প্রশ্নপ্রতি ' + num(SEC_PER_Q) + ' সে.</span></div></div>' +
      '<ul class="small"><li>প্রতি ভুলে ০.২৫ কাটা যাবে (ভর্তি পরীক্ষার মতো)।</li><li>উত্তর ও ব্যাখ্যা দেখাবে জমা দেওয়ার পর।</li><li>আগে দেননি এমন প্রশ্নকে অগ্রাধিকার; সহজ:মাঝারি:কঠিন ≈ ৩০:৪৫:২৫।</li></ul>' +
      '<button class="btn primary block" id="fs">▶ পরীক্ষা শুরু</button></section>';
    qs('#fs').onclick = function () {
      var picked = pickFinal(sid);
      var cfg = { preset: 'final', final: sid, title: 'Subject Final — ' + s.t, qids: picked.map(function (q) { return q.id; }), minutes: Math.round(picked.length * SEC_PER_Q / 60),
        neg: 0.25, fb: 'end', shuffle: true, noExp: true, pause: false };
      if (Store.get('test:active', null)) P.submitTest(true);
      P.startTest(cfg);
    };
  }
  /* Learning Quality Score (০–১০০) = ৬০% কঠিনতা-ভারযুক্ত নির্ভুলতা + ২০% অধ্যায়-কভারেজ + ২০% গতি */
  function finalStats(res) {
    var W = { 1: 1, 2: 2, 3: 3 }, num_ = 0, den = 0, byCh = {}, byL = {}, att = 0, time = 0;
    res.qids.forEach(function (id) {
      var q = QB.get(id); if (!q) return;
      var d = W[q.d || 2], a = res.ans[id], ok = a === q.a;
      den += d; if (a !== undefined) { att++; time += res.spent[id] || 0; num_ += ok ? d : -0.25 * d; }
      var c = byCh[q.cid] || (byCh[q.cid] = { c: 0, n: 0 }); c.n++; if (ok) c.c++;
      if (q.lid) { var l = byL[q.lid] || (byL[q.lid] = { c: 0, n: 0, w: 0 }); l.n++; if (ok) l.c++; else l.w++; }
    });
    var wAcc = den ? Math.max(0, num_ / den) : 0;
    var chs = Object.keys(byCh), good = chs.filter(function (k) { return byCh[k].c / byCh[k].n >= 0.6; }).length;
    var cov = chs.length ? good / chs.length : 0;
    var avg = att ? time / att : 0, speed = att ? Math.min(1, SEC_PER_Q / Math.max(1, avg)) : 0;
    return { wAcc: wAcc, cov: cov, speed: speed, avg: avg, lqs: Math.round(100 * (0.6 * wAcc + 0.2 * cov + 0.2 * speed)), acc: pct(res.c, res.qids.length), byCh: byCh, byL: byL };
  }
  function finalResultHTML(res) {
    var sid = res.cfg.final, s = SMAP[sid]; if (!s) return '';
    var f = finalStats(res), ms = QB.mastery(QB.forSubject(sid));
    var h = '<section class="card"><h2>🏁 Subject Final রিপোর্ট</h2><div class="grid2">' +
      '<div class="stat"><span class="small muted">Learning Quality Score</span><b>' + num(f.lqs) + '</b><span class="small muted">/১০০</span></div>' +
      '<div class="stat"><span class="small muted">বিষয়ের Mastery</span><b>' + (ms ? C.pct(ms.mastery) : '—') + '</b><span class="small muted">' + (ms ? num(ms.tried) + '/' + num(ms.total) + ' প্রশ্ন চেষ্টা করা' : '') + '</span></div></div>' +
      '<details class="small" style="margin-top:.5rem"><summary>LQS কীভাবে হিসাব হয়</summary><p>৬০% কঠিনতা-ভারযুক্ত নির্ভুলতা (সহজ ১, মাঝারি ২, কঠিন ৩ গুণ; ভুলে ০.২৫ গুণ কাটা) = ' + C.pct(f.wAcc * 100) + '<br>' +
      '২০% অধ্যায়-কভারেজ (≥৬০% সঠিক এমন অধ্যায়ের অনুপাত) = ' + C.pct(f.cov * 100) + '<br>' +
      '২০% গতি (লক্ষ্য প্রশ্নপ্রতি ' + num(SEC_PER_Q) + ' সে.; আপনার গড় ' + num(Math.round(f.avg)) + ' সে.) = ' + C.pct(f.speed * 100) + '<br>Mastery = যেসব প্রশ্নের শেষ উত্তর সঠিক / বিষয়ের মোট প্রশ্ন।</p></details>';
    // অধ্যায়ভিত্তিক
    var chs = Object.keys(f.byCh).filter(function (k) { return CMAP[k]; }).sort(function (a, b) { return f.byCh[a].c / f.byCh[a].n - f.byCh[b].c / f.byCh[b].n; });
    h += '<h3>অধ্যায়ভিত্তিক</h3><table class="data"><tr><th>অধ্যায়</th><th class="n">সঠিক</th><th class="n">%</th></tr>' + chs.map(function (k) {
      var x = f.byCh[k], p = pct(x.c, x.n);
      return '<tr' + (p < 60 && x.n >= 2 ? ' class="weak"' : '') + '><td>' + esc(CMAP[k].t) + '</td><td class="n">' + num(x.c) + '/' + num(x.n) + '</td><td class="n">' + C.pct(p) + (p < 60 && x.n >= 2 ? ' ⚠' : '') + '</td></tr>';
    }).join('') + '</table>';
    // রিভিশন প্ল্যান
    var weakL = Object.keys(f.byL).filter(function (l) { return LMAP[l] && f.byL[l].w > 0; }).sort(function (a, b) { return f.byL[b].w - f.byL[a].w || (f.byL[a].c / f.byL[a].n) - (f.byL[b].c / f.byL[b].n); });
    if (!weakL.length) h += '<p class="banner ok">দারুণ! কোনো পাঠে ভুল নেই। পরের ধাপ: অন্য বিষয়ের Final বা Mega Mock।</p>';
    else {
      var goal = Math.max(20, C.settings().goal || 60), days = [], cur = [], used = 0;
      weakL.forEach(function (l) { var m = LMAP[l].m || 15; if (cur.length && used + m > goal) { days.push(cur); cur = []; used = 0; } cur.push(l); used += m; });
      if (cur.length) days.push(cur);
      h += '<h3>দুর্বল টপিক ও রিভিশন প্ল্যান</h3><p class="small muted">ভুলের সংখ্যা অনুযায়ী সাজানো; আপনার দৈনিক লক্ষ্য ' + C.fmtMin(goal) + ' ধরে দিন ভাগ করা। প্রতিটি পাঠ: পড়ুন → পাঠের Quiz → Flashcard।</p>' +
        days.slice(0, 14).map(function (d, i) {
          return '<div class="plan-day"><b>দিন ' + num(i + 1) + '</b>' + d.map(function (l) {
            var L = LMAP[l];
            return '<div class="plan-item"><a href="#/l/' + l + '">' + esc(L.t) + '</a> <span class="small muted">(' + num(f.byL[l].w) + 'টি ভুল · ' + C.fmtMin(L.m) + ')</span>' +
              '<div class="small"><a href="#/quiz/l/' + l + '">❓ Quiz</a> · <a href="#/flash/review?lid=' + l + '">🃏 Flashcard</a></div></div>';
          }).join('') + '</div>';
        }).join('') + (days.length > 14 ? '<p class="small muted">… আরও ' + num(days.length - 14) + ' দিনের পাঠ — আগে এগুলো শেষ করুন, তারপর আবার Final দিন।</p>' : '') +
        '<div class="grid2" style="margin-top:.6rem"><a class="btn" href="#/mistakes?sub=' + sid + '">📕 এই বিষয়ের ভুলগুলো Retry</a><a class="btn primary" href="#/final/' + sid + '">🔁 আবার Final</a></div>';
    }
    return h + '</section>';
  }

  C.addRoute(/^#\/mega\/([\w-]+)/, function (m) { viewUnit(m[1]); }, 'practice');
  C.addRoute(/^#\/mega/, viewHub, 'practice');
  C.addRoute(/^#\/final\/([\w-]+)/, function (m) { viewFinalStart(m[1]); }, 'practice');
  C.addRoute(/^#\/final/, viewFinalHub, 'practice');

  window.Mega = { plan: plan, onWritten: onWritten, writtenNote: writtenNote, finalStats: finalStats, bumpBest: bumpBest };
})();
